/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.trend;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.util.IlandSerializedName;

/**
 * Web Reputation Event.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class WebReputationEvent implements Serializable {

  private static final long serialVersionUID = -40531457946596717L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(WebReputationEventField.VM_UUID)
  private String vmUuid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(WebReputationEventField.HOST_ID)
  private int hostId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(WebReputationEventField.HOST_NAME)
  private String hostName;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(WebReputationEventField.LOG_TIME)
  private Calendar logTime;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(WebReputationEventField.RANK)
  private int rank;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(WebReputationEventField.RISK)
  private String risk;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(WebReputationEventField.TAGS)
  private String tags;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(WebReputationEventField.URL)
  private String url;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(WebReputationEventField.EVENT_ID)
  private Long eventId;

  public WebReputationEvent() {
  }

  /**
   * Get the VM uuid.
   *
   * @return {@link String} vm uuid
   */
  public String getVmUuid() {
    return vmUuid;
  }

  /**
   * Set the VM uuid.
   *
   * @param vmUuid {@link String} vm uuid
   */
  public void setVmUuid(final String vmUuid) {
    this.vmUuid = vmUuid;
  }

  /**
   * Get the host ID.
   *
   * @return host id
   */
  public int getHostId() {
    return hostId;
  }

  /**
   * Set the host ID.
   *
   * @param hostId host id
   */
  public void setHostId(final int hostId) {
    this.hostId = hostId;
  }

  /**
   * Get the host name.
   *
   * @return {@link String} host name
   */
  public String getHostName() {
    return hostName;
  }

  /**
   * Set the host name.
   *
   * @param hostName {@link String} host name
   */
  public void setHostName(final String hostName) {
    this.hostName = hostName;
  }

  /**
   * Get the log time.
   *
   * @return {@link Calendar} log time
   */
  public Calendar getLogTime() {
    if (logTime == null) {
      final Calendar defaultDate = Calendar.getInstance();
      defaultDate.setTime(new Date(0));
      return defaultDate;
    }
    return logTime;
  }

  /**
   * Set the log time.
   *
   * @param logTime {@link Calendar} log time
   */
  public void setLogTime(final Calendar logTime) {
    this.logTime = logTime;
  }

  /**
   * Get the rank.
   *
   * @return rank
   */
  public int getRank() {
    return rank;
  }

  /**
   * Set the rank.
   *
   * @param rank rank
   */
  public void setRank(final int rank) {
    this.rank = rank;
  }

  /**
   * Get the risk.
   *
   * @return {@link String} risk
   */
  public String getRisk() {
    return risk;
  }

  /**
   * Set the risk.
   *
   * @param risk {@link String} risk
   */
  public void setRisk(final String risk) {
    this.risk = risk;
  }

  /**
   * Get the tags.
   *
   * @return {@link String} tags
   */
  public String getTags() {
    return tags;
  }

  /**
   * Set the tags.
   *
   * @param tags {@link String} tags
   */
  public void setTags(final String tags) {
    this.tags = tags;
  }

  /**
   * Get the URL.
   *
   * @return {@link String} url
   */
  public String getUrl() {
    return url;
  }

  /**
   * Set the URL.
   *
   * @param url {@link String} url
   */
  public void setUrl(final String url) {
    this.url = url;
  }

  /**
   * Get the event ID.
   *
   * @return event ID
   */
  public Long getEventId() {
    return eventId;
  }

  /**
   * Set the event Id.j
   *
   * @param eventId event id
   */
  public void setEventId(final Long eventId) {
    this.eventId = eventId;
  }

}
