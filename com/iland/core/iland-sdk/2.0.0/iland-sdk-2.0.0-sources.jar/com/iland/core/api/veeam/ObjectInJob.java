/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;

/**
 * ObjectInJob.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class ObjectInJob implements Serializable {

  private static final long serialVersionUID = 387391344879799109L;

  @XmlAttribute(name = "Type")
  private String type;

  @XmlAttribute(name = "Href")
  private String href;

  @XmlElement(name = "ObjectInJobId")
  private String objectInJobId;

  @XmlElement(name = "HierarchyObjRef")
  private String hierarchyObjRef;

  @XmlElement(name = "Name")
  private String name;

  @XmlElement(name = "DisplayName")
  private String displayName;

  @XmlElement(name = "Order")
  private long order;

  @XmlElement(name = "GuestProcessingOptions")
  private GuestProcessingOptions guestProcessingOptions;

  public ObjectInJob() {
  }

  public ObjectInJob(final String type, final String href,
      final String objectInJobId, final String hierarchyObjRef,
      final String name, final String displayName, final long order,
      final GuestProcessingOptions guestProcessingOptions) {
    this.type = type;
    this.href = href;
    this.objectInJobId = objectInJobId;
    this.hierarchyObjRef = hierarchyObjRef;
    this.name = name;
    this.displayName = displayName;
    this.order = order;
    this.guestProcessingOptions = guestProcessingOptions;
  }

  /**
   * Get the type.
   *
   * @return type
   */
  public String getType() {
    return type;
  }

  /**
   * Get the HREF.
   *
   * @return href
   */
  public String getHref() {
    return href;
  }

  /**
   * Get the object in job ID.
   *
   * @return object in job ID
   */
  public String getObjectInJobId() {
    return objectInJobId;
  }

  /**
   * Get the hierarchy object reference.
   *
   * @return hierarchy obj ref
   */
  public String getHierarchyObjRef() {
    return hierarchyObjRef;
  }

  /**
   * Get the name.
   *
   * @return name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the display name.
   *
   * @return display name
   */
  public String getDisplayName() {
    return displayName;
  }

  /**
   * Get the order.
   *
   * @return order
   */
  public long getOrder() {
    return order;
  }

  /**
   * Get the guest processing options.
   *
   * @return {@link GuestProcessingOptions} guest processing options
   */
  public GuestProcessingOptions getGuestProcessingOptions() {
    return guestProcessingOptions;
  }

}
