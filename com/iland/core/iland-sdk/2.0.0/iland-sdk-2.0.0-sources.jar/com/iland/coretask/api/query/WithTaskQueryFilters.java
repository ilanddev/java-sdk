/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.coretask.api.query;

import com.iland.common.query.entity.EntityFilters;
import com.iland.common.query.generation.GenerationFilters;
import com.iland.common.query.page.PagingOrder;
import com.iland.common.query.time.TimeFilters;
import com.iland.common.query.user.UserFilters;
import java.util.Optional;
import javax.annotation.ParametersAreNonnullByDefault;
import org.immutables.value.Generated;

@Generated(from = "TaskQueryFilters", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public interface WithTaskQueryFilters {

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#getEntityFilters() entityFilters} attribute.
   * @param value The value for entityFilters
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withEntityFilters(EntityFilters value);

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#getEntityFilters() entityFilters} attribute.
   * A shallow reference equality check on the optional value is used to prevent copying of the same value by returning {@code this}.
   * @param optional A value for entityFilters
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withEntityFilters(Optional<? extends EntityFilters> optional);

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#getTimeFilters() timeFilters} attribute.
   * @param value The value for timeFilters
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withTimeFilters(TimeFilters value);

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#getTimeFilters() timeFilters} attribute.
   * A shallow reference equality check on the optional value is used to prevent copying of the same value by returning {@code this}.
   * @param optional A value for timeFilters
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withTimeFilters(Optional<? extends TimeFilters> optional);

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#getGenerationFilters() generationFilters} attribute.
   * @param value The value for generationFilters
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withGenerationFilters(GenerationFilters value);

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#getGenerationFilters() generationFilters} attribute.
   * A shallow reference equality check on the optional value is used to prevent copying of the same value by returning {@code this}.
   * @param optional A value for generationFilters
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withGenerationFilters(Optional<? extends GenerationFilters> optional);

  /**
   * Copy the current immutable object by setting a value for the {@link TaskQueryFilters#getOffset() offset} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for offset
   * @return A modified copy of the {@code this} object
   */
  TaskQueryFilters withOffset(Long value);

  /**
   * Copy the current immutable object by setting a value for the {@link TaskQueryFilters#getLimit() limit} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for limit
   * @return A modified copy of the {@code this} object
   */
  TaskQueryFilters withLimit(Long value);

  /**
   * Copy the current immutable object by setting a value for the {@link TaskQueryFilters#getOrder() order} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for order
   * @return A modified copy of the {@code this} object
   */
  TaskQueryFilters withOrder(PagingOrder value);

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#getUserFilters() userFilters} attribute.
   * @param value The value for userFilters
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withUserFilters(UserFilters value);

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#getUserFilters() userFilters} attribute.
   * A shallow reference equality check on the optional value is used to prevent copying of the same value by returning {@code this}.
   * @param optional A value for userFilters
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withUserFilters(Optional<? extends UserFilters> optional);

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#isSynced() isSynced} attribute.
   * @param value The value for isSynced
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withIsSynced(boolean value);

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#isSynced() isSynced} attribute.
   * A shallow reference equality check on the optional value is used to prevent copying of the same value by returning {@code this}.
   * @param optional A value for isSynced
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withIsSynced(Optional<Boolean> optional);

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#getTaskOperation() taskOperation} attribute.
   * @param value The value for taskOperation
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withTaskOperation(String value);

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#getTaskOperation() taskOperation} attribute.
   * A shallow reference equality check on the optional value is used to prevent copying of the same value by returning {@code this}.
   * @param optional A value for taskOperation
   * @return A modified copy of {@code this} object
   */
  TaskQueryFilters withTaskOperation(Optional<String> optional);
}
