/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.coretask.api.query;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.iland.coretask.api.CoreTaskApi;
import com.iland.coretask.api.grpc.CoreTask;
import com.iland.coretask.api.grpc.GetCoreTaskRequest;

/**
 * API for querying {@link CoreTask}s using preset parameters.
 * For dynamic queries, see {@link CoreTaskDynamicQueryApi}.
 */
public interface CoreTaskQueryApi {
  /**
   * Gets a core task, returns {@link Optional#empty()} if it can't be found.
   *
   * @param task {@link GetCoreTaskRequest} the request
   * @return {@link CoreTask} the core task
   */
  Optional<CoreTask> getCoreTask(GetCoreTaskRequest task);

  /**
   * Gets a core task by its location and uuid.
   *
   * @param locationId {@link String} the location id
   * @param uuid       {@link String} the uuid
   * @return {@link CoreTask} the core task
   * @deprecated use {@link CoreTaskApi#getCoreTask(GetCoreTaskRequest)} instead
   */
  @Deprecated
  Optional<CoreTask> getCoreTask(final String locationId, final String uuid);

  /**
   * Gets a core task by its native id, returns {@link Optional#empty()} if it can't be found.
   *
   * @param locationId {@link String} the location id
   * @param taskType   {@link String} the task type
   * @param taskId     {@link String} the task id
   * @return {@link CoreTask} the core task
   * @apiNote The taskId is not the same as the task uuid. In some scenarios, multiple
   * locations create/update a task with the same task id.
   * See {@link CoreTaskQueryApi#getTaskUuidsFromNativeId(String)}.
   */
  Optional<CoreTask> getCoreTaskByNativeId(String locationId, String taskType,
      String taskId);

  /**
   * Gets the un-synchronized tasks associated with a specified entity.
   *
   * @param entityUuid {@link String} the entity uuid
   * @return {@link List} of {@link CoreTask} the un-synchronized tasks
   */
  List<CoreTask> getUnsynchronizedTasks(String entityUuid);

  /**
   * Gets the UUIDs of a task from its native ID.
   *
   * @param taskId {@link String} the native task ID.
   * @return {@link Map} from location ID to the UUID of the task
   * @apiNote This should only be used in specific scenarios, such as a Zerto
   * cloud-to-cloud failover where multiple locations create/update a task with
   * the same task id.
   */
  Map<String, String> getTaskUuidsFromNativeId(String taskId);

  /**
   * Gets the tasks that are associated with a specified entity.
   *
   * @param entityUuid {@link String} the entity uuid
   * @param offset     the integer offset
   * @param limit      the integer limit
   * @return {@link List} of {@link CoreTask} the tasks for entity
   */
  List<CoreTask> getTasksForEntity(String entityUuid, int offset, int limit);

  /**
   * Gets the un-synchronized tasks in a specified organization.
   *
   * @param orgUuid {@link String} the org uuid
   * @return {@link List} of {@link CoreTask} the un-synchronized tasks in org
   */
  List<CoreTask> getUnsynchronizedTasksInOrg(String orgUuid);


  /**
   * Gets the un-synchronized tasks for a particular location.
   *
   * @param locationId {@link String} the location id
   * @param allowCache boolean whether to allow using data from cache
   * @return {@link List} of {@link CoreTask} the un-synchronized tasks for
   * location
   */
  List<CoreTask> getUnsynchronizedTasksForLocation(String locationId, boolean allowCache);


  /**
   * Gets paged list of synchronized tasks for a specified organization.
   *
   * @param orgUuid {@link String} the organization uuid
   * @param offset  integer paging offset
   * @param limit   integer paging limit
   * @return {@link List} of {@link CoreTask}
   */
  List<CoreTask> getSynchronizedTasksInOrg(String orgUuid, int offset, int limit);

  /**
   * Gets top-level continuity tasks for an organization.
   *
   * @param orgUuid {@link String} the organization UUID
   * @param offset  integer paging offset
   * @param limit   integer paging limit
   * @return {@link List} of {@link CoreTask}
   */
  List<CoreTask> getContinuityTasksForOrg(String orgUuid, int offset, int limit);
}
