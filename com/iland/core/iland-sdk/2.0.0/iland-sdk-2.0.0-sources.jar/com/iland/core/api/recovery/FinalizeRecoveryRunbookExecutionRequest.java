/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.recovery;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.api.serialization.JsonRequired;

/**
 * FinalizeRecoveryRunbookExectionRequest.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class FinalizeRecoveryRunbookExecutionRequest implements Serializable {

  private static final long serialVersionUID = 8952928080559499391L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @JsonRequired("parent runbook execution task uuid")
  private String parentRunbookTaskUuid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @JsonRequired("parameters for ending a live recovery runbook execution")
  private Map<String, FinalizeRecoveryGroupOption> finalizeRecoveryParams;

  public FinalizeRecoveryRunbookExecutionRequest(
      final String parentRunbookTaskUuid,
      final Map<String, FinalizeRecoveryGroupOption> finalizeRecoveryParams) {
    this.parentRunbookTaskUuid = parentRunbookTaskUuid;
    this.finalizeRecoveryParams = finalizeRecoveryParams;
  }

  /**
   * Get the parent runbook task UUID.
   *
   * @return {@link String} parent runbook task UUID
   */
  public String getParentRunbookTaskUuid() {
    return parentRunbookTaskUuid;
  }

  /**
   * Get the map of parameters for finalizing a live recovery runbook live
   * execution.
   *
   * @return {@link Map} of {@link String} to
   * {@link FinalizeRecoveryGroupOption} per recovery group options for
   * finalizing recovery execution
   */
  public Map<String, FinalizeRecoveryGroupOption> getFinalizeRecoveryParams() {
    return finalizeRecoveryParams;
  }

  /**
   * Validate that the specification is valid for the given runbook.
   *
   * @throws IllegalArgumentException if the specification leaves out a finalize
   *                                  operation for any recovery group in the runbook.
   */
  public void validateSpecification(
      @Nonnull final DisasterRecoveryRunbook runbook)
      throws IllegalArgumentException {
    if (finalizeRecoveryParams == null) {
      throw new IllegalArgumentException(
          "Must provide failover recovery params.");
    }
    if (parentRunbookTaskUuid == null) {
      throw new IllegalArgumentException(
          "Must provide a valid parent runbook task UUID.");
    }
    final List<RecoveryGroupDescriptor> rgdList =
        runbook.getRecoveryGroupList();
    // make sure they are not passing tons of arbitrary params that are outside
    // the scope of what this does
    if (rgdList.size() < finalizeRecoveryParams.size()) {
      throw new IllegalArgumentException(
          "Params provided to finalize runbook exeuction were not valid. You must provide one and only one finalization option for each recovery group.");
    }
    // make sure they provide one option for each recovery group
    for (final RecoveryGroupDescriptor rgd : rgdList) {
      if (!finalizeRecoveryParams.containsKey(rgd.getUuid())) {
        throw new IllegalArgumentException(String
            .format("Must provide a finalization option for recovery group=%s",
                rgd.getUuid()));
      }
    }
  }

}
