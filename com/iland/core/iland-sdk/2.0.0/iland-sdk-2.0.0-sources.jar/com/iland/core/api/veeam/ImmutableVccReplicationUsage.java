/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import com.google.common.base.MoreObjects;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import javax.annotation.concurrent.NotThreadSafe;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link VccReplicationUsage}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableVccReplicationUsage.builder()}.
 */
@Generated(from = "VccReplicationUsage", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableVccReplicationUsage implements VccReplicationUsage {
  private final String location_id;
  private final String vdc_id;
  private final Long storage;

  private ImmutableVccReplicationUsage(String location_id, String vdc_id, Long storage) {
    this.location_id = location_id;
    this.vdc_id = vdc_id;
    this.storage = storage;
  }

  /**
   * Specifies location id
   */
  @Override
  public String location_id() {
    return location_id;
  }

  /**
   * Vdc uuid
   */
  @Override
  public String vdc_id() {
    return vdc_id;
  }

  /**
   * Amount of space consumed by company replicas, in bytes.
   */
  @Override
  public Long storage() {
    return storage;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link VccReplicationUsage#location_id() location_id} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for location_id
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableVccReplicationUsage withLocation_id(String value) {
    String newValue = Objects.requireNonNull(value, "location_id");
    if (this.location_id.equals(newValue)) return this;
    return new ImmutableVccReplicationUsage(newValue, this.vdc_id, this.storage);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link VccReplicationUsage#vdc_id() vdc_id} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for vdc_id
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableVccReplicationUsage withVdc_id(String value) {
    String newValue = Objects.requireNonNull(value, "vdc_id");
    if (this.vdc_id.equals(newValue)) return this;
    return new ImmutableVccReplicationUsage(this.location_id, newValue, this.storage);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link VccReplicationUsage#storage() storage} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for storage
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableVccReplicationUsage withStorage(Long value) {
    Long newValue = Objects.requireNonNull(value, "storage");
    if (this.storage.equals(newValue)) return this;
    return new ImmutableVccReplicationUsage(this.location_id, this.vdc_id, newValue);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableVccReplicationUsage} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableVccReplicationUsage
        && equalTo((ImmutableVccReplicationUsage) another);
  }

  private boolean equalTo(ImmutableVccReplicationUsage another) {
    return location_id.equals(another.location_id)
        && vdc_id.equals(another.vdc_id)
        && storage.equals(another.storage);
  }

  /**
   * Computes a hash code from attributes: {@code location_id}, {@code vdc_id}, {@code storage}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + location_id.hashCode();
    h += (h << 5) + vdc_id.hashCode();
    h += (h << 5) + storage.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code VccReplicationUsage} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("VccReplicationUsage")
        .omitNullValues()
        .add("location_id", location_id)
        .add("vdc_id", vdc_id)
        .add("storage", storage)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link VccReplicationUsage} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable VccReplicationUsage instance
   */
  public static ImmutableVccReplicationUsage copyOf(VccReplicationUsage instance) {
    if (instance instanceof ImmutableVccReplicationUsage) {
      return (ImmutableVccReplicationUsage) instance;
    }
    return ImmutableVccReplicationUsage.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableVccReplicationUsage ImmutableVccReplicationUsage}.
   * <pre>
   * ImmutableVccReplicationUsage.builder()
   *    .location_id(String) // required {@link VccReplicationUsage#location_id() location_id}
   *    .vdc_id(String) // required {@link VccReplicationUsage#vdc_id() vdc_id}
   *    .storage(Long) // required {@link VccReplicationUsage#storage() storage}
   *    .build();
   * </pre>
   * @return A new ImmutableVccReplicationUsage builder
   */
  public static ImmutableVccReplicationUsage.Builder builder() {
    return new ImmutableVccReplicationUsage.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableVccReplicationUsage ImmutableVccReplicationUsage}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "VccReplicationUsage", generator = "Immutables")
  @NotThreadSafe
  public static final class Builder {
    private static final long INIT_BIT_LOCATION_ID = 0x1L;
    private static final long INIT_BIT_VDC_ID = 0x2L;
    private static final long INIT_BIT_STORAGE = 0x4L;
    private long initBits = 0x7L;

    private @Nullable String location_id;
    private @Nullable String vdc_id;
    private @Nullable Long storage;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code VccReplicationUsage} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(VccReplicationUsage instance) {
      Objects.requireNonNull(instance, "instance");
      location_id(instance.location_id());
      vdc_id(instance.vdc_id());
      storage(instance.storage());
      return this;
    }

    /**
     * Initializes the value for the {@link VccReplicationUsage#location_id() location_id} attribute.
     * @param location_id The value for location_id 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder location_id(String location_id) {
      this.location_id = Objects.requireNonNull(location_id, "location_id");
      initBits &= ~INIT_BIT_LOCATION_ID;
      return this;
    }

    /**
     * Initializes the value for the {@link VccReplicationUsage#vdc_id() vdc_id} attribute.
     * @param vdc_id The value for vdc_id 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder vdc_id(String vdc_id) {
      this.vdc_id = Objects.requireNonNull(vdc_id, "vdc_id");
      initBits &= ~INIT_BIT_VDC_ID;
      return this;
    }

    /**
     * Initializes the value for the {@link VccReplicationUsage#storage() storage} attribute.
     * @param storage The value for storage 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder storage(Long storage) {
      this.storage = Objects.requireNonNull(storage, "storage");
      initBits &= ~INIT_BIT_STORAGE;
      return this;
    }

    /**
     * Builds a new {@link ImmutableVccReplicationUsage ImmutableVccReplicationUsage}.
     * @return An immutable instance of VccReplicationUsage
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableVccReplicationUsage build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableVccReplicationUsage(location_id, vdc_id, storage);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_LOCATION_ID) != 0) attributes.add("location_id");
      if ((initBits & INIT_BIT_VDC_ID) != 0) attributes.add("vdc_id");
      if ((initBits & INIT_BIT_STORAGE) != 0) attributes.add("storage");
      return "Cannot build VccReplicationUsage, some of required attributes are not set " + attributes;
    }
  }
}
