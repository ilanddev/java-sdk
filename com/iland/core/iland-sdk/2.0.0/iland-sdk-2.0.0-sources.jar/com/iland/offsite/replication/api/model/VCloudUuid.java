/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import static java.util.Objects.requireNonNull;

import java.util.Objects;
import java.util.UUID;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * {@link VCloudUuid VCloud UUID}.
 */
public class VCloudUuid {

	protected static final String URN_PREFIX = "urn:vcloud";

	private static final Pattern PATTERN;

	static {
		final String uuidRegex =
			"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
		final String regex =
			"([0-9a-z\\-\\.]+):%s:(\\w+):(%s)".formatted(URN_PREFIX, uuidRegex);
		PATTERN = Pattern.compile(regex);
	}

	private final LocationId locationId;

	private final IlandEntityPrefix entityPrefix;

	private final UUID uuid;

	static <V extends VCloudUuid> V of(final String value,
		final Predicate<IlandEntityPrefix> entityPrefixPredicate,
		final BiFunction<LocationId, UUID, V> factory) {
		if (!value.contains(URN_PREFIX)) {
			throw new IllegalArgumentException(
				"%s is not a valid vcloud UUID".formatted(value));
		}

		final Matcher matcher = PATTERN.matcher(value);
		if (matcher.matches()) {
			final String prefix = matcher.group(2);
			final IlandEntityPrefix entityPrefix1 =
				IlandEntityPrefix.from(prefix);
			if (!entityPrefixPredicate.test(entityPrefix1)) {
				throw new IllegalArgumentException(
					"%s is not a valid vcloud UUID".formatted(value));
			}

			final String locationId = matcher.group(1);
			final String uuid = matcher.group(3);

			return factory.apply(LocationId.of(locationId),
				UUID.fromString(uuid));
		}

		throw new IllegalArgumentException(
			"%s is not a valid vcloud UUID".formatted(value));
	}

	protected VCloudUuid(final LocationId locationId,
		final IlandEntityPrefix entityPrefix, final UUID uuid) {
		this.locationId =
			requireNonNull(locationId, "location ID must not be null");
		this.entityPrefix =
			requireNonNull(entityPrefix, "entity prefix must not be null");
		this.uuid = requireNonNull(uuid, "uuid must not be null");
	}

	public LocationId locationId() {
		return this.locationId;
	}

	public IlandEntityPrefix entityPrefix() {
		return this.entityPrefix;
	}

	public UUID uuid() {
		return this.uuid;
	}

	@Override
	public String toString() {
		return "%s:%s:%s:%s".formatted(locationId(), URN_PREFIX, entityPrefix(),
			uuid());
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o)
			return true;
		if (!(o instanceof final VCloudUuid that))
			return false;
		return Objects.equals(locationId, that.locationId)
			&& entityPrefix == that.entityPrefix && Objects.equals(uuid,
			that.uuid);
	}

	@Override
	public int hashCode() {
		return Objects.hash(locationId, entityPrefix, uuid);
	}

}
