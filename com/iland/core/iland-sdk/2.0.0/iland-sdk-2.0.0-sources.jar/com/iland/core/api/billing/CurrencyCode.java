/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import com.google.gson.annotations.Expose;

/**
 * Platform supported currencies.
 *
 * @author <a href='mailto:janguenot@iland.com'>Julien Anguenot</a>
 */
public enum CurrencyCode {

  AUD("AUD", "A$"),

  // US Dollar
  USD("USD", "$"),

  // Singapore Dollar
  SGD("SGD", "S$"),

  // Canadian Dollar
  CAD("CAD", "CA$"),

  // EURO
  EUR("EUR", "\u20AC"),

  // British Pound
  GBP("GBP", "\u00A3"),

  INR("INR", "\u020B9");

  @Expose
  private final String value;

  @Expose
  private final String symbol;

  CurrencyCode(final String value, final String symbol) {
    this.value = value;
    this.symbol = symbol;
  }

  /**
   * Get the value.
   *
   * @return {@link String} value
   */
  public String getValue() {
    return value;
  }

  /**
   * Get the currency symbol.
   *
   * @return {@link String} symbol
   */
  public String getSymbol() {
    return symbol;
  }

  @Override
  public String toString() {
    return getValue();
  }

}
