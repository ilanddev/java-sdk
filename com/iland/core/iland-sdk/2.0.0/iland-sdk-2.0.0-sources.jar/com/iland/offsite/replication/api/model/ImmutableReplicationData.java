/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import com.google.common.base.MoreObjects;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link ReplicationData}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableReplicationData.builder()}.
 */
@Generated(from = "ReplicationData", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableReplicationData implements ReplicationData {
  private final Long dataInBytes;
  private final Long dataInBytesAfterDeduplication;
  private final Long consumedStorage;
  private final Long contractedStorage;
  private final RunStats runStats;

  private ImmutableReplicationData(
      Long dataInBytes,
      Long dataInBytesAfterDeduplication,
      Long consumedStorage,
      Long contractedStorage,
      RunStats runStats) {
    this.dataInBytes = dataInBytes;
    this.dataInBytesAfterDeduplication = dataInBytesAfterDeduplication;
    this.consumedStorage = consumedStorage;
    this.contractedStorage = contractedStorage;
    this.runStats = runStats;
  }

  /**
   * @return The value of the {@code dataInBytes} attribute
   */
  @Override
  public Long dataInBytes() {
    return dataInBytes;
  }

  /**
   * @return The value of the {@code dataInBytesAfterDeduplication} attribute
   */
  @Override
  public Long dataInBytesAfterDeduplication() {
    return dataInBytesAfterDeduplication;
  }

  /**
   * @return The value of the {@code consumedStorage} attribute
   */
  @Override
  public Long consumedStorage() {
    return consumedStorage;
  }

  /**
   * @return The value of the {@code contractedStorage} attribute
   */
  @Override
  public Long contractedStorage() {
    return contractedStorage;
  }

  /**
   * @return The value of the {@code runStats} attribute
   */
  @Override
  public RunStats runStats() {
    return runStats;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ReplicationData#dataInBytes() dataInBytes} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for dataInBytes
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableReplicationData withDataInBytes(Long value) {
    Long newValue = Objects.requireNonNull(value, "dataInBytes");
    if (this.dataInBytes.equals(newValue)) return this;
    return new ImmutableReplicationData(
        newValue,
        this.dataInBytesAfterDeduplication,
        this.consumedStorage,
        this.contractedStorage,
        this.runStats);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ReplicationData#dataInBytesAfterDeduplication() dataInBytesAfterDeduplication} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for dataInBytesAfterDeduplication
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableReplicationData withDataInBytesAfterDeduplication(Long value) {
    Long newValue = Objects.requireNonNull(value, "dataInBytesAfterDeduplication");
    if (this.dataInBytesAfterDeduplication.equals(newValue)) return this;
    return new ImmutableReplicationData(this.dataInBytes, newValue, this.consumedStorage, this.contractedStorage, this.runStats);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ReplicationData#consumedStorage() consumedStorage} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for consumedStorage
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableReplicationData withConsumedStorage(Long value) {
    Long newValue = Objects.requireNonNull(value, "consumedStorage");
    if (this.consumedStorage.equals(newValue)) return this;
    return new ImmutableReplicationData(
        this.dataInBytes,
        this.dataInBytesAfterDeduplication,
        newValue,
        this.contractedStorage,
        this.runStats);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ReplicationData#contractedStorage() contractedStorage} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for contractedStorage
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableReplicationData withContractedStorage(Long value) {
    Long newValue = Objects.requireNonNull(value, "contractedStorage");
    if (this.contractedStorage.equals(newValue)) return this;
    return new ImmutableReplicationData(
        this.dataInBytes,
        this.dataInBytesAfterDeduplication,
        this.consumedStorage,
        newValue,
        this.runStats);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ReplicationData#runStats() runStats} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for runStats
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableReplicationData withRunStats(RunStats value) {
    if (this.runStats == value) return this;
    RunStats newValue = Objects.requireNonNull(value, "runStats");
    return new ImmutableReplicationData(
        this.dataInBytes,
        this.dataInBytesAfterDeduplication,
        this.consumedStorage,
        this.contractedStorage,
        newValue);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableReplicationData} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableReplicationData
        && equalsByValue((ImmutableReplicationData) another);
  }

  private boolean equalsByValue(ImmutableReplicationData another) {
    return dataInBytes.equals(another.dataInBytes)
        && dataInBytesAfterDeduplication.equals(another.dataInBytesAfterDeduplication)
        && consumedStorage.equals(another.consumedStorage)
        && contractedStorage.equals(another.contractedStorage)
        && runStats.equals(another.runStats);
  }

  /**
   * Computes a hash code from attributes: {@code dataInBytes}, {@code dataInBytesAfterDeduplication}, {@code consumedStorage}, {@code contractedStorage}, {@code runStats}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + dataInBytes.hashCode();
    h += (h << 5) + dataInBytesAfterDeduplication.hashCode();
    h += (h << 5) + consumedStorage.hashCode();
    h += (h << 5) + contractedStorage.hashCode();
    h += (h << 5) + runStats.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code ReplicationData} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("ReplicationData")
        .omitNullValues()
        .add("dataInBytes", dataInBytes)
        .add("dataInBytesAfterDeduplication", dataInBytesAfterDeduplication)
        .add("consumedStorage", consumedStorage)
        .add("contractedStorage", contractedStorage)
        .add("runStats", runStats)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link ReplicationData} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ReplicationData instance
   */
  public static ImmutableReplicationData copyOf(ReplicationData instance) {
    if (instance instanceof ImmutableReplicationData) {
      return (ImmutableReplicationData) instance;
    }
    return ImmutableReplicationData.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableReplicationData ImmutableReplicationData}.
   * <pre>
   * ImmutableReplicationData.builder()
   *    .dataInBytes(Long) // required {@link ReplicationData#dataInBytes() dataInBytes}
   *    .dataInBytesAfterDeduplication(Long) // required {@link ReplicationData#dataInBytesAfterDeduplication() dataInBytesAfterDeduplication}
   *    .consumedStorage(Long) // required {@link ReplicationData#consumedStorage() consumedStorage}
   *    .contractedStorage(Long) // required {@link ReplicationData#contractedStorage() contractedStorage}
   *    .runStats(com.iland.offsite.replication.api.model.RunStats) // required {@link ReplicationData#runStats() runStats}
   *    .build();
   * </pre>
   * @return A new ImmutableReplicationData builder
   */
  public static ImmutableReplicationData.Builder builder() {
    return new ImmutableReplicationData.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableReplicationData ImmutableReplicationData}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "ReplicationData", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_DATA_IN_BYTES = 0x1L;
    private static final long INIT_BIT_DATA_IN_BYTES_AFTER_DEDUPLICATION = 0x2L;
    private static final long INIT_BIT_CONSUMED_STORAGE = 0x4L;
    private static final long INIT_BIT_CONTRACTED_STORAGE = 0x8L;
    private static final long INIT_BIT_RUN_STATS = 0x10L;
    private long initBits = 0x1fL;

    private @Nullable Long dataInBytes;
    private @Nullable Long dataInBytesAfterDeduplication;
    private @Nullable Long consumedStorage;
    private @Nullable Long contractedStorage;
    private @Nullable RunStats runStats;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code ReplicationData} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(ReplicationData instance) {
      Objects.requireNonNull(instance, "instance");
      this.dataInBytes(instance.dataInBytes());
      this.dataInBytesAfterDeduplication(instance.dataInBytesAfterDeduplication());
      this.consumedStorage(instance.consumedStorage());
      this.contractedStorage(instance.contractedStorage());
      this.runStats(instance.runStats());
      return this;
    }

    /**
     * Initializes the value for the {@link ReplicationData#dataInBytes() dataInBytes} attribute.
     * @param dataInBytes The value for dataInBytes 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder dataInBytes(Long dataInBytes) {
      this.dataInBytes = Objects.requireNonNull(dataInBytes, "dataInBytes");
      initBits &= ~INIT_BIT_DATA_IN_BYTES;
      return this;
    }

    /**
     * Initializes the value for the {@link ReplicationData#dataInBytesAfterDeduplication() dataInBytesAfterDeduplication} attribute.
     * @param dataInBytesAfterDeduplication The value for dataInBytesAfterDeduplication 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder dataInBytesAfterDeduplication(Long dataInBytesAfterDeduplication) {
      this.dataInBytesAfterDeduplication = Objects.requireNonNull(dataInBytesAfterDeduplication, "dataInBytesAfterDeduplication");
      initBits &= ~INIT_BIT_DATA_IN_BYTES_AFTER_DEDUPLICATION;
      return this;
    }

    /**
     * Initializes the value for the {@link ReplicationData#consumedStorage() consumedStorage} attribute.
     * @param consumedStorage The value for consumedStorage 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder consumedStorage(Long consumedStorage) {
      this.consumedStorage = Objects.requireNonNull(consumedStorage, "consumedStorage");
      initBits &= ~INIT_BIT_CONSUMED_STORAGE;
      return this;
    }

    /**
     * Initializes the value for the {@link ReplicationData#contractedStorage() contractedStorage} attribute.
     * @param contractedStorage The value for contractedStorage 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder contractedStorage(Long contractedStorage) {
      this.contractedStorage = Objects.requireNonNull(contractedStorage, "contractedStorage");
      initBits &= ~INIT_BIT_CONTRACTED_STORAGE;
      return this;
    }

    /**
     * Initializes the value for the {@link ReplicationData#runStats() runStats} attribute.
     * @param runStats The value for runStats 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder runStats(RunStats runStats) {
      this.runStats = Objects.requireNonNull(runStats, "runStats");
      initBits &= ~INIT_BIT_RUN_STATS;
      return this;
    }

    /**
     * Builds a new {@link ImmutableReplicationData ImmutableReplicationData}.
     * @return An immutable instance of ReplicationData
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableReplicationData build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableReplicationData(dataInBytes, dataInBytesAfterDeduplication, consumedStorage, contractedStorage, runStats);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_DATA_IN_BYTES) != 0) attributes.add("dataInBytes");
      if ((initBits & INIT_BIT_DATA_IN_BYTES_AFTER_DEDUPLICATION) != 0) attributes.add("dataInBytesAfterDeduplication");
      if ((initBits & INIT_BIT_CONSUMED_STORAGE) != 0) attributes.add("consumedStorage");
      if ((initBits & INIT_BIT_CONTRACTED_STORAGE) != 0) attributes.add("contractedStorage");
      if ((initBits & INIT_BIT_RUN_STATS) != 0) attributes.add("runStats");
      return "Cannot build ReplicationData, some of required attributes are not set " + attributes;
    }
  }
}
