/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import java.io.Serializable;
import java.util.Date;

import com.iland.core.api.zerto.Vpg;
import com.iland.core.api.zerto.ZertoVpg;

/**
 * Zerto Rpo Alert.
 * <p>
 * Holds info necessary to determine an alert on a zerto actual RPO value
 * against a target RPO of the of the VPG.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class ZertoRpoAlert implements Serializable, Comparable<ZertoRpoAlert> {

  private static final long serialVersionUID = -3886028895087122991L;

  private Vpg vpg;

  private long actualRpo;

  private Date time;

  public ZertoRpoAlert(final Vpg vpg, final long actualRpo, final Date time) {
    this.vpg = vpg;
    this.actualRpo = actualRpo;
    this.time = time;
  }

  /**
   * Get the VPG related to the alert.
   *
   * @return {@link ZertoVpg} instance
   */
  public Vpg getVpg() {
    return vpg;
  }

  /**
   * Get the actual rpo observed.
   *
   * @return actual rpo
   */
  public long getActualRpo() {
    return actualRpo;
  }

  /**
   * Get the alert timestamp.
   *
   * @return {@link Date} instance
   */
  public Date getTime() {
    return time;
  }

  @Override
  public int compareTo(final ZertoRpoAlert o) {
    // Sort alerts in descending order based on time
    return (int) (o.getTime().getTime() - time.getTime());
  }

}
