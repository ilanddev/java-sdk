/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import static java.util.Objects.requireNonNull;

import java.math.BigDecimal;
import java.util.Optional;

import com.google.common.base.MoreObjects;

import com.iland.cohesity.helios.sdk.v2.model.ClusterConnectionStatus;
import com.iland.cohesity.helios.sdk.v2.model.HeliosClusterTenant;

/**
 * Default implementation of {@link ClusterUid}.
 */
public record SimpleClusterUid(Long clusterId, Long clusterIncarnationId)
	implements ClusterUid {

	public static ClusterUid of(final ClusterConnectionStatus status) {
		final Long clusterId = Optional.of(status)
			.map(ClusterConnectionStatus::getClusterId)
			.map(BigDecimal::longValue)
			.orElseThrow(() -> new IllegalArgumentException(
				"invalid cluster ID " + status.getClusterId()));
		final Long clusterIncarnationId = Optional.of(status)
			.map(ClusterConnectionStatus::getClusterIncarnationId)
			.map(BigDecimal::longValue)
			.orElseThrow(() -> new IllegalArgumentException(
				"invalid cluster Incarnation ID "
					+ status.getClusterIncarnationId()));

		return new SimpleClusterUid(clusterId, clusterIncarnationId);
	}

	public static ClusterUid of(final HeliosClusterTenant tenant) {
		final Long clusterId = Optional.of(tenant)
			.map(HeliosClusterTenant::getClusterId)
			.orElseThrow(() -> new IllegalArgumentException(
				"invalid cluster ID " + tenant.getClusterId()));
		final Long clusterIncarnationId = Optional.of(tenant)
			.map(HeliosClusterTenant::getClusterIncarnationId)
			.orElseThrow(() -> new IllegalArgumentException(
				"invalid cluster Incarnation ID "
					+ tenant.getClusterIncarnationId()));

		return new SimpleClusterUid(clusterId, clusterIncarnationId);
	}

	public static ClusterUid of(final ClusterUid uid) {
		return new SimpleClusterUid(uid.clusterId(),
			uid.clusterIncarnationId());
	}

	public SimpleClusterUid(final Long clusterId,
		final Long clusterIncarnationId) {
		this.clusterId =
			requireNonNull(clusterId, "cluster ID must not be null");
		this.clusterIncarnationId = requireNonNull(clusterIncarnationId,
			"cluster incarnation ID must not be null");
	}

	@Override
	public boolean equals(final Object o) {
		if (!(o instanceof final ClusterUid that))
			return false;

		return clusterId.equals(that.clusterId())
			&& clusterIncarnationId.equals(that.clusterIncarnationId());
	}

	@Override
	public String toString() {
		return MoreObjects.toStringHelper(this)
			.add("clusterId", clusterId)
			.add("clusterIncarnationId", clusterIncarnationId)
			.toString();
	}

}
