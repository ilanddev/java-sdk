/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.recovery;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * VmBootupLog.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class VmBootupLog implements Serializable {

  private static final long serialVersionUID = 8102255625646396884L;

  public static final String VM_UUID = "vm_uuid";

  public static final String VM_NAME = "vm_name";

  public static final String SCREENSHOT = "screenshot";

  public static final String TIMESTAMP = "timestamp";

  public static final String IP_ADDRESS = "ip_address";

  public static final String ERROR_LOG = "error_log";

  @Expose
  @SerializedName(VM_UUID)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String vmUuid;

  @Expose
  @SerializedName(VM_NAME)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String vmName;

  @Expose
  @SerializedName(SCREENSHOT)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private byte[] screenshot;

  @Expose
  @SerializedName(TIMESTAMP)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private Instant timestamp;

  @Expose
  @SerializedName(IP_ADDRESS)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String ipAddress;

  @Expose
  @SerializedName(ERROR_LOG)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String errorLog;

  public VmBootupLog(final String vmUuid, final String vmName,
      final byte[] screenshot, final Instant timestamp, final String ipAddress,
      final String errorLog) {
    this.vmUuid = vmUuid;
    this.vmName = vmName;
    this.screenshot = screenshot;
    this.timestamp = timestamp;
    this.ipAddress = ipAddress;
    this.errorLog = errorLog;
  }

  /**
   * Get the VM UUID.
   *
   * @return {@link String} VM UUID
   */
  public String getVmUuid() {
    return vmUuid;
  }

  /**
   * Get the VM name.
   *
   * @return {@link String} VM name
   */
  public String getVmName() {
    return vmName;
  }

  /**
   * Get the VM console screenshot.
   *
   * @return screenshot of VM console
   */
  public byte[] getScreenshot() {
    return screenshot;
  }

  /**
   * Get the timestamp the log was created.
   *
   * @return {@link Instant} log timestamp
   */
  public Instant getTimestamp() {
    return timestamp;
  }

  /**
   * Get the VM IP address.
   *
   * @return {@link String} IP address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Get the VM error log.
   *
   * @return {@link String} error log
   */
  public String getErrorLog() {
    return errorLog;
  }

}
