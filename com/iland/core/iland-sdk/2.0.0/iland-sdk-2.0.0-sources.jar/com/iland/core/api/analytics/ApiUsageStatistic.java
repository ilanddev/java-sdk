/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.analytics;

import java.io.Serializable;

/**
 * API Usage Statistic.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class ApiUsageStatistic implements Serializable {

  private static final long serialVersionUID = 320037880649046168L;

  public static final String YEAR = "year";

  public static final String MONTH = "month";

  public static final String DAY = "day";

  public static final String USER = "user";

  public static final String LOCATION_ID = "location_id";

  public static final String ENDPOINT = "endpoint";

  public static final String VERSION = "version";

  public static final String REQUEST_COUNT = "request_count";

  private String username;

  private String locationId;

  private double requestVersion;

  private String endpoint;

  public ApiUsageStatistic(final String username, final String locationId,
      final double requestVersion, final String endpoint) {
    this.username = username;
    this.locationId = locationId;
    this.requestVersion = requestVersion;
    this.endpoint = endpoint;
  }

  /**
   * Get the username of user who initiated the API request.
   *
   * @return {@link String} username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Get the location ID that handled the request.
   *
   * @return {@link String} location ID
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Get the API version used for the request.
   *
   * @return API version
   */
  public double getRequestVersion() {
    return requestVersion;
  }

  /**
   * Get the API endpoint that was invoked.
   *
   * @return {@link String} API endpoint
   */
  public String getEndpoint() {
    return endpoint;
  }

}
