/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vac;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import com.iland.core.api.entity.AbstractEntity;
import com.iland.core.api.entity.Entity;
import com.iland.core.model.EntityType;

/**
 * Backup Repository.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public final class BaBackupRepository extends AbstractEntity implements Serializable {

  private static final long serialVersionUID = -7122878156423128475L;

  /**
   * The constant URN_BACKUP_REPO.
   */
  public static final String URN_BACKUP_REPO = "urn:vac:backuprepo";

  private final String id;

  private final String repositoryUid;

  private final String serverName;

  private final String companyName;

  private final String locationName;

  private final double capacity;

  private final double freeSpace;

  private final double backupSize;

  private final String healthState;

  private final int backupServerId;

  private final boolean isServiceProviderRepository;

  private final double committedStoragePercentage;

  /**
   * Instantiates a new Backup repository.
   *
   * @param uuid                        the uuid
   * @param deleted                     the deleted
   * @param deletedDate                 the deleted date
   * @param name                        the name
   * @param updatedDate                 the updated date
   * @param id                          the id
   * @param repositoryUid               the repository uid
   * @param serverName                  the server name
   * @param companyName                 the company name
   * @param locationName                the location name
   * @param capacity                    the capacity
   * @param freeSpace                   the free space
   * @param backupSize                  the backup size
   * @param healthState                 the health state
   * @param backupServerId              the backup server id
   * @param isServiceProviderRepository the is service provider repository
   */
  public BaBackupRepository(final String uuid, final boolean deleted,
      final Instant deletedDate, final String name, final Instant updatedDate,
      final String id, final String repositoryUid, final String serverName,
      final String companyName, final String locationName,
      final double capacity, final double freeSpace, final double backupSize,
      final String healthState, final int backupServerId,
      final boolean isServiceProviderRepository,
      final double committedStoragePercentage) {
    super(uuid, deleted, deletedDate, name, updatedDate);
    this.id = id;
    this.repositoryUid = repositoryUid;
    this.serverName = serverName;
    this.companyName = companyName;
    this.locationName = locationName;
    this.capacity = capacity;
    this.freeSpace = freeSpace;
    this.backupSize = backupSize;
    this.healthState = healthState;
    this.backupServerId = backupServerId;
    this.isServiceProviderRepository = isServiceProviderRepository;
    this.committedStoragePercentage = committedStoragePercentage;
  }

  /**
   * Gets system ID assigned to a backup repository in Veeam Availability
   * Console RESTful API.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Gets name of a backup repository configured in Veeam Backup & Replication
   * or cloud repository configured in Veeam Cloud Connect.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets repository uid.
   *
   * @return the repository uid
   */
  public String getRepositoryUid() {
    return repositoryUid;
  }

  /**
   * Gets name of Veeam backup server that manages a backup repository or
   * a cloud repository.
   *
   * @return the server name
   */
  public String getServerName() {
    return serverName;
  }

  /**
   * Gets name of company or department that uses a backup repository.
   *
   * @return the company name
   */
  public String getCompanyName() {
    return companyName;
  }

  /**
   * Gets name of company or department location to which backup repository
   * is assigned.
   *
   * @return the location name
   */
  public String getLocationName() {
    return locationName;
  }

  /**
   * Gets capacity of a backup repository in GB.
   *
   * @return the capacity
   */
  public double getCapacity() {
    return capacity;
  }

  /**
   * Gets free space remaining on a backup repository in GB.
   *
   * @return the free space
   */
  public double getFreeSpace() {
    return freeSpace;
  }

  /**
   * Gets total amount of backed up data in GB.
   *
   * @return the backup size
   */
  public double getBackupSize() {
    return backupSize;
  }

  /**
   * Gets repository health state. Possible values: OK, Warning, Error.
   *
   * @return the health state
   */
  public String getHealthState() {
    return healthState;
  }

  /**
   * Gets backup server id.
   *
   * @return the backup server id
   */
  public int getBackupServerId() {
    return backupServerId;
  }

  /**
   * Is service provider repository boolean.
   *
   * @return the boolean
   */
  public boolean isServiceProviderRepository() {
    return isServiceProviderRepository;
  }

  /**
   *  Get the amount of committed storage percentage.
   *
   * @return amount of storage percentage
   */
  public double getCommittedStoragePercentage() {
    return committedStoragePercentage;
  }

  @Override
  public boolean entityEquals(final Entity o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BaBackupRepository that = (BaBackupRepository) o;
    return Double.compare(that.capacity, capacity) == 0
        && Double.compare(that.freeSpace, freeSpace) == 0
        && Double.compare(that.backupSize, backupSize) == 0
        && backupServerId == that.backupServerId
        && isServiceProviderRepository == that.isServiceProviderRepository
        && Objects.equals(id, that.id) && Objects.equals(name, that.name)
        && Objects.equals(repositoryUid, that.repositoryUid) && Objects
        .equals(serverName, that.serverName) && Objects
        .equals(companyName, that.companyName) && Objects
        .equals(locationName, that.locationName) && Objects
        .equals(healthState, that.healthState);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(id, name, repositoryUid, serverName, companyName, locationName,
            capacity, freeSpace, backupSize, healthState, backupServerId,
            isServiceProviderRepository, committedStoragePercentage);
  }

  @Override
  public EntityType getEntityType() {
    return EntityType.VAC_BACKUP_REPOSITORY;
  }

  @Override
  public int entityHashCode() {
    return Objects
        .hash(id, name, repositoryUid, serverName, companyName, locationName,
            capacity, freeSpace, backupSize, healthState, backupServerId,
            isServiceProviderRepository, committedStoragePercentage);
  }

  @Override
  protected boolean entityEquals(final AbstractEntity o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BaBackupRepository that = (BaBackupRepository) o;
    return Double.compare(that.capacity, capacity) == 0
        && Double.compare(that.freeSpace, freeSpace) == 0
        && Double.compare(that.backupSize, backupSize) == 0
        && backupServerId == that.backupServerId
        && isServiceProviderRepository == that.isServiceProviderRepository
        && Objects.equals(id, that.id) && Objects.equals(name, that.name)
        && Objects.equals(repositoryUid, that.repositoryUid) && Objects
        .equals(serverName, that.serverName) && Objects
        .equals(companyName, that.companyName) && Objects
        .equals(locationName, that.locationName) && Objects
        .equals(healthState, that.healthState);
  }
}
