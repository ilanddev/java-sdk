/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.iland.core.api.constants.OperatingSystemFamily;

/**
 * Operating System Util.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class OperatingSystemUtil {

  private static final Pattern INVALID_WINDOWS_COMPUTER_NAME_PATTERN =
      Pattern.compile("^.*[^A-Za-z0-9-]+.*$|^[0-9]+$|^-.*$|^.*-$");

  private static final Pattern INVALID_NON_WINDOWS_COMPUTER_NAME_PATTERN =
      Pattern.compile("^.*[^A-Za-z0-9-\\.]+.*$|^[0-9]+$|^[-\\.].*$|^.*[-\\.]$");

  private static final int MAX_WINDOWS_COMPUTER_NAME_LENGTH = 15;

  private static final int MAX_NON_WINDOWS_COMPUTER_NAME_LENGTH = 63;

  /**
   * Indicates whether a given computer name is valid given the relevant OS
   * family.
   *
   * @param osFamily     {@link OperatingSystemFamily} the relevant OS family
   * @param computerName {@link String} the computer name to check
   * @return boolean value indicating whether the computer name is valid
   */
  public static List<String> isComputerNameValid(
      @Nonnull final OperatingSystemFamily osFamily,
      @Nonnull final String computerName) {
    final List<String> errorList = new ArrayList<>();
    switch (osFamily) {
      case WINDOWS:
        if (computerName.length() > MAX_WINDOWS_COMPUTER_NAME_LENGTH) {
          errorList.add(String
              .format("Computer name exceeds the max character length of %d.",
                  MAX_WINDOWS_COMPUTER_NAME_LENGTH));
        }
        if (INVALID_WINDOWS_COMPUTER_NAME_PATTERN.matcher(computerName)
            .matches()) {
          errorList.add(
              "Computer name can only contain alphanumeric characters and hyphens.");
        }
        return errorList;
      case OTHER:
      case LINUX:
        if (computerName.length() > MAX_NON_WINDOWS_COMPUTER_NAME_LENGTH) {
          errorList.add(String
              .format("Computer name exceeds the max character length of %d.",
                  MAX_NON_WINDOWS_COMPUTER_NAME_LENGTH));
        }
        if (INVALID_NON_WINDOWS_COMPUTER_NAME_PATTERN.matcher(computerName)
            .matches()) {
          errorList.add(
              "Computer name can only contain alphanumeric characters, hyphens and periods.");
        }
        return errorList;
      default:
        throw new IllegalStateException(String.format(
            "unknown OperatingSystemFamily %s when checking computer name validity.",
            osFamily.name()));
    }
  }

  /**
   * Checks whether a given computer name is valid with the least restrictive
   * constraint
   *
   * @param computerName {@link String} the computer name to check
   * @return boolean
   */
  public static boolean isComputerNameValid(
      @Nonnull final String computerName) {
    return !INVALID_NON_WINDOWS_COMPUTER_NAME_PATTERN.matcher(computerName)
        .matches();
  }

}
