/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vac;

import java.io.Serializable;
import java.time.Instant;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.annotation.Nonnull;

import com.iland.common.entity.CommonEntityType;
import com.iland.core.api.entity.AbstractEntity;
import com.iland.core.api.entity.Entity;
import com.iland.core.api.entity.EntityUtil;
import com.iland.core.api.entity.LocationEntity;
import com.iland.core.api.iam.ProductType;
import com.iland.core.model.EntityType;

/**
 * VAC Job.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public class BaJob extends AbstractEntity implements Serializable,
    LocationEntity {

  private static final long serialVersionUID = -2576912194309415531L;

  public static final String JOB = "-job-";

  private final String id;

  private final BaJobStatus status;

  private final String type;

  private final Instant lastRun;

  private final Instant endTime;

  private final int duration;

  private final String durationUnits;

  private final double processionRate;

  private final String processingRateUnits;

  private final int avgDuration;

  private final String avgDurationUnits;

  private final double transferredData;

  private final String transferredDataUnits;

  private final String bottleneck;

  private final String serverName;

  private final boolean isEnabled;

  private final int protectedVMs;

  private final String schedulingType;

  private final String companyId;

  private final String locationId;

  private Map<com.iland.common.entity.EntityType, String> ancestors;

  private final String companyUuid;

  /**
   * Instantiates a new Ba job.
   *
   * @param uuid                 the uuid
   * @param deleted              the deleted
   * @param deletedDate          the deleted date
   * @param name                 the name
   * @param updatedDate          the updated date
   * @param id                   the id
   * @param status               the status
   * @param type                 the type
   * @param lastRun              the last run
   * @param endTime              the end time
   * @param duration             the duration
   * @param durationUnits        the duration units
   * @param processionRate       the procession rate
   * @param processingRateUnits  the processing rate units
   * @param avgDuration          the avg duration
   * @param avgDurationUnits     the avg duration units
   * @param transferredData      the transferred data
   * @param transferredDataUnits the transferred data units
   * @param bottleneck           the bottleneck
   * @param serverName           the server name
   * @param isEnabled            the is enabled
   * @param protectedVMs         the protected v ms
   * @param schedulingType       the scheduling type
   * @param companyId            the company id
   * @param locationId           the location id
   * @param companyUuid          the company uuid
   */
  public BaJob(final String uuid, final boolean deleted,
      final Instant deletedDate, final String name, final Instant updatedDate,
      final String id, final BaJobStatus status, final String type,
      final Instant lastRun, final Instant endTime, final int duration,
      final String durationUnits, final double processionRate,
      final String processingRateUnits, final int avgDuration,
      final String avgDurationUnits, final double transferredData,
      final String transferredDataUnits, final String bottleneck,
      final String serverName, final boolean isEnabled, final int protectedVMs,
      final String schedulingType, final String companyId, final String locationId,
      final String companyUuid) {
    super(uuid, deleted, deletedDate, name, updatedDate);
    this.id = id;
    this.status = status;
    this.type = type;
    this.lastRun = lastRun;
    this.endTime = endTime;
    this.duration = duration;
    this.durationUnits = durationUnits;
    this.processionRate = processionRate;
    this.processingRateUnits = processingRateUnits;
    this.avgDuration = avgDuration;
    this.avgDurationUnits = avgDurationUnits;
    this.transferredData = transferredData;
    this.transferredDataUnits = transferredDataUnits;
    this.bottleneck = bottleneck;
    this.serverName = serverName;
    this.isEnabled = isEnabled;
    this.protectedVMs = protectedVMs;
    this.schedulingType = schedulingType;
    this.companyId = companyId;
    this.locationId = locationId;
    this.companyUuid = companyUuid;
  }

  /**
   * Gets system ID assigned to a job in Veeam Availability Console RESTful API.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Gets name of the job configured in Veeam Backup & Replication.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets status of the latest job session.
   * <p>
   * Possible values:
   * <p>
   * Success
   * Warning
   * Failed
   * Running
   * No Info.
   *
   * @return the status
   */
  public BaJobStatus getStatus() {
    return status;
  }

  /**
   * Gets veeam Backup & Replication job type.
   * <p>
   * Possible values:
   * <p>
   * Backup
   * Replication
   * SureBackup
   * Backup Copy
   * File to Tape
   * Backup to Tape
   * Copy
   * SQL Log Backup Job
   * Oracle Log Backup Job
   * Quick Migration
   * SAN Rescan
   * Failover Plan
   * Agent Backup Job (Managed by Agent)
   * Agent Backup Job (Managed by Backup Server)
   * Agent Backup Policy
   * Agent Backup Job
   * Windows Agent Backup Copy
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Gets date and time when the latest job session started.
   * Date and time string is formatted in accordance with ISO 8601.
   *
   * @return the last run
   */
  public Instant getLastRun() {
    return lastRun;
  }

  /**
   * Gets date and time when the latest job session finished.
   * Date and time string is formatted in accordance with ISO 8601.
   *
   * @return the end time
   */
  public Instant getEndTime() {
    return endTime;
  }

  /**
   * Gets time taken to complete the latest job session.
   *
   * @return the duration
   */
  public int getDuration() {
    return duration;
  }

  /**
   * Gets measurement units for the latest job duration. Has the constant value s.
   *
   * @return the duration units
   */
  public String getDurationUnits() {
    return durationUnits;
  }

  /**
   * Gets rate at which VM data was processed during the latest job session.
   *
   * @return the procession rate
   */
  public double getProcessionRate() {
    return processionRate;
  }

  /**
   * Gets measurement units for the rate at which VM data was processed during the latest job session.
   * Possible values: B/s (bytes per second) and its multiples formed with metric prefixes.
   *
   * @return the processing rate units
   */
  public String getProcessingRateUnits() {
    return processingRateUnits;
  }

  /**
   * Gets average time taken to complete a job session.
   *
   * @return the avg duration
   */
  public int getAvgDuration() {
    return avgDuration;
  }

  /**
   * Gets measurement units for the average job duration. Has the constant value s.
   *
   * @return the avg duration units
   */
  public String getAvgDurationUnits() {
    return avgDurationUnits;
  }

  /**
   * Gets total amount of data that was transferred to target during the latest job session.
   *
   * @return the transferred data
   */
  public double getTransferredData() {
    return transferredData;
  }

  /**
   * Gets measurement units for the data that was transferred to target during the latest job session.
   * Possible values: B (byte) and its multiples formed with metric prefixes.
   *
   * @return the transferred data units
   */
  public String getTransferredDataUnits() {
    return transferredDataUnits;
  }

  /**
   * Gets bottleneck in the process of transferring the data from source to target.
   * <p>
   * Possible values:
   * <p>
   * Source
   * Proxy
   * Network
   * Target
   * Source WAN accelerator
   * Target WAN accelerator
   *
   * @return the bottleneck
   */
  public String getBottleneck() {
    return bottleneck;
  }

  /**
   * Gets name of the Veeam Backup & Replication or Veeam Cloud Connect server
   * on which a job was configured.
   *
   * @return the server name
   */
  public String getServerName() {
    return serverName;
  }

  /**
   * Indicates whether a job schedule is enabled.
   *
   * @return the boolean
   */
  public boolean isEnabled() {
    return isEnabled;
  }

  /**
   * Gets number of VMs protected by the job.
   *
   * @return the protected v ms
   */
  public int getProtectedVMs() {
    return protectedVMs;
  }

  /**
   * Gets type of schedule configured for the job.
   * <p>
   * Possible values:
   * <p>
   * Continuously
   * Periodically
   * Monthly
   * Daily
   * Chained.
   *
   * @return the scheduling type
   */
  public String getSchedulingType() {
    return schedulingType;
  }

  /**
   * Gets the company id.
   *
   * @return the company id
   */
  @Override
  @Nonnull
  public String getCompanyId() {
    return companyId;
  }

  /**
   * Gets the location id.
   *
   * @return the location id
   */
  @Override
  @Nonnull
  public String getLocationId() {
    return locationId;
  }

  @Override
  public EntityType getEntityType() {
    return EntityType.VAC_JOB;
  }

  @Override
  public boolean entityEquals(final Entity o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    if (!super.equals(o))
      return false;
    final BaJob baJob = (BaJob) o;
    return duration == baJob.duration
        && Double.compare(baJob.processionRate, processionRate) == 0
        && avgDuration == baJob.avgDuration
        && Double.compare(baJob.transferredData, transferredData) == 0
        && isEnabled == baJob.isEnabled && protectedVMs == baJob.protectedVMs
        && Objects.equals(companyId, baJob.companyId) && Objects.equals(
        locationId, baJob.locationId)
        && Objects.equals(id, baJob.id) && Objects.equals(status, baJob.status)
        && Objects.equals(type, baJob.type) && Objects
        .equals(lastRun, baJob.lastRun) && Objects
        .equals(endTime, baJob.endTime) && Objects
        .equals(durationUnits, baJob.durationUnits) && Objects
        .equals(processingRateUnits, baJob.processingRateUnits) && Objects
        .equals(avgDurationUnits, baJob.avgDurationUnits) && Objects
        .equals(transferredDataUnits, baJob.transferredDataUnits) && Objects
        .equals(bottleneck, baJob.bottleneck) && Objects
        .equals(serverName, baJob.serverName) && Objects.equals(schedulingType,
        baJob.schedulingType) && Objects.equals(companyUuid, baJob.companyUuid);
  }

  @Override
  public int entityHashCode() {
    return Objects.hash(super.hashCode(), id, status, type, lastRun, endTime,
        durationUnits, processionRate, processingRateUnits, avgDuration,
        avgDurationUnits, transferredData, transferredDataUnits, bottleneck,
        serverName, isEnabled, protectedVMs, schedulingType, companyId,
        locationId, companyUuid);
  }

  @Nonnull
  @Override
  public Map<com.iland.common.entity.EntityType, String> getAncestors() {
    if (ancestors == null || ancestors.isEmpty()) {
      final Map<com.iland.common.entity.EntityType, String> result =
          new HashMap<>();
      result.put(CommonEntityType.COMPANY, companyId);
      result.put(EntityType.VCC_BACKUP_TENANT, EntityUtil
          .getIdForCompanyProduct(companyId, ProductType.ILAND_BACKUP));
      result.put(EntityType.VCC_BACKUP_LOCATION, EntityUtil
          .getIdForCompanyProductLocation(companyId, ProductType.ILAND_BACKUP,
              locationId));
      ancestors = Collections.unmodifiableMap(result);
    }
    return ancestors;
  }

  public String getCompanyUuid() {
    return companyUuid;
  }

  public enum BaJobStatus {

    STARTING("Starting..."),

    SUCCESS("Success"),

    WARNING("Warning"),

    STOPPING("Stopping..."),

    FAILED("Failed"),

    RUNNING("Running"),

    NO_INFO("No Info"),

    ENABLING("Enabling..."),

    DISABLING("Disabling..."),

    UNKNOWN("Unknown");

    private String value;

    /**
     * Get the VAC value of the job status.
     *
     * @return {@link String} vac value
     */
    public String getValue() {
      return value;
    }

    public static Map<String, BaJobStatus> statusMap = new HashMap<>();

    static {
      for (final BaJobStatus baJobStatus : values()) {
        statusMap.put(baJobStatus.getValue(), baJobStatus);
      }
    }

    BaJobStatus(final String value) {
      this.value = value;
    }

    /**
     * Gets a Ba Job status enum given the VAC value.
     *
     * @param value {@link String} value
     * @return {@link BaJobStatus} ba job status
     */
    public static BaJobStatus getBaJobStatus(final String value) {
      return statusMap.getOrDefault(value, UNKNOWN);
    }

  }

}
