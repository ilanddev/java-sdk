/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlElement;

/**
 * VCC vCloud compute resource element.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
public class VccVCloudComputeResource implements Serializable {

  @XmlElement(name = "VirtualDataCenterName")
  private String virtualDataCenterName;

  @XmlElement(name = "VirtualDataCenterRef")
  private String virtualDataCenterRef;

  @XmlElement(name = "Enabled")
  private boolean enabled;

  @XmlElement(name = "AllocationModel")
  private String allocationModel;

  @XmlElement(name = "UseNetworkFailoverResources")
  private boolean useNetworkFailoverResources;

  @XmlElement(name = "ResourceUsage")
  private VccVCloudResourceUsage resourceUsage;

  public VccVCloudComputeResource() {
  }

  public VccVCloudComputeResource(final String virtualDataCenterName,
      final String virtualDataCenterRef, final boolean enabled,
      final String allocationModel, final boolean useNetworkFailoverResources,
      final VccVCloudResourceUsage resourceUsage) {
    this.virtualDataCenterName = virtualDataCenterName;
    this.virtualDataCenterRef = virtualDataCenterRef;
    this.enabled = enabled;
    this.allocationModel = allocationModel;
    this.useNetworkFailoverResources = useNetworkFailoverResources;
    this.resourceUsage = resourceUsage;
  }

  public String getVirtualDataCenterName() {
    return virtualDataCenterName;
  }

  public String getVirtualDataCenterRef() {
    return virtualDataCenterRef;
  }

  public boolean isEnabled() {
    return enabled;
  }

  public String getAllocationModel() {
    return allocationModel;
  }

  public boolean isUseNetworkFailoverResources() {
    return useNetworkFailoverResources;
  }

  public VccVCloudResourceUsage getResourceUsage() {
    return resourceUsage;
  }
}
