/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.annotation.Nonnull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.entity.AbstractEntity;
import com.iland.core.api.entity.Entity;
import com.iland.core.api.entity.EntityAncestorUtil;
import com.iland.core.api.entity.EntityField;
import com.iland.core.api.entity.LocationEntity;
import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.model.EntityType;

/**
 * VCC-R failover plan.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
public class VccFailoverPlan extends AbstractEntity implements LocationEntity {

  private static final long serialVersionUID = -4066086606463475164L;

  public static final String URN_VCC_FAILOVER_PLAN = ":urn:vcc:failoverplan:";

  private static final String VEEAM_CLOUD_FAILOVER_PLAN_URN_PART =
      "urn:veeam:CloudFailoverPlan:";

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(EntityField.COMPANY_ID)
  private final String companyId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(EntityField.LOCATION_ID)
  private final String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(EntityField.ORG_UUID)
  private final String orgUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccFailoverPlanField.HREF)
  private final String href;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccFailoverPlanField.UID)
  private final String uid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccFailoverPlanField.DESCRIPTION)
  private final String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccFailoverPlanField.LAST_TEST)
  private Instant lastTest;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccFailoverPlanField.VCC_TENANT_UID)
  private final String vccTenantUid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccFailoverPlanField.VCC_TENANT_NAME)
  private final String vccTenantName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccFailoverPlanField.VMS)
  private final List<VccFailoverPlanVm> vms;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccFailoverPlanField.STATUS)
  private VccFailoverPlanStatus status;

  private Map<com.iland.common.entity.EntityType, String> ancestors;

  private static String normalizeUid(final String nativeId) {
    return nativeId.replace(VEEAM_CLOUD_FAILOVER_PLAN_URN_PART, "");
  }

  private static String normalizeUuid(final String nativeId,
      final String locationId) {
    return String.format("%s%s%s", locationId, URN_VCC_FAILOVER_PLAN,
        VccFailoverPlan.normalizeUid(nativeId));
  }

  public VccFailoverPlan(final String companyId, final String locationId,
      final String orgUuid, final String href, final String uid,
      final String name, final String description, final Instant updatedDate,
      final Instant deletedDate, final Instant lastTest,
      final String vccTenantUid, final String vccTenantName,
      final List<VccFailoverPlanVm> vms) {
    super(VccFailoverPlan.normalizeUuid(uid, locationId), deletedDate != null,
        deletedDate, name, updatedDate);
    this.companyId = companyId;
    this.locationId = locationId;
    this.orgUuid = orgUuid;
    this.vccTenantUid = vccTenantUid;
    this.vccTenantName = vccTenantName;
    this.href = href;
    this.uid = uid;
    this.description = description;
    this.lastTest = lastTest;
    this.vms = vms;
  }

  @Nonnull
  @Override
  public String getLocationId() {
    return locationId;
  }

  /**
   * Returns the corresponding Org UUID
   *
   * @return unique platform identifier
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Returns VCC-R internal HREF
   *
   * @return Veeam URL
   */
  public String getHref() {
    return href;
  }

  /**
   * Returns VCC-R Veeam instance unique identifier.
   *
   * @return normalized Veeam instance unique identifier.
   */
  public String getUid() {
    if (uid != null) {
      return VccFailoverPlan.normalizeUid(uid);
    }
    return null;
  }

  @Override
  public String toString() {
    return String.format("VCC-R Failover plan [orgUuid=%s]", orgUuid);
  }

  @Override
  public EntityType getEntityType() {
    return EntityType.IAAS_VCC_FAILOVER_PLAN;
  }

  @Nonnull
  @Override
  public String getCompanyId() {
    return companyId;
  }

  @Nonnull
  @Override
  public Map<com.iland.common.entity.EntityType, String> getAncestors() {
    if (ancestors == null || ancestors.isEmpty()) {
      ancestors = EntityAncestorUtil.getAncestorsFromOrganization(companyId,
          locationId, orgUuid);
    }

    return ancestors;
  }

  @Override
  public String getEntityName() {
    return getName();
  }

  @Override
  public int entityHashCode() {
    return Objects
        .hash(super.entityHashCode(), locationId, orgUuid, description, uid,
            status, companyId, vccTenantUid, vms, href, vccTenantName);
  }

  @Override
  public boolean entityEquals(final Entity other) {
    if (other == null || !EntityType.IAAS_VPG.equals(other.getEntityType())) {
      return false;
    }
    final VccFailoverPlan otherFp = (VccFailoverPlan) other;
    return super.entityEquals(otherFp) && Objects
        .equals(locationId, otherFp.locationId) && Objects
        .equals(orgUuid, otherFp.orgUuid) && Objects
        .equals(description, otherFp.description) && Objects
        .equals(status, otherFp.status) && Objects
        .equals(companyId, otherFp.companyId) && Objects
        .equals(uid, otherFp.uid) && Objects.equals(href, otherFp.href)
        && Objects.equals(vccTenantName, otherFp.vccTenantName) && Objects
        .equals(vccTenantUid, otherFp.vccTenantUid);
  }

  /**
   * Returns the VCC-R failover plan Veeam description.
   *
   * @return the VCC-R failover plan Veeam description.
   */
  public String getDescription() {
    return description;
  }

  /**
   * Returns the date of last failover test.
   *
   * @return the date of last failover test or null if failover tests
   * never ran
   */
  public Instant getLastTest() {
    return lastTest;
  }

  /**
   * Returns the normalized corresponding unique VCC tenant UID.
   *
   * @return the normalized corresponding unique VCC tenant UID.
   */
  public String getVccTenantUid() {
    return vccTenantUid;
  }

  /**
   * Returns the corresponding VCC tenant name.
   *
   * @return the corresponding VCC tenant name.
   */
  public String getVccTenantName() {
    return vccTenantName;
  }

  /**
   * Returns the list of Veeam Failover virtual machines.
   * <p>
   * We cannot reference the vCLoud virtual machines here because of missing
   * references Veeam side.
   *
   * @return list of {@link VccFailoverPlanVm}
   */
  public List<VccFailoverPlanVm> getVms() {
    return vms;
  }

  /**
   * Returns the status of the VCC-R failover plan.
   *
   * @return a {@link VccFailoverPlanStatus} instance.
   */
  public VccFailoverPlanStatus getStatus() {
    return status;
  }

  /**
   * Sets the status of the VCC-R failover plan.
   *
   * @param status a {@link VccFailoverPlanStatus} instance.
   */
  public void setStatus(final VccFailoverPlanStatus status) {
    this.status = status;
  }

  /**
   * Sets the date of last failover test.
   *
   * @param lastTest date time.
   */
  public void setLastTest(final Instant lastTest) {
    this.lastTest = lastTest;
  }

}
