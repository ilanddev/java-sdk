/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.api.serialization.JsonOptional;
import com.iland.core.api.serialization.JsonRequired;

/**
 * AbstractResourceAlert.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public abstract class AbstractResourceAlert implements Serializable {

  private static final long serialVersionUID = 1472730649796871208L;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.GROUP)
  @JsonRequired("performance counter group")
  protected String group;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.NAME)
  @JsonRequired("performance counter name")
  protected String name;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.TYPE)
  @JsonRequired("performance counter type")
  protected String type;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.USERNAME)
  @JsonOptional("username")
  protected String username;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.ACTION)
  @JsonOptional("alert action")
  protected String action;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.EQUALITY_CONDITION)
  @JsonRequired("equality condition")
  protected String equalityRelation;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.ENABLED)
  @JsonRequired("enabled")
  protected boolean enabled;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.BREACH)
  @JsonRequired("alert breach period")
  protected int breachPeriod;

  protected AbstractResourceAlert() {
  }

  protected AbstractResourceAlert(final String group, final String name,
      final String type) {
    this.group = group;
    this.name = name;
    this.type = type;
  }

  /**
   * Get the performance counter group attached to this alert.
   *
   * @return {@link String} performance counter group
   */
  public String getGroup() {
    return group;
  }

  /**
   * Set the performance counter group attached to this alert.
   *
   * @param group {@link String} performance counter group
   */
  public void setGroup(final String group) {
    this.group = group;
  }

  /**
   * Get the performance counter name attached to this alert.
   *
   * @return {@link String} performance counter name
   */
  public String getName() {
    return name;
  }

  /**
   * Set the performance counter name attached to this alert.
   *
   * @param name {@link String} performance counter name
   */
  public void setName(final String name) {
    this.name = name;
  }

  /**
   * Get the performance counter type attached to this alert.
   *
   * @return {@link String} performance counter type
   */
  public String getType() {
    return type;
  }

  /**
   * Set the performance counter group attached to this alert.
   *
   * @param type {@link String} performance counter group
   */
  public void setType(final String type) {
    this.type = type;
  }


  /**
   * Get the username associated with the alert.
   *
   * @return {@link String} username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Set the username associated with the alert.
   *
   * @param username {@link String} username
   */
  public void setUsername(final String username) {
    this.username = username;
  }

  /**
   * Get equality relation.
   * <p>
   * e.g. '<=' or '>='
   *
   * @return {@link String} equality relation
   */
  public String getRelation() {
    return equalityRelation;
  }

  /**
   * Set the equality relation.
   * <p>
   * e.g. '<=' or '>='
   *
   * @param relation equality relation
   */
  public void setRelation(final String relation) {
    this.equalityRelation = relation;
  }

  /**
   * Get action to perform when alert is triggered.
   *
   * @return {@link String} action
   */
  public String getAction() {
    return action;
  }

  /**
   * Set the action to perform when alert is triggered.
   *
   * @param action {@link String} action
   */
  public void setAction(final String action) {
    this.action = action;
  }

  /**
   * Get the breach period that is required in order for the alert to be
   * triggered.
   * <p>
   * i.e. the number of consecutive periods in which the threshold must be met
   * before alert is sent.
   *
   * @return breach period
   */
  public int getBreachPeriod() {
    return breachPeriod;
  }

  /**
   * Set the breach period that is required in order for the alert to be
   * triggered.
   * <p>
   * i.e. the number of consecutive periods in which the threshold must be met
   * before alert is sent.
   *
   * @param breachPeriod breach period
   */
  public void setBreachPeriod(final int breachPeriod) {
    this.breachPeriod = breachPeriod;
  }

  /**
   * Set whether the alert is enabled.
   *
   * @return enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Set whether the alert is enabled.
   *
   * @param enabled enabled
   */
  public void setEnabled(final boolean enabled) {
    this.enabled = enabled;
  }

}
