/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.usage;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Vapp Resource Summary.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
public class VappResourceSummary extends AbstractResourceSummary {

  private static final long serialVersionUID = 5505484487624758806L;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(ResourceSummaryField.NUMBER_OF_VMS)
  private long numberOfVms = 0;

  public VappResourceSummary() {
  }

  public VappResourceSummary(final double reservedCpu, final double reservedMem,
      final double consumedCpu, final double consumedMem,
      final double consumedDisk, final double provisionedDisk,
      final long numberOfVms, final double configuredDisk) {
    super(reservedCpu, reservedMem, consumedCpu, consumedMem, consumedDisk,
        provisionedDisk, configuredDisk);
    this.numberOfVms = numberOfVms;
  }

  /**
   * Return the number of VMs.
   *
   * @return number of VMs
   */
  public long getNumberOfVms() {
    return numberOfVms;
  }

}
