/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.keycloak;

import com.google.common.base.MoreObjects;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import javax.annotation.concurrent.NotThreadSafe;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link KeycloakApiKey}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableKeycloakApiKey.builder()}.
 */
@Generated(from = "KeycloakApiKey", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableKeycloakApiKey implements KeycloakApiKey {
  private final String companyId;
  private final String clientId;
  private final String id;
  private final String clientSecret;
  private final @Nullable String description;

  private ImmutableKeycloakApiKey(
      String companyId,
      String clientId,
      String id,
      String clientSecret,
      @Nullable String description) {
    this.companyId = companyId;
    this.clientId = clientId;
    this.id = id;
    this.clientSecret = clientSecret;
    this.description = description;
  }

  /**
   * The crmId of the company requesting the api keys
   */
  @Override
  public String companyId() {
    return companyId;
  }

  /**
   * The clientId represents the client key
   */
  @Override
  public String clientId() {
    return clientId;
  }

  /**
   * The id represents client in keycloak
   */
  @Override
  public String id() {
    return id;
  }

  /**
   * The clientSecret represents secret generated in keycloak
   */
  @Override
  public String clientSecret() {
    return clientSecret;
  }

  /**
   * The description set by the company admin
   */
  @Override
  public Optional<String> description() {
    return Optional.ofNullable(description);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link KeycloakApiKey#companyId() companyId} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for companyId
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableKeycloakApiKey withCompanyId(String value) {
    String newValue = Objects.requireNonNull(value, "companyId");
    if (this.companyId.equals(newValue)) return this;
    return new ImmutableKeycloakApiKey(newValue, this.clientId, this.id, this.clientSecret, this.description);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link KeycloakApiKey#clientId() clientId} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for clientId
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableKeycloakApiKey withClientId(String value) {
    String newValue = Objects.requireNonNull(value, "clientId");
    if (this.clientId.equals(newValue)) return this;
    return new ImmutableKeycloakApiKey(this.companyId, newValue, this.id, this.clientSecret, this.description);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link KeycloakApiKey#id() id} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for id
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableKeycloakApiKey withId(String value) {
    String newValue = Objects.requireNonNull(value, "id");
    if (this.id.equals(newValue)) return this;
    return new ImmutableKeycloakApiKey(this.companyId, this.clientId, newValue, this.clientSecret, this.description);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link KeycloakApiKey#clientSecret() clientSecret} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for clientSecret
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableKeycloakApiKey withClientSecret(String value) {
    String newValue = Objects.requireNonNull(value, "clientSecret");
    if (this.clientSecret.equals(newValue)) return this;
    return new ImmutableKeycloakApiKey(this.companyId, this.clientId, this.id, newValue, this.description);
  }

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link KeycloakApiKey#description() description} attribute.
   * @param value The value for description
   * @return A modified copy of {@code this} object
   */
  public final ImmutableKeycloakApiKey withDescription(String value) {
    @Nullable String newValue = Objects.requireNonNull(value, "description");
    if (Objects.equals(this.description, newValue)) return this;
    return new ImmutableKeycloakApiKey(this.companyId, this.clientId, this.id, this.clientSecret, newValue);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link KeycloakApiKey#description() description} attribute.
   * An equality check is used on inner nullable value to prevent copying of the same value by returning {@code this}.
   * @param optional A value for description
   * @return A modified copy of {@code this} object
   */
  public final ImmutableKeycloakApiKey withDescription(Optional<String> optional) {
    @Nullable String value = optional.orElse(null);
    if (Objects.equals(this.description, value)) return this;
    return new ImmutableKeycloakApiKey(this.companyId, this.clientId, this.id, this.clientSecret, value);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableKeycloakApiKey} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableKeycloakApiKey
        && equalTo((ImmutableKeycloakApiKey) another);
  }

  private boolean equalTo(ImmutableKeycloakApiKey another) {
    return companyId.equals(another.companyId)
        && clientId.equals(another.clientId)
        && id.equals(another.id)
        && clientSecret.equals(another.clientSecret)
        && Objects.equals(description, another.description);
  }

  /**
   * Computes a hash code from attributes: {@code companyId}, {@code clientId}, {@code id}, {@code clientSecret}, {@code description}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + companyId.hashCode();
    h += (h << 5) + clientId.hashCode();
    h += (h << 5) + id.hashCode();
    h += (h << 5) + clientSecret.hashCode();
    h += (h << 5) + Objects.hashCode(description);
    return h;
  }

  /**
   * Prints the immutable value {@code KeycloakApiKey} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("KeycloakApiKey")
        .omitNullValues()
        .add("companyId", companyId)
        .add("clientId", clientId)
        .add("id", id)
        .add("clientSecret", clientSecret)
        .add("description", description)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link KeycloakApiKey} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable KeycloakApiKey instance
   */
  public static ImmutableKeycloakApiKey copyOf(KeycloakApiKey instance) {
    if (instance instanceof ImmutableKeycloakApiKey) {
      return (ImmutableKeycloakApiKey) instance;
    }
    return ImmutableKeycloakApiKey.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableKeycloakApiKey ImmutableKeycloakApiKey}.
   * <pre>
   * ImmutableKeycloakApiKey.builder()
   *    .companyId(String) // required {@link KeycloakApiKey#companyId() companyId}
   *    .clientId(String) // required {@link KeycloakApiKey#clientId() clientId}
   *    .id(String) // required {@link KeycloakApiKey#id() id}
   *    .clientSecret(String) // required {@link KeycloakApiKey#clientSecret() clientSecret}
   *    .description(String) // optional {@link KeycloakApiKey#description() description}
   *    .build();
   * </pre>
   * @return A new ImmutableKeycloakApiKey builder
   */
  public static ImmutableKeycloakApiKey.Builder builder() {
    return new ImmutableKeycloakApiKey.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableKeycloakApiKey ImmutableKeycloakApiKey}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "KeycloakApiKey", generator = "Immutables")
  @NotThreadSafe
  public static final class Builder {
    private static final long INIT_BIT_COMPANY_ID = 0x1L;
    private static final long INIT_BIT_CLIENT_ID = 0x2L;
    private static final long INIT_BIT_ID = 0x4L;
    private static final long INIT_BIT_CLIENT_SECRET = 0x8L;
    private long initBits = 0xfL;

    private @Nullable String companyId;
    private @Nullable String clientId;
    private @Nullable String id;
    private @Nullable String clientSecret;
    private @Nullable String description;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code KeycloakApiKey} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(KeycloakApiKey instance) {
      Objects.requireNonNull(instance, "instance");
      companyId(instance.companyId());
      clientId(instance.clientId());
      id(instance.id());
      clientSecret(instance.clientSecret());
      Optional<String> descriptionOptional = instance.description();
      if (descriptionOptional.isPresent()) {
        description(descriptionOptional);
      }
      return this;
    }

    /**
     * Initializes the value for the {@link KeycloakApiKey#companyId() companyId} attribute.
     * @param companyId The value for companyId 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder companyId(String companyId) {
      this.companyId = Objects.requireNonNull(companyId, "companyId");
      initBits &= ~INIT_BIT_COMPANY_ID;
      return this;
    }

    /**
     * Initializes the value for the {@link KeycloakApiKey#clientId() clientId} attribute.
     * @param clientId The value for clientId 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder clientId(String clientId) {
      this.clientId = Objects.requireNonNull(clientId, "clientId");
      initBits &= ~INIT_BIT_CLIENT_ID;
      return this;
    }

    /**
     * Initializes the value for the {@link KeycloakApiKey#id() id} attribute.
     * @param id The value for id 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder id(String id) {
      this.id = Objects.requireNonNull(id, "id");
      initBits &= ~INIT_BIT_ID;
      return this;
    }

    /**
     * Initializes the value for the {@link KeycloakApiKey#clientSecret() clientSecret} attribute.
     * @param clientSecret The value for clientSecret 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder clientSecret(String clientSecret) {
      this.clientSecret = Objects.requireNonNull(clientSecret, "clientSecret");
      initBits &= ~INIT_BIT_CLIENT_SECRET;
      return this;
    }

    /**
     * Initializes the optional value {@link KeycloakApiKey#description() description} to description.
     * @param description The value for description
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder description(String description) {
      this.description = Objects.requireNonNull(description, "description");
      return this;
    }

    /**
     * Initializes the optional value {@link KeycloakApiKey#description() description} to description.
     * @param description The value for description
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder description(Optional<String> description) {
      this.description = description.orElse(null);
      return this;
    }

    /**
     * Builds a new {@link ImmutableKeycloakApiKey ImmutableKeycloakApiKey}.
     * @return An immutable instance of KeycloakApiKey
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableKeycloakApiKey build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableKeycloakApiKey(companyId, clientId, id, clientSecret, description);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_COMPANY_ID) != 0) attributes.add("companyId");
      if ((initBits & INIT_BIT_CLIENT_ID) != 0) attributes.add("clientId");
      if ((initBits & INIT_BIT_ID) != 0) attributes.add("id");
      if ((initBits & INIT_BIT_CLIENT_SECRET) != 0) attributes.add("clientSecret");
      return "Cannot build KeycloakApiKey, some of required attributes are not set " + attributes;
    }
  }
}
