/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.nsx;

import java.time.Instant;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Nonnull;

import com.iland.core.api.entity.CompanyEntityRef;
import com.iland.core.api.net.VcdEdge;
import com.iland.core.api.vcd.Vdc;
import com.iland.core.web.rest.shared.nsx.NsxEntityType;

/**
 * Nsx Edge Entity Ref.
 *
 * @author <a href=“mailto:cjsnyder@iland.com”>Collin Snyder</a>
 */
public class NsxEdgeEntityRef implements CompanyEntityRef {

  private final VcdEdge edge;

  private final Vdc vdc;

  public NsxEdgeEntityRef(final VcdEdge edge, final Vdc vdc) {
    this.edge = edge;
    this.vdc = vdc;
  }

  @Nonnull
  @Override
  public String getCompanyId() {
    return vdc.getCompanyId();
  }

  @Nonnull
  @Override
  public Map<com.iland.common.entity.EntityType, String> getAncestors() {
    final Map<com.iland.common.entity.EntityType, String> ancestorMap =
        new HashMap<>(vdc.getAncestors());
    ancestorMap.put(NsxEntityType.IAAS_EDGE, getUuid());
    return Collections.unmodifiableMap(ancestorMap);
  }

  @Override
  public String getUuid() {
    return edge.getUuid();
  }

  @Override
  public boolean isDeleted() {
    return false;
  }

  @Override
  public String getName() {
    return edge.getName();
  }

  @Override
  public com.iland.common.entity.EntityType getEntityType() {
    return NsxEntityType.IAAS_EDGE;
  }

  @Override
  public Instant getDeletedDate() {
    return null;
  }

}
