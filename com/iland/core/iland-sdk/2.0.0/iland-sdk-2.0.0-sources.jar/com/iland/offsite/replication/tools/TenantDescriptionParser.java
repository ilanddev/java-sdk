/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.tools;

import static java.util.function.Predicate.not;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.Nullable;

import com.iland.offsite.replication.api.model.VdcUuid;

public final class TenantDescriptionParser {

	/**
	 * Parses one or more vDC UUIDs from comma-separated-values usually supplied
	 * by a Cohesity tenant description.
	 *
	 * @param description Cohesity tenant description
	 * @return a {@link Set set} of {@link VdcUuid vDC UUIDs} that may be empty if
	 * no binding is present or the binding is invalid
	 */
	public static Set<VdcUuid> parseDescription(
		@Nullable final String description) {
		return Optional.ofNullable(description)
			.map(TenantDescriptionParser::parse)
			.orElseGet(Collections::emptySet);
	}

	private static Set<VdcUuid> parse(final String description) {
		final String[] tokens = description.split(",");

		return Arrays.stream(tokens)
			.map(String::trim)
			.filter(not(String::isEmpty))
			.filter(token -> token.contains(":vdc:"))
			.map(VdcUuid::of)
			.collect(Collectors.toUnmodifiableSet());
	}

	private TenantDescriptionParser() {
	}

}
