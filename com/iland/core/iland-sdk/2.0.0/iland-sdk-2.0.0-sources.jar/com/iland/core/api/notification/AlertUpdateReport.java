/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Alert Update Report.
 * <p>
 * Details which alerts were sucessfully updated and which ones failed.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class AlertUpdateReport implements Serializable {

  private static final long serialVersionUID = 1623721813108800438L;

  public static final String SUCCESS = "success";

  public static final String FAILED = "failed";

  @Expose
  @SerializedName(SUCCESS)
  private final List<Alert> success;

  @Expose
  @SerializedName(FAILED)
  private final List<Alert> failed;

  public AlertUpdateReport(final List<Alert> success,
      final List<Alert> failed) {
    this.success = success;
    this.failed = failed;
  }

  /**
   * Get the alerts that were successfully updated.
   *
   * @return {@link List} of {@link Alert} successfully updated alerts
   */
  public List<Alert> getSuccess() {
    return success;
  }

  /**
   * Get the alerts that could not be updated.
   *
   * @return {@link List} of {@link Alert} failed to update alerts
   */
  public List<Alert> getFailed() {
    return failed;
  }

}
