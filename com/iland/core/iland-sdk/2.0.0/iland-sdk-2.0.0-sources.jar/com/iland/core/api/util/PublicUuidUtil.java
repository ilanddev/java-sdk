/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.util;

import java.util.Optional;

import javax.annotation.Nullable;

/**
 * Public Uuid Util.
 *
 * @author <a href=mailto:aquinones@iland.com">Ari Quinones</a>
 */
public class PublicUuidUtil {

	private static final String PUBLIC = "public-";

	private static final String VCLOUD = "vcloud:";

	/**
	 * Adds 'public-' to uuid
	 *
	 * @param uuid {@link String} uuid to modify
	 * @return {@link String} modified uuid
	 */
	@Nullable
	public static String addPublicToUuid(@Nullable final String uuid) {
		return Optional.ofNullable(uuid)
			.map(x -> x.replace(VCLOUD, VCLOUD + PUBLIC)).orElse(null);
	}

	/**
	 * Strips away the 'public-' in uuid if it exists
	 *
	 * @param uuid {@link String} uuid to check
	 * @return {@link String} stripped uuid
	 */
	@Nullable
	public static String stripUuidIfPublic(@Nullable final String uuid) {
		return Optional.ofNullable(uuid).map(x -> x.replace(PUBLIC, ""))
			.orElse(null);
	}

}
