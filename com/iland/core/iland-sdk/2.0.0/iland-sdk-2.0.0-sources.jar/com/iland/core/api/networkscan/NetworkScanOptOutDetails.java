/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.networkscan;

import java.util.Set;

/**
 * Network Scan Opt Out Details.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public class NetworkScanOptOutDetails {

	private String orgUuid;

	private boolean optOut;

	private Set<String> exclusions;

	public NetworkScanOptOutDetails(final String orgUuid, final boolean optOut,
		final Set<String> exclusions) {
		this.orgUuid = orgUuid;
		this.optOut = optOut;
		this.exclusions = exclusions;
	}

	/**
	 * Get the org uuid.
	 *
	 * @return {@link String} org uuid
	 */
	public String getOrgUuid() {
		return orgUuid;
	}

	/**
	 * Is the org opted out.
	 *
	 * @return is opt out
	 */
	public boolean isOptOut() {
		return optOut;
	}

	/**
	 * Get the set of ip addresses and ranges to exclude.
	 *
	 * @return {@link Set} of {@link String} ip exclusions
	 */
	public Set<String> getExclusions() {
		return exclusions;
	}

}
