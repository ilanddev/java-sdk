/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import static java.util.Objects.requireNonNullElseGet;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Alert.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public abstract class Alert implements Serializable {

  public static final String ALERT_UUID_PREFIX = "urn:iland:alert:";

  @Expose
  private String uuid;

  @Expose
  @SerializedName("delivery")
  private final AlertDeliverySpec deliverySpec;

  @Expose
  private final String username;

  @Expose
  private final boolean enabled;

  @Expose
  private final AlertType type;

  public Alert(final String username, final AlertDeliverySpec deliverySpec,
      final boolean enabled, final AlertType type) {
    this.uuid = ALERT_UUID_PREFIX + UUID.randomUUID();
    this.username = username;
    this.deliverySpec = deliverySpec;
    this.enabled = enabled;
    this.type = type;
  }

  public Alert(final String uuid, final String username,
      final AlertDeliverySpec deliverySpec, final boolean enabled,
      final AlertType type) {
    this.uuid = requireNonNullElseGet(uuid, Alert::generateAlertUuid);
    this.username = username;
    this.deliverySpec = deliverySpec;
    this.enabled = enabled;
    this.type = type;
  }

  /**
   * Get the delivery spec.
   *
   * @return {@link AlertDeliverySpec} delivery spec
   */
  public AlertDeliverySpec getDeliverySpec() {
    return deliverySpec;
  }

  /**
   * Get the username.
   *
   * @return {@link String} username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Set whether the alert is enabled.
   *
   * @return enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Get the alert type
   *
   * @return type of alert
   */
  public AlertType getType() {
    return type;
  }

  /**
   * Get the uuid.
   *
   * @return uuid
   */
  public String getUuid() {
    if (uuid == null) {
      uuid = generateAlertUuid();
    }

    return uuid;
  }

  /**
   * Get the entity's uuid.
   *
   * @return entity uuid
   */
  abstract public String getEntityUuid();

  @Override
  public boolean equals(final Object o) {
    return (this == o) || (o instanceof Alert alert
        && Objects.equals(getUuid(), alert.getUuid())
        && Objects.equals(getDeliverySpec(), alert.getDeliverySpec())
        && Objects.equals(getUsername(), alert.getUsername())
        && isEnabled() == alert.isEnabled()
        && Objects.equals(getType(), alert.getType()));
  }

  @Override
  public int hashCode() {
    return Objects.hash(getUuid(), getDeliverySpec(), getUsername(),
        isEnabled(), getType());
  }

  private static String generateAlertUuid() {
    return ALERT_UUID_PREFIX + UUID.randomUUID();
  }

}
