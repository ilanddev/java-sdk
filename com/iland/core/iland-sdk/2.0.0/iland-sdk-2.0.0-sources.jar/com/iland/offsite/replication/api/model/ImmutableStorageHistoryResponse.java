/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableList;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link StorageHistoryResponse}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableStorageHistoryResponse.builder()}.
 */
@Generated(from = "StorageHistoryResponse", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableStorageHistoryResponse
    implements StorageHistoryResponse {
  private final ImmutableList<StorageHistoryItem> items;

  private ImmutableStorageHistoryResponse(
      ImmutableList<StorageHistoryItem> items) {
    this.items = items;
  }

  /**
   * @return The value of the {@code items} attribute
   */
  @Override
  public ImmutableList<StorageHistoryItem> items() {
    return items;
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link StorageHistoryResponse#items() items}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final ImmutableStorageHistoryResponse withItems(StorageHistoryItem... elements) {
    ImmutableList<StorageHistoryItem> newValue = ImmutableList.copyOf(elements);
    return new ImmutableStorageHistoryResponse(newValue);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link StorageHistoryResponse#items() items}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of items elements to set
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableStorageHistoryResponse withItems(Iterable<? extends StorageHistoryItem> elements) {
    if (this.items == elements) return this;
    ImmutableList<StorageHistoryItem> newValue = ImmutableList.copyOf(elements);
    return new ImmutableStorageHistoryResponse(newValue);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableStorageHistoryResponse} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableStorageHistoryResponse
        && equalsByValue((ImmutableStorageHistoryResponse) another);
  }

  private boolean equalsByValue(ImmutableStorageHistoryResponse another) {
    return items.equals(another.items);
  }

  /**
   * Computes a hash code from attributes: {@code items}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + items.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code StorageHistoryResponse} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("StorageHistoryResponse")
        .omitNullValues()
        .add("items", items)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link StorageHistoryResponse} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable StorageHistoryResponse instance
   */
  public static ImmutableStorageHistoryResponse copyOf(StorageHistoryResponse instance) {
    if (instance instanceof ImmutableStorageHistoryResponse) {
      return (ImmutableStorageHistoryResponse) instance;
    }
    return ImmutableStorageHistoryResponse.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableStorageHistoryResponse ImmutableStorageHistoryResponse}.
   * <pre>
   * ImmutableStorageHistoryResponse.builder()
   *    .addItems|addAllItems(com.iland.offsite.replication.api.model.StorageHistoryItem) // {@link StorageHistoryResponse#items() items} elements
   *    .build();
   * </pre>
   * @return A new ImmutableStorageHistoryResponse builder
   */
  public static ImmutableStorageHistoryResponse.Builder builder() {
    return new ImmutableStorageHistoryResponse.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableStorageHistoryResponse ImmutableStorageHistoryResponse}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "StorageHistoryResponse", generator = "Immutables")
  public static final class Builder {
    private ImmutableList.Builder<StorageHistoryItem> items = ImmutableList.builder();

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code StorageHistoryResponse} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * Collection elements and entries will be added, not replaced.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(StorageHistoryResponse instance) {
      Objects.requireNonNull(instance, "instance");
      addAllItems(instance.items());
      return this;
    }

    /**
     * Adds one element to {@link StorageHistoryResponse#items() items} list.
     * @param element A items element
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addItems(StorageHistoryItem element) {
      this.items.add(element);
      return this;
    }

    /**
     * Adds elements to {@link StorageHistoryResponse#items() items} list.
     * @param elements An array of items elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addItems(StorageHistoryItem... elements) {
      this.items.add(elements);
      return this;
    }


    /**
     * Sets or replaces all elements for {@link StorageHistoryResponse#items() items} list.
     * @param elements An iterable of items elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder items(Iterable<? extends StorageHistoryItem> elements) {
      this.items = ImmutableList.builder();
      return addAllItems(elements);
    }

    /**
     * Adds elements to {@link StorageHistoryResponse#items() items} list.
     * @param elements An iterable of items elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addAllItems(Iterable<? extends StorageHistoryItem> elements) {
      this.items.addAll(elements);
      return this;
    }

    /**
     * Builds a new {@link ImmutableStorageHistoryResponse ImmutableStorageHistoryResponse}.
     * @return An immutable instance of StorageHistoryResponse
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableStorageHistoryResponse build() {
      return new ImmutableStorageHistoryResponse(items.build());
    }
  }
}
