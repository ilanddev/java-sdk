/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification.types;

import static com.google.common.base.Preconditions.checkArgument;

import java.io.Serial;
import java.util.Optional;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.notification.Alert;
import com.iland.core.api.notification.AlertDeliverySpec;
import com.iland.core.api.notification.AlertType;
import com.iland.core.api.util.ByteUnit;

/**
 * Advanced Backups Storage Alert.
 */
public final class AdvancedBackupsAlertTrigger extends Alert {

	@Serial
	private static final long serialVersionUID = 347561020247043313L;

	private static final Set<AlertType> SUPPORTED_ALERT_TYPES =
		Set.of(AlertType.advanced_backups_burst);

	public static final String VDC_UUID = "vdc_uuid";

	public static final String UNIT = "unit";

	public static final String THRESHOLD = "threshold";

	@Expose
	@Since(1.0)
	@SerializedName("entity_uuid")
	private String vdcUuid;

	@Expose
	@Since(1.0)
	@SerializedName("unit")
	private final String unit;

	@Expose
	@Since(1.0)
	@SerializedName("alert_threshold")
	private final int threshold;

	public AdvancedBackupsAlertTrigger(final String uuid, final String username,
		final AlertDeliverySpec deliverySpec, final boolean enabled,
		final AlertType alertType, final String vdcUuid, final String unit,
		final int threshold) {
		super(uuid, username, deliverySpec, enabled, alertType);
		checkArgument(SUPPORTED_ALERT_TYPES.contains(alertType),
			"unsupported alert type");
		this.vdcUuid = vdcUuid;
		this.unit = ByteUnit.fromValue(unit)
			.orElseThrow(() -> new IllegalArgumentException(
				"unit %s is not supported".formatted(unit)))
			.name();
		this.threshold = threshold;
	}

	public AdvancedBackupsAlertTrigger(final String uuid,
		final AdvancedBackupsAlertTrigger a, final AlertType alertType) {
		super(uuid, a.getUsername(), a.getDeliverySpec(), a.isEnabled(),
			alertType);
		checkArgument(SUPPORTED_ALERT_TYPES.contains(alertType),
			"unsupported alert type");
		this.vdcUuid = a.getVdcUuid();
		this.unit = Optional.of(a)
			.map(AdvancedBackupsAlertTrigger::getUnit)
			.flatMap(ByteUnit::fromValue)
			.orElseThrow(() -> new IllegalArgumentException(
				"unit %s is not supported".formatted(a.getUnit())))
			.name();
		this.threshold = a.getThreshold();
	}

	@Override
	public String getEntityUuid() {
		return getVdcUuid();
	}

	/**
	 * Get the VDC UUID.
	 *
	 * @return VDC UUID
	 */
	public String getVdcUuid() {
		return vdcUuid;
	}

	/**
	 * Get the unit, e.g. "%" or "GB" or "GiB".
	 *
	 * @return the {@link String unit}
	 */
	public String getUnit() {
		return unit;
	}

	/**
	 * Get the severity threshold as a percentage, e.g. {@literal 70} means "70%" or greater.
	 *
	 * @return {@link int} severity threshold
	 */
	public int getThreshold() {
		return threshold;
	}

}
