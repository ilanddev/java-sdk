/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import com.google.common.base.MoreObjects;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link HeliosTenantId}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableHeliosTenantId.builder()}.
 */
@Generated(from = "HeliosTenantId", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableHeliosTenantId implements HeliosTenantId {
  private final String id;
  private final CompanyId companyId;

  private ImmutableHeliosTenantId(String id, CompanyId companyId) {
    this.id = id;
    this.companyId = companyId;
  }

  /**
   * @return The value of the {@code id} attribute
   */
  @Override
  public String id() {
    return id;
  }

  /**
   * @return The value of the {@code companyId} attribute
   */
  @Override
  public CompanyId companyId() {
    return companyId;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link HeliosTenantId#id() id} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for id
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableHeliosTenantId withId(String value) {
    String newValue = Objects.requireNonNull(value, "id");
    if (this.id.equals(newValue)) return this;
    return new ImmutableHeliosTenantId(newValue, this.companyId);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link HeliosTenantId#companyId() companyId} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for companyId
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableHeliosTenantId withCompanyId(CompanyId value) {
    if (this.companyId == value) return this;
    CompanyId newValue = Objects.requireNonNull(value, "companyId");
    return new ImmutableHeliosTenantId(this.id, newValue);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableHeliosTenantId} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableHeliosTenantId
        && equalsByValue((ImmutableHeliosTenantId) another);
  }

  private boolean equalsByValue(ImmutableHeliosTenantId another) {
    return id.equals(another.id)
        && companyId.equals(another.companyId);
  }

  /**
   * Computes a hash code from attributes: {@code id}, {@code companyId}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + id.hashCode();
    h += (h << 5) + companyId.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code HeliosTenantId} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("HeliosTenantId")
        .omitNullValues()
        .add("id", id)
        .add("companyId", companyId)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link HeliosTenantId} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable HeliosTenantId instance
   */
  public static ImmutableHeliosTenantId copyOf(HeliosTenantId instance) {
    if (instance instanceof ImmutableHeliosTenantId) {
      return (ImmutableHeliosTenantId) instance;
    }
    return ImmutableHeliosTenantId.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableHeliosTenantId ImmutableHeliosTenantId}.
   * <pre>
   * ImmutableHeliosTenantId.builder()
   *    .id(String) // required {@link HeliosTenantId#id() id}
   *    .companyId(com.iland.offsite.replication.api.model.CompanyId) // required {@link HeliosTenantId#companyId() companyId}
   *    .build();
   * </pre>
   * @return A new ImmutableHeliosTenantId builder
   */
  public static ImmutableHeliosTenantId.Builder builder() {
    return new ImmutableHeliosTenantId.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableHeliosTenantId ImmutableHeliosTenantId}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "HeliosTenantId", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_ID = 0x1L;
    private static final long INIT_BIT_COMPANY_ID = 0x2L;
    private long initBits = 0x3L;

    private @Nullable String id;
    private @Nullable CompanyId companyId;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code HeliosTenantId} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(HeliosTenantId instance) {
      Objects.requireNonNull(instance, "instance");
      this.id(instance.id());
      this.companyId(instance.companyId());
      return this;
    }

    /**
     * Initializes the value for the {@link HeliosTenantId#id() id} attribute.
     * @param id The value for id 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder id(String id) {
      this.id = Objects.requireNonNull(id, "id");
      initBits &= ~INIT_BIT_ID;
      return this;
    }

    /**
     * Initializes the value for the {@link HeliosTenantId#companyId() companyId} attribute.
     * @param companyId The value for companyId 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder companyId(CompanyId companyId) {
      this.companyId = Objects.requireNonNull(companyId, "companyId");
      initBits &= ~INIT_BIT_COMPANY_ID;
      return this;
    }

    /**
     * Builds a new {@link ImmutableHeliosTenantId ImmutableHeliosTenantId}.
     * @return An immutable instance of HeliosTenantId
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableHeliosTenantId build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableHeliosTenantId(id, companyId);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_ID) != 0) attributes.add("id");
      if ((initBits & INIT_BIT_COMPANY_ID) != 0) attributes.add("companyId");
      return "Cannot build HeliosTenantId, some of required attributes are not set " + attributes;
    }
  }
}
