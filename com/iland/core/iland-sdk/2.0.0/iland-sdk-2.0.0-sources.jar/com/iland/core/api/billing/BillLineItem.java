/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Bill Line Item.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class BillLineItem implements Serializable {

  private static final long serialVersionUID = -8343041413567742273L;

  @Expose
  @SerializedName(BillLineItemField.NAME)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final String name;

  @Expose
  @SerializedName(BillLineItemField.PRICE)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final double cost;

  @Expose
  @SerializedName(BillLineItemField.QUANTITY)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final double quantity;

  @Expose
  @SerializedName(BillLineItemField.PRODUCT_ID)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final String productId;

  @Expose
  @SerializedName(BillLineItemField.VDC_UUID)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final String vdcUuid;

  @Expose
  @SerializedName(BillLineItemField.CONTRACT_ID)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final String contractId;

  public BillLineItem(final String name, final double cost,
      final double quantity, final String productId, final String vdcUuid,
      final String contractId) {
    this.name = name;
    this.cost = cost;
    this.quantity = quantity;
    this.productId = productId;
    this.vdcUuid = vdcUuid;
    this.contractId = contractId;
  }

  /**
   * Get the line item name.
   *
   * @return {@link String} item name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the line item cost.
   *
   * @return item cost
   */
  public double getCost() {
    return cost;
  }

  /**
   * Get the quantity of an item.
   *
   * @return item quantity
   */
  public double getQuantity() {
    return quantity;
  }

  /**
   * Get the item's Salesforce product id
   *
   * @return product id
   */
  public String getProductId() {
    return productId;
  }

  /**
   * Gets the associated vDC UUID.
   *
   * @return vdc uuid
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Gets the associated contract ID.
   *
   * @return contract id
   */
  public String getContractId() {
    return contractId;
  }
}
