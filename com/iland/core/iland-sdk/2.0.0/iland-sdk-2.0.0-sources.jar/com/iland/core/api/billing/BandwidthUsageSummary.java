/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Bandwidth Usage Summary.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public class BandwidthUsageSummary implements Serializable {

  private static final long serialVersionUID = -9553278388270122L;

  @Since(ApiVersion.ZERO_DOT_NINE)
  @Expose
  @SerializedName(BandwidthUsageSummaryField.RESERVED_AMOUNT)
  private final double reservedAmount;

  @Since(ApiVersion.ZERO_DOT_NINE)
  @Expose
  @SerializedName(BandwidthUsageSummaryField.TOTAL_USAGE)
  private final double totalUsage;

  @Since(ApiVersion.ZERO_DOT_NINE)
  @Expose
  @SerializedName(BandwidthUsageSummaryField.BURST_USAGE)
  private final double burstUsage;

  @Since(ApiVersion.ZERO_DOT_NINE)
  @Expose
  @SerializedName(BandwidthUsageSummaryField.MONTH)
  private final int month;

  @Since(ApiVersion.ZERO_DOT_NINE)
  @Expose
  @SerializedName(BandwidthUsageSummaryField.YEAR)
  private final int year;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(BandwidthUsageSummaryField.BILLING_MODEL_TYPE)
  private final BillingModelType billingModelType;

  public BandwidthUsageSummary(final double reservedAmount,
      final double totalUsage, final double burstUsage, final int month,
      final int year, final BillingModelType billingModelType) {
    this.reservedAmount = reservedAmount;
    this.totalUsage = totalUsage;
    this.burstUsage = burstUsage;
    this.month = month;
    this.year = year;
    this.billingModelType = billingModelType;
  }

  /**
   * Get reserved bandwidth amount in GB.
   *
   * @return reserved bandwidth amount
   */
  public double getReservedAmount() {
    return reservedAmount;
  }

  /**
   * Get total bandwidth usage in GB.
   *
   * @return total bandwidth usage
   */
  public double getTotalUsage() {
    return totalUsage;
  }

  /**
   * Get burst usage in GB.
   *
   * @return burst bandwidth usage
   */
  public double getBurstUsage() {
    return burstUsage;
  }

  /**
   * Get bandwidth summary's month.
   *
   * @return month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Get bandwidth summary's year.
   *
   * @return year
   */
  public int getYear() {
    return year;
  }

  /**
   * Returns the billing model type for the month the bandwidth summary
   * corresponds to.
   *
   * @return one of {@link BillingModelType}
   */
  public BillingModelType getBillingModelType() {
    return billingModelType;
  }

}
