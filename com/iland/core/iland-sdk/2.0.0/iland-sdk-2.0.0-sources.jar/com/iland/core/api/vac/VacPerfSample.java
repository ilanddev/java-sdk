/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vac;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;

import javax.annotation.Nonnull;

import com.google.gson.annotations.SerializedName;

/**
 * VacPerfSample.
 *
 * @author <a href="mailto:nkapsrzak@iland.com">Nick Kasprzak</a>
 */
public class VacPerfSample implements Serializable {

  private static final long serialVersionUID = 4900859619335376529L;

  protected static final String TIMESTAMP_MUST_BE_NON_NULL =
      "Timestamp on VAC perf samples must be non-null.";

  protected static final String CANNOT_AGGREGATE_WITH_DIFFERING_TIMESTAMPS =
      "Cannot aggregeate VAC perf samples with differing timestamps.";

  protected static final String MUST_HAVE_ATLEAST_ONE_SAMPLE_FOR_AVERAGE =
      "Must have at least one sample to get an average samples.";

  @SerializedName(VacPerfSampleField.USED_QUOTA)
  private long usedQuota;

  @SerializedName(VacPerfSampleField.QUOTA)
  private long quota;

  @SerializedName(VacPerfSampleField.TIME)
  private Instant time;

  /**
   * Instantiates a new Vac perf sample.
   *
   * @param usedQuota the used quota
   * @param quota     the quota
   * @param time      the time
   */
  public VacPerfSample(final long usedQuota, final long quota,
      final Instant time) {
    this.usedQuota = usedQuota;
    this.quota = quota;
    this.time = time;
  }

  /**
   * Gets used quota in megabytes (MB).
   *
   * @return the used quota
   */
  public long getUsedQuota() {
    return usedQuota;
  }

  /**
   * Gets quota in megabytes (MB).
   *
   * @return the quota
   */
  public long getQuota() {
    return quota;
  }

  /**
   * Gets time.
   *
   * @return the time
   */
  public Instant getTime() {
    return time;
  }

  /**
   * Set the used quota.
   *
   * @param usedQuota used quota
   */
  public void setUsedQuota(final long usedQuota) {
    this.usedQuota = usedQuota;
  }

  /**
   * Aggregate the list of {@link VacPerfSample} into one sample.
   *
   * @param samples {@link List} of {@link VacPerfSample} perf samples
   * @return {@link VacPerfSample} aggregated sample
   */
  @Nonnull
  public static VacPerfSample getAggregatedPerf(
      @Nonnull final List<VacPerfSample> samples) {
    if (samples.isEmpty()) {
      return new VacPerfSample(0, 0, Instant.now());
    }
    long quota = 0;
    long usedQuota = 0;
    final Instant ts = samples.get(0).getTime();
    if (ts == null) {
      throw new IllegalArgumentException(TIMESTAMP_MUST_BE_NON_NULL);
    }
    for (final VacPerfSample p : samples) {
      quota += p.getQuota();
      usedQuota += p.getUsedQuota();
      if (!ts.equals(p.getTime())) {
        throw new IllegalArgumentException(
            CANNOT_AGGREGATE_WITH_DIFFERING_TIMESTAMPS);
      }
    }
    return new VacPerfSample(usedQuota, quota, ts);
  }

  /**
   * Calculate average performance for a PerfSampleSerie over a certain interval
   * of time.
   *
   * @param samples a {@link List} of {@link VacPerfSample} instance to
   *                calculate average for
   * @return an {@link VacPerfSample} with average value
   */
  @Nonnull
  public static VacPerfSample getAvgPerfFor(
      @Nonnull final List<VacPerfSample> samples) {
    if (samples.isEmpty()) {
      throw new IllegalArgumentException(
          MUST_HAVE_ATLEAST_ONE_SAMPLE_FOR_AVERAGE);
    }
    long quota = 0;
    long usedQuota = 0;
    for (final VacPerfSample p : samples) {
      quota += p.getQuota();
      usedQuota += p.getUsedQuota();
    }
    // Ignore fractional part
    final long averageQuota = quota / samples.size();
    final long averateUsedQuota = usedQuota / samples.size();

    // create a new PerfSample with timestamp of latest sample (they are
    // returned in ASC order)
    return new VacPerfSample(averateUsedQuota, averageQuota,
        samples.get(samples.size() - 1).getTime());
  }

}
