/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.trend;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.util.IlandSerializedName;

/**
 * Log Inspection Event.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class LogInspectionEvent implements Serializable {

  private static final long serialVersionUID = 7990452759921946769L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.VM_UUID)
  private String vmUuid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.ACTION)
  private String action;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.COMMAND)
  private String command;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.DATA)
  private String data;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.DESCRIPTION)
  private String description;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.DESTINATION_IP)
  private String destinationIp;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.DESTINATION_PORT)
  private String destinationPort;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.DESTINATION_USER)
  private String destinationUser;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.FULL_EVENT)
  private String fullEvent;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.GROUPS)
  private String groups;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.HOST_ID)
  private int hostId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.HOST_NAME)
  private String hostName;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.LOCATION)
  private String location;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.EVENT_ID)
  private Long eventId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.RULE_ID)
  private int ruleId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.LOG_TIME)
  private Calendar logTime;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.MESSAGE)
  private String message;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.PROGRAM_NAME)
  private String programName;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.PROTOCOL)
  private String protocol;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.RANK)
  private int rank;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.REASON)
  private String reason;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.SEVERITY)
  private String severity;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.SOURCE_HOST_NAME)
  private String sourceHostName;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.SOURCE_ID)
  private String sourceId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.SOURCE_IP)
  private String sourceIp;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.SOURCE_PORT)
  private String sourcePort;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.SOURCE_USER)
  private String sourceUser;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.STATUS)
  private String status;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.SYSTEM_NAME)
  private String systemName;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.TAGS)
  private String tags;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(LogInspectionEventField.URL)
  private String url;

  /**
   * Instantiates a new Log inspection event.
   */
  public LogInspectionEvent() {
  }

  /**
   * Get the VM uuid.
   *
   * @return vm uuid
   */
  public String getVmUuid() {
    return vmUuid;
  }

  /**
   * Set the VM uuid.
   *
   * @param vmUuid vm uuid
   */
  public void setVmUuid(final String vmUuid) {
    this.vmUuid = vmUuid;
  }

  /**
   * Get the action.
   *
   * @return action
   */
  public String getAction() {
    return action;
  }

  /**
   * Set the action.
   *
   * @param action action
   */
  public void setAction(final String action) {
    this.action = action;
  }

  /**
   * Get the command.
   *
   * @return command
   */
  public String getCommand() {
    return command;
  }

  /**
   * Set the command.
   *
   * @param command command
   */
  public void setCommand(final String command) {
    this.command = command;
  }

  /**
   * Get the data.
   *
   * @return data
   */
  public String getData() {
    return data;
  }

  /**
   * Set the data.
   *
   * @param data data
   */
  public void setData(final String data) {
    this.data = data;
  }

  /**
   * Get the description.
   *
   * @return description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Set the description.
   *
   * @param description description
   */
  public void setDescription(final String description) {
    this.description = description;
  }

  /**
   * Get the destination IP.
   *
   * @return destination IP
   */
  public String getDestinationIp() {
    return destinationIp;
  }

  /**
   * Set the destination IP.
   *
   * @param destinationIp destination IP
   */
  public void setDestinationIp(final String destinationIp) {
    this.destinationIp = destinationIp;
  }

  /**
   * Get the destination port.
   *
   * @return destination port
   */
  public String getDestinationPort() {
    return destinationPort;
  }

  /**
   * Set the destination port.
   *
   * @param destinationPort destination port
   */
  public void setDestinationPort(final String destinationPort) {
    this.destinationPort = destinationPort;
  }

  /**
   * Get the destination user.
   *
   * @return destination user
   */
  public String getDestinationUser() {
    return destinationUser;
  }

  /**
   * Set the destination user.
   *
   * @param destinationUser destination user
   */
  public void setDestinationUser(final String destinationUser) {
    this.destinationUser = destinationUser;
  }

  /**
   * Get the full event.
   *
   * @return full event
   */
  public String getFullEvent() {
    return fullEvent;
  }

  /**
   * Set the full event.
   *
   * @param fullEvent full event
   */
  public void setFullEvent(final String fullEvent) {
    this.fullEvent = fullEvent;
  }

  /**
   * Gets groups.
   *
   * @return the groups
   */
  public String getGroups() {
    return groups;
  }

  /**
   * Sets groups.
   *
   * @param groups the groups
   */
  public void setGroups(final String groups) {
    this.groups = groups;
  }

  /**
   * Gets host id.
   *
   * @return the host id
   */
  public int getHostId() {
    return hostId;
  }

  /**
   * Sets host id.
   *
   * @param hostId the host id
   */
  public void setHostId(final int hostId) {
    this.hostId = hostId;
  }

  /**
   * Gets host name.
   *
   * @return the host name
   */
  public String getHostName() {
    return hostName;
  }

  /**
   * Sets host name.
   *
   * @param hostName the host name
   */
  public void setHostName(final String hostName) {
    this.hostName = hostName;
  }

  /**
   * Gets location.
   *
   * @return the location
   */
  public String getLocation() {
    return location;
  }

  /**
   * Sets location.
   *
   * @param location the location
   */
  public void setLocation(final String location) {
    this.location = location;
  }

  /**
   * Gets event id.
   *
   * @return the event id
   */
  public Long getEventId() {
    return eventId;
  }

  /**
   * Sets event id.
   *
   * @param eventId the event id
   */
  public void setEventId(final Long eventId) {
    this.eventId = eventId;
  }

  /**
   * Gets rule id.
   *
   * @return the rule id
   */
  public int getRuleId() {
    return ruleId;
  }

  /**
   * Sets rule id.
   *
   * @param ruleId the rule id
   */
  public void setRuleId(final int ruleId) {
    this.ruleId = ruleId;
  }

  /**
   * Gets log time.
   *
   * @return the log time
   */
  public Calendar getLogTime() {
    if (logTime == null) {
      final Calendar defaultDate = Calendar.getInstance();
      defaultDate.setTime(new Date(0));
      return defaultDate;
    }
    return logTime;
  }

  /**
   * Sets log time.
   *
   * @param logTime the log time
   */
  public void setLogTime(final Calendar logTime) {
    this.logTime = logTime;
  }

  /**
   * Gets message.
   *
   * @return the message
   */
  public String getMessage() {
    return message;
  }

  /**
   * Sets message.
   *
   * @param message the message
   */
  public void setMessage(final String message) {
    this.message = message;
  }

  /**
   * Gets program name.
   *
   * @return the program name
   */
  public String getProgramName() {
    return programName;
  }

  /**
   * Sets program name.
   *
   * @param programName the program name
   */
  public void setProgramName(final String programName) {
    this.programName = programName;
  }

  /**
   * Gets protocol.
   *
   * @return the protocol
   */
  public String getProtocol() {
    return protocol;
  }

  /**
   * Sets protocol.
   *
   * @param protocol the protocol
   */
  public void setProtocol(final String protocol) {
    this.protocol = protocol;
  }

  /**
   * Gets rank.
   *
   * @return the rank
   */
  public int getRank() {
    return rank;
  }

  /**
   * Sets rank.
   *
   * @param rank the rank
   */
  public void setRank(final int rank) {
    this.rank = rank;
  }

  /**
   * Gets reason.
   *
   * @return the reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * Sets reason.
   *
   * @param reason the reason
   */
  public void setReason(final String reason) {
    this.reason = reason;
  }

  /**
   * Gets severity.
   *
   * @return the severity
   */
  public String getSeverity() {
    return severity;
  }

  /**
   * Sets severity.
   *
   * @param severity the severity
   */
  public void setSeverity(final String severity) {
    this.severity = severity;
  }

  /**
   * Gets source host name.
   *
   * @return the source host name
   */
  public String getSourceHostName() {
    return sourceHostName;
  }

  /**
   * Sets source host name.
   *
   * @param sourceHostName the source host name
   */
  public void setSourceHostName(final String sourceHostName) {
    this.sourceHostName = sourceHostName;
  }

  /**
   * Gets source id.
   *
   * @return the source id
   */
  public String getSourceId() {
    return sourceId;
  }

  /**
   * Sets source id.
   *
   * @param sourceId the source id
   */
  public void setSourceId(final String sourceId) {
    this.sourceId = sourceId;
  }

  /**
   * Gets source ip.
   *
   * @return the source ip
   */
  public String getSourceIp() {
    return sourceIp;
  }

  /**
   * Sets source ip.
   *
   * @param sourceIp the source ip
   */
  public void setSourceIp(final String sourceIp) {
    this.sourceIp = sourceIp;
  }

  /**
   * Gets source port.
   *
   * @return the source port
   */
  public String getSourcePort() {
    return sourcePort;
  }

  /**
   * Sets source port.
   *
   * @param sourcePort the source port
   */
  public void setSourcePort(final String sourcePort) {
    this.sourcePort = sourcePort;
  }

  /**
   * Gets source user.
   *
   * @return the source user
   */
  public String getSourceUser() {
    return sourceUser;
  }

  /**
   * Sets source user.
   *
   * @param sourceUser the source user
   */
  public void setSourceUser(final String sourceUser) {
    this.sourceUser = sourceUser;
  }

  /**
   * Gets status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Sets status.
   *
   * @param status the status
   */
  public void setStatus(final String status) {
    this.status = status;
  }

  /**
   * Gets system name.
   *
   * @return the system name
   */
  public String getSystemName() {
    return systemName;
  }

  /**
   * Sets system name.
   *
   * @param systemName the system name
   */
  public void setSystemName(final String systemName) {
    this.systemName = systemName;
  }

  /**
   * Gets tags.
   *
   * @return the tags
   */
  public String getTags() {
    return tags;
  }

  /**
   * Sets tags.
   *
   * @param tags the tags
   */
  public void setTags(final String tags) {
    this.tags = tags;
  }

  /**
   * Gets url.
   *
   * @return the url
   */
  public String getUrl() {
    return url;
  }

  /**
   * Sets url.
   *
   * @param url the url
   */
  public void setUrl(final String url) {
    this.url = url;
  }

}
