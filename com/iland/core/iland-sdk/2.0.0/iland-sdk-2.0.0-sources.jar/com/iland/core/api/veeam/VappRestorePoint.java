/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;

/**
 * VappRestorePoint.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class VappRestorePoint implements Serializable {

  private static final long serialVersionUID = 596402003780224590L;

  @XmlAttribute(name = "Href")
  private String href;

  @XmlAttribute(name = "Name")
  private String name;

  @XmlAttribute(name = "UID")
  private String uid;

  @XmlElement(name = "Links")
  private VeeamLinks links;

  public VappRestorePoint() {
  }

  public VappRestorePoint(final String href, final String name,
      final String uid, final VeeamLinks links) {
    this.href = href;
    this.name = name;
    this.uid = uid;
    this.links = links;
  }

  /**
   * Get the href.
   *
   * @return href
   */
  public String getHref() {
    return href;
  }

  /**
   * Get the retore point name.
   *
   * @return name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the ID.
   *
   * @return restore point ID
   */
  public String getUid() {
    return uid;
  }

  /**
   * Get associated links.
   *
   * @return {@link VeeamLinks} links
   */
  public VeeamLinks getLinks() {
    return links;
  }

}
