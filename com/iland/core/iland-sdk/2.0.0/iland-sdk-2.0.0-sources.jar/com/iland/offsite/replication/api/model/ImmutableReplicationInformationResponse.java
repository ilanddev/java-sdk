/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableList;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link ReplicationInformationResponse}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableReplicationInformationResponse.builder()}.
 */
@Generated(from = "ReplicationInformationResponse", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableReplicationInformationResponse
    implements ReplicationInformationResponse {
  private final ReplicationData replicationData;
  private final ImmutableList<JobReplicationData> jobReplicationData;

  private ImmutableReplicationInformationResponse(
      ReplicationData replicationData,
      ImmutableList<JobReplicationData> jobReplicationData) {
    this.replicationData = replicationData;
    this.jobReplicationData = jobReplicationData;
  }

  /**
   * @return The value of the {@code replicationData} attribute
   */
  @Override
  public ReplicationData replicationData() {
    return replicationData;
  }

  /**
   * @return The value of the {@code jobReplicationData} attribute
   */
  @Override
  public ImmutableList<JobReplicationData> jobReplicationData() {
    return jobReplicationData;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ReplicationInformationResponse#replicationData() replicationData} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for replicationData
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableReplicationInformationResponse withReplicationData(ReplicationData value) {
    if (this.replicationData == value) return this;
    ReplicationData newValue = Objects.requireNonNull(value, "replicationData");
    return new ImmutableReplicationInformationResponse(newValue, this.jobReplicationData);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link ReplicationInformationResponse#jobReplicationData() jobReplicationData}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final ImmutableReplicationInformationResponse withJobReplicationData(JobReplicationData... elements) {
    ImmutableList<JobReplicationData> newValue = ImmutableList.copyOf(elements);
    return new ImmutableReplicationInformationResponse(this.replicationData, newValue);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link ReplicationInformationResponse#jobReplicationData() jobReplicationData}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of jobReplicationData elements to set
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableReplicationInformationResponse withJobReplicationData(Iterable<? extends JobReplicationData> elements) {
    if (this.jobReplicationData == elements) return this;
    ImmutableList<JobReplicationData> newValue = ImmutableList.copyOf(elements);
    return new ImmutableReplicationInformationResponse(this.replicationData, newValue);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableReplicationInformationResponse} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableReplicationInformationResponse
        && equalsByValue((ImmutableReplicationInformationResponse) another);
  }

  private boolean equalsByValue(ImmutableReplicationInformationResponse another) {
    return replicationData.equals(another.replicationData)
        && jobReplicationData.equals(another.jobReplicationData);
  }

  /**
   * Computes a hash code from attributes: {@code replicationData}, {@code jobReplicationData}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + replicationData.hashCode();
    h += (h << 5) + jobReplicationData.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code ReplicationInformationResponse} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("ReplicationInformationResponse")
        .omitNullValues()
        .add("replicationData", replicationData)
        .add("jobReplicationData", jobReplicationData)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link ReplicationInformationResponse} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ReplicationInformationResponse instance
   */
  public static ImmutableReplicationInformationResponse copyOf(ReplicationInformationResponse instance) {
    if (instance instanceof ImmutableReplicationInformationResponse) {
      return (ImmutableReplicationInformationResponse) instance;
    }
    return ImmutableReplicationInformationResponse.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableReplicationInformationResponse ImmutableReplicationInformationResponse}.
   * <pre>
   * ImmutableReplicationInformationResponse.builder()
   *    .replicationData(com.iland.offsite.replication.api.model.ReplicationData) // required {@link ReplicationInformationResponse#replicationData() replicationData}
   *    .addJobReplicationData|addAllJobReplicationData(com.iland.offsite.replication.api.model.JobReplicationData) // {@link ReplicationInformationResponse#jobReplicationData() jobReplicationData} elements
   *    .build();
   * </pre>
   * @return A new ImmutableReplicationInformationResponse builder
   */
  public static ImmutableReplicationInformationResponse.Builder builder() {
    return new ImmutableReplicationInformationResponse.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableReplicationInformationResponse ImmutableReplicationInformationResponse}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "ReplicationInformationResponse", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_REPLICATION_DATA = 0x1L;
    private long initBits = 0x1L;

    private @Nullable ReplicationData replicationData;
    private ImmutableList.Builder<JobReplicationData> jobReplicationData = ImmutableList.builder();

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code ReplicationInformationResponse} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * Collection elements and entries will be added, not replaced.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(ReplicationInformationResponse instance) {
      Objects.requireNonNull(instance, "instance");
      this.replicationData(instance.replicationData());
      addAllJobReplicationData(instance.jobReplicationData());
      return this;
    }

    /**
     * Initializes the value for the {@link ReplicationInformationResponse#replicationData() replicationData} attribute.
     * @param replicationData The value for replicationData 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder replicationData(ReplicationData replicationData) {
      this.replicationData = Objects.requireNonNull(replicationData, "replicationData");
      initBits &= ~INIT_BIT_REPLICATION_DATA;
      return this;
    }

    /**
     * Adds one element to {@link ReplicationInformationResponse#jobReplicationData() jobReplicationData} list.
     * @param element A jobReplicationData element
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addJobReplicationData(JobReplicationData element) {
      this.jobReplicationData.add(element);
      return this;
    }

    /**
     * Adds elements to {@link ReplicationInformationResponse#jobReplicationData() jobReplicationData} list.
     * @param elements An array of jobReplicationData elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addJobReplicationData(JobReplicationData... elements) {
      this.jobReplicationData.add(elements);
      return this;
    }


    /**
     * Sets or replaces all elements for {@link ReplicationInformationResponse#jobReplicationData() jobReplicationData} list.
     * @param elements An iterable of jobReplicationData elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder jobReplicationData(Iterable<? extends JobReplicationData> elements) {
      this.jobReplicationData = ImmutableList.builder();
      return addAllJobReplicationData(elements);
    }

    /**
     * Adds elements to {@link ReplicationInformationResponse#jobReplicationData() jobReplicationData} list.
     * @param elements An iterable of jobReplicationData elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addAllJobReplicationData(Iterable<? extends JobReplicationData> elements) {
      this.jobReplicationData.addAll(elements);
      return this;
    }

    /**
     * Builds a new {@link ImmutableReplicationInformationResponse ImmutableReplicationInformationResponse}.
     * @return An immutable instance of ReplicationInformationResponse
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableReplicationInformationResponse build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableReplicationInformationResponse(replicationData, jobReplicationData.build());
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_REPLICATION_DATA) != 0) attributes.add("replicationData");
      return "Cannot build ReplicationInformationResponse, some of required attributes are not set " + attributes;
    }
  }
}
