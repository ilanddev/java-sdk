/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.utils;

import static java.util.Objects.requireNonNull;
import static java.util.function.Function.identity;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * {@link EnumMapper} maps one enum value to another using customizable
 * conventions.
 *
 * @author <a href="mailto:tspilman@iland.com">Tag Spilman</a>
 */
public final class EnumMapper {

	private EnumMapper() {
	}

	/**
	 * Maps one enum to another using by matching the names exactly.
	 *
	 * @param fromEnum    an enum object
	 * @param toEnumClass the enum class to map to
	 * @param <FromEnum>  the from-enum class
	 * @param <ToEnum>    the to-enum class
	 * @return an {@link Optional optional} enum object of type {@link ToEnum}
	 */
	public static <FromEnum extends Enum<?>, ToEnum extends Enum<?>> Optional<ToEnum> mapExact(
		final FromEnum fromEnum, final Class<ToEnum> toEnumClass) {
		return map(fromEnum, toEnumClass, identity(), String::compareTo);
	}

	/**
	 * Maps one enum to another. The to-enum value is determined to be equivalent
	 * if the from-name (in lower case) contains the to-name (in lower case) or
	 * vice versa.
	 *
	 * @param fromEnum    an enum object
	 * @param toEnumClass the enum class to map to
	 * @param <FromEnum>  the from-enum class
	 * @param <ToEnum>    the to-enum class
	 * @return an {@link Optional optional} enum object of type {@link ToEnum}
	 */
	public static <FromEnum extends Enum<?>, ToEnum extends Enum<?>> Optional<ToEnum> mapLoose(
		final FromEnum fromEnum, final Class<ToEnum> toEnumClass) {
		return map(fromEnum, toEnumClass, String::toLowerCase,
			EnumMapper::containsComparator);
	}

	/**
	 * Maps one enum to another. The to-enum value is determined to be equivalent
	 * if the from-name (in lower case) contains the to-name (in lower case) or
	 * vice versa.
	 *
	 * @param fromEnum    an enum object
	 * @param toEnumClass the enum class to map to
	 * @param <FromEnum>  the from-enum class
	 * @param <ToEnum>    the to-enum class
	 * @return an enum object of type {@link ToEnum}
	 * @throws IllegalArgumentException if no match is found
	 */
	public static <FromEnum extends Enum<?>, ToEnum extends Enum<?>> ToEnum mapLooseOrThrow(
		final FromEnum fromEnum, final Class<ToEnum> toEnumClass) {
		return mapLoose(fromEnum, toEnumClass).orElseThrow(() -> {
			final String simpleName =
				toEnumClass.getSimpleName().replaceAll("Enum", "");
			final String[] classNameTokens = simpleName.split(
				"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])");
			final String humanReadableClassName = Stream.of(classNameTokens)
				.map(String::toLowerCase)
				.collect(Collectors.joining(" "));
			final String message =
				"Unrecognized %s: %s".formatted(humanReadableClassName,
					fromEnum.name());

			return new IllegalArgumentException(message);
		});
	}

	/**
	 * Maps one enum to another. The to-enum value is determined to be equivalent
	 * if the from-name (in lower case) contains the to-name (in lower case) or
	 * vice versa.
	 *
	 * @param fromEnum    an enum object
	 * @param toEnumClass the enum class to map to
	 * @param <FromEnum>  the from-enum class
	 * @param <ToEnum>    the to-enum class
	 * @return an enum object of type {@link ToEnum}
	 * @throws IllegalArgumentException if no match is found
	 */
	public static <FromEnum extends Enum<?>, ToEnum extends Enum<?>> ToEnum mapLooseOrThrow(
		final FromEnum fromEnum, final Class<ToEnum> toEnumClass,
		final String name) {
		return mapLoose(fromEnum, toEnumClass).orElseThrow(() -> {
			final String message =
				"Unrecognized %s: %s".formatted(name, fromEnum.name());

			return new IllegalArgumentException(message);
		});
	}

	/**
	 * @param fromEnum      an enum object
	 * @param toEnumClass   the enum class to map to
	 * @param nameFormatter the name formatter to be used prior to the equivalency
	 *                      check
	 * @param comparator    the comparator to be used for the equivalency check
	 * @param <FromEnum>    the from-enum class
	 * @param <ToEnum>      the to-enum class
	 * @return an {@link Optional optional} enum object of type {@link ToEnum}
	 */
	public static <FromEnum extends Enum<?>, ToEnum extends Enum<?>> Optional<ToEnum> map(
		final FromEnum fromEnum, final Class<ToEnum> toEnumClass,
		final Function<String, String> nameFormatter,
		final Comparator<String> comparator) {
		if (fromEnum == null) {
			return Optional.empty();
		}

		requireNonNull(toEnumClass, "toEnumClass must not be null");
		requireNonNull(nameFormatter, "nameFormatter must not be null");
		requireNonNull(comparator, "comparator must not be null");

		final String fromName = nameFormatter.apply(fromEnum.name());
		final ToEnum[] enumConstants = toEnumClass.getEnumConstants();
		return Arrays.stream(enumConstants).filter(toEnum -> {
			final String toName = nameFormatter.apply(toEnum.name());
			return comparator.compare(fromName, toName) == 0;
		}).findFirst();
	}

	/**
	 * Returns {@literal 0} if {@literal  a} contains {@literal  b} or vice versa,
	 * otherwise returns {@literal 1}.
	 *
	 * @param a a string
	 * @param b a string
	 * @return {@literal 0} if {@literal  a} contains {@literal  b} or vice versa,
	 * otherwise {@literal 1}
	 */
	public static int containsComparator(final String a, final String b) {
		return (a.contains(b) || b.contains(a)) ? 0 : 1;
	}

}
