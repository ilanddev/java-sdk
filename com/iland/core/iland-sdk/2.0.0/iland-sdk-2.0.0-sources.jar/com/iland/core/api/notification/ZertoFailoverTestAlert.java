/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.api.serialization.JsonRequired;

/**
 * Zerto Failover Test Alert.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class ZertoFailoverTestAlert implements Serializable {

  private static final long serialVersionUID = 7014323154667281745L;

  @Expose
  @JsonRequired("vpg uuid")
  @SerializedName(ZertoFailoverTestAlertField.VPG_UUID)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private String vpgUuid;

  @Expose
  @JsonRequired("username")
  @SerializedName(ZertoFailoverTestAlertField.USERNAME)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private String username;

  @Expose
  @JsonRequired("email address for alert")
  @SerializedName(ZertoFailoverTestAlertField.EMAIL)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private String email;

  @Expose
  @JsonRequired("number of weeks after the last test failover that an alert should be sent")
  @SerializedName(ZertoFailoverTestAlertField.WEEKS_BEFORE_ALERT)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private int weeksBeforeAlert;

  public ZertoFailoverTestAlert() {
  }

  public ZertoFailoverTestAlert(final String vpgUuid, final String username,
      final String email, final int weeksBeforeAlert) {
    this.vpgUuid = vpgUuid;
    this.username = username;
    this.email = email;
    this.weeksBeforeAlert = weeksBeforeAlert;
  }

  /**
   * Get the VPG uuid that the alert is for.
   *
   * @return {@link String} vpg uuid
   * @required
   */
  public String getVpgUuid() {
    return vpgUuid;
  }

  /**
   * Set the VPG uuid that the alert is for.
   *
   * @param vpgUuid {@link String} vpg uuid
   */
  public void setVpgUuid(final String vpgUuid) {
    this.vpgUuid = vpgUuid;
  }

  /**
   * Get the username that the alert is for.
   *
   * @return {@link String} username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Set the username the alert is for.
   *
   * @param username {@link String} username
   */
  public void setUsername(final String username) {
    this.username = username;
  }

  /**
   * Get the email associated with the alert.
   *
   * @return {@link String} email address
   */
  public String getEmail() {
    return email;
  }

  /**
   * Get the number of weeks that must elapse without a test failover before an
   * alert is emailed.
   *
   * @return weeks before alert after last test failover
   */
  public int getWeeksBeforeAlert() {
    return weeksBeforeAlert;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((email == null) ? 0 : email.hashCode());
    result = prime * result + ((username == null) ? 0 : username.hashCode());
    result = prime * result + ((vpgUuid == null) ? 0 : vpgUuid.hashCode());
    result = prime * result + weeksBeforeAlert;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ZertoFailoverTestAlert other = (ZertoFailoverTestAlert) obj;
    if (email == null) {
      if (other.email != null)
        return false;
    } else if (!email.equals(other.email))
      return false;
    if (username == null) {
      if (other.username != null)
        return false;
    } else if (!username.equals(other.username))
      return false;
    if (vpgUuid == null) {
      if (other.vpgUuid != null)
        return false;
    } else if (!vpgUuid.equals(other.vpgUuid))
      return false;
    if (weeksBeforeAlert != other.weeksBeforeAlert)
      return false;
    return true;
  }

}
