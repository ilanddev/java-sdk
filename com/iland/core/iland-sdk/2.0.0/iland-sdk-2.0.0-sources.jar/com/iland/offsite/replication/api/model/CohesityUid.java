/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * {@link EntityUid}. A UID for any entity with a cluster ID, cluster
 * incarnation ID, and entity ID, e.g. a protection group.
 */
public final class CohesityUid implements EntityUid {

	private static final Pattern PATTERN =
		Pattern.compile("(\\d+):(\\d+):(\\d+)");

	private final long clusterId;

	private final long clusterIncarnationId;

	private final long entityId;

	/**
	 * @return an instance of {@link EntityUid} where the clusterId, clusterIncarnationId, and entityId are all zero.
	 */
	public static CohesityUid newInstance() {
		return new CohesityUid(0L, 0L, 0L);
	}

	public static CohesityUid of(final String value) {
		final Matcher matcher = PATTERN.matcher(value);
		if (matcher.matches()) {
			final String clusterId = matcher.group(1);
			final String clusterIncarnationId = matcher.group(2);
			final String entityId = matcher.group(3);

			return new CohesityUid(Long.parseLong(clusterId),
				Long.parseLong(clusterIncarnationId), Long.parseLong(entityId));
		}

		throw new IllegalArgumentException("invalid cohesity uid: " + value);
	}

	private CohesityUid(final long clusterId, final long clusterIncarnationId,
		final long entityId) {
		this.clusterId = clusterId;
		this.clusterIncarnationId = clusterIncarnationId;
		this.entityId = entityId;
	}

	@Override
	public Long clusterId() {
		return clusterId;
	}

	@Override
	public Long clusterIncarnationId() {
		return clusterIncarnationId;
	}

	@Override
	public long entityId() {
		return entityId;
	}

	@Override
	public String toString() {
		return "%d:%d:%d".formatted(clusterId(), clusterIncarnationId(),
			entityId());
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o)
			return true;
		if (!(o instanceof final EntityUid that))
			return false;
		return clusterId == that.clusterId()
			&& clusterIncarnationId == that.clusterIncarnationId()
			&& entityId == that.entityId();
	}

	@Override
	public int hashCode() {
		return Objects.hash(clusterId, clusterIncarnationId, entityId);
	}

}
