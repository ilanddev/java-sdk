/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.coretask.api.domain;

import java.util.Collection;
import java.util.List;

/**
 * Core Task field mask paths.
 */
public final class CoreTaskPaths {

	public static final String crm = "crm";
	public static final String locationId = "locationId";
	public static final String taskId = "taskId";
	public static final String status = "status";
	public static final String operation = "operation";
	public static final String operationDescription = "operationDescription";
	public static final String active = "active";
	public static final String synced = "synced";
	public static final String message = "message";
	public static final String taskType = "taskType";
	public static final String entityUuid = "entityUuid";
	public static final String startTime = "startTime";
	public static final String endTime = "endTime";
	public static final String otherAttributes = "otherAttributes";
	public static final String orgUuid = "orgUuid";
	public static final String progress = "progress";
	public static final String username = "username";
	public static final String userFullName = "userFullName";
	public static final String parentTaskUuid = "parentTaskUuid";
	public static final String subTasks = "subTasks";
	public static final String initiatedFromEcs = "initiatedFromEcs";
	public static final String entityName = "entityName";
	public static final String systemUser = "systemUser";
	public static final String uuid = "uuid";
	public static final String initiationTime = "initiationTime";

	public static Collection<String> allPaths() {
		return List.of(crm, locationId, taskId, status, operation,
			operationDescription, active, synced, message, taskType, entityUuid,
			startTime, endTime, otherAttributes, orgUuid, progress, username,
			userFullName, parentTaskUuid, subTasks, initiatedFromEcs,
			entityName, systemUser, uuid, initiationTime);
	}

	private CoreTaskPaths() {
	}

}
