/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vac;

import java.time.Instant;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Nonnull;

import com.iland.common.entity.CommonEntityType;
import com.iland.core.api.entity.Entity;
import com.iland.core.api.entity.EntityUtil;
import com.iland.core.api.entity.LocationEntity;
import com.iland.core.api.iam.ProductType;
import com.iland.core.model.EntityType;

/**
 * VSPC Company.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public final class VspcCompany implements LocationEntity {

  public static final String VAC_CLOUD_TENANT_URN_PART = ":urn:vac:tenant:";

  private String name;

  private String locationId;

  private Instant lastActive;

  private String uuid;

  private boolean isEnabled;

  private String companyId;

  private boolean backupProtectionEnabled;

  private int backupProtectionPeriod;

  private int vmsBackedUp;

  private int vmsBackedUpToCloud;

  private long totalStorageQuota;

  private long usedStorageQuota;

  private String endpoint;

  private int agentAndSubTenantCount;

  private boolean isManagedByServiceProvider;

  private boolean isRepositoryStoredInAWS;

  private boolean isImmutabilityEnabled;

  private int immutabilityInterval;

  private boolean testDrive;

  private String contractUuid;

  private String href;

  private String siteUuid;

  private String backupRepoUid;

  private String companyUid;

  private String backupResourceUid;

  private String description;

  private Map<com.iland.common.entity.EntityType, String> ancestors;

  public VspcCompany(final VspcCompanySiteResourceBuilder builder) {
    this.name = builder.name;
    this.locationId = builder.locationId;
    this.lastActive = builder.lastActive;
    this.uuid = builder.uuid;
    this.isEnabled = builder.isEnabled;
    this.companyId = builder.companyId;
    this.backupProtectionEnabled = builder.backupProtectionEnabled;
    this.backupProtectionPeriod = builder.backupProtectionPeriod;
    this.vmsBackedUp = builder.vmsBackedUp;
    this.vmsBackedUpToCloud = builder.vmsBackedUpToCloud;
    this.totalStorageQuota = builder.totalStorageQuota;
    this.usedStorageQuota = builder.usedStorageQuota;
    this.endpoint = builder.endpoint;
    this.agentAndSubTenantCount = builder.agentAndSubTenantCount;
    this.isManagedByServiceProvider = builder.isManagedByServiceProvider;
    this.isRepositoryStoredInAWS = builder.isRepositoryStoredInAWS;
    this.isImmutabilityEnabled = builder.isImmutabilityEnabled;
    this.immutabilityInterval = builder.immutabilityInterval;
    this.testDrive = builder.testDrive;
    this.contractUuid = builder.contractUuid;
    this.href = builder.href;
    this.siteUuid = builder.siteUid;
    this.backupRepoUid = builder.backupRepoUid;
    this.companyUid = builder.companyUid;
    this.backupResourceUid = builder.backupResourceUid;
    this.description = builder.description;
  }

  public String getName() {
    return name;
  }

  public String getLocationId() {
    return locationId;
  }

  public Instant getLastActive() {
    return lastActive;
  }

  @Override
  public EntityType getEntityType() {
    return EntityType.VCC_BACKUP_TENANT;
  }

  @Override
  public String getEntityName() {
    return name;
  }

  public String getUuid() {
    return uuid;
  }

  @Override
  public boolean isDeleted() {
    return false;
  }

  @Override
  public Instant getDeletedDate() {
    return null;
  }

  @Override
  public Instant getUpdatedDate() {
    return null;
  }

  @Override
  public boolean entityEquals(final Entity other) {
    return false;
  }

  @Override
  public int entityHashCode() {
    return 0;
  }

  public boolean isEnabled() {
    return isEnabled;
  }

  public String getCompanyId() {
    return companyId;
  }

  public String getBackupResourceUid() {
    return backupResourceUid;
  }

  @Nonnull
  @Override
  public Map<com.iland.common.entity.EntityType, String> getAncestors() {
    if (ancestors == null || ancestors.isEmpty()) {
      final Map<com.iland.common.entity.EntityType, String> result =
          new HashMap<>();
      result.put(CommonEntityType.COMPANY, companyId);
      result.put(EntityType.VCC_BACKUP_PRODUCT,
          EntityUtil.getIdForCompanyProduct(companyId,
              ProductType.ILAND_BACKUP));
      result.put(EntityType.VCC_BACKUP_LOCATION,
          EntityUtil.getIdForCompanyProductLocation(companyId,
              ProductType.ILAND_BACKUP, locationId));
      ancestors = Collections.unmodifiableMap(result);
    }
    return ancestors;
  }

  public String getHref() {
    return href;
  }

  public boolean isBackupProtectionEnabled() {
    return backupProtectionEnabled;
  }

  public int getBackupProtectionPeriod() {
    return backupProtectionPeriod;
  }

  public int getVmsBackedUp() {
    return vmsBackedUp;
  }

  public int getVmsBackedUpToCloud() {
    return vmsBackedUpToCloud;
  }

  public long getTotalStorageQuota() {
    return totalStorageQuota;
  }

  public long getUsedStorageQuota() {
    return usedStorageQuota;
  }

  public String getEndpoint() {
    return endpoint;
  }

  public int getAgentAndSubTenantCount() {
    return agentAndSubTenantCount;
  }

  public boolean isManagedByServiceProvider() {
    return isManagedByServiceProvider;
  }

  public boolean isRepositoryStoredInAWS() {
    return isRepositoryStoredInAWS;
  }

  public boolean getIsImmutabilityEnabled() {
    return isImmutabilityEnabled;
  }

  public int getImmutabilityInterval() {
    return immutabilityInterval;
  }

  public boolean isTestDrive() {
    return testDrive;
  }

  public String getContractUuid() {
    return contractUuid;
  }

  public String getSiteUuid() {
    return siteUuid;
  }

  public String getBackupRepoUid() {
    return backupRepoUid;
  }

  public String getCompanyUid() {
    return companyUid;
  }

  public String getDescription() {
    return description;
  }

  public static class VspcCompanySiteResourceBuilder {

    private String name;

    private String locationId;

    private Instant lastActive;

    private String lastResult;

    private String uuid;

    private boolean isEnabled;

    private String companyId;

    private boolean backupProtectionEnabled;

    private int backupProtectionPeriod;

    private int vmsBackedUp;

    private int vmsBackedUpToCloud;

    private long totalStorageQuota;

    private long usedStorageQuota;

    private String endpoint;

    private int agentAndSubTenantCount;

    private boolean isManagedByServiceProvider;

    private boolean isRepositoryStoredInAWS;

    private boolean isImmutabilityEnabled;

    private int immutabilityInterval;

    private boolean testDrive;

    private String contractUuid;

    private String href;

    private String siteUid;

    private String backupRepoUid;

    private String backupResourceUid;

    private String companyUid;

    private String description;

    public VspcCompanySiteResourceBuilder name(final String name) {
      this.name = name;
      return this;
    }

    public VspcCompanySiteResourceBuilder locationId(final String locationId) {
      this.locationId = locationId;
      return this;
    }

    public VspcCompanySiteResourceBuilder lastActive(final Instant lastActive) {
      this.lastActive = lastActive;
      return this;
    }

    public VspcCompanySiteResourceBuilder lastResult(final String lastResult) {
      this.lastResult = lastResult;
      return this;
    }

    public VspcCompanySiteResourceBuilder uuid(final String uuid) {
      this.uuid = uuid;
      return this;
    }

    public VspcCompanySiteResourceBuilder isEnabled(final boolean isEnabled) {
      this.isEnabled = isEnabled;
      return this;
    }

    public VspcCompanySiteResourceBuilder companyId(final String companyId) {
      this.companyId = companyId;
      return this;
    }

    public VspcCompanySiteResourceBuilder backupProtectionEnabled(
        final boolean backupProtectionEnabled) {
      this.backupProtectionEnabled = backupProtectionEnabled;
      return this;
    }

    public VspcCompanySiteResourceBuilder backupProtectionPeriod(
        final int backupProtectionPeriod) {
      this.backupProtectionPeriod = backupProtectionPeriod;
      return this;
    }

    public VspcCompanySiteResourceBuilder vmsBackedUp(final int vmsBackedUp) {
      this.vmsBackedUp = vmsBackedUp;
      return this;
    }

    public VspcCompanySiteResourceBuilder vmsBackedUpToCloud(
        final int vmsBackedUpToCloud) {
      this.vmsBackedUpToCloud = vmsBackedUpToCloud;
      return this;
    }

    public VspcCompanySiteResourceBuilder totalStorageQuota(
        final long totalStorageQuota) {
      this.totalStorageQuota = totalStorageQuota;
      return this;
    }

    public VspcCompanySiteResourceBuilder usedStorageQuota(
        final long usedStorageQuota) {
      this.usedStorageQuota = usedStorageQuota;
      return this;
    }

    public VspcCompanySiteResourceBuilder endpoint(final String endpoint) {
      this.endpoint = endpoint;
      return this;
    }

    public VspcCompanySiteResourceBuilder agentAndSubTenantCount(
        final int agentAndSubTenantCount) {
      this.agentAndSubTenantCount = agentAndSubTenantCount;
      return this;
    }

    public VspcCompanySiteResourceBuilder isManagedByServiceProvider(
        final boolean isManagedByServiceProvider) {
      this.isManagedByServiceProvider = isManagedByServiceProvider;
      return this;
    }

    public VspcCompanySiteResourceBuilder isRepositoryStoredInAWS(
        final boolean isRepositoryStoredInAWS) {
      this.isRepositoryStoredInAWS = isRepositoryStoredInAWS;
      return this;
    }

    public VspcCompanySiteResourceBuilder isImmutabilityEnabled(
        final boolean isImmutabilityEnabled) {
      this.isImmutabilityEnabled = isImmutabilityEnabled;
      return this;
    }

    public VspcCompanySiteResourceBuilder immutabilityInterval(
        final int immutabilityInterval) {
      this.immutabilityInterval = immutabilityInterval;
      return this;
    }

    public VspcCompanySiteResourceBuilder testDrive(final boolean testDrive) {
      this.testDrive = testDrive;
      return this;
    }

    public VspcCompanySiteResourceBuilder contractUuid(
        final String contractUuid) {
      this.contractUuid = contractUuid;
      return this;
    }

    public VspcCompanySiteResourceBuilder href(final String href) {
      this.href = href;
      return this;
    }

    public VspcCompanySiteResourceBuilder siteUid(final String siteUid) {
      this.siteUid = siteUid;
      return this;
    }

    public VspcCompanySiteResourceBuilder backupRepoUid(
        final String backupRepoUid) {
      this.backupRepoUid = backupRepoUid;
      return this;
    }

    public VspcCompanySiteResourceBuilder backupResourceUid(
        final String backupResourceUid) {
      this.backupResourceUid = backupResourceUid;
      return this;
    }

    public VspcCompanySiteResourceBuilder companyUid(final String companyUid) {
      this.companyUid = companyUid;
      return this;
    }

    public VspcCompanySiteResourceBuilder description(
        final String description) {
      this.description = description;
      return this;
    }

    public VspcCompany build() {
      return new VspcCompany(this);
    }
  }
}
