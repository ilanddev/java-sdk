/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vdi;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

import com.google.common.base.MoreObjects;

/**
 * VDI User.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class VdiUser implements Serializable {

  private static final long serialVersionUID = -4930976014813143829L;

  private static final String URN_PREFIX = "urn:iland:vdi-user";

  private final String orgUuid;

  private final String uuid;

  private final String name;

  private final String email;

  /**
   * Create vdi user.
   *
   * @param orgUuid the org uuid
   * @param name    the name
   * @param email   the email
   * @return the vdi user
   */
  public static VdiUser create(final String orgUuid, final String name,
      final String email) {
    final String locationId = orgUuid.split(":")[0];
    final String uuid =
        String.format("%s:%s:%s", locationId, URN_PREFIX, UUID.randomUUID());
    return new VdiUser(orgUuid, uuid, name, email);
  }

  /**
   * Instantiates a new Vdi user.
   *
   * @param orgUuid the org uuid
   * @param uuid    the uuid
   * @param name    the name
   * @param email   the email
   */
  public VdiUser(final String orgUuid, final String uuid, final String name,
      final String email) {
    this.uuid = uuid;
    this.orgUuid = orgUuid;
    this.name = name;
    this.email = email;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets email.
   *
   * @return the email
   */
  public String getEmail() {
    return email;
  }

  /**
   * Gets org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final VdiUser vdiUser = (VdiUser) o;
    return Objects.equals(orgUuid, vdiUser.orgUuid) && Objects
        .equals(uuid, vdiUser.uuid) && Objects.equals(name, vdiUser.name)
        && Objects.equals(email, vdiUser.email);
  }

  @Override
  public int hashCode() {
    return Objects.hash(orgUuid, uuid, name, email);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("orgUuid", orgUuid)
        .add("uuid", uuid).add("name", name).add("email", email).toString();
  }
}
