/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.task;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Core Task class. Instances of this class should only be instantiated from the
 * CoreTaskService.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class CoreTask extends CoreTaskAdapter implements Serializable {

  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 2355088474748426012L;

  public static final String URN_ILAND_TASK = "urn:iland:task:";

  /**
   * The uuid.
   */
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(CoreTaskField.UUID)
  private String uuid;

  /**
   * The initiation time.
   */
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(CoreTaskField.INITIATION_TIME)
  private Date initiationTime;

  /**
   * Instantiates a new core task. This should be only be called from the
   * CoreTaskService!
   *
   * @param adapter        the adapter
   * @param uuid           the uuid
   * @param initiationTime the initiation time
   */
  public CoreTask(final CoreTaskAdapter adapter, final String uuid,
      final Date initiationTime) {
    super(adapter);
    this.uuid = uuid;
    this.initiationTime = initiationTime;
  }

  /**
   * Instantiates a new core task. This should be only be called from the
   * CoreTaskService!
   *
   * @param adapter        the adapter
   * @param uuid           the uuid
   * @param initiationTime the initiation time
   * @param crm            the company ID
   */
  public CoreTask(final CoreTaskAdapter adapter, final String uuid,
      final Date initiationTime, final String crm) {
    this(adapter, uuid, initiationTime);
    this.crm = crm;
  }

  /**
   * Instantiates a new core task. This should only be called by the
   * CoreTaskService!
   *
   * @param existingTask the existing task
   * @param adapter      the adapter
   */
  public CoreTask(final CoreTask existingTask, final CoreTaskAdapter adapter) {
    super(existingTask, adapter);
    this.uuid = existingTask.uuid;
    this.initiationTime = existingTask.initiationTime;
  }

  /**
   * Gets the uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets the task UUID without the URN prefix.
   *
   * @return {@link String}
   */
  public String getUnprefixedUuid() {
    return normalizeUuidWithoutPrefix(this.uuid);
  }

  /**
   * Gets the initiation time.
   *
   * @return the initiation time
   */
  public Date getInitiationTime() {
    if (initiationTime != null) {
      return (Date) initiationTime.clone();
    }
    return null;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = super.hashCode();
    result = prime * result + ((initiationTime == null) ?
        0 :
        initiationTime.hashCode());
    result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (!super.equals(obj))
      return false;
    if (!(obj instanceof CoreTask))
      return false;
    CoreTask other = (CoreTask) obj;
    if (initiationTime == null) {
      if (other.initiationTime != null)
        return false;
    } else if (!initiationTime.equals(other.initiationTime))
      return false;
    if (uuid == null) {
      if (other.uuid != null)
        return false;
    } else if (!uuid.equals(other.uuid))
      return false;
    return true;
  }

  /**
   * Normalizes a task UUID by stripping a URN prefix if present.
   *
   * @param uuid {@link String} the UUID
   * @return {@link String} the unprefixed UUID
   */
  public static String normalizeUuidWithoutPrefix(String uuid) {
    if (uuid == null) {
      return null;
    }
    if (uuid.startsWith(CoreTask.URN_ILAND_TASK)) {
      return uuid.replace(CoreTask.URN_ILAND_TASK, "");
    }
    return uuid;
  }

  /**
   * Normalizes a task UUID by adding a URN prefix if it is not present.
   *
   * @param uuid {@link String} the UUID
   * @return {@link String} the prefixed UUID
   */
  public static String normalizeUuidWithPrefix(String uuid) {
    if (uuid == null) {
      return null;
    }
    if (uuid.startsWith(CoreTask.URN_ILAND_TASK)) {
      return uuid;
    }
    return CoreTask.URN_ILAND_TASK + uuid;
  }

}
