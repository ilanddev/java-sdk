/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * BillingAnalyticsData.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class BillingAnalyticsData implements Serializable {

  private static final long serialVersionUID = -2759595394866658098L;

  public static final String YEAR = "year";

  public static final String MONTH = "month";

  public static final String DAY = "day";

  public static final String HOUR = "hour";

  public static final String DATA = "data";

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(YEAR)
  private int year;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(MONTH)
  private int month;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(DAY)
  private int day;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(HOUR)
  private int hour;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(DATA)
  private List<BillingAnalyticsResult> data;

  public BillingAnalyticsData(final int year, final int month, final int day,
      final int hour, final List<BillingAnalyticsResult> data) {
    this.year = year;
    this.month = month;
    this.day = day;
    this.hour = hour;
    this.data = data;
  }

  /**
   * Get the year.
   *
   * @return year
   */
  public int getYear() {
    return year;
  }

  /**
   * Get the month.
   *
   * @return month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Get the day.
   *
   * @return day
   */
  public int getDay() {
    return day;
  }

  /**
   * Get the hour.
   *
   * @return hour
   */
  public int getHour() {
    return hour;
  }

  /**
   * Get the list of analytics data.
   *
   * @return {@link List} of {@link BillingAnalyticsResult} analytics data
   */
  public List<BillingAnalyticsResult> getData() {
    return data;
  }

}
