/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;


import java.util.HashMap;
import java.util.Map;

/**
 * Billing Column
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public enum BillingColumn {

  CPU_USAGE("cpu_usage", "CPU Usage(GHz*h)"),

  CPU_TOTAL_COST("cpu_total_cost", "CPU Total Cost"),

  CPU_RESERVED_USAGE("cpu_reserve_usage", "CPU Reserved Usage(GHz*h)"),

  CPU_RESREVED_COST("cpu_reserve_cost", "CPU Reserved Cost"),

  CPU_BURST_USAGE("cpu_burst_usage", "CPU Burst Usage(GHz*h)"),

  CPU_BURST_COST("cpu_burst_cost", "CPU Burst Cost"),

  RAM_USAGE("ram_usage", "RAM Usage(GB*h)"),

  RAM_TOAL_COST("ram_total_cost", "RAM Total Cost"),

  RAM_RESERVED_USAGE("ram_reserve_usage", "RAM Reserved Usage(GB*h)"),

  RAM_RESERVED_COST("ram_reserve_cost", "RAM Reserved Cost"),

  RAM_BURST_USAGE("ram_burst_usage", "RAM Burst Usage(GB*h)"),

  RAM_BURST_COST("ram_burst_cost", "RAM Burst Cost"),

  HDD_RESERVED_USAGE("hdd_reserve_usage", "Reserved Adv. HDD Usage(GB*h)"),

  HDD_RESERVED_COST("hdd_reserve_cost", "Reserved Adv. HDD Cost"),

  HDD_BURST_USAGE("hdd_burst_usage", "Burst Adv. HDD Usage(GB*h)"),

  HDD_BURST_COST("hdd_burst_cost", "Burst Adv. HDD Cost"),

  HDD_TOTAL_USAGE("hdd_total_usage", "Total Adv. HDD Usage(GB*h)"),

  HDD_TOTAL_COST("hdd_total_cost", "Adv. HDD Total Cost"),

  SSD_RESERVED_USAGE("ssd_reserve_usage", "Reserved SSD Usage(GB*h)"),

  SSD_RESERVED_COST("ssd_reserve_cost", "Reserved SSD Cost"),

  SSD_BURST_USAGE("ssd_burst_usage", "Burst SSD Usage(GB*h)"),

  SSD_BURST_COST("ssd_burst_cost", "Burst SSD Cost"),

  SSD_TOTAL_USAGE("ssd_total_usage", "Total SSD Usage(GB*h)"),

  SSD_TOTAL_COST("ssd_total_cost", "SSD Total Cost"),

  ARCHIVE_RESERVED_USAGE("archive_reserve_usage",
      "Reserved Archive Usage(GB*h)"),

  ARCHIVE_RESERVED_COST("archive_reserve_cost", "Reserved Archive Cost"),

  ARCHIVE_BURST_USAGE("archive_burst_usage", "Burst Archive Usage(GB*h)"),

  ARCHIVE_BURST_COST("archive_burst_cost", "Burst Archive Cost"),

  ARCHIVE_TOTAL_USAGE("archive_total_usage", "Total Archive Usage(GB*h)"),

  ARCHIVE_TOTAL_COST("archive_total_cost", "Archive Total Cost"),

  BANDWIDTH_USAGE("bandwidth_usage", "Bandwidth Usage(GB)"),

  BANDWIDTH_TOTAL_COST("bandwidth_total_cost", "Bandwidth Total Cost"),

  BANDWIDTH_BURST_COST("bandwidth_burst_cost", "Bandwidth Burst Cost"),

  BANDWIDTH_RESERVED_COST("bandwidth_reserve_cost", "Bandwidth Reserved Cost"),

  TOTAL_COST("total_cost", "Total Cost"),

  TYPE("type", "Entity Type"),

  NAME("name", "Entity Name"),

  IS_TEST_DRIVE("is_test_drive", "Is Test Drive"),

  IS_DELETED("is_deleted", "Is Deleted"),

  DELETED_DATE("deleted_date", "Deletion Date"),

  VDC_NAME("vdc_name", "VDC Name"),

  CONTRACT_NUMBER("contract_number", "Contract Number");

  private final String apiName;

  private final String colName;

  private static final Map<String, String> apiNameMap = new HashMap<>();

  private static final Map<String, String> colNameMap = new HashMap<>();

  private static final Map<String, BillingColumn> billColMap = new HashMap<>();

  static {
    for (final BillingColumn col : BillingColumn.values()) {
      apiNameMap.put(col.apiName, col.colName);
      colNameMap.put(col.colName, col.apiName);
      billColMap.put(col.apiName, col);
    }
  }

  BillingColumn(final String apiName, final String colName) {
    this.apiName = apiName;
    this.colName = colName;
  }

  public static String fromApiName(final String apiName) {
    return apiNameMap.getOrDefault(apiName, null);
  }

  public static String fromColName(final String colName) {
    return colNameMap.getOrDefault(colName, null);
  }

  public static BillingColumn getBillingColumnFromName(final String name) {
    return billColMap.getOrDefault(name, null);
  }

  public String getColName() {
    return colName;
  }

  public String apiName() {
    return apiName;
  }

}
