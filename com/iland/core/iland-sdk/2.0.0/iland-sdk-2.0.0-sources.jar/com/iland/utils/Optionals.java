/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.utils;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Stream;

import jakarta.ws.rs.NotFoundException;

/**
 * Utilities for {@link Optional optionals}.
 */
public final class Optionals {

	private Optionals() {
	}

	public static Supplier<RuntimeException> mapped(final String targetName,
		final String sourceName, Object sourceValue) {
		return thrown(NotFoundException.class,
			() -> Messages.mapped(targetName, sourceName, sourceValue));
	}

	public static Supplier<RuntimeException> notFound(final String name,
		final Object value) {
		// FIXME: replace with ServiceApiException(Status.NOT_FOUND
		// FIXME: copy "ServiceApiException invalidArgument" and "ServiceApiException toApiException"
		return thrown(NotFoundException.class,
			() -> Messages.notFound(name, value));
	}

	public static Supplier<RuntimeException> thrown(final String name) {
		return thrown(RuntimeException.class, name);
	}

	public static <X extends Throwable> Supplier<X> thrown(
		final Class<? extends X> c, final String name) {
		return thrown(c, () -> Messages.thrown(name));
	}

	public static <X extends Throwable> Supplier<X> thrown(
		final Class<? extends X> c, final Supplier<String> message) {
		return () -> {
			try {
				final Constructor<? extends X> constructor =
					c.getConstructor(String.class);
				return constructor.newInstance(message.get());
			} catch (final NoSuchMethodException | InstantiationException |
			               IllegalAccessException |
			               InvocationTargetException e) {
				throw new RuntimeException(e);
			}
		};
	}

	/**
	 * @param optionals an array of {@link Optional optionals}
	 * @param <T>       the type of value
	 * @return the first {@link Optional optional} from <code>optionals</code> that {@link Optional#isPresent() is present}.
	 */
	public static <T> Optional<T> findFirstIsPresent(
		final Optional<T>... optionals) {
		return Stream.of(optionals)
			.filter(Optional::isPresent)
			.findFirst()
			.orElseGet(Optional::empty);
	}

}
