/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vdi;

import java.io.Serializable;
import java.util.Optional;
import java.util.UUID;

/**
 * VDI Automation Deployment.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class VdiAutomationDeployment implements Serializable {

  private static final long serialVersionUID = 5010569806355074855L;

  private static final String URN_PREFIX = "urn:iland:vdi-deployment";

  private final String orgUuid;

  private final String uuid;

  private final String automationGroupUuid;

  private final State state;

  private final DeploymentUser user;

  private final AutomationGroupConfig configuration;

  private final DeploymentDetails deploymentDetails;

  private final boolean undeployFlag;

  private final String failureMessage;

  /**
   * Instantiates a new Vdi automation deployment.
   *
   * @param uuid                the uuid
   * @param orgUuid             the org uuid
   * @param automationGroupUuid the automation group uuid
   * @param state               the state
   * @param user                the user that is associated with the deployment
   * @param configuration       the configuration
   * @param deploymentDetails   the deployment details
   * @param undeployFlag        the undeploy flag
   * @param failureMessage      the failure message
   */
  public VdiAutomationDeployment(final String uuid, final String orgUuid,
      final String automationGroupUuid, final State state,
      final DeploymentUser user, final AutomationGroupConfig configuration,
      final DeploymentDetails deploymentDetails, final boolean undeployFlag,
      final String failureMessage) {
    this.orgUuid = orgUuid;
    this.uuid = uuid;
    this.automationGroupUuid = automationGroupUuid;
    this.state = state;
    this.user = user;
    this.configuration = configuration;
    this.deploymentDetails = deploymentDetails;
    this.undeployFlag = undeployFlag;
    this.failureMessage = failureMessage;
  }


  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets the org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets automation group uuid.
   *
   * @return the automation group uuid
   */
  public String getAutomationGroupUuid() {
    return automationGroupUuid;
  }

  /**
   * Gets state.
   *
   * @return the state
   */
  public State getState() {
    return state;
  }

  /**
   * Gets configuration.
   *
   * @return the configuration
   */
  public AutomationGroupConfig getConfiguration() {
    return configuration;
  }

  /**
   * Indicates whether the undeploy flag is set. If set, the deployment should
   * be destroyed ASAP.
   *
   * @return boolean value
   */
  public boolean isUndeployFlagSet() {
    return undeployFlag;
  }

  /**
   * Gets deployment details.
   *
   * @return the deployment details
   */
  public DeploymentDetails getDeploymentDetails() {
    return deploymentDetails;
  }

  /**
   * Gets user.
   *
   * @return the user
   */
  public DeploymentUser getUser() {
    return user;
  }

  /**
   * Gets the failure message.
   *
   * @return optional failure message
   */
  public Optional<String> getFailureMessage() {
    return Optional.ofNullable(failureMessage);
  }

  /**
   * The type Deployment user.
   */
  public static class DeploymentUser {

    private final String userUuid;

    private final String userEmail;

    private final String userFullName;


    /**
     * Instantiates a new Deployment user.
     *
     * @param userUuid     the user uuid
     * @param userEmail    the user email
     * @param userFullName the user full name
     */
    public DeploymentUser(final String userUuid, final String userEmail,
        final String userFullName) {
      this.userUuid = userUuid;
      this.userEmail = userEmail;
      this.userFullName = userFullName;
    }

    /**
     * Gets user uuid.
     *
     * @return the user uuid
     */
    public String getUserUuid() {
      return userUuid;
    }

    /**
     * Gets user email.
     *
     * @return the user email
     */
    public String getUserEmail() {
      return userEmail;
    }

    /**
     * Gets user full name.
     *
     * @return the user full name
     */
    public String getUserFullName() {
      return userFullName;
    }
  }


  /**
   * The type Deployment details.
   */
  public static class DeploymentDetails {

    /**
     * The constant EMPTY_INSTANCE.
     */
    public static DeploymentDetails EMPTY_INSTANCE =
        new DeploymentDetails(null, null, null, null, null, null);

    private final String internalIp;

    private final String publicRdpPort;

    private final String vmUuid;

    private final String vappUuid;

    private final String guestAdminPassword;

    private final String computerName;

    /**
     * Instantiates a new Deployment details.
     *
     * @param internalIp         the internal ip
     * @param publicRdpPort      the public rdp port
     * @param vmUuid             the vm uuid
     * @param vappUuid           the vapp uuid
     * @param guestAdminPassword the guest admin password
     * @param computerName       the computer name
     */
    private DeploymentDetails(final String internalIp,
        final String publicRdpPort, final String vmUuid, final String vappUuid,
        final String guestAdminPassword, final String computerName) {
      this.internalIp = internalIp;
      this.publicRdpPort = publicRdpPort;
      this.vmUuid = vmUuid;
      this.vappUuid = vappUuid;
      this.guestAdminPassword = guestAdminPassword;
      this.computerName = computerName;
    }

    /**
     * Gets internal ip.
     *
     * @return the internal ip
     */
    public String getInternalIp() {
      return internalIp;
    }

    /**
     * Gets public rdp port.
     *
     * @return the public rdp port
     */
    public String getPublicRdpPort() {
      return publicRdpPort;
    }

    /**
     * Gets vm uuid.
     *
     * @return the vm uuid
     */
    public String getVmUuid() {
      return vmUuid;
    }

    /**
     * Gets vapp uuid.
     *
     * @return the vapp uuid
     */
    public String getVappUuid() {
      return vappUuid;
    }

    /**
     * Gets guest admin password.
     *
     * @return the guest admin password
     */
    public String getGuestAdminPassword() {
      return guestAdminPassword;
    }

    /**
     * Gets computer name.
     *
     * @return the computer name
     */
    public String getComputerName() {
      return computerName;
    }

    /**
     * The type Builder.
     */
    public static final class Builder {

      private String internalIp;

      private String publicRdpPort;

      private String vmUuid;

      private String vappUuid;

      private String guestAdminPassword;

      private String computerName;

      private Builder(final String internalIp, final String publicRdpPort,
          final String vmUuid, final String vappUuid,
          final String guestAdminPassword, final String computerName) {
        this.internalIp = internalIp;
        this.publicRdpPort = publicRdpPort;
        this.vmUuid = vmUuid;
        this.vappUuid = vappUuid;
        this.guestAdminPassword = guestAdminPassword;
        this.computerName = computerName;
      }

      /**
       * From builder.
       *
       * @param other the other
       * @return the builder
       */
      public static Builder from(final DeploymentDetails other) {
        return new Builder(other.internalIp, other.publicRdpPort, other.vmUuid,
            other.vappUuid, other.guestAdminPassword, other.computerName);
      }

      /**
       * With internal ip builder.
       *
       * @param internalIp the internal ip
       * @return the builder
       */
      public Builder withInternalIp(final String internalIp) {
        this.internalIp = internalIp;
        return this;
      }

      /**
       * With public rdp port builder.
       *
       * @param publicRdpPort the public rdp port
       * @return the builder
       */
      public Builder withPublicRdpPort(final String publicRdpPort) {
        this.publicRdpPort = publicRdpPort;
        return this;
      }

      /**
       * With vm uuid builder.
       *
       * @param vmUuid the vm uuid
       * @return the builder
       */
      public Builder withVmUuid(final String vmUuid) {
        this.vmUuid = vmUuid;
        return this;
      }

      /**
       * With vapp uuid builder.
       *
       * @param vappUuid the vapp uuid
       * @return the builder
       */
      public Builder withVappUuid(final String vappUuid) {
        this.vappUuid = vappUuid;
        return this;
      }

      /**
       * With guest admin password builder.
       *
       * @param guestAdminPassword the guest admin password
       * @return the builder
       */
      public Builder withGuestAdminPassword(final String guestAdminPassword) {
        this.guestAdminPassword = guestAdminPassword;
        return this;
      }

      /**
       * With computer name builder.
       *
       * @param computerName the computer name
       * @return the builder
       */
      public Builder withComputerName(final String computerName) {
        this.computerName = computerName;
        return this;
      }

      /**
       * Build deployment details.
       *
       * @return the deployment details
       */
      public DeploymentDetails build() {
        return new DeploymentDetails(internalIp, publicRdpPort, vmUuid,
            vappUuid, guestAdminPassword, computerName);
      }


    }
  }


  /**
   * The type Automation group config.
   */
  public static class AutomationGroupConfig {

    private final String vmTemplateUuid;

    private final String deploymentVdcUuid;

    private final String orgVdcNetworkUuid;

    private final NetworkConnectionType networkConnectionType;

    private final String edgeUuid;

    private final String publicRdpIp;

    private final String domainToJoin;

    private final boolean joinDomainEnabled;

    private final boolean guestPasswordResetRequired;

    private final String storageProfileUuid;

    /**
     * Instantiates a new Automation group config.
     *
     * @param vmTemplateUuid             the vm template uuid
     * @param deploymentVdcUuid          the deployment vdc uuid
     * @param orgVdcNetworkUuid          the org vdc network uuid
     * @param networkConnectionType      the network connection type
     * @param domainToJoin               the domain to join
     * @param edgeUuid                   the edge uuid
     * @param publicRdpIp                the public rdp ip
     * @param joinDomainEnabled          whether joining a domain is enabled
     * @param guestPasswordResetRequired whether guest password reset is required
     * @param storageProfileUuid         the storage profile uuid
     */
    public AutomationGroupConfig(final String vmTemplateUuid,
        final String deploymentVdcUuid, final String orgVdcNetworkUuid,
        final NetworkConnectionType networkConnectionType,
        final String domainToJoin, final String edgeUuid,
        final String publicRdpIp, final boolean joinDomainEnabled,
        final boolean guestPasswordResetRequired,
        final String storageProfileUuid) {
      this.vmTemplateUuid = vmTemplateUuid;
      this.deploymentVdcUuid = deploymentVdcUuid;
      this.orgVdcNetworkUuid = orgVdcNetworkUuid;
      this.networkConnectionType = networkConnectionType;
      this.domainToJoin = domainToJoin;
      this.edgeUuid = edgeUuid;
      this.publicRdpIp = publicRdpIp;
      this.joinDomainEnabled = joinDomainEnabled;
      this.guestPasswordResetRequired = guestPasswordResetRequired;
      this.storageProfileUuid = storageProfileUuid;
    }

    /**
     * Gets vm template uuid.
     *
     * @return the vm template uuid
     */
    public String getVmTemplateUuid() {
      return vmTemplateUuid;
    }

    /**
     * Gets deployment vdc uuid.
     *
     * @return the deployment vdc uuid
     */
    public String getDeploymentVdcUuid() {
      return deploymentVdcUuid;
    }

    /**
     * Gets org vdc network uuid.
     *
     * @return the org vdc network uuid
     */
    public String getOrgVdcNetworkUuid() {
      return orgVdcNetworkUuid;
    }

    /**
     * Gets domain to join.
     *
     * @return the domain to join
     */
    public String getDomainToJoin() {
      return domainToJoin;
    }

    /**
     * Gets edge uuid.
     *
     * @return the edge uuid
     */
    public String getEdgeUuid() {
      return edgeUuid;
    }

    /**
     * Gets public rdp ip.
     *
     * @return the public rdp ip
     */
    public String getPublicRdpIp() {
      return publicRdpIp;
    }

    /**
     * Gets network connection type.
     *
     * @return the network connection type
     */
    public NetworkConnectionType getNetworkConnectionType() {
      return networkConnectionType;
    }

    /**
     * Is join domain enabled boolean.
     *
     * @return the boolean
     */
    public boolean isJoinDomainEnabled() {
      return joinDomainEnabled;
    }

    /**
     * Is guest password reset required boolean.
     *
     * @return the boolean
     */
    public boolean isGuestPasswordResetRequired() {
      return guestPasswordResetRequired;
    }

    /**
     * Gets storage profile uuid.
     *
     * @return the storage profile uuid
     */
    public Optional<String> getStorageProfileUuid() {
      return Optional.ofNullable(storageProfileUuid);
    }
  }


  /**
   * The enum State.
   */
  public enum State {

    /**
     * Queued for deployment state.
     */
    QUEUED_FOR_DEPLOYMENT,

    /**
     * Deploying state.
     */
    DEPLOYING,

    /**
     * Booting state.
     */
    BOOTING,

    /**
     * Configuring rdp access state.
     */
    CONFIGURING_RDP_ACCESS,

    /**
     * Sending user access notification state.
     */
    SENDING_USER_ACCESS_NOTIFICATION,

    /**
     * Ready state.
     */
    READY,

    /**
     * Sending user undeploy notification state.
     */
    SENDING_USER_UNDEPLOY_NOTIFICATION,

    /**
     * Removing rdp access state.
     */
    REMOVING_RDP_ACCESS,

    /**
     * Powering down state.
     */
    POWERING_DOWN,

    /**
     * Undeploying state.
     */
    UNDEPLOYING,

    /**
     * Failed state.
     */
    FAILED

  }


  /**
   * The type Builder.
   */
  public static final class Builder {
    private final String orgUuid;
    private final String uuid;
    private final String automationGroupUuid;
    private State state;
    private final DeploymentUser user;
    private final AutomationGroupConfig configuration;
    private DeploymentDetails deploymentDetails;
    private boolean undeployFlag;
    private String failureMessage;

    private Builder(final String uuid, final String orgUuid,
        final String automationGroupUuid, final State state,
        final DeploymentUser deploymentUser,
        final AutomationGroupConfig automationGroupConfig,
        final DeploymentDetails deploymentDetails, final boolean undeployFlag,
        final String failureMessage) {
      this.uuid = uuid;
      this.orgUuid = orgUuid;
      this.automationGroupUuid = automationGroupUuid;
      this.user = deploymentUser;
      this.configuration = automationGroupConfig;
      this.state = state;
      this.deploymentDetails = deploymentDetails;
      this.undeployFlag = undeployFlag;
      this.failureMessage = failureMessage;
    }

    /**
     * New queued builder.
     *
     * @param orgUuid               the org uuid
     * @param automationGroupUuid   the automation group uuid
     * @param deploymentUser        the deployment user
     * @param automationGroupConfig the automation group config
     * @return the builder
     */
    public static Builder newQueued(final String orgUuid,
        final String automationGroupUuid, final DeploymentUser deploymentUser,
        final AutomationGroupConfig automationGroupConfig) {
      final String locationId = automationGroupUuid.split(":")[0];
      final String uuid = String.format("%s:%s:%s", locationId, URN_PREFIX,
          UUID.nameUUIDFromBytes(String.format("%s:%s", automationGroupUuid,
              deploymentUser.getUserUuid()).getBytes()).toString());
      return new Builder(uuid, orgUuid, automationGroupUuid,
          State.QUEUED_FOR_DEPLOYMENT, deploymentUser, automationGroupConfig,
          DeploymentDetails.EMPTY_INSTANCE, false, null);
    }

    /**
     * From builder.
     *
     * @param deployment the deployment
     * @return the builder
     */
    public static Builder from(final VdiAutomationDeployment deployment) {
      return new Builder(deployment.uuid, deployment.getOrgUuid(),
          deployment.automationGroupUuid, deployment.state, deployment.user,
          deployment.configuration, deployment.deploymentDetails,
          deployment.undeployFlag, deployment.failureMessage);
    }

    /**
     * With state builder.
     *
     * @param state the state
     * @return the builder
     */
    public Builder withState(State state) {
      if (State.FAILED.equals(state)) {
        throw new IllegalArgumentException(
            "failed state should be set using the withFailureState method");
      }
      this.state = state;
      return this;
    }

    /**
     * With deployment details builder.
     *
     * @param deploymentDetails the deployment details
     * @return the builder
     */
    public Builder withDeploymentDetails(
        final DeploymentDetails deploymentDetails) {
      this.deploymentDetails = deploymentDetails;
      return this;
    }

    /**
     * With undeploy flag set builder.
     *
     * @return the builder
     */
    public Builder withUndeployFlagSet() {
      this.undeployFlag = true;
      return this;
    }

    /**
     * With failure state builder.
     *
     * @param failureMessage the failure message
     * @return the builder
     */
    public Builder withFailureState(String failureMessage) {
      this.state = State.FAILED;
      this.failureMessage = failureMessage;
      return this;
    }

    /**
     * Build vdi automation deployment.
     *
     * @return the vdi automation deployment
     */
    public VdiAutomationDeployment build() {
      return new VdiAutomationDeployment(uuid, orgUuid, automationGroupUuid,
          state, user, configuration, deploymentDetails, undeployFlag,
          failureMessage);
    }
  }
}
