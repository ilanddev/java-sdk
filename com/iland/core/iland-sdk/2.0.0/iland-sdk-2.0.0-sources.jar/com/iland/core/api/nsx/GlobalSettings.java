/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.nsx;

import java.io.Serializable;
import java.util.List;

/**
 * GlobalSettings.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class GlobalSettings implements Serializable {

  private static final long serialVersionUID = 809910428727105185L;

  private String psk;

  private String serviceCertificate;

  private List<String> caCertificates;

  private List<String> crlCertificates;

  public GlobalSettings() {
  }

  public GlobalSettings(final String psk, final String serviceCertificate,
      final List<String> caCertificates, final List<String> crlCertificates) {
    this.psk = psk;
    this.serviceCertificate = serviceCertificate;
    this.caCertificates = caCertificates;
    this.crlCertificates = crlCertificates;
  }

  /**
   * Get the global pre shared key.
   *
   * @return {@link String} global pre-shared key
   */
  public String getPsk() {
    return psk;
  }

  /**
   * Get the list of CA certificates.
   *
   * @return {@link String} CA certificates
   */
  public List<String> getCaCertificates() {
    return caCertificates;
  }

  /**
   * Get the list of CRL certificates.
   *
   * @return {@link String} CRL certificates
   */
  public List<String> getCrlCertificates() {
    return crlCertificates;
  }

  /**
   * Get the service certificate.
   *
   * @return {@link String} service certificate
   */
  public String getServiceCertificate() {
    return serviceCertificate;
  }

}
