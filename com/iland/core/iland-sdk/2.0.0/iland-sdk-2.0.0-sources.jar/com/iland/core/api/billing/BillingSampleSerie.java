/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * BillingSampleSerie.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class BillingSampleSerie implements Serializable {

  private static final long serialVersionUID = -3492634883759415678L;

  public static final String INTERVAL = "interval";

  public static final String SUMMARY = "summary";

  public static final String SAMPLES = "samples";

  public static final String CURRENCY = "currency_code";

  public static final String ENTITY_UUID = "entity_uuid";

  public static final String ENTITY_NAME = "entity_name";

  @Expose
  @SerializedName(ENTITY_UUID)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String entityUuid;

  @Expose
  @SerializedName(ENTITY_NAME)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String entityName;

  @Expose
  @SerializedName(INTERVAL)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private long interval;

  @Expose
  @SerializedName(SUMMARY)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String summary;

  @Expose
  @SerializedName(SAMPLES)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private List<BillingSample> samples;

  @Expose
  @SerializedName(CURRENCY)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String currencyCode;

  public BillingSampleSerie() {
  }

  public BillingSampleSerie(final String entityName, final String entityUuid,
      final long interval, final String summary,
      final List<BillingSample> samples, final String currencyCode) {
    this.entityName = entityName;
    this.entityUuid = entityUuid;
    this.interval = interval;
    this.summary = summary;
    this.samples = samples;
    this.currencyCode = currencyCode;
  }

  /**
   * Get the interval in seconds between samples.
   *
   * @return sample interval
   */
  public long getInterval() {
    return interval;
  }

  /**
   * Get the serie summary.
   *
   * @return {@link String} summary
   */
  public String getSummary() {
    return summary;
  }

  /**
   * Get the list of samples.
   *
   * @return {@link List} of {@link BillingSample} list of samples
   */
  public List<BillingSample> getSamples() {
    return samples;
  }

  /**
   * Get the currency code.
   *
   * @return {@link String} currency code
   */
  public String getCurrencyCode() {
    return currencyCode;
  }

  /**
   * Get the entity uuid.
   *
   * @return entity uuid
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Get the entity name.
   *
   * @return entity name
   */
  public String getEntityName() {
    return entityName;
  }

}
