/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.security;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Login Event.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class LoginEvent implements Serializable {

  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = 1L;

  /**
   * The username.
   */
  @SerializedName(LoginEventField.USERNAME)
  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final String username;

  /**
   * The type.
   */
  @SerializedName(LoginEventField.TYPE)
  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final String type;

  /**
   * The time.
   */
  @SerializedName(LoginEventField.TIME)
  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final long time;

  /**
   * The user's ip address.
   */
  @SerializedName(LoginEventField.IP_ADDRESS)
  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final String ipAddress;

  @SerializedName(LoginEventField.CLIENT_NAME)
  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final String clientName;

  /**
   * Instantiates a new login event.
   *
   * @param username  the username
   * @param type      the type
   * @param time      the time
   * @param ipAddress ip address
   */
  public LoginEvent(final String username, final String type, final long time,
      final String ipAddress, final String clientName) {
    super();
    this.username = username;
    this.type = type;
    this.time = time;
    this.ipAddress = ipAddress;
    this.clientName = clientName;
  }

  /**
   * Gets the username.
   *
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Gets the time.
   *
   * @return the time
   */
  public long getTime() {
    return time;
  }

  /**
   * Get the ip address.
   *
   * @return user's ip address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Get the client name.
   *
   * @return {@link String} client name
   */
  public String getClientName() {
    return clientName;
  }

}
