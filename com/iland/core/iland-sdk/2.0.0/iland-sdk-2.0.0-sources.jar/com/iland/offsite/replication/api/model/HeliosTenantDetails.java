/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iland.cohesity.helios.sdk.v2.model.HeliosClusterTenant;
import com.iland.offsite.replication.tools.TenantDescriptionParser;

/**
 * {@link HeliosTenantDetails}.
 */
public final class HeliosTenantDetails implements ClusterUid {

	private static final Logger logger =
		LoggerFactory.getLogger(HeliosTenantDetails.class);

	private static final Pattern PATTERN = Pattern.compile("(.*):(\\w+/)");

	private final HeliosClusterTenant.StatusEnum status;

	private final Long clusterId;

	private final Long clusterIncarnationId;

	private final String id;

	private final CompanyId companyId;

	private final String name;

	private final Set<VdcUuid> vdcUuids;

	public static HeliosTenantDetails of(final HeliosClusterTenant tenant) {
		return new HeliosTenantDetails(tenant);
	}

	private HeliosTenantDetails(final HeliosClusterTenant tenant) {
		this.status = tenant.getStatus();
		this.clusterId = Optional.of(tenant)
			.map(HeliosClusterTenant::getClusterId)
			.orElseThrow(() -> new IllegalArgumentException(
				"invalid cluster id for " + tenant.getName()));
		this.clusterIncarnationId = Optional.of(tenant)
			.map(HeliosClusterTenant::getClusterIncarnationId)
			.orElseThrow(() -> new IllegalArgumentException(
				"invalid cluster incarnation id for " + tenant.getName()));
		final HeliosTenantId heliosTenantId = Optional.of(tenant)
			.map(HeliosClusterTenant::getId)
			.flatMap(HeliosTenantDetails::parseId)
			.orElseThrow(() -> new IllegalArgumentException(
				"invalid helios tenant id: %s".formatted(tenant.getId())));
		this.id = heliosTenantId.id();
		this.companyId = heliosTenantId.companyId();
		this.name = tenant.getName();
		this.vdcUuids =
			TenantDescriptionParser.parseDescription(tenant.getDescription());
	}

	public static Optional<HeliosTenantId> parseId(final String id) {
		final Matcher matcher = PATTERN.matcher(id);
		if (matcher.matches()) {
			final String innerId = matcher.group(1);
			final String companyId = matcher.group(2);
			final HeliosTenantId heliosTenantId =
				ImmutableHeliosTenantId.builder()
					.id(innerId)
					.companyId(CompanyId.of(companyId))
					.build();

			return Optional.of(heliosTenantId);
		}

		logger.warn("invalid helios tenant id: {}", id);

		return Optional.empty();
	}

	@Override
	public Long clusterId() {
		return this.clusterId;
	}

	@Override
	public Long clusterIncarnationId() {
		return this.clusterIncarnationId;
	}

	/**
	 * @return the ID of this {@link HeliosTenantDetails tenant}
	 */
	public String id() {
		return this.id;
	}

	/**
	 * @return the {@link CompanyId company ID} of this {@link HeliosTenantDetails tenant}
	 */
	public CompanyId companyId() {
		return this.companyId;
	}

	/**
	 * @return the name of this {@link HeliosTenantDetails tenant}
	 */
	public String name() {
		return this.name;
	}

	/**
	 * @return a {@link Set set} of {@link VdcUuid VDC UUIDs}
	 */
	public Set<VdcUuid> vdcUuids() {
		return this.vdcUuids;
	}

	/**
	 * @return {@literal true} if this {@link HeliosTenantDetails tenant} is active
	 */
	public boolean isActive() {
		return HeliosClusterTenant.StatusEnum.ACTIVE.equals(this.status);
	}

	/**
	 * @return a human-readable status
	 */
	public String status() {
		return Optional.of(status)
			.map(Enum::name)
			.orElse("disconnected")
			.toLowerCase();
	}

	@Override
	public String toString() {
		return "%s:%s".formatted(id(),
			companyId().companyIdWithTrailingSlash());
	}

}
