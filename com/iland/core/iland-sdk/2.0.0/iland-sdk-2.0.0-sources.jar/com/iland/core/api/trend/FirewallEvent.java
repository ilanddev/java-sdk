/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.trend;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.util.IlandSerializedName;

/**
 * Firewall Event.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class FirewallEvent implements Serializable {

  private static final long serialVersionUID = -6248974694365790764L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.VM_UUID)
  private String vmUuid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.ACTION)
  private String action;

  @Expose(deserialize = false)
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.DATA)
  private byte[] data;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.DATA_FLAGS)
  private Integer dataFlags;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.DATA_INDEX)
  private Integer dataIndex;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.DESTINATION_IP)
  private String destinationIP;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.DESTINATION_MAC)
  private String destinationMAC;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.DESTINATION_PORT)
  private String destinationPort;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.DIRECTION)
  private String direction;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.DRIVER_TIME)
  private Long driverTime;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.END_TIME)
  private Calendar endTime;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.EVENT_ORIGIN)
  private String eventOrigin;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.FIREWALL_EVENT_ID)
  private Long firewallEventID;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.FLAGS)
  private String flags;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.FLOW)
  private String flow;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.FRAME_TYPE)
  private String frameType;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.HOST_ID)
  private Integer hostID;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.HOST_NAME)
  private String hostName;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.INTERFACE)
  private String iface;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.NOTE)
  private String note;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.PACKET_SIZE)
  private int packetSize;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.PROTOCOL)
  private String protocol;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.RANK)
  private int rank;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.REASON)
  private String reason;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.REPEAT_COUNT)
  private int repeatCount;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.SOURCE_IP)
  private String sourceIP;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.SOURCE_MAC)
  private String sourceMAC;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.SOURCE_PORT)
  private String sourcePort;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.START_TIME)
  private Calendar startTime;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.STATUS)
  private Integer status;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(FirewallEventField.TAGS)
  private String tags;

  public FirewallEvent() {
  }

  /**
   * Get the VM uuid.
   *
   * @return {@link String} vm uuid
   */
  public String getVmUuid() {
    return vmUuid;
  }

  /**
   * Set the VM uuid.
   *
   * @param vmUuid {@link String} vm uuid
   */
  public void setVmUuid(final String vmUuid) {
    this.vmUuid = vmUuid;
  }

  /**
   * Get the firewall action.
   *
   * @return {@link String} action
   */
  public String getAction() {
    return action;
  }

  /**
   * Set the firewall action.
   *
   * @param action {@link String} action
   */
  public void setAction(final String action) {
    this.action = action;
  }

  /**
   * Get the firewall event data.
   *
   * @return data of firewall event
   */
  public byte[] getData() {
    return data;
  }

  /**
   * Set the firewall event data.
   *
   * @param data firewall event data
   */
  public void setData(final byte[] data) {
    this.data = data;
  }

  /**
   * Get the data flags.
   *
   * @return {@link Integer} data flags
   */
  public Integer getDataFlags() {
    return dataFlags;
  }

  /**
   * Set the data flags.
   *
   * @param dataFlags {@link Integer} data flags
   */
  public void setDataFlags(final Integer dataFlags) {
    this.dataFlags = dataFlags;
  }

  /**
   * Get the data index.
   *
   * @return {@link Integer} data index
   */
  public Integer getDataIndex() {
    return dataIndex;
  }

  /**
   * Set the data index.
   *
   * @param dataIndex {@link Integer} data index
   */
  public void setDataIndex(final Integer dataIndex) {
    this.dataIndex = dataIndex;
  }

  /**
   * Get the destination IP.
   *
   * @return {@link String} destination IP
   */
  public String getDestinationIP() {
    return destinationIP;
  }

  /**
   * Set the destination IP.
   *
   * @param destinationIP {@link String} destination IP
   */
  public void setDestinationIP(final String destinationIP) {
    this.destinationIP = destinationIP;
  }

  /**
   * Get the destination MAC address.
   *
   * @return {@link String} destination MAC address
   */
  public String getDestinationMAC() {
    return destinationMAC;
  }

  /**
   * Set the destination MAC address.
   *
   * @param destinationMAC {@link String} destination MAC address
   */
  public void setDestinationMAC(final String destinationMAC) {
    this.destinationMAC = destinationMAC;
  }

  /**
   * Get the destination port.
   *
   * @return {@link String} destination port
   */
  public String getDestinationPort() {
    return destinationPort;
  }

  /**
   * Set the destination port.
   *
   * @param destinationPort {@link String} destination port
   */
  public void setDestinationPort(final String destinationPort) {
    this.destinationPort = destinationPort;
  }

  /**
   * Get the direction.
   *
   * @return {@link String} direction
   */
  public String getDirection() {
    return direction;
  }

  /**
   * Set the direction.
   *
   * @param direction {@link String} direction
   */
  public void setDirection(final String direction) {
    this.direction = direction;
  }

  /**
   * Get the driver time.
   *
   * @return {@link Long} driver time
   */
  public Long getDriverTime() {
    return driverTime;
  }

  /**
   * Set the driver time.
   *
   * @param driverTime {@link Long} driver time
   */
  public void setDriverTime(final Long driverTime) {
    this.driverTime = driverTime;
  }

  /**
   * Get the end time.
   *
   * @return {@link Calendar} end time
   */
  public Calendar getEndTime() {
    if (endTime == null) {
      final Calendar defaultDate = Calendar.getInstance();
      defaultDate.setTime(new Date(0));
      return defaultDate;
    }
    return endTime;
  }

  /**
   * Set the end time.
   *
   * @param endTime {@link Calendar} end time
   */
  public void setEndTime(final Calendar endTime) {
    this.endTime = endTime;
  }

  /**
   * Get the event origin.
   *
   * @return {@link String} event origin
   */
  public String getEventOrigin() {
    return eventOrigin;
  }

  /**
   * Set the event origin.
   *
   * @param eventOrigin {@link String} event origin
   */
  public void setEventOrigin(final String eventOrigin) {
    this.eventOrigin = eventOrigin;
  }

  /**
   * Get the firewall event ID.
   *
   * @return {@link Long} firewall event ID
   */
  public Long getFirewallEventID() {
    return firewallEventID;
  }

  /**
   * Set the firewall event ID.
   *
   * @param firewallEventID {@link Long} firewall event ID
   */
  public void setFirewallEventID(final Long firewallEventID) {
    this.firewallEventID = firewallEventID;
  }

  /**
   * Get the flags.
   *
   * @return {@link String} flags
   */
  public String getFlags() {
    return flags;
  }

  /**
   * Set the flags.
   *
   * @param flags {@link String} flags
   */
  public void setFlags(final String flags) {
    this.flags = flags;
  }

  /**
   * Get the flow.
   *
   * @return {@link String} flow
   */
  public String getFlow() {
    return flow;
  }

  /**
   * Set the flow.
   *
   * @param flow {@link String} flow
   */
  public void setFlow(final String flow) {
    this.flow = flow;
  }

  /**
   * Get the frame type.
   *
   * @return {@link String} frame type
   */
  public String getFrameType() {
    return frameType;
  }

  /**
   * Set the frame type.
   *
   * @param frameType {@link String} frame type
   */
  public void setFrameType(final String frameType) {
    this.frameType = frameType;
  }

  /**
   * Get the host ID.
   *
   * @return {@link Integer} host ID
   */
  public Integer getHostID() {
    return hostID;
  }

  /**
   * Set the host ID.
   *
   * @param hostID {@link Integer} host ID
   */
  public void setHostID(final Integer hostID) {
    this.hostID = hostID;
  }

  /**
   * Get the host name.
   *
   * @return {@link String} host name
   */
  public String getHostName() {
    return hostName;
  }

  /**
   * Set the host name.
   *
   * @param hostName {@link String} host name
   */
  public void setHostName(final String hostName) {
    this.hostName = hostName;
  }

  /**
   * Get the interface.
   *
   * @return {@link String} interface
   */
  public String getIface() {
    return iface;
  }

  /**
   * Set the interface.
   *
   * @param iface {@link String} interface
   */
  public void setIface(final String iface) {
    this.iface = iface;
  }

  /**
   * Get the note.
   *
   * @return {@link String} note
   */
  public String getNote() {
    return note;
  }

  /**
   * Set the note.
   *
   * @param note {@link String} note
   */
  public void setNote(final String note) {
    this.note = note;
  }

  /**
   * Get the packet size.
   *
   * @return packet size
   */
  public int getPacketSize() {
    return packetSize;
  }

  /**
   * Set the packet size.
   *
   * @param packetSize packet size
   */
  public void setPacketSize(final int packetSize) {
    this.packetSize = packetSize;
  }

  /**
   * Get the protocol.
   *
   * @return {@link String} protocol
   */
  public String getProtocol() {
    return protocol;
  }

  /**
   * Set the protocol.
   *
   * @param protocol {@link String} protocol
   */
  public void setProtocol(final String protocol) {
    this.protocol = protocol;
  }

  /**
   * Get the rank.
   *
   * @return rank
   */
  public int getRank() {
    return rank;
  }

  /**
   * Set the rank
   *
   * @param rank rank.
   */
  public void setRank(final int rank) {
    this.rank = rank;
  }

  /**
   * Get the reason.
   *
   * @return {@link String} reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * Set the reason.
   *
   * @param reason {@link String} reason
   */
  public void setReason(final String reason) {
    this.reason = reason;
  }

  /**
   * Get the repeat count.
   *
   * @return repeat count
   */
  public int getRepeatCount() {
    return repeatCount;
  }

  /**
   * Set the repeat count.
   *
   * @param repeatCount repeat count
   */
  public void setRepeatCount(final int repeatCount) {
    this.repeatCount = repeatCount;
  }

  /**
   * Get the source IP.
   *
   * @return {@link String} source IP address
   */
  public String getSourceIP() {
    return sourceIP;
  }

  /**
   * Set the source IP.
   *
   * @param sourceIP {@link String} source IP
   */
  public void setSourceIP(final String sourceIP) {
    this.sourceIP = sourceIP;
  }

  /**
   * Get the source MAC address.
   *
   * @return {@link String} source MAC address
   */
  public String getSourceMAC() {
    return sourceMAC;
  }

  /**
   * Set the source MAC address.
   *
   * @param sourceMAC {@link String} source MAC address
   */
  public void setSourceMAC(final String sourceMAC) {
    this.sourceMAC = sourceMAC;
  }

  /**
   * Get the source port.
   *
   * @return {@link String} source port
   */
  public String getSourcePort() {
    return sourcePort;
  }

  /**
   * Set the source port.
   *
   * @param sourcePort {@link String} source port
   */
  public void setSourcePort(final String sourcePort) {
    this.sourcePort = sourcePort;
  }

  /**
   * Get the start time.
   *
   * @return {@link Calendar} start time
   */
  public Calendar getStartTime() {
    return startTime;
  }

  /**
   * Set the start time.
   *
   * @param startTime {@link Calendar} start time
   */
  public void setStartTime(final Calendar startTime) {
    this.startTime = startTime;
  }

  /**
   * Get the status.
   *
   * @return {@link Integer} status
   */
  public Integer getStatus() {
    return status;
  }

  /**
   * Set the status.
   *
   * @param status {@link String} status
   */
  public void setStatus(final Integer status) {
    this.status = status;
  }

  /**
   * Get the tags.
   *
   * @return {@link String} tags
   */
  public String getTags() {
    return tags;
  }

  /**
   * Set the tags.
   *
   * @param tags {@link String} tags
   */
  public void setTags(final String tags) {
    this.tags = tags;
  }

}
