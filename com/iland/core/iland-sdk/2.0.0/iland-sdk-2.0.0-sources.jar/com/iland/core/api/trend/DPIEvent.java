/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.trend;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.util.IlandSerializedName;

/**
 * DPI Event.
 * <p>
 * Intrusion Protection Event.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class DPIEvent implements Serializable {

  private static final long serialVersionUID = -8350542684135006533L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.EVENT_ID)
  private Long eventId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.RULE_ID)
  private int ruleId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.ACTION)
  private String action;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.DATA)
  private byte[] data;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.DATA_FLAGS)
  private int dataFlags;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.DATA_INDEX)
  private int dataIndex;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.DESTINATION_IP)
  private String destinationIP;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.DESTINATION_MAC)
  private String destinationMAC;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.DESTINATION_PORT)
  private String destinationPort;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.DIRECTION)
  private String direction;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.DRIVER_TIME)
  private long driverTime;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.END_TIME)
  private Calendar endTime;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.EVENT_ORIGIN)
  private String eventOrigin;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.FLAGS)
  private String flags;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.FLOW)
  private String flow;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.VM_UUID)
  private String vmUuid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.HOST_ID)
  private int hostID;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.HOST_NAME)
  private String hostName;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.INTERFACE)
  private String iface;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.NOTE)
  private String note;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.PACKET_SIZE)
  private int packetSize;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.PROTOCOL)
  private String protocol;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.RANK)
  private int rank;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.REASON)
  private String reason;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.REPEAT_COUNT)
  private int repeatCount;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.SOURCE_IP)
  private String sourceIP;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.SOURCE_MAC)
  private String sourceMAC;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.SOURCE_PORT)
  private String sourcePort;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.START_TIME)
  private Calendar startTime;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.STATUS)
  private int status;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(DPIEventField.TAGS)
  private String tags;

  /**
   * Instantiates a new DPI event.
   */
  public DPIEvent() {
  }

  /**
   * Gets event id.
   *
   * @return the event id
   */
  public Long getEventId() {
    return eventId;
  }

  /**
   * Sets event id.
   *
   * @param eventId the event id
   */
  public void setEventId(final Long eventId) {
    this.eventId = eventId;
  }

  /**
   * Gets rule id.
   *
   * @return the rule id
   */
  public int getRuleId() {
    return ruleId;
  }

  /**
   * Sets rule id.
   *
   * @param ruleId the rule id
   */
  public void setRuleId(final int ruleId) {
    this.ruleId = ruleId;
  }

  /**
   * Gets action.
   *
   * @return the action
   */
  public String getAction() {
    return action;
  }

  /**
   * Sets action.
   *
   * @param action the action
   */
  public void setAction(final String action) {
    this.action = action;
  }

  /**
   * Get data.
   *
   * @return the byte [ ]
   */
  public byte[] getData() {
    return data;
  }

  /**
   * Sets data.
   *
   * @param data the data
   */
  public void setData(final byte[] data) {
    this.data = data;
  }

  /**
   * Gets data flags.
   *
   * @return the data flags
   */
  public int getDataFlags() {
    return dataFlags;
  }

  /**
   * Sets data flags.
   *
   * @param dataFlags the data flags
   */
  public void setDataFlags(final int dataFlags) {
    this.dataFlags = dataFlags;
  }

  /**
   * Gets data index.
   *
   * @return the data index
   */
  public int getDataIndex() {
    return dataIndex;
  }

  /**
   * Sets data index.
   *
   * @param dataIndex the data index
   */
  public void setDataIndex(final int dataIndex) {
    this.dataIndex = dataIndex;
  }

  /**
   * Gets destination IP.
   *
   * @return the destination IP
   */
  public String getDestinationIP() {
    return destinationIP;
  }

  /**
   * Sets destination iP.
   *
   * @param destinationIP the destination iP
   */
  public void setDestinationIP(final String destinationIP) {
    this.destinationIP = destinationIP;
  }

  /**
   * Gets destination mAC.
   *
   * @return the destination mAC
   */
  public String getDestinationMAC() {
    return destinationMAC;
  }

  /**
   * Sets destination mAC.
   *
   * @param destinationMAC the destination mAC
   */
  public void setDestinationMAC(final String destinationMAC) {
    this.destinationMAC = destinationMAC;
  }

  /**
   * Gets destination port.
   *
   * @return the destination port
   */
  public String getDestinationPort() {
    return destinationPort;
  }

  /**
   * Sets destination port.
   *
   * @param destinationPort the destination port
   */
  public void setDestinationPort(final String destinationPort) {
    this.destinationPort = destinationPort;
  }

  /**
   * Gets direction.
   *
   * @return the direction
   */
  public String getDirection() {
    return direction;
  }

  /**
   * Sets direction.
   *
   * @param direction the direction
   */
  public void setDirection(final String direction) {
    this.direction = direction;
  }

  /**
   * Gets driver time.
   *
   * @return the driver time
   */
  public long getDriverTime() {
    return driverTime;
  }

  /**
   * Sets driver time.
   *
   * @param driverTime the driver time
   */
  public void setDriverTime(final long driverTime) {
    this.driverTime = driverTime;
  }

  /**
   * Gets end time.
   *
   * @return the end time
   */
  public Calendar getEndTime() {
    if (endTime == null) {
      final Calendar defaultDate = Calendar.getInstance();
      defaultDate.setTime(new Date(0));
      return defaultDate;
    }
    return endTime;
  }

  /**
   * Sets end time.
   *
   * @param endTime the end time
   */
  public void setEndTime(final Calendar endTime) {
    this.endTime = endTime;
  }

  /**
   * Gets event origin.
   *
   * @return the event origin
   */
  public String getEventOrigin() {
    return eventOrigin;
  }

  /**
   * Sets event origin.
   *
   * @param eventOrigin the event origin
   */
  public void setEventOrigin(final String eventOrigin) {
    this.eventOrigin = eventOrigin;
  }

  /**
   * Gets flags.
   *
   * @return the flags
   */
  public String getFlags() {
    return flags;
  }

  /**
   * Sets flags.
   *
   * @param flags the flags
   */
  public void setFlags(final String flags) {
    this.flags = flags;
  }

  /**
   * Gets flow.
   *
   * @return the flow
   */
  public String getFlow() {
    return flow;
  }

  /**
   * Sets flow.
   *
   * @param flow the flow
   */
  public void setFlow(final String flow) {
    this.flow = flow;
  }

  /**
   * Gets host iD.
   *
   * @return the host iD
   */
  public int getHostID() {
    return hostID;
  }

  /**
   * Sets host iD.
   *
   * @param hostID the host iD
   */
  public void setHostID(final int hostID) {
    this.hostID = hostID;
  }

  /**
   * Gets host name.
   *
   * @return the host name
   */
  public String getHostName() {
    return hostName;
  }

  /**
   * Sets host name.
   *
   * @param hostName the host name
   */
  public void setHostName(final String hostName) {
    this.hostName = hostName;
  }

  /**
   * Gets iface.
   *
   * @return the iface
   */
  public String getIface() {
    return iface;
  }

  /**
   * Sets iface.
   *
   * @param iface the iface
   */
  public void setIface(final String iface) {
    this.iface = iface;
  }

  /**
   * Gets note.
   *
   * @return the note
   */
  public String getNote() {
    return note;
  }

  /**
   * Sets note.
   *
   * @param note the note
   */
  public void setNote(final String note) {
    this.note = note;
  }

  /**
   * Gets packet size.
   *
   * @return the packet size
   */
  public int getPacketSize() {
    return packetSize;
  }

  /**
   * Sets packet size.
   *
   * @param packetSize the packet size
   */
  public void setPacketSize(final int packetSize) {
    this.packetSize = packetSize;
  }

  /**
   * Gets protocol.
   *
   * @return the protocol
   */
  public String getProtocol() {
    return protocol;
  }

  /**
   * Sets protocol.
   *
   * @param protocol the protocol
   */
  public void setProtocol(final String protocol) {
    this.protocol = protocol;
  }

  /**
   * Gets rank.
   *
   * @return the rank
   */
  public int getRank() {
    return rank;
  }

  /**
   * Sets rank.
   *
   * @param rank the rank
   */
  public void setRank(final int rank) {
    this.rank = rank;
  }

  /**
   * Gets reason.
   *
   * @return the reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * Sets reason.
   *
   * @param reason the reason
   */
  public void setReason(final String reason) {
    this.reason = reason;
  }

  /**
   * Gets repeat count.
   *
   * @return the repeat count
   */
  public int getRepeatCount() {
    return repeatCount;
  }

  /**
   * Sets repeat count.
   *
   * @param repeatCount the repeat count
   */
  public void setRepeatCount(final int repeatCount) {
    this.repeatCount = repeatCount;
  }

  /**
   * Gets source iP.
   *
   * @return the source iP
   */
  public String getSourceIP() {
    return sourceIP;
  }

  /**
   * Sets source iP.
   *
   * @param sourceIP the source iP
   */
  public void setSourceIP(final String sourceIP) {
    this.sourceIP = sourceIP;
  }

  /**
   * Gets source mAC.
   *
   * @return the source mAC
   */
  public String getSourceMAC() {
    return sourceMAC;
  }

  /**
   * Sets source mAC.
   *
   * @param sourceMAC the source mAC
   */
  public void setSourceMAC(final String sourceMAC) {
    this.sourceMAC = sourceMAC;
  }

  /**
   * Gets source port.
   *
   * @return the source port
   */
  public String getSourcePort() {
    return sourcePort;
  }

  /**
   * Sets source port.
   *
   * @param sourcePort the source port
   */
  public void setSourcePort(final String sourcePort) {
    this.sourcePort = sourcePort;
  }

  /**
   * Gets start time.
   *
   * @return the start time
   */
  public Calendar getStartTime() {
    return startTime;
  }

  /**
   * Sets start time.
   *
   * @param startTime the start time
   */
  public void setStartTime(final Calendar startTime) {
    this.startTime = startTime;
  }

  /**
   * Gets status.
   *
   * @return the status
   */
  public int getStatus() {
    return status;
  }

  /**
   * Sets status.
   *
   * @param status the status
   */
  public void setStatus(final int status) {
    this.status = status;
  }

  /**
   * Gets tags.
   *
   * @return the tags
   */
  public String getTags() {
    return tags;
  }

  /**
   * Sets tags.
   *
   * @param tags the tags
   */
  public void setTags(final String tags) {
    this.tags = tags;
  }

  /**
   * Gets vm uuid.
   *
   * @return the vm uuid
   */
  public String getVmUuid() {
    return vmUuid;
  }

  /**
   * Sets vm uuid.
   *
   * @param vmUuid the vm uuid
   */
  public void setVmUuid(final String vmUuid) {
    this.vmUuid = vmUuid;
  }

}
