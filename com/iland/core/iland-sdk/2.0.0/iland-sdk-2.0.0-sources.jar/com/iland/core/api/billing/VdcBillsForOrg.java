/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * VdcBillsForOrg.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class VdcBillsForOrg implements Serializable {

  private static final long serialVersionUID = -3082720661098294173L;

  public static final String ORG_UUID = "org_uuid";

  public static final String MONTH = "month";

  public static final String YEAR = "year";

  public static final String VDC_BILLS = "vdc_bills";

  @Expose
  @SerializedName(ORG_UUID)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String orgUuid;

  @Expose
  @SerializedName(MONTH)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private int month;

  @Expose
  @SerializedName(YEAR)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private int year;

  @Expose
  @SerializedName(VDC_BILLS)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private List<Bill> bills;

  public VdcBillsForOrg(final String orgUuid, final int month, final int year,
      final List<Bill> bills) {
    this.orgUuid = orgUuid;
    this.month = month;
    this.year = year;
    this.bills = bills;
  }

  /**
   * Get the list of vdc bills for the given org.
   *
   * @return {@link List} of {@link Bill} vDC bills
   */
  public List<Bill> getBills() {
    return bills;
  }

  /**
   * Get the org uuid.
   *
   * @return {@link String} org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Get the month.
   *
   * @return month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Get the year.
   *
   * @return year
   */
  public int getYear() {
    return year;
  }

}
