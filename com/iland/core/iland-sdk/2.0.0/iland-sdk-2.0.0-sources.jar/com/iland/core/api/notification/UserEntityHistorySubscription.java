/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.entity.EntityType;
import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.api.serialization.JsonRequired;

/**
 * User Entity History Subscription.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class UserEntityHistorySubscription implements Serializable {

  private static final long serialVersionUID = 7788374077581332818L;

  @Expose
  @SerializedName(UserEntityHistorySubscriptionField.ENTITY_TYPE)
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The type of the entity")
  private EntityType entityType;

  @Expose
  @SerializedName(UserEntityHistorySubscriptionField.ENTITY_UUID)
  @Since(ApiVersion.ZERO_DOT_ONE)
  @JsonRequired("entity uuid")
  private final String entityUuid;

  @Expose
  @SerializedName(UserEntityHistorySubscriptionField.USERNAME)
  @Since(ApiVersion.ZERO_DOT_ONE)
  @JsonRequired("username")
  private final String username;

  @Expose
  @SerializedName(UserEntityHistorySubscriptionField.EMAIL)
  @Since(ApiVersion.ZERO_DOT_ONE)
  @JsonRequired("email")
  private final String email;

  @Expose
  @SerializedName(UserEntityHistorySubscriptionField.FREQUENCY)
  @Since(ApiVersion.ZERO_DOT_ONE)
  @JsonRequired("subscription frequency currently only 'weekly' is supported")
  private final String frequency;

  @Expose
  @SerializedName(UserEntityHistorySubscriptionField.ENABLED)
  @Since(ApiVersion.ZERO_DOT_ONE)
  @JsonRequired("whether subscription is enabled")
  private final boolean enabled;

  public UserEntityHistorySubscription(final EntityType entityType,
      final String entityUuid, final String username, final String email,
      final String frequency, final boolean enabled) {
    this.entityType = entityType;
    this.entityUuid = entityUuid;
    this.username = username;
    this.email = email;
    this.frequency = frequency;
    this.enabled = enabled;
  }

  /**
   * Gets entity uuid.
   *
   * @return entity uuid
   * @required
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Gets username.
   *
   * @return username
   * @required
   */
  public String getUsername() {
    return username;
  }

  /**
   * Gets email.
   *
   * @return email address
   * @required
   */
  public String getEmail() {
    return email;
  }

  /**
   * Gets the subscription frequency.
   *
   * @return the subscription frequency (currently only 'weekly' is supported
   * @required
   */
  public String getFrequency() {
    return frequency;
  }

  /**
   * Is enabled.
   *
   * @return is enabled
   * @required
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Gets the entity type.
   *
   * @return {@link EntityType} the entity type
   */
  public EntityType getEntityType() {
    return entityType;
  }

  /**
   * Set the entity type.
   *
   * @param et {@link EntityType} entity type
   */
  public void setEntityType(final EntityType et) {
    this.entityType = et;
  }

}
