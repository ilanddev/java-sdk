/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vac;

import java.io.Serializable;
import java.util.Objects;

/**
 * Wan Accelerator.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprza</a>
 */
public final class BaWanAccelerator implements Serializable {

  private static final long serialVersionUID = 2108110796634164494L;

  private final String id;

  private final String name;

  private final String cloudConnectAgentUid;

  private final boolean isClientsAccelerator;

  /**
   * Instantiates a new Ba wan accelerator.
   *
   * @param id                   the id
   * @param name                 the name
   * @param cloudConnectAgentUid the cloud connect agent uid
   * @param isClientsAccelerator the is clients accelerator
   */
  public BaWanAccelerator(final String id, final String name,
      final String cloudConnectAgentUid, final boolean isClientsAccelerator) {
    this.id = id;
    this.name = name;
    this.cloudConnectAgentUid = cloudConnectAgentUid;
    this.isClientsAccelerator = isClientsAccelerator;
  }

  /**
   * Gets id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Gets name or IP-address of a machine which performs the role of WAN Accelerator.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets cloud connect agent uid.
   *
   * @return the cloud connect agent uid
   */
  public String getCloudConnectAgentUid() {
    return cloudConnectAgentUid;
  }

  /**
   * Is clients accelerator boolean.
   *
   * @return the boolean
   */
  public boolean isClientsAccelerator() {
    return isClientsAccelerator;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BaWanAccelerator that = (BaWanAccelerator) o;
    return isClientsAccelerator == that.isClientsAccelerator && Objects
        .equals(id, that.id) && Objects.equals(name, that.name) && Objects
        .equals(cloudConnectAgentUid, that.cloudConnectAgentUid);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(id, name, cloudConnectAgentUid, isClientsAccelerator);
  }
}
