/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.recovery;

/**
 * DisasterRecoveryRunbookReportDetailsField.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class DisasterRecoveryRunbookReportDetailsField {

  public static final String TASK_UUID = "task_uuid";

  public static final String STATUS = "status";

  public static final String LOCATION_ID = "location_id";

  public static final String TYPE = "type";

  public static final String TASK_COMPLETE = "task_complete";

  public static final String DATA = "data";

  public static final String START_TIME = "start_time";

  public static final String END_TIME = "end_time";

  public static final String PROTECTED_VM_COUNT = "protected_vm_count";

  public static final String BOOTUP_LOGS = "bootup_logs";

  public static final String DETAILS = "details";

  public static final String RECOVERY_GROUP_UUID = "recovery_group_uuid";

  public static final String FAILOVER_STATUS = "failover_status";

}
