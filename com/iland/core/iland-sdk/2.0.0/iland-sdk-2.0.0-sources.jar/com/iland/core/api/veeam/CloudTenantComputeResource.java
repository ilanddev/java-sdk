/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlElement;

/**
 * Cloud Tenant Compute Resource.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class CloudTenantComputeResource implements Serializable {

  private static final long serialVersionUID = 3921099001506051761L;

  @XmlElement(name = "CloudHardwarePlanUid")
  private String cloudHardwarePlanUid;

  @XmlElement(name = "WanAcceleratorUid")
  private String wanAcceleratorUid;

  @XmlElement(name = "PlatformType")
  private String platformType;

  @XmlElement(name = "UseNetworkFailoverResources")
  private boolean useNetworkFailoverResources;

  @XmlElement(name = "NetworkAppliance")
  private NetworkAppliance networkAppliance;

  @XmlElement(name = "ComputeResourceStats")
  private ComputeResourceStats computeResourceStats;

  public CloudTenantComputeResource() {
  }

  public CloudTenantComputeResource(final String cloudHardwarePlanUid,
      final String wanAcceleratorUid, final String platformType,
      final boolean useNetworkFailoverResources,
      final NetworkAppliance networkAppliance,
      final ComputeResourceStats computeResourceStats) {
    this.cloudHardwarePlanUid = cloudHardwarePlanUid;
    this.wanAcceleratorUid = wanAcceleratorUid;
    this.platformType = platformType;
    this.useNetworkFailoverResources = useNetworkFailoverResources;
    this.networkAppliance = networkAppliance;
    this.computeResourceStats = computeResourceStats;
  }

  /**
   * Get the cloud hardware plan UID.
   *
   * @return hardware plan UID
   */
  public String getCloudHardwarePlanUid() {
    return cloudHardwarePlanUid;
  }

  /**
   * Get the wan accelerator UID.
   *
   * @return wan accelerator UID.
   */
  public String getWanAcceleratorUid() {
    return wanAcceleratorUid;
  }

  /**
   * Get the platform type.
   *
   * @return {@link String} platform type
   */
  public String getPlatformType() {
    return platformType;
  }

  /**
   * Whether the plan is setup to use network failover resources.
   *
   * @return use network failover resources
   */
  public boolean isUseNetworkFailoverResources() {
    return useNetworkFailoverResources;
  }

  /**
   * Get the network appliance.
   *
   * @return {@link NetworkAppliance} network appliance
   */
  public NetworkAppliance getNetworkAppliance() {
    return networkAppliance;
  }

  /**
   * Get the compute resource stats.
   *
   * @return {@link ComputeResourceStats} compute resources stats
   */
  public ComputeResourceStats getComputeResourceStats() {
    return computeResourceStats;
  }

}
