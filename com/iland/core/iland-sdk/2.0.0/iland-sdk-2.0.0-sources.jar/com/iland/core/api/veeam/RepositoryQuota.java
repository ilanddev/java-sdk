/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlElement;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Repository Quota.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class RepositoryQuota implements Serializable {

  private static final long serialVersionUID = 7624898782139164353L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FIVE)
  @SerializedName(RepositoryQuotaField.DISPLAY_NAME)
  @XmlElement(name = "DisplayName")
  private String displayName;

  @XmlElement(name = "TenantResourceId")
  private String tenantResourceId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FIVE)
  @SerializedName(RepositoryQuotaField.QUOTA_MB)
  @XmlElement(name = "QuotaMb")
  private long quotaMb;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FIVE)
  @SerializedName(RepositoryQuotaField.USED_QUOTA_MB)
  @XmlElement(name = "UsedQuotaMb")
  private long usedQuotaMb;

  public RepositoryQuota() {
  }

  public RepositoryQuota(final String displayName,
      final String tenantResourceId, final long quotaMb,
      final long usedQuotaMb) {
    this.displayName = displayName;
    this.tenantResourceId = tenantResourceId;
    this.quotaMb = quotaMb;
    this.usedQuotaMb = usedQuotaMb;
  }

  /**
   * Get the repo display name.
   *
   * @return display name for the repo
   */
  public String getDisplayName() {
    return displayName;
  }

  /**
   * Get the tenant resource ID.
   *
   * @return {@link String} tenant resource ID
   */
  public String getTenantResourceId() {
    return tenantResourceId;
  }

  /**
   * Get the quota in MB.
   *
   * @return quota
   */
  public long getQuotaMb() {
    return quotaMb;
  }

  /**
   * Get the used quota in MB.
   *
   * @return used quota
   */
  public long getUsedQuotaMb() {
    return usedQuotaMb;
  }

}
