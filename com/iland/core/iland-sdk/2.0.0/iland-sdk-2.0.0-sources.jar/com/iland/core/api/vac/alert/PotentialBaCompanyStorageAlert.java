/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vac.alert;

import java.io.Serializable;
import java.util.Optional;

import com.iland.core.api.notification.CloudTenantAlert;
import com.iland.core.api.vac.VacPerfSample;
import com.iland.core.api.vac.VspcCompany;

/**
 * Represents a potential alert related to VAC Company storage.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
public final class PotentialBaCompanyStorageAlert
    implements Serializable, Comparable<PotentialBaCompanyStorageAlert> {

  private static final long serialVersionUID = -7164094392491550590L;

  private VspcCompany baCompany;

  private final VacPerfSample vacPerfSample;

  private CloudTenantAlert alert;

  private String link;

  public PotentialBaCompanyStorageAlert(final VspcCompany baCompany,
      final VacPerfSample vacPerfSample) {
    this.baCompany = baCompany;
    this.vacPerfSample = vacPerfSample;
  }

  public VspcCompany getBaCompany() {
    return baCompany;
  }

  public VacPerfSample getVacPerfSample() {
    return vacPerfSample;
  }

  /**
   * Set the cloud tenant alert that was hit.
   *
   * @param alert {@link CloudTenantAlert} the alert that hit
   */
  public void setAlert(final CloudTenantAlert alert) {
    this.alert = alert;
  }

  /**
   * Get the actual alert if one is set.
   *
   * @return {@link CloudTenantAlert} cloud tenant alert
   */
  public Optional<CloudTenantAlert> getAlert() {
    if (alert != null) {
      return Optional.of(alert);
    }
    return Optional.empty();
  }

  /**
   * Get the console link.
   *
   * @return {@link String} console link
   */
  public String getLink() {
    return link;
  }

  /**
   * Set the console link.
   *
   * @param link {@link String} console
   */
  public void setLink(final String link) {
    this.link = link;
  }

  @Override
  public int compareTo(final PotentialBaCompanyStorageAlert alert) {
    // sort a list of potential cloud tenant alerts in a descending fashion
    return alert.getVacPerfSample().getTime()
        .compareTo(this.getVacPerfSample().getTime());
  }

}
