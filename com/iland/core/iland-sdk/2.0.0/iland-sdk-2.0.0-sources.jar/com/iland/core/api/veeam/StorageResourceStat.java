/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlElement;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Storage Resource Stat.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class StorageResourceStat implements Serializable {

  private static final long serialVersionUID = 7283763395926495710L;

  @Expose
  @SerializedName(ComputeResourceStatField.STORAGE_NAME)
  @XmlElement(name = "StorageName")
  private String storageName;

  @Expose
  @SerializedName(ComputeResourceStatField.STORAGE_USAGE_GB)
  @XmlElement(name = "StorageUsageGb")
  private long storageUsageGb;

  @Expose
  @SerializedName(ComputeResourceStatField.STORAGE_LIMIT_GB)
  @XmlElement(name = "StorageLimitGb")
  private long storageLimitGb;

  public StorageResourceStat() {
  }

  public StorageResourceStat(final String storageName,
      final long storageUsageGb, final long storageLimitGb) {
    this.storageName = storageName;
    this.storageUsageGb = storageUsageGb;
    this.storageLimitGb = storageLimitGb;
  }

  /**
   * Get the storage name.
   *
   * @return storage name
   */
  public String getStorageName() {
    return storageName;
  }

  /**
   * Get the storage usage in GB.
   *
   * @return storage usage
   */
  public long getStorageUsageGb() {
    return storageUsageGb;
  }

  /**
   * Get the storage limit in GB.
   *
   * @return storage limit
   */
  public long getStorageLimitGb() {
    return storageLimitGb;
  }

}
