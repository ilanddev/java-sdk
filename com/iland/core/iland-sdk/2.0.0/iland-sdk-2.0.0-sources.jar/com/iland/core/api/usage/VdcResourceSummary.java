/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.usage;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Vdc Resource Summary Implementation.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
public class VdcResourceSummary extends VappResourceSummary {

  private static final long serialVersionUID = -7310346665234015751L;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(ResourceSummaryField.NUMBER_OF_VAPPS)
  private long numberOfVapps = 0;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(ResourceSummaryField.ALLOC_CPU)
  private double allocationCpu = 0;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(ResourceSummaryField.ALLOC_MEMORY)
  private double allocationMemory = 0;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(ResourceSummaryField.CONFIGURED_MEMORY)
  private double configuredMemory = 0;

  @Since(ApiVersion.ZERO_DOT_EIGHT)
  @Expose
  @SerializedName(ResourceSummaryField.CONFIGURED_CPU)
  private double configuredCpu = 0;

  public VdcResourceSummary() {
  }

  public VdcResourceSummary(final double reservedCpu, final double reservedMem,
      final double consumedCpu, final double consumedMem,
      final double consumedDisk, final double provisionedDisk,
      final long numberOfVms, final long numberOfVapps,
      final double allocationCpu, final double allocationMemory,
      final double configuredMemory, final double configuredDisk,
      final double configuredCpu) {
    super(reservedCpu, reservedMem, consumedCpu, consumedMem, consumedDisk,
        provisionedDisk, numberOfVms, configuredDisk);
    this.numberOfVapps = numberOfVapps;
    this.allocationCpu = allocationCpu;
    this.allocationMemory = allocationMemory;
    this.configuredMemory = configuredMemory;
    this.configuredCpu = configuredCpu;
  }

  /**
   * Return the number of Vapps.
   *
   * @return number of Vapps.
   */
  public long getNumberOfVapps() {
    return numberOfVapps;
  }

  /**
   * Get the vdc allocation cpu value in Ghz.
   * <p>
   * Should be 0 for Vdc types other than allocation model.
   *
   * @return double representing allocation cpu in MHZ
   */
  public double getAllocationCpu() {
    return allocationCpu;
  }

  /**
   * Get the vdc allocation memory value.
   * <p>
   * Should be 0 for Vdc types other than allocation model.
   *
   * @return double representing allocation memory
   */
  public double getAllocationMemory() {
    return allocationMemory;
  }

  /**
   * Get the configured memory for the VDC. The sum of all non-powered-off VM
   * memory allocations.
   *
   * @return double representing configured memory
   */
  public double getConfiguredMemory() {
    return configuredMemory;
  }

  /**
   * Get the configured CPU.
   *
   * @return configured cpu
   */
  public double getConfiguredCpu() {
    return configuredCpu;
  }

}
