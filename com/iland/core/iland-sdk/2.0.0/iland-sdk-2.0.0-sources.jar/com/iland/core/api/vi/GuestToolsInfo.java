/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vi;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Guest Tools Information.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
public class GuestToolsInfo implements Serializable {

  private static final long serialVersionUID = 766404496419718391L;

  public static final String VERSION = "version";

  public static final String RUNNING_STATUS = "running_status";

  public static final String STATUS = "status";

  @Expose
  @SerializedName(STATUS)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private String status;

  @Expose
  @SerializedName(RUNNING_STATUS)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private String runningStatus;

  @Expose
  @SerializedName(VERSION)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private String version;

  public GuestToolsInfo() {
  }

  public GuestToolsInfo(final String status, final String runningStatus,
      final String version) {
    this.status = status;
    this.runningStatus = runningStatus;
    this.version = version;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(final String status) {
    this.status = status;
  }

  public String getRunningStatus() {
    return runningStatus;
  }

  public void setRunningStatus(final String runningStatus) {
    this.runningStatus = runningStatus;
  }

  public String getVersion() {
    return version;
  }

  public void setVersion(final String version) {
    this.version = version;
  }

}
