/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.util.Location;

/**
 * VccBill.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class VccBill implements Serializable {

  private static final long serialVersionUID = 960941543562455596L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_EIGHT)
  @SerializedName(VccBillField.TOTAL)
  private double total;

  @Expose
  @Since(ApiVersion.ZERO_DOT_EIGHT)
  @SerializedName(VccBillField.YEAR)
  private int year;

  @Expose
  @Since(ApiVersion.ZERO_DOT_EIGHT)
  @SerializedName(VccBillField.MONTH)
  private int month;

  @Expose
  @Since(ApiVersion.ZERO_DOT_EIGHT)
  @SerializedName(VccBillField.CURRENCY_CODE)
  private CurrencyCode currencyCode;

  @Expose
  @Since(ApiVersion.ZERO_DOT_EIGHT)
  @SerializedName(VccBillField.STORAGE_QUOTA_IN_GB)
  private long storageQuotaInGB;

  @Expose
  @Since(ApiVersion.ZERO_DOT_EIGHT)
  @SerializedName(VccBillField.STORAGE_PRICE_PER_GB)
  private double storagePricePerGB;

  @Expose
  @Since(ApiVersion.ZERO_DOT_EIGHT)
  @SerializedName(VccBillField.FULL_MONTH_CONTRACT_COST)
  private double fullMonthContractCost;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccBillField.HAS_INSIDER_PROTECTION)
  private boolean hasInsiderProtection;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccBillField.INSIDER_PROTECTION_PRICE_PER_GB)
  private double insiderProtectionPricePerGB;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccBillField.INSIDER_PROTECTION_TOTAL)
  private double insiderProtectionTotal;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccBillField.WAN_ACCELERATOR_APPLIANCE_TOTAL)
  private double wanAcceleratorApplianceTotal;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccBillField.DEDICATED_VEEAM_CLOUD_GATEWAY_TOTAL)
  private double dedicatedVeeamGatewayTotal;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccBillField.RENTAL_LICENSES_SUBSCRIPTIONS_TOTAL)
  private double rentalLicensesSubscriptionsTotal;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(VccBillField.CROSS_CONNECT_SUBSCRIPTIONS_TOTAL)
  private double crossConnectSubscriptionsTotal;

  public VccBill(final double total, final int year, final int month,
      final CurrencyCode currencyCode, final long storageQuotaInGB,
      final double storagePricePerGB, final double fullMonthContractCost,
      final boolean hasInsiderProtection,
      final double insiderProtectionPricePerGB,
      final double insiderProtectionTotal,
      final double wanAcceleratorApplianceTotal,
      final double dedicatedVeeamGatewayTotal,
      final double rentalLicensesSubscriptionsTotal,
      final double crossConnectSubscriptionsTotal) {
    this.total = total;
    this.year = year;
    this.month = month;
    this.currencyCode = currencyCode;
    this.storageQuotaInGB = storageQuotaInGB;
    this.storagePricePerGB = storagePricePerGB;
    this.fullMonthContractCost = fullMonthContractCost;
    this.hasInsiderProtection = hasInsiderProtection;
    this.insiderProtectionPricePerGB = insiderProtectionPricePerGB;
    this.insiderProtectionTotal = insiderProtectionTotal;
    this.wanAcceleratorApplianceTotal = wanAcceleratorApplianceTotal;
    this.dedicatedVeeamGatewayTotal = dedicatedVeeamGatewayTotal;
    this.rentalLicensesSubscriptionsTotal = rentalLicensesSubscriptionsTotal;
    this.crossConnectSubscriptionsTotal = crossConnectSubscriptionsTotal;
  }

  /**
   * Get a bill for a test drive customer.
   *
   * @param locationId {@link String} location ID
   * @return {@link VccBill} for a test drive customer
   */
  public static VccBill getTestDriveBill(final String locationId) {
    return new VccBill(0, LocalDateTime.now().getYear(),
        LocalDateTime.now().getMonthValue(),
        Location.getDefaultCurrencyCode(locationId), 0, 0, 0, false, 0, 0, 0, 0,
        0, 0);
  }

  /**
   * Get the total.
   *
   * @return total cost
   */
  public double getTotal() {
    return total;
  }

  /**
   * Get the year.
   *
   * @return year
   */
  public int getYear() {
    return year;
  }

  /**
   * Get the month.
   *
   * @return month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Get the currency code for the bill.
   *
   * @return {@link CurrencyCode} currency code
   */
  public CurrencyCode getCurrencyCode() {
    return currencyCode;
  }

  /**
   * Get the storage price per GB.
   *
   * @return per GB storage price
   */
  public double getStoragePricePerGB() {
    return storagePricePerGB;
  }

  /**
   * Get the full month contract cost.
   *
   * @return full month contract cost
   */
  public double getFullMonthContractCost() {
    return fullMonthContractCost;
  }

  /**
   * Get the storage quota in GB.
   *
   * @return storage quota
   */
  public long getStorageQuotaInGB() {
    return storageQuotaInGB;
  }

  /**
   * Sets the currency code.
   *
   * @param currencyCode {@link CurrencyCode} currency code
   */
  public void setCurrencyCode(final CurrencyCode currencyCode) {
    this.currencyCode = currencyCode;
  }

  /**
   * Does the VCC customer have insider protection.
   *
   * @return has insider protection
   */
  public boolean hasInsiderProtection() {
    return hasInsiderProtection;
  }

  /**
   * Get the insider protection price per GB.
   *
   * @return insider protection price per GB
   */
  public double getInsiderProtectionPricePerGB() {
    return insiderProtectionPricePerGB;
  }

  /**
   * Get the insider protection total.
   *
   * @return insider protection total
   */
  public double getInsiderProtectionTotal() {
    return insiderProtectionTotal;
  }

  /**
   * Get the wan accelerator appliance total.
   *
   * @return wan accelerator total
   */
  public double getWanAcceleratorApplianceTotal() {
    return wanAcceleratorApplianceTotal;
  }

  /**
   * Get the dedicated veeam gateway total.
   *
   * @return dedicated veeam gateway total
   */
  public double getDedicatedVeeamGatewayTotal() {
    return dedicatedVeeamGatewayTotal;
  }

  /**
   * Get the rental licenses subscriptions total.
   *
   * @return rental licenses subscriptions total
   */
  public double getRentalLicensesSubscriptionsTotal() {
    return rentalLicensesSubscriptionsTotal;
  }

  /**
   * Get the cross connect subscriptions total.
   *
   * @return cross connect subscriptions total
   */
  public double getCrossConnectSubscriptionsTotal() {
    return crossConnectSubscriptionsTotal;
  }

  /**
   * Is a WAN accelerator customer.
   *
   * @return is wan accelerator customer
   */
  public boolean hasWanAccelerator() {
    return wanAcceleratorApplianceTotal > 0;
  }

}
