/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.recovery;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import javax.annotation.Nonnull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.entity.AbstractEntity;
import com.iland.core.api.entity.CompanyEntity;
import com.iland.core.api.entity.Entity;
import com.iland.core.api.entity.EntityAncestorUtil;
import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.model.EntityType;

/**
 * Recovery Runbook.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class DisasterRecoveryRunbook extends AbstractEntity
    implements CompanyEntity {

  private static final long serialVersionUID = 5820151414669246910L;

  private static final String URN_ILAND_RUNBOOK = ":urn:iland:runbook:";

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(RecoveryRunbookField.CRM)
  private String crm;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(RecoveryRunbookField.LOCATION_ID)
  private String locationId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(RecoveryRunbookField.ORG_UUID)
  private String orgUuid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(RecoveryRunbookField.DESCRIPTION)
  private String description;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(RecoveryRunbookField.CREATED_DATE)
  private Instant createdDate;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(RecoveryRunbookField.LAST_TEST)
  private Instant lastTest;

  // list of VPG uuids for now since one recovery plan is equivalent to one VPG
  // this is an ordered list - where order denotes recovery order
  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(RecoveryRunbookField.RECOVERY_GROUPS)
  private List<RecoveryGroupDescriptor> recoveryGroupList;

  private Map<com.iland.common.entity.EntityType, String> ancestors;

  public DisasterRecoveryRunbook(final String crm, final String locationId,
      final String orgUuid, final String uuid, final String name,
      final String description,
      final List<RecoveryGroupDescriptor> recoveryGroupList,
      final boolean deleted, final Instant createdDate,
      final Instant deletedDate, final Instant updatedDate,
      final Instant lastTest) {
    super(uuid, deleted, deletedDate, name, updatedDate);
    this.crm = crm;
    this.locationId = locationId;
    this.orgUuid = orgUuid;
    this.description = description;
    this.recoveryGroupList = recoveryGroupList;
    this.createdDate = createdDate;
    this.lastTest = lastTest;
  }

  /**
   * Create a new recovery runbook.
   *
   * @param crm               {@link String} CRM number
   * @param locationId        {@link String} location ID
   * @param orgUuid           {@link String} organization UUID
   * @param name              {@link String} runbook name
   * @param description       {@link String} description
   * @param recoveryGroupList {@link List} of {@link RecoveryGroupDescriptor}
   *                          recovery groups
   * @return {@link DisasterRecoveryRunbook} new recovery runbook
   */
  public static DisasterRecoveryRunbook createNew(final String crm,
      final String locationId, final String orgUuid, final String name,
      final String description,
      final List<RecoveryGroupDescriptor> recoveryGroupList) {
    final Instant now = Instant.now();
    return new DisasterRecoveryRunbook(crm, locationId, orgUuid,
        locationId + URN_ILAND_RUNBOOK + UUID.randomUUID(), name, description,
        recoveryGroupList, false, now, null, now, null);
  }

  /**
   * Get the CRM.
   *
   * @return {@link String} CRM
   */
  public String getCrm() {
    return crm;
  }

  /**
   * Get the location ID.
   *
   * @return {@link String} location ID
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Get the organization uuid.
   *
   * @return {@link String} organization uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Get the runbook description.
   *
   * @return {@link String} runbook description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get the last test date.
   *
   * @return {@link Instant} last test
   */
  public Instant getLastTest() {
    return lastTest;
  }

  /**
   * Set the last test.
   *
   * @param lastTest {@link Instant} last test date
   */
  public void setLastTest(final Instant lastTest) {
    this.lastTest = lastTest;
  }

  /**
   * Get the list of recovery plan descriptors.
   *
   * @return {@link List} of {@link RecoveryGroupDescriptor} recovery plan
   * descriptors
   */
  public List<RecoveryGroupDescriptor> getRecoveryGroupList() {
    return recoveryGroupList;
  }

  /**
   * Get the runbook creation date.
   *
   * @return {@link Instant} created date
   */
  public Instant getCreatedDate() {
    return createdDate;
  }

  @Nonnull
  @Override
  public Map<com.iland.common.entity.EntityType, String> getAncestors() {
    if (ancestors == null || ancestors.isEmpty()) {
      ancestors = EntityAncestorUtil.getAncestorsFromOrganization(crm,
          locationId, orgUuid);
    }

    return ancestors;
  }

  @Nonnull
  @Override
  public String getCompanyId() {
    return crm;
  }

  @Override
  public int entityHashCode() {
    return Objects
        .hash(super.entityHashCode(), crm, locationId, orgUuid, description,
            createdDate, recoveryGroupList, lastTest);
  }

  @Override
  public boolean entityEquals(final Entity other) {
    if (other == null || !EntityType.IAAS_DISASTER_RECOVERY_RUNBOOK
        .equals(other.getEntityType())) {
      return false;
    }
    final DisasterRecoveryRunbook otherRunbook =
        (DisasterRecoveryRunbook) other;
    return super.entityEquals(otherRunbook) && Objects
        .equals(crm, otherRunbook.crm) && Objects
        .equals(locationId, otherRunbook.locationId) && Objects
        .equals(orgUuid, otherRunbook.orgUuid) && Objects
        .equals(description, otherRunbook.description) && Objects
        .equals(createdDate, otherRunbook.createdDate) && Objects
        .equals(lastTest, otherRunbook.lastTest) && Objects
        .equals(recoveryGroupList, otherRunbook.recoveryGroupList);
  }

  @Override
  public EntityType getEntityType() {
    return EntityType.IAAS_DISASTER_RECOVERY_RUNBOOK;
  }

}
