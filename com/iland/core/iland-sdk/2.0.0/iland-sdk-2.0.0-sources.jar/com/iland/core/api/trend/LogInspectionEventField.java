/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.trend;

/**
 * Log Inspection Event Field.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public final class LogInspectionEventField {

  public static final String ACTION = "action";

  public static final String COMMAND = "command";

  public static final String DATA = "data";

  public static final String DESCRIPTION = "description";

  public static final String DESTINATION_IP = "destination_ip";

  public static final String DESTINATION_PORT = "destination_port";

  public static final String DESTINATION_USER = "destination_user";

  public static final String FULL_EVENT = "full_event";

  public static final String GROUPS = "groups";

  public static final String HOST_ID = "host_id";

  public static final String HOST_NAME = "host_name";

  public static final String LOCATION = "location";

  public static final String EVENT_ID = "event_id";

  public static final String RULE_ID = "rule_id";

  public static final String LOG_TIME = "log_time";

  public static final String MESSAGE = "message";

  public static final String PROGRAM_NAME = "program_name";

  public static final String PROTOCOL = "protocol";

  public static final String RANK = "rank";

  public static final String REASON = "reason";

  public static final String SEVERITY = "severity";

  public static final String SOURCE_HOST_NAME = "source_host_name";

  public static final String SOURCE_ID = "source_id";

  public static final String SOURCE_IP = "source_ip";

  public static final String SOURCE_PORT = "source_port";

  public static final String SOURCE_USER = "source_user";

  public static final String STATUS = "status";

  public static final String SYSTEM_NAME = "system_name";

  public static final String TAGS = "tags";

  public static final String URL = "url";

  public static final String VM_UUID = "vm_uuid";

  private LogInspectionEventField() {
  }

}
