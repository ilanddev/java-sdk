/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.coretask.api.domain;

import com.google.common.base.MoreObjects;
import com.google.errorprone.annotations.Var;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link LocationId}.
 * <p>
 * Use the static factory method to create immutable instances:
 * {@code LocationIdTuple.of()}.
 */
@Generated(from = "LocationId", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
final class LocationIdTuple implements LocationId {
  private final String value;
  private transient final String shortIdentifier;

  private LocationIdTuple(String value) {
    this.value = Objects.requireNonNull(value, "value");
    this.shortIdentifier = Objects.requireNonNull(LocationId.super.shortIdentifier(), "shortIdentifier");
  }

  private LocationIdTuple(LocationIdTuple original, String value) {
    this.value = value;
    this.shortIdentifier = Objects.requireNonNull(LocationId.super.shortIdentifier(), "shortIdentifier");
  }

  /**
   * @return The value of the {@code value} attribute
   */
  @Override
  public String value() {
    return value;
  }

  /**
   * @return The computed-at-construction value of the {@code shortIdentifier} attribute
   */
  @Override
  public String shortIdentifier() {
    return shortIdentifier;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link LocationId#value() value} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for value
   * @return A modified copy of the {@code this} object
   */
  public final LocationIdTuple withValue(String value) {
    String newValue = Objects.requireNonNull(value, "value");
    if (this.value.equals(newValue)) return this;
    return validate(new LocationIdTuple(this, newValue));
  }

  /**
   * This instance is equal to all instances of {@code LocationIdTuple} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof LocationIdTuple
        && equalTo(0, (LocationIdTuple) another);
  }

  private boolean equalTo(int synthetic, LocationIdTuple another) {
    return value.equals(another.value);
  }

  /**
   * Computes a hash code from attributes: {@code value}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + value.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code LocationId} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("LocationId")
        .omitNullValues()
        .add("value", value)
        .toString();
  }

  /**
   * Construct a new immutable {@code LocationId} instance.
   * @param value The value for the {@code value} attribute
   * @return An immutable LocationId instance
   */
  public static LocationIdTuple of(String value) {
    return validate(new LocationIdTuple(value));
  }

  private static LocationIdTuple validate(LocationIdTuple instance) {
    instance.check();
    return instance;
  }

  /**
   * Creates an immutable copy of a {@link LocationId} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable LocationId instance
   */
  public static LocationIdTuple copyOf(LocationId instance) {
    if (instance instanceof LocationIdTuple) {
      return (LocationIdTuple) instance;
    }
    return LocationIdTuple.of(instance.value());
  }
}
