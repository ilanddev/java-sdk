/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.api.serialization.JsonRequired;

/**
 * User Vm Resource Alert Subscription Impl.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class UserExtNetworkResourceAlert extends AbstractResourceAlert {

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.EXTERNAL_NETWORK_UUID)
  private String externalNetwork;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.THRESHOLD)
  @JsonRequired("alert threshold")
  protected double threshold;

  public UserExtNetworkResourceAlert() {
  }

  public UserExtNetworkResourceAlert(final String externalNetwork,
      final String group, final String name, final String type,
      final double threshold) {
    super(group, name, type);
    this.externalNetwork = externalNetwork;
    this.threshold = threshold;
  }

  /**
   * Get the external network uuid attached to this alert.
   *
   * @return {@link String} external network uuid
   */
  public String getExternalNetwork() {
    return externalNetwork;
  }

  /**
   * Set the external networ
   * k uuid attached to this alert.
   *
   * @param externalNetwork {@link String} vm uuid
   */
  public void setExternalNetwork(final String externalNetwork) {
    this.externalNetwork = externalNetwork;
  }

  /**
   * Get the alerting threshold at which the user wants to receive alerts for
   * the counter specified by group, name and type.
   *
   * @return alerting threshold
   */
  public double getThreshold() {
    return threshold;
  }

  /**
   * Set the alerting threshold at which the user wants to receive alerts for
   * the counter specified by group, name and type.
   *
   * @param threshold alerting threshold
   */
  public void setThreshold(final long threshold) {
    this.threshold = threshold;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserExtNetworkResourceAlert that = (UserExtNetworkResourceAlert) o;

    if (Double.compare(that.getThreshold(), getThreshold()) != 0)
      return false;
    if (isEnabled() != that.isEnabled())
      return false;
    if (getBreachPeriod() != that.getBreachPeriod())
      return false;
    if (getExternalNetwork() != null ?
        !getExternalNetwork().equals(that.getExternalNetwork()) :
        that.getExternalNetwork() != null)
      return false;
    if (getGroup() != null ?
        !getGroup().equals(that.getGroup()) :
        that.getGroup() != null)
      return false;
    if (getName() != null ?
        !getName().equals(that.getName()) :
        that.getName() != null)
      return false;
    if (getType() != null ?
        !getType().equals(that.getType()) :
        that.getType() != null)
      return false;
    if (getUsername() != null ?
        !getUsername().equals(that.getUsername()) :
        that.getUsername() != null)
      return false;
    if (getAction() != null ?
        !getAction().equals(that.getAction()) :
        that.getAction() != null)
      return false;
    return equalityRelation != null ?
        equalityRelation.equals(that.equalityRelation) :
        that.equalityRelation == null;
  }

  @Override
  public int hashCode() {
    int result;
    long temp;
    result = getExternalNetwork() != null ? getExternalNetwork().hashCode() : 0;
    result = 31 * result + (getGroup() != null ? getGroup().hashCode() : 0);
    result = 31 * result + (getName() != null ? getName().hashCode() : 0);
    result = 31 * result + (getType() != null ? getType().hashCode() : 0);
    temp = Double.doubleToLongBits(getThreshold());
    result = 31 * result + (int) (temp ^ (temp >>> 32));
    result =
        31 * result + (getUsername() != null ? getUsername().hashCode() : 0);
    result = 31 * result + (getAction() != null ? getAction().hashCode() : 0);
    result = 31 * result + (equalityRelation != null ?
        equalityRelation.hashCode() :
        0);
    result = 31 * result + (isEnabled() ? 1 : 0);
    result = 31 * result + getBreachPeriod();
    return result;
  }

}
