/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;

/**
 * Bill Field.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Cory Snyder</a>
 */
public enum BillField {

  @SerializedName(BillingEntityField.CPU) CPU(BillingEntityField.CPU),

  @SerializedName(BillingEntityField.CPU_USAGE) CPU_USAGE(
      BillingEntityField.CPU_USAGE),

  @SerializedName(BillingEntityField.CPU_BURST_USAGE) CPU_BURST_USAGE(
      BillingEntityField.CPU_BURST_USAGE),

  @SerializedName(BillingEntityField.CPU_BURST) CPU_BURST(
      BillingEntityField.CPU_BURST),

  @SerializedName(BillingEntityField.CPU_RES_USAGE) CPU_RES_USAGE(
      BillingEntityField.CPU_RES_USAGE),

  @SerializedName(BillingEntityField.MEMORY) MEMORY(BillingEntityField.MEMORY),

  @SerializedName(BillingEntityField.MEMORY_USAGE) MEMORY_USAGE(
      BillingEntityField.MEMORY_USAGE),

  @SerializedName(BillingEntityField.MEMORY_BURST) MEMORY_BURST(
      BillingEntityField.MEMORY_BURST),

  @SerializedName(BillingEntityField.MEMORY_BURST_USAGE) MEMORY_BURST_USAGE(
      BillingEntityField.MEMORY_BURST_USAGE),

  @SerializedName(BillingEntityField.MEMORY_RES_USAGE) MEMORY_RES_USAGE(
      BillingEntityField.MEMORY_RES_USAGE),

  @SerializedName(BillingEntityField.DISK) DISK(BillingEntityField.DISK),

  @SerializedName(BillingEntityField.DISK_USAGE) DISK_USAGE(
      BillingEntityField.DISK_USAGE),

  @SerializedName(BillingEntityField.DISK_BURST) DISK_BURST(
      BillingEntityField.DISK_BURST),

  @SerializedName(BillingEntityField.DISK_BURST_USAGE) DISK_BURST_USAGE(
      BillingEntityField.DISK_BURST_USAGE),

  @SerializedName(BillingEntityField.BANDWIDTH) BANDWIDTH(
      BillingEntityField.BANDWIDTH),

  @SerializedName(BillingEntityField.BANDWIDTH_USAGE) BANDWIDTH_USAGE(
      BillingEntityField.BANDWIDTH_USAGE),

  @SerializedName(BillingEntityField.BANDWIDTH_BURST) BANDWIDTH_BURST(
      BillingEntityField.BANDWIDTH_BURST),

  @SerializedName(BillingEntityField.BANDWIDTH_RES_USAGE) BANDWIDTH_RES_USAGE(
      BillingEntityField.BANDWIDTH_RES_USAGE),

  @SerializedName(BillingEntityField.BANDWIDTH_BURST_USAGE) BANDWIDTH_BURST_USAGE(
      BillingEntityField.BANDWIDTH_BURST_USAGE);

  private static final Map<String, BillField> reverseMap = new HashMap<>();

  static {
    for (final BillField field : values()) {
      BillField.reverseMap.put(field.representation, field);
    }
  }

  private final String representation;

  BillField(final String representation) {
    this.representation = representation;
  }

  /**
   * Gets a {@link BillField} from it's string value.
   *
   * @param value the value
   * @return {@link BillField}
   */
  public static BillField fromString(final String value) {
    if (!BillField.reverseMap.containsKey(value)) {
      throw new IllegalArgumentException(
          String.format("BillField does not have member=%s", value));
    }
    return BillField.reverseMap.get(value);
  }

  @Override
  public String toString() {
    return this.representation;
  }

}
