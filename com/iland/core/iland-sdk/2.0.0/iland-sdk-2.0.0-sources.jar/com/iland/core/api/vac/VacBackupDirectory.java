/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vac;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;

/**
 * Vac Backup Directory.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public final class VacBackupDirectory implements Serializable {

  private static final long serialVersionUID = -8597657194725370024L;

  private final String uuid;

  private final String name;

  private final float sizeMb;

  private final Instant modifiedAt;

  private final String repositoryName;

  private final String backupServerName;

  private final boolean recycled;

  private final List<VacBackupFile> backupFiles;

  /**
   * Instantiates a new Vac backup directory.
   *
   * @param uuid             the uuid
   * @param name             the name
   * @param sizeMb           the size mb
   * @param modifiedAt       the modified at
   * @param repositoryName   the repository name
   * @param backupServerName the backup server name
   * @param recycled         the recycled
   * @param backupFiles      the backup files
   */
  public VacBackupDirectory(final String uuid, final String name,
      final float sizeMb, final Instant modifiedAt,
      final String repositoryName, final String backupServerName,
      final boolean recycled, final List<VacBackupFile> backupFiles) {
    this.uuid = uuid;
    this.name = name;
    this.sizeMb = sizeMb;
    this.modifiedAt = modifiedAt;
    this.repositoryName = repositoryName;
    this.backupServerName = backupServerName;
    this.recycled = recycled;
    this.backupFiles = backupFiles;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets size mb.
   *
   * @return the size mb
   */
  public float getSizeMb() {
    return sizeMb;
  }

  /**
   * Gets modified at.
   *
   * @return the modified at
   */
  public Instant getModifiedAt() {
    return modifiedAt;
  }

  /**
   * Gets repository name.
   *
   * @return the repository name
   */
  public String getRepositoryName() {
    return repositoryName;
  }

  /**
   * Gets backup server name.
   *
   * @return the backup server name
   */
  public String getBackupServerName() {
    return backupServerName;
  }

  /**
   * Is recycled boolean.
   *
   * @return the boolean
   */
  public boolean isRecycled() {
    return recycled;
  }

  /**
   * Gets backup files.
   *
   * @return the backup files
   */
  public List<VacBackupFile> getBackupFiles() {
    return backupFiles;
  }
}
