/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * VeeamCloudTenantResources.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class CloudRepository implements Serializable {

  private static final long serialVersionUID = 7624898782139164353L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(CloudRepositoryField.DISPLAY_NAME)
  @XmlElement(name = "DisplayName")
  private String displayName;

  @XmlElement(name = "RepositoryUid")
  private String repositoryUid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(CloudRepositoryField.QUOTA)
  @XmlElement(name = "Quota")
  private long quota;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(CloudRepositoryField.USED_QUOTA)
  @XmlElement(name = "UsedQuota")
  private long usedQuota;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(CloudRepositoryField.WAN_ACCELERATOR_UUID)
  @XmlElement(name = "WanAcceleratorUid")
  private String wanAcceleratorUid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(CloudRepositoryField.WAN_ACCELERATOR)
  private WanAccelerator wanAccelerator;

  public CloudRepository() {
  }

  public CloudRepository(final String displayName, final String repositoryUid,
      final long quota, final String wanAcceleratorUid) {
    this.displayName = displayName;
    this.repositoryUid = repositoryUid;
    this.quota = quota;
    this.wanAcceleratorUid = wanAcceleratorUid;
  }

  /**
   * Get the repo display name.
   *
   * @return display name for the repo
   */
  public String getDisplayName() {
    return displayName;
  }

  /**
   * Get the repository UID.
   *
   * @return repo UID
   */
  public String getRepositoryUid() {
    return repositoryUid;
  }

  /**
   * Get the total repo quota.
   *
   * @return total quota
   */
  public long getQuota() {
    return quota;
  }

  /**
   * Get the WAN acceleartor UID.
   *
   * @return WAN accelerator UID.
   */
  public String getWanAcceleratorUid() {
    return wanAcceleratorUid;
  }

  /**
   * Get the used quota.
   *
   * @return used quota
   */
  public long getUsedQuota() {
    return usedQuota;
  }

  /**
   * Set the used quota.
   *
   * @param usedQuota used quota
   */
  public void setUsedQuota(final long usedQuota) {
    this.usedQuota = usedQuota;
  }

  /**
   * Set the quota on the cloud repo.
   *
   * @param quota total quota
   */
  public void setQuota(final long quota) {
    this.quota = quota;
  }

  /**
   * Set the WAN accelerator.
   *
   * @param wanAccelerator {@link WanAccelerator} wan accelerator
   */
  public void setWanAccelerator(final WanAccelerator wanAccelerator) {
    this.wanAccelerator = wanAccelerator;
  }

  /**
   * Get the WanAccelerator for the repository.
   *
   * @return {@link WanAccelerator} WAN accelerator
   */
  public WanAccelerator getWanAccelerator() {
    return wanAccelerator;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final CloudRepository that = (CloudRepository) o;

    if (getQuota() != that.getQuota())
      return false;
    if (getUsedQuota() != that.getUsedQuota())
      return false;
    if (getDisplayName() != null ?
        !getDisplayName().equals(that.getDisplayName()) :
        that.getDisplayName() != null)
      return false;
    if (getRepositoryUid() != null ?
        !getRepositoryUid().equals(that.getRepositoryUid()) :
        that.getRepositoryUid() != null)
      return false;
    if (getWanAcceleratorUid() != null ?
        !getWanAcceleratorUid().equals(that.getWanAcceleratorUid()) :
        that.getWanAcceleratorUid() != null)
      return false;
    return getWanAccelerator() != null ?
        getWanAccelerator().equals(that.getWanAccelerator()) :
        that.getWanAccelerator() == null;
  }

  @Override
  public int hashCode() {
    int result = getDisplayName() != null ? getDisplayName().hashCode() : 0;
    result = 31 * result + (getRepositoryUid() != null ?
        getRepositoryUid().hashCode() :
        0);
    result = 31 * result + (int) (getQuota() ^ (getQuota() >>> 32));
    result = 31 * result + (int) (getUsedQuota() ^ (getUsedQuota() >>> 32));
    result = 31 * result + (getWanAcceleratorUid() != null ?
        getWanAcceleratorUid().hashCode() :
        0);
    result = 31 * result + (getWanAccelerator() != null ?
        getWanAccelerator().hashCode() :
        0);
    return result;
  }

}
