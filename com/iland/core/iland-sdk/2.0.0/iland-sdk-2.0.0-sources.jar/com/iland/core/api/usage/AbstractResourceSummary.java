/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.usage;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Abstract resource summary.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
public abstract class AbstractResourceSummary implements ResourceSummary {

  private static final long serialVersionUID = 3352591660875608036L;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(ResourceSummaryField.RESERVED_CPU)
  protected double reservedCpu = 0.0;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(ResourceSummaryField.RESERVED_MEMORY)
  protected double reservedMem = 0.0;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(ResourceSummaryField.CONSUMED_CPU)
  protected double consumedCpu = 0.0;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(ResourceSummaryField.CONSUMED_MEMORY)
  protected double consumedMem = 0.0;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(ResourceSummaryField.CONSUMED_DISK)
  protected double consumedDisk = 0.0;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(ResourceSummaryField.PROVISIONED_DISK)
  protected double provisionedDisk = 0.0;

  @Since(ApiVersion.ZERO_DOT_EIGHT)
  @Expose
  @SerializedName(ResourceSummaryField.CONFIGURED_DISK)
  protected double configuredDisk = 0.0;

  protected AbstractResourceSummary() {
  }

  public AbstractResourceSummary(final double reservedCpu,
      final double reservedMem, final double consumedCpu,
      final double consumedMem, final double consumedDisk,
      final double provisionedDisk, final double configuredDisk) {
    super();
    this.reservedCpu = reservedCpu;
    this.reservedMem = reservedMem;
    this.consumedCpu = consumedCpu;
    this.consumedMem = consumedMem;
    this.consumedDisk = consumedDisk;
    this.provisionedDisk = provisionedDisk;
    this.configuredDisk = configuredDisk;
  }

  @Override
  public double getReservedCpu() {
    return reservedCpu;
  }

  @Override
  public double getReservedMem() {
    return reservedMem;
  }

  @Override
  public double getConsumedCpu() {
    return consumedCpu;
  }

  @Override
  public double getConsumedMem() {
    return consumedMem;
  }

  @Override
  public double getConsumedDisk() {
    return consumedDisk;
  }

  @Override
  public double getProvisionedDisk() {
    return provisionedDisk;
  }

  @Override
  public double getConfiguredDisk() {
    return configuredDisk;
  }

}
