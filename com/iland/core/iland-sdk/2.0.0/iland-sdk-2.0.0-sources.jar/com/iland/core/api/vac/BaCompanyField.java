/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vac;

import java.io.Serializable;

import com.iland.core.api.entity.EntityField;

/**
 * Ba Company Field.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public final class BaCompanyField extends EntityField implements Serializable {

  private static final long serialVersionUID = -2788754985556180735L;

  public static final String UID = "uid";

  public static final String TYPE = "type";

  public static final String HREF = "href";

  public static final String ID = "uid";

  public static final String DESCRIPTION = "description";

  public static final String ENABLED = "enabled";

  public static final String LAST_RESULT = "last_result";

  public static final String LAST_ACTIVE = "last_active";

  public static final String CRM = "crm";

  public static final String EMAIL = "email";

  public static final String YEAR = "year";

  public static final String MONTH = "month";

  public static final String DATA = "data";

  public static final String VAC_COMPANY = "vac_company";

  public static final String VAC_COMPANY_NAME = "vac_company_name";

  public static final String COMPANY = "company";

  public static final String COMPANY_NAME = "company_name";

  public static final String USER = "user";

  public static final String BACKUP_RESOURCE_ID = "backup_resource_id";

  public static final String BACKUP_REPO_UID = "backup_repo_id";

  public static final String VAC_SAVE_BACKUP_RESOURCE =
      "vac_save_backup_resource";

  public static final String VAC_CREATE_COMPANY = "vac_create_company";

  public static final String NEW_BACKUP_STORAGE_QUOTA =
      "new_backup_storage_quota";

  public static final String VAC_JOB_UUID = "vac_job_uuid";

  private BaCompanyField() {}
}
