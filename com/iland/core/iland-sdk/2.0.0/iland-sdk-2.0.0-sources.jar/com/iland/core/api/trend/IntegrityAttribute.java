/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.trend;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.util.IlandSerializedName;

/**
 * Integrity Attribute.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class IntegrityAttribute implements Serializable {

  private static final long serialVersionUID = 1852013222092739785L;

  @Expose
  @IlandSerializedName(IntegrityAttributeField.FRIENDLY_VALUE)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private String friendlyValue;

  @Expose
  @IlandSerializedName(IntegrityAttributeField.NAME)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private String name;

  @Expose
  @IlandSerializedName(IntegrityAttributeField.VALUE)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private String value;

  public IntegrityAttribute() {
  }

  /**
   * Get the friendly value.
   *
   * @return {@link String} friendly value
   */
  public String getFriendlyValue() {
    return friendlyValue;
  }

  /**
   * Set the friendly value.
   *
   * @param friendlyValue {@link String} friendly value
   */
  public void setFriendlyValue(final String friendlyValue) {
    this.friendlyValue = friendlyValue;
  }

  /**
   * Get the name.
   *
   * @return {@link String} name
   */
  public String getName() {
    return name;
  }

  /**
   * Set the name.
   *
   * @param name {@link String} name
   */
  public void setName(final String name) {
    this.name = name;
  }

  /**
   * Get the value.
   *
   * @return {@link String} value
   */
  public String getValue() {
    return value;
  }

  /**
   * Set the value.
   *
   * @param value {@link String} value
   */
  public void setValue(final String value) {
    this.value = value;
  }

}
