/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.support;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;
import com.google.gson.annotations.Until;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.api.serialization.JsonOptional;
import com.iland.core.api.serialization.JsonRequired;

/**
 * Support Ticket.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class SupportTicket implements Serializable {

  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = -7934359887231852308L;

  /**
   * The ticket number.
   */
  @Expose
  @JsonRequired("The unique ticket number.")
  @SerializedName(SupportTicketField.ID)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final int id;

  /**
   * The summary.
   */
  @Expose
  @JsonRequired("Summary of the support ticket request.")
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final String summary;

  /**
   * The status.
   */
  @Expose
  @JsonRequired("Status of the support ticket request.")
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final SupportTicketStatus status;

  /**
   * The org uuid.
   */
  @Expose
  @Deprecated
  @JsonOptional("(Deprecated) The UUID of the organization that the support request is associated with.")
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Until(ApiVersion.ZERO_DOT_EIGHT)
  @SerializedName(SupportTicketField.ORG_UUID)
  private String orgUuid;

  /**
   * The org uuid.
   */
  @Expose
  @JsonRequired("The UUID of the company that the support request is associated with.")
  @Since(ApiVersion.ZERO_DOT_EIGHT)
  @SerializedName(SupportTicketField.CRM)
  private final String crm;

  /**
   * The creator full name.
   */
  @Expose
  @JsonRequired("Full name of the user who created the request.")
  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(SupportTicketField.CREATOR_FULL_NAME)
  private final String creatorFullName;

  /**
   * The creator user name.
   */
  @Expose
  @JsonRequired("User name of the user who created the request.")
  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(SupportTicketField.CREATOR_USER_NAME)
  private final String creatorUserName;

  /**
   * The creation date.
   */
  @Expose
  @JsonRequired("Date that the ticket was created.")
  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(SupportTicketField.CREATION_DATE)
  private final Date creationDate;

  /**
   * List of email addresses to cc on ticket updates.
   */
  @Expose
  @JsonOptional("List of email addresses to cc on ticket updates.")
  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(SupportTicketField.CC_EMAIL_ADDRESSES)
  private final List<String> ccEmailAddresses;

  /**
   * Whether email cc updates are enabled.
   */
  @Expose
  @JsonOptional("Whether email cc updates are enabled.")
  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(SupportTicketField.CC_EMAILS_ENABLED)
  private final boolean ccEmailsEnabled;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(SupportTicketField.REGARDING_ID)
  private final int regardingId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(SupportTicketField.SERVICE_ID)
  private final int serviceId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(SupportTicketField.CATEGORY_ID)
  private final Integer categoryId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(SupportTicketField.SEVERITY)
  private final Severity severity;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(SupportTicketField.REGARDING_NAME)
  private final String regardingName;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(SupportTicketField.SERVICE_NAME)
  private final String serviceName;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(SupportTicketField.CATEGORY_NAME)
  private final String categoryName;

  /**
   * Instantiates a new support ticket.
   *
   * @param ticketNumber     the ticket number
   * @param summary          the summary
   * @param status           the status
   * @param crm              the company identifier
   * @param creatorFullName  the creator full name
   * @param creatorUserName  the creator user name
   * @param creationDate     the creation date
   * @param ccEmailAddresses the cc email addresses
   * @param ccEmailsEnabled  the cc emails enabled
   * @param regardingId      the regarding option id
   * @param serviceId        the service option id
   * @param categoryId       the category option id
   * @param severity         the severity
   * @param regardingName    the regarding option name
   * @param serviceName      the service option name
   * @param categoryName     the category option name
   */
  public SupportTicket(final int ticketNumber, final String summary,
      final SupportTicketStatus status, final String crm,
      final String creatorFullName, final String creatorUserName,
      final Date creationDate, final List<String> ccEmailAddresses,
      final boolean ccEmailsEnabled, final int regardingId, final int serviceId,
      final Integer categoryId, final Severity severity,
      final String regardingName, final String serviceName,
      final String categoryName) {
    this.id = ticketNumber;
    this.crm = crm;
    this.summary = summary;
    this.status = status;
    this.creatorFullName = creatorFullName;
    this.creatorUserName = creatorUserName;
    this.creationDate = creationDate;
    this.ccEmailAddresses = ccEmailAddresses;
    this.ccEmailsEnabled = ccEmailsEnabled;
    this.regardingId = regardingId;
    this.serviceId = serviceId;
    this.categoryId = categoryId;
    this.severity = severity;
    this.regardingName = regardingName;
    this.serviceName = serviceName;
    this.categoryName = categoryName;
  }

  /**
   * Gets the ticket number.
   *
   * @return the ticket number
   */
  public int getId() {
    return id;
  }

  /**
   * Gets the summary.
   *
   * @return the summary
   */
  public String getSummary() {
    return summary;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public SupportTicketStatus getStatus() {
    return status;
  }

  /**
   * Gets the company identifier.
   *
   * @return the company identifier
   */
  public String getCrm() {
    return crm;
  }

  /**
   * Gets the org uuid.
   *
   * @return the org uuid.
   */
  @Deprecated
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Sets the org uuid.
   *
   * @param orgUuid the org uuid.
   */
  @Deprecated
  public void setOrgUuid(final String orgUuid) {
    this.orgUuid = orgUuid;
  }

  /**
   * Gets the creator full name.
   *
   * @return the creator full name
   */
  public String getCreatorFullName() {
    return creatorFullName;
  }

  /**
   * Gets the creator user name.
   *
   * @return the creator user name
   */
  public String getCreatorUserName() {
    return creatorUserName;
  }

  /**
   * Gets the creation date.
   *
   * @return the creation date
   */
  public Date getCreationDate() {
    return creationDate;
  }

  /**
   * Gets the cc email addresses.
   *
   * @return the cc email addresses
   */
  public List<String> getCcEmailAddresses() {
    return ccEmailAddresses;
  }

  /**
   * Checks if is cc emails enabled.
   *
   * @return true, if is cc emails enabled
   */
  public boolean isCcEmailsEnabled() {
    return ccEmailsEnabled;
  }

  /**
   * Gets the regarding option id.
   *
   * @return {@link Integer} regarding option id
   */
  public int getRegardingId() {
    return regardingId;
  }

  /**
   * Gets the service option id.
   *
   * @return {@link Integer} service option id
   */
  public int getServiceId() {
    return serviceId;
  }

  /**
   * Get the support category id.
   *
   * @return {@link Integer} category option id
   */
  public Integer getCategoryId() {
    return categoryId;
  }

  /**
   * Gets the severity.
   *
   * @return {@link Severity} severity
   */
  public Severity getSeverity() {
    return severity;
  }

  /**
   * Gets the regarding option name.
   *
   * @return {@link String} regarding option name
   */
  public String getRegardingName() {
    return regardingName;
  }

  /**
   * Gets the service option name.
   *
   * @return {@link String} service option name
   */
  public String getServiceName() {
    return serviceName;
  }

  /**
   * Gets the category option name.
   *
   * @return {@link String} category option name
   */
  public String getCategoryName() {
    return categoryName;
  }

  @Override
  public String toString() {
    return String.format(
        "SupportTicket [id=%s, summary=%s, status=%s, crm=%s, creatorFullName=%s, creatorUserName=%s, creationDate=%s, ccEmailAddresses=%s, ccEmailsEnabled=%s]",
        id, summary, status, crm, creatorFullName, creatorUserName,
        creationDate, ccEmailAddresses, ccEmailsEnabled);
  }

}
