/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.processing.Generated;
import com.google.gson.*;
import com.google.gson.stream.*;
import com.google.gson.reflect.*;
import java.io.IOException;

/**
 * A {@code TypeAdapterFactory} that handles all of the immutable types generated under {@code $APIModelGenerator}.
 * @see ImmutableTargetData
 * @see ImmutableJobReplicationData
 * @see ImmutableReplicationData
 * @see ImmutableReplicationInformationResponse
 * @see ImmutableStorageHistoryParameters
 * @see ImmutableRunStats
 * @see ImmutableReplicationInformationParameters
 * @see ImmutableStorageHistoryItem
 * @see ImmutableStorageHistoryResponse
 * @see ImmutableHeliosTenantId
 */
@SuppressWarnings({"all", "MethodCanBeStatic"})
@ParametersAreNonnullByDefault
@Generated("org.immutables.processor.ProxyProcessor")
@org.immutables.value.Generated(from = "com.iland.offsite.replication.api.model", generator = "Gsons")
public final class GsonAdapters$APIModelGenerator implements TypeAdapterFactory {
  @SuppressWarnings({"unchecked", "rawtypes"}) // safe unchecked, types are verified in runtime
  @Override
  public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
    if (TargetDataTypeAdapter.adapts(type)) {
      return (TypeAdapter<T>) new TargetDataTypeAdapter(gson);
    }
    if (JobReplicationDataTypeAdapter.adapts(type)) {
      return (TypeAdapter<T>) new JobReplicationDataTypeAdapter(gson);
    }
    if (ReplicationDataTypeAdapter.adapts(type)) {
      return (TypeAdapter<T>) new ReplicationDataTypeAdapter(gson);
    }
    if (ReplicationInformationResponseTypeAdapter.adapts(type)) {
      return (TypeAdapter<T>) new ReplicationInformationResponseTypeAdapter(gson);
    }
    if (StorageHistoryParametersTypeAdapter.adapts(type)) {
      return (TypeAdapter<T>) new StorageHistoryParametersTypeAdapter(gson);
    }
    if (RunStatsTypeAdapter.adapts(type)) {
      return (TypeAdapter<T>) new RunStatsTypeAdapter(gson);
    }
    if (ReplicationInformationParametersTypeAdapter.adapts(type)) {
      return (TypeAdapter<T>) new ReplicationInformationParametersTypeAdapter(gson);
    }
    if (StorageHistoryItemTypeAdapter.adapts(type)) {
      return (TypeAdapter<T>) new StorageHistoryItemTypeAdapter(gson);
    }
    if (StorageHistoryResponseTypeAdapter.adapts(type)) {
      return (TypeAdapter<T>) new StorageHistoryResponseTypeAdapter(gson);
    }
    if (HeliosTenantIdTypeAdapter.adapts(type)) {
      return (TypeAdapter<T>) new HeliosTenantIdTypeAdapter(gson);
    }
    return null;
  }

  @Override
  public String toString() {
    return "GsonAdapters$APIModelGenerator(TargetData, JobReplicationData, ReplicationData, ReplicationInformationResponse, StorageHistoryParameters, RunStats, ReplicationInformationParameters, StorageHistoryItem, StorageHistoryResponse, HeliosTenantId)";
  }

  @org.immutables.value.Generated(from = "TargetData", generator = "Gsons")
  @SuppressWarnings({"unchecked", "rawtypes"}) // safe unchecked, types are verified in runtime
  private static class TargetDataTypeAdapter extends TypeAdapter<TargetData> {
    public final JobStatus statusTypeSample = null;
    public final Instant startTimeTypeSample = null;
    public final Instant endTimeTypeSample = null;
    private final TypeAdapter<JobStatus> statusTypeAdapter;
    private final TypeAdapter<Instant> startTimeTypeAdapter;
    private final TypeAdapter<Instant> endTimeTypeAdapter;
    final String statusName;
    final String startTimeName;
    final String endTimeName;

    @org.immutables.value.Generated(from = "TargetData", generator = "Gsons")
    static class TargetDataNamingFields {
      public Optional<JobStatus> status;
      public Optional<Instant> startTime;
      public Optional<Instant> endTime;
    }

    TargetDataTypeAdapter(Gson gson) {
      this.statusTypeAdapter = gson.getAdapter( JobStatus.class);
      this.startTimeTypeAdapter = gson.getAdapter( Instant.class);
      this.endTimeTypeAdapter = gson.getAdapter( Instant.class);
      this.statusName = translateName(gson, TargetDataNamingFields.class, "status");
      this.startTimeName = translateName(gson, TargetDataNamingFields.class, "startTime");
      this.endTimeName = translateName(gson, TargetDataNamingFields.class, "endTime");
    }

    static boolean adapts(TypeToken<?> type) {
      return TargetData.class == type.getRawType()
          || ImmutableTargetData.class == type.getRawType();
    }

    @Override
    public void write(JsonWriter out, TargetData value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        writeTargetData(out, value);
      }
    }

    @Override
    public TargetData read(JsonReader in) throws IOException {
      return readTargetData(in);
    }

    private void writeTargetData(JsonWriter out, TargetData instance)
        throws IOException {
      out.beginObject();
      Optional<JobStatus> statusOptional = instance.status();
      if (statusOptional.isPresent()) {
        out.name(statusName);
        JobStatus statusValue = statusOptional.get();
        statusTypeAdapter.write(out, statusValue);
      } else if (out.getSerializeNulls()) {
        out.name(statusName);
        out.nullValue();
      }
      Optional<Instant> startTimeOptional = instance.startTime();
      if (startTimeOptional.isPresent()) {
        out.name(startTimeName);
        Instant startTimeValue = startTimeOptional.get();
        startTimeTypeAdapter.write(out, startTimeValue);
      } else if (out.getSerializeNulls()) {
        out.name(startTimeName);
        out.nullValue();
      }
      Optional<Instant> endTimeOptional = instance.endTime();
      if (endTimeOptional.isPresent()) {
        out.name(endTimeName);
        Instant endTimeValue = endTimeOptional.get();
        endTimeTypeAdapter.write(out, endTimeValue);
      } else if (out.getSerializeNulls()) {
        out.name(endTimeName);
        out.nullValue();
      }
      out.endObject();
    }

    private TargetData readTargetData(JsonReader in)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
        return null;
      }
      ImmutableTargetData.Builder builder = ImmutableTargetData.builder();
      in.beginObject();
      while (in.hasNext()) {
        eachAttribute(in, builder);
      }
      in.endObject();
      return builder.build();
    }

    private void eachAttribute(JsonReader in, ImmutableTargetData.Builder builder)
        throws IOException {
      String name = in.nextName();
      if (statusName.equals(name)) {
        readInStatus(in, builder);
        return;
      }
      if (startTimeName.equals(name)) {
        readInStartTime(in, builder);
        return;
      }
      if (endTimeName.equals(name)) {
        readInEndTime(in, builder);
        return;
      }
      in.skipValue();
    }

    private void readInStatus(JsonReader in, ImmutableTargetData.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        JobStatus value = statusTypeAdapter.read(in);
        builder.status(value);
      }
    }

    private void readInStartTime(JsonReader in, ImmutableTargetData.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        Instant value = startTimeTypeAdapter.read(in);
        builder.startTime(value);
      }
    }

    private void readInEndTime(JsonReader in, ImmutableTargetData.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        Instant value = endTimeTypeAdapter.read(in);
        builder.endTime(value);
      }
    }
  }

  @org.immutables.value.Generated(from = "JobReplicationData", generator = "Gsons")
  @SuppressWarnings({"unchecked", "rawtypes"}) // safe unchecked, types are verified in runtime
  private static class JobReplicationDataTypeAdapter extends TypeAdapter<JobReplicationData> {
    public final Long protectedObjectsTypeSample = null;
    public final Boolean isCompliantTypeSample = null;
    public final TargetData targetsTypeSample = null;
    private final TypeAdapter<Long> protectedObjectsTypeAdapter;
    private final TypeAdapter<Boolean> isCompliantTypeAdapter;
    private final TypeAdapter<TargetData> targetsTypeAdapter;
    final String nameName;
    final String protectedObjectsName;
    final String isCompliantName;
    final String targetsName;

    @org.immutables.value.Generated(from = "JobReplicationData", generator = "Gsons")
    static class JobReplicationDataNamingFields {
      public Optional<String> name;
      public Optional<Long> protectedObjects;
      public Optional<Boolean> isCompliant;
      public List<TargetData> targets;
    }

    JobReplicationDataTypeAdapter(Gson gson) {
      this.protectedObjectsTypeAdapter = gson.getAdapter( Long.class);
      this.isCompliantTypeAdapter = gson.getAdapter( Boolean.class);
      this.targetsTypeAdapter = gson.getAdapter( TargetData.class);
      this.nameName = translateName(gson, JobReplicationDataNamingFields.class, "name");
      this.protectedObjectsName = translateName(gson, JobReplicationDataNamingFields.class, "protectedObjects");
      this.isCompliantName = translateName(gson, JobReplicationDataNamingFields.class, "isCompliant");
      this.targetsName = translateName(gson, JobReplicationDataNamingFields.class, "targets");
    }

    static boolean adapts(TypeToken<?> type) {
      return JobReplicationData.class == type.getRawType()
          || ImmutableJobReplicationData.class == type.getRawType();
    }

    @Override
    public void write(JsonWriter out, JobReplicationData value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        writeJobReplicationData(out, value);
      }
    }

    @Override
    public JobReplicationData read(JsonReader in) throws IOException {
      return readJobReplicationData(in);
    }

    private void writeJobReplicationData(JsonWriter out, JobReplicationData instance)
        throws IOException {
      out.beginObject();
      Optional<String> nameOptional = instance.name();
      if (nameOptional.isPresent()) {
        out.name(nameName);
        String nameValue = nameOptional.get();
        out.value(nameValue);
      } else if (out.getSerializeNulls()) {
        out.name(nameName);
        out.nullValue();
      }
      Optional<Long> protectedObjectsOptional = instance.protectedObjects();
      if (protectedObjectsOptional.isPresent()) {
        out.name(protectedObjectsName);
        Long protectedObjectsValue = protectedObjectsOptional.get();
        protectedObjectsTypeAdapter.write(out, protectedObjectsValue);
      } else if (out.getSerializeNulls()) {
        out.name(protectedObjectsName);
        out.nullValue();
      }
      Optional<Boolean> isCompliantOptional = instance.isCompliant();
      if (isCompliantOptional.isPresent()) {
        out.name(isCompliantName);
        Boolean isCompliantValue = isCompliantOptional.get();
        isCompliantTypeAdapter.write(out, isCompliantValue);
      } else if (out.getSerializeNulls()) {
        out.name(isCompliantName);
        out.nullValue();
      }
      List<TargetData> targetsElements = instance.targets();
      out.name(targetsName);
      out.beginArray();
      for (TargetData e : targetsElements) {
        targetsTypeAdapter.write(out, e);
      }
      out.endArray();
      out.endObject();
    }

    private JobReplicationData readJobReplicationData(JsonReader in)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
        return null;
      }
      ImmutableJobReplicationData.Builder builder = ImmutableJobReplicationData.builder();
      in.beginObject();
      while (in.hasNext()) {
        eachAttribute(in, builder);
      }
      in.endObject();
      return builder.build();
    }

    private void eachAttribute(JsonReader in, ImmutableJobReplicationData.Builder builder)
        throws IOException {
      String name = in.nextName();
      if (nameName.equals(name)) {
        readInName(in, builder);
        return;
      }
      if (protectedObjectsName.equals(name)) {
        readInProtectedObjects(in, builder);
        return;
      }
      if (isCompliantName.equals(name)) {
        readInIsCompliant(in, builder);
        return;
      }
      if (targetsName.equals(name)) {
        readInTargets(in, builder);
        return;
      }
      in.skipValue();
    }

    private void readInName(JsonReader in, ImmutableJobReplicationData.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        builder.name(in.nextString());
      }
    }

    private void readInProtectedObjects(JsonReader in, ImmutableJobReplicationData.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        Long value = protectedObjectsTypeAdapter.read(in);
        builder.protectedObjects(value);
      }
    }

    private void readInIsCompliant(JsonReader in, ImmutableJobReplicationData.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        Boolean value = isCompliantTypeAdapter.read(in);
        builder.isCompliant(value);
      }
    }

    private void readInTargets(JsonReader in, ImmutableJobReplicationData.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.BEGIN_ARRAY) {
        in.beginArray();
        while(in.hasNext()) {
          TargetData value = targetsTypeAdapter.read(in);
          builder.addTargets(value);
        }
        in.endArray();
      } else if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        TargetData value = targetsTypeAdapter.read(in);
        builder.addTargets(value);
      }
    }
  }

  @org.immutables.value.Generated(from = "ReplicationData", generator = "Gsons")
  @SuppressWarnings({"unchecked", "rawtypes"}) // safe unchecked, types are verified in runtime
  private static class ReplicationDataTypeAdapter extends TypeAdapter<ReplicationData> {
    public final Long dataInBytesTypeSample = null;
    public final Long dataInBytesAfterDeduplicationTypeSample = null;
    public final Long consumedStorageTypeSample = null;
    public final Long contractedStorageTypeSample = null;
    public final RunStats runStatsTypeSample = null;
    private final TypeAdapter<Long> dataInBytesTypeAdapter;
    private final TypeAdapter<Long> dataInBytesAfterDeduplicationTypeAdapter;
    private final TypeAdapter<Long> consumedStorageTypeAdapter;
    private final TypeAdapter<Long> contractedStorageTypeAdapter;
    private final TypeAdapter<RunStats> runStatsTypeAdapter;
    final String dataInBytesName;
    final String dataInBytesAfterDeduplicationName;
    final String consumedStorageName;
    final String contractedStorageName;
    final String runStatsName;

    @org.immutables.value.Generated(from = "ReplicationData", generator = "Gsons")
    static class ReplicationDataNamingFields {
      public Long dataInBytes;
      public Long dataInBytesAfterDeduplication;
      public Long consumedStorage;
      public Long contractedStorage;
      public RunStats runStats;
    }

    ReplicationDataTypeAdapter(Gson gson) {
      this.dataInBytesTypeAdapter = gson.getAdapter( Long.class);
      this.dataInBytesAfterDeduplicationTypeAdapter = gson.getAdapter( Long.class);
      this.consumedStorageTypeAdapter = gson.getAdapter( Long.class);
      this.contractedStorageTypeAdapter = gson.getAdapter( Long.class);
      this.runStatsTypeAdapter = gson.getAdapter( RunStats.class);
      this.dataInBytesName = translateName(gson, ReplicationDataNamingFields.class, "dataInBytes");
      this.dataInBytesAfterDeduplicationName = translateName(gson, ReplicationDataNamingFields.class, "dataInBytesAfterDeduplication");
      this.consumedStorageName = translateName(gson, ReplicationDataNamingFields.class, "consumedStorage");
      this.contractedStorageName = translateName(gson, ReplicationDataNamingFields.class, "contractedStorage");
      this.runStatsName = translateName(gson, ReplicationDataNamingFields.class, "runStats");
    }

    static boolean adapts(TypeToken<?> type) {
      return ReplicationData.class == type.getRawType()
          || ImmutableReplicationData.class == type.getRawType();
    }

    @Override
    public void write(JsonWriter out, ReplicationData value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        writeReplicationData(out, value);
      }
    }

    @Override
    public ReplicationData read(JsonReader in) throws IOException {
      return readReplicationData(in);
    }

    private void writeReplicationData(JsonWriter out, ReplicationData instance)
        throws IOException {
      out.beginObject();
      out.name(dataInBytesName);
      dataInBytesTypeAdapter.write(out, instance.dataInBytes());
      out.name(dataInBytesAfterDeduplicationName);
      dataInBytesAfterDeduplicationTypeAdapter.write(out, instance.dataInBytesAfterDeduplication());
      out.name(consumedStorageName);
      consumedStorageTypeAdapter.write(out, instance.consumedStorage());
      out.name(contractedStorageName);
      contractedStorageTypeAdapter.write(out, instance.contractedStorage());
      out.name(runStatsName);
      runStatsTypeAdapter.write(out, instance.runStats());
      out.endObject();
    }

    private ReplicationData readReplicationData(JsonReader in)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
        return null;
      }
      ImmutableReplicationData.Builder builder = ImmutableReplicationData.builder();
      in.beginObject();
      while (in.hasNext()) {
        eachAttribute(in, builder);
      }
      in.endObject();
      return builder.build();
    }

    private void eachAttribute(JsonReader in, ImmutableReplicationData.Builder builder)
        throws IOException {
      String name = in.nextName();
      if (dataInBytesName.equals(name)) {
        readInDataInBytes(in, builder);
        return;
      }
      if (dataInBytesAfterDeduplicationName.equals(name)) {
        readInDataInBytesAfterDeduplication(in, builder);
        return;
      }
      if (consumedStorageName.equals(name)) {
        readInConsumedStorage(in, builder);
        return;
      }
      if (contractedStorageName.equals(name)) {
        readInContractedStorage(in, builder);
        return;
      }
      if (runStatsName.equals(name)) {
        readInRunStats(in, builder);
        return;
      }
      in.skipValue();
    }

    private void readInDataInBytes(JsonReader in, ImmutableReplicationData.Builder builder)
        throws IOException {
      Long value = dataInBytesTypeAdapter.read(in);
      builder.dataInBytes(value);
    }

    private void readInDataInBytesAfterDeduplication(JsonReader in, ImmutableReplicationData.Builder builder)
        throws IOException {
      Long value = dataInBytesAfterDeduplicationTypeAdapter.read(in);
      builder.dataInBytesAfterDeduplication(value);
    }

    private void readInConsumedStorage(JsonReader in, ImmutableReplicationData.Builder builder)
        throws IOException {
      Long value = consumedStorageTypeAdapter.read(in);
      builder.consumedStorage(value);
    }

    private void readInContractedStorage(JsonReader in, ImmutableReplicationData.Builder builder)
        throws IOException {
      Long value = contractedStorageTypeAdapter.read(in);
      builder.contractedStorage(value);
    }

    private void readInRunStats(JsonReader in, ImmutableReplicationData.Builder builder)
        throws IOException {
      RunStats value = runStatsTypeAdapter.read(in);
      builder.runStats(value);
    }
  }

  @org.immutables.value.Generated(from = "ReplicationInformationResponse", generator = "Gsons")
  @SuppressWarnings({"unchecked", "rawtypes"}) // safe unchecked, types are verified in runtime
  private static class ReplicationInformationResponseTypeAdapter extends TypeAdapter<ReplicationInformationResponse> {
    public final ReplicationData replicationDataTypeSample = null;
    public final JobReplicationData jobReplicationDataTypeSample = null;
    private final TypeAdapter<ReplicationData> replicationDataTypeAdapter;
    private final TypeAdapter<JobReplicationData> jobReplicationDataTypeAdapter;
    final String replicationDataName;
    final String jobReplicationDataName;

    @org.immutables.value.Generated(from = "ReplicationInformationResponse", generator = "Gsons")
    static class ReplicationInformationResponseNamingFields {
      public ReplicationData replicationData;
      public List<JobReplicationData> jobReplicationData;
    }

    ReplicationInformationResponseTypeAdapter(Gson gson) {
      this.replicationDataTypeAdapter = gson.getAdapter( ReplicationData.class);
      this.jobReplicationDataTypeAdapter = gson.getAdapter( JobReplicationData.class);
      this.replicationDataName = translateName(gson, ReplicationInformationResponseNamingFields.class, "replicationData");
      this.jobReplicationDataName = translateName(gson, ReplicationInformationResponseNamingFields.class, "jobReplicationData");
    }

    static boolean adapts(TypeToken<?> type) {
      return ReplicationInformationResponse.class == type.getRawType()
          || ImmutableReplicationInformationResponse.class == type.getRawType();
    }

    @Override
    public void write(JsonWriter out, ReplicationInformationResponse value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        writeReplicationInformationResponse(out, value);
      }
    }

    @Override
    public ReplicationInformationResponse read(JsonReader in) throws IOException {
      return readReplicationInformationResponse(in);
    }

    private void writeReplicationInformationResponse(JsonWriter out, ReplicationInformationResponse instance)
        throws IOException {
      out.beginObject();
      out.name(replicationDataName);
      replicationDataTypeAdapter.write(out, instance.replicationData());
      List<JobReplicationData> jobReplicationDataElements = instance.jobReplicationData();
      out.name(jobReplicationDataName);
      out.beginArray();
      for (JobReplicationData e : jobReplicationDataElements) {
        jobReplicationDataTypeAdapter.write(out, e);
      }
      out.endArray();
      out.endObject();
    }

    private ReplicationInformationResponse readReplicationInformationResponse(JsonReader in)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
        return null;
      }
      ImmutableReplicationInformationResponse.Builder builder = ImmutableReplicationInformationResponse.builder();
      in.beginObject();
      while (in.hasNext()) {
        eachAttribute(in, builder);
      }
      in.endObject();
      return builder.build();
    }

    private void eachAttribute(JsonReader in, ImmutableReplicationInformationResponse.Builder builder)
        throws IOException {
      String name = in.nextName();
      if (replicationDataName.equals(name)) {
        readInReplicationData(in, builder);
        return;
      }
      if (jobReplicationDataName.equals(name)) {
        readInJobReplicationData(in, builder);
        return;
      }
      in.skipValue();
    }

    private void readInReplicationData(JsonReader in, ImmutableReplicationInformationResponse.Builder builder)
        throws IOException {
      ReplicationData value = replicationDataTypeAdapter.read(in);
      builder.replicationData(value);
    }

    private void readInJobReplicationData(JsonReader in, ImmutableReplicationInformationResponse.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.BEGIN_ARRAY) {
        in.beginArray();
        while(in.hasNext()) {
          JobReplicationData value = jobReplicationDataTypeAdapter.read(in);
          builder.addJobReplicationData(value);
        }
        in.endArray();
      } else if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        JobReplicationData value = jobReplicationDataTypeAdapter.read(in);
        builder.addJobReplicationData(value);
      }
    }
  }

  @org.immutables.value.Generated(from = "StorageHistoryParameters", generator = "Gsons")
  @SuppressWarnings({"unchecked", "rawtypes"}) // safe unchecked, types are verified in runtime
  private static class StorageHistoryParametersTypeAdapter extends TypeAdapter<StorageHistoryParameters> {
    public final CompanyId companyIdTypeSample = null;
    public final VdcUuid vdcUuidsTypeSample = null;
    public final Instant startTimeTypeSample = null;
    public final Instant endTimeTypeSample = null;
    private final TypeAdapter<CompanyId> companyIdTypeAdapter;
    private final TypeAdapter<VdcUuid> vdcUuidsTypeAdapter;
    private final TypeAdapter<Instant> startTimeTypeAdapter;
    private final TypeAdapter<Instant> endTimeTypeAdapter;
    final String companyIdName;
    final String vdcUuidsName;
    final String startTimeName;
    final String endTimeName;

    @org.immutables.value.Generated(from = "StorageHistoryParameters", generator = "Gsons")
    static class StorageHistoryParametersNamingFields {
      public CompanyId companyId;
      public List<VdcUuid> vdcUuids;
      public Optional<Instant> startTime;
      public Optional<Instant> endTime;
    }

    StorageHistoryParametersTypeAdapter(Gson gson) {
      this.companyIdTypeAdapter = gson.getAdapter( CompanyId.class);
      this.vdcUuidsTypeAdapter = gson.getAdapter( VdcUuid.class);
      this.startTimeTypeAdapter = gson.getAdapter( Instant.class);
      this.endTimeTypeAdapter = gson.getAdapter( Instant.class);
      this.companyIdName = translateName(gson, StorageHistoryParametersNamingFields.class, "companyId");
      this.vdcUuidsName = translateName(gson, StorageHistoryParametersNamingFields.class, "vdcUuids");
      this.startTimeName = translateName(gson, StorageHistoryParametersNamingFields.class, "startTime");
      this.endTimeName = translateName(gson, StorageHistoryParametersNamingFields.class, "endTime");
    }

    static boolean adapts(TypeToken<?> type) {
      return StorageHistoryParameters.class == type.getRawType()
          || ImmutableStorageHistoryParameters.class == type.getRawType();
    }

    @Override
    public void write(JsonWriter out, StorageHistoryParameters value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        writeStorageHistoryParameters(out, value);
      }
    }

    @Override
    public StorageHistoryParameters read(JsonReader in) throws IOException {
      return readStorageHistoryParameters(in);
    }

    private void writeStorageHistoryParameters(JsonWriter out, StorageHistoryParameters instance)
        throws IOException {
      out.beginObject();
      out.name(companyIdName);
      companyIdTypeAdapter.write(out, instance.companyId());
      List<VdcUuid> vdcUuidsElements = instance.vdcUuids();
      out.name(vdcUuidsName);
      out.beginArray();
      for (VdcUuid e : vdcUuidsElements) {
        vdcUuidsTypeAdapter.write(out, e);
      }
      out.endArray();
      Optional<Instant> startTimeOptional = instance.startTime();
      if (startTimeOptional.isPresent()) {
        out.name(startTimeName);
        Instant startTimeValue = startTimeOptional.get();
        startTimeTypeAdapter.write(out, startTimeValue);
      } else if (out.getSerializeNulls()) {
        out.name(startTimeName);
        out.nullValue();
      }
      Optional<Instant> endTimeOptional = instance.endTime();
      if (endTimeOptional.isPresent()) {
        out.name(endTimeName);
        Instant endTimeValue = endTimeOptional.get();
        endTimeTypeAdapter.write(out, endTimeValue);
      } else if (out.getSerializeNulls()) {
        out.name(endTimeName);
        out.nullValue();
      }
      out.endObject();
    }

    private StorageHistoryParameters readStorageHistoryParameters(JsonReader in)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
        return null;
      }
      ImmutableStorageHistoryParameters.Builder builder = ImmutableStorageHistoryParameters.builder();
      in.beginObject();
      while (in.hasNext()) {
        eachAttribute(in, builder);
      }
      in.endObject();
      return builder.build();
    }

    private void eachAttribute(JsonReader in, ImmutableStorageHistoryParameters.Builder builder)
        throws IOException {
      String name = in.nextName();
      if (companyIdName.equals(name)) {
        readInCompanyId(in, builder);
        return;
      }
      if (vdcUuidsName.equals(name)) {
        readInVdcUuids(in, builder);
        return;
      }
      if (startTimeName.equals(name)) {
        readInStartTime(in, builder);
        return;
      }
      if (endTimeName.equals(name)) {
        readInEndTime(in, builder);
        return;
      }
      in.skipValue();
    }

    private void readInCompanyId(JsonReader in, ImmutableStorageHistoryParameters.Builder builder)
        throws IOException {
      CompanyId value = companyIdTypeAdapter.read(in);
      builder.companyId(value);
    }

    private void readInVdcUuids(JsonReader in, ImmutableStorageHistoryParameters.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.BEGIN_ARRAY) {
        in.beginArray();
        while(in.hasNext()) {
          VdcUuid value = vdcUuidsTypeAdapter.read(in);
          builder.addVdcUuids(value);
        }
        in.endArray();
      } else if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        VdcUuid value = vdcUuidsTypeAdapter.read(in);
        builder.addVdcUuids(value);
      }
    }

    private void readInStartTime(JsonReader in, ImmutableStorageHistoryParameters.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        Instant value = startTimeTypeAdapter.read(in);
        builder.startTime(value);
      }
    }

    private void readInEndTime(JsonReader in, ImmutableStorageHistoryParameters.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        Instant value = endTimeTypeAdapter.read(in);
        builder.endTime(value);
      }
    }
  }

  @org.immutables.value.Generated(from = "RunStats", generator = "Gsons")
  @SuppressWarnings({"unchecked", "rawtypes"}) // safe unchecked, types are verified in runtime
  private static class RunStatsTypeAdapter extends TypeAdapter<RunStats> {
    final String cancelledName;
    final String failedName;
    final String ongoingName;
    final String successfulName;
    final String totalName;
    final String slaViolationsName;

    @org.immutables.value.Generated(from = "RunStats", generator = "Gsons")
    static class RunStatsNamingFields {
      public long cancelled;
      public long failed;
      public long ongoing;
      public long successful;
      public long total;
      public long slaViolations;
    }

    RunStatsTypeAdapter(Gson gson) {
      this.cancelledName = translateName(gson, RunStatsNamingFields.class, "cancelled");
      this.failedName = translateName(gson, RunStatsNamingFields.class, "failed");
      this.ongoingName = translateName(gson, RunStatsNamingFields.class, "ongoing");
      this.successfulName = translateName(gson, RunStatsNamingFields.class, "successful");
      this.totalName = translateName(gson, RunStatsNamingFields.class, "total");
      this.slaViolationsName = translateName(gson, RunStatsNamingFields.class, "slaViolations");
    }

    static boolean adapts(TypeToken<?> type) {
      return RunStats.class == type.getRawType()
          || ImmutableRunStats.class == type.getRawType();
    }

    @Override
    public void write(JsonWriter out, RunStats value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        writeRunStats(out, value);
      }
    }

    @Override
    public RunStats read(JsonReader in) throws IOException {
      return readRunStats(in);
    }

    private void writeRunStats(JsonWriter out, RunStats instance)
        throws IOException {
      out.beginObject();
      out.name(cancelledName);
      out.value(instance.cancelled());
      out.name(failedName);
      out.value(instance.failed());
      out.name(ongoingName);
      out.value(instance.ongoing());
      out.name(successfulName);
      out.value(instance.successful());
      out.name(totalName);
      out.value(instance.total());
      out.name(slaViolationsName);
      out.value(instance.slaViolations());
      out.endObject();
    }

    private RunStats readRunStats(JsonReader in)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
        return null;
      }
      ImmutableRunStats.Builder builder = ImmutableRunStats.builder();
      in.beginObject();
      while (in.hasNext()) {
        eachAttribute(in, builder);
      }
      in.endObject();
      return builder.build();
    }

    private void eachAttribute(JsonReader in, ImmutableRunStats.Builder builder)
        throws IOException {
      String name = in.nextName();
      if (cancelledName.equals(name)) {
        readInCancelled(in, builder);
        return;
      }
      if (failedName.equals(name)) {
        readInFailed(in, builder);
        return;
      }
      if (ongoingName.equals(name)) {
        readInOngoing(in, builder);
        return;
      }
      if (successfulName.equals(name)) {
        readInSuccessful(in, builder);
        return;
      }
      if (slaViolationsName.equals(name)) {
        readInSlaViolations(in, builder);
        return;
      }
      in.skipValue();
    }

    private void readInCancelled(JsonReader in, ImmutableRunStats.Builder builder)
        throws IOException {
      builder.cancelled(in.nextLong());
    }

    private void readInFailed(JsonReader in, ImmutableRunStats.Builder builder)
        throws IOException {
      builder.failed(in.nextLong());
    }

    private void readInOngoing(JsonReader in, ImmutableRunStats.Builder builder)
        throws IOException {
      builder.ongoing(in.nextLong());
    }

    private void readInSuccessful(JsonReader in, ImmutableRunStats.Builder builder)
        throws IOException {
      builder.successful(in.nextLong());
    }

    private void readInSlaViolations(JsonReader in, ImmutableRunStats.Builder builder)
        throws IOException {
      builder.slaViolations(in.nextLong());
    }
  }

  @org.immutables.value.Generated(from = "ReplicationInformationParameters", generator = "Gsons")
  @SuppressWarnings({"unchecked", "rawtypes"}) // safe unchecked, types are verified in runtime
  private static class ReplicationInformationParametersTypeAdapter extends TypeAdapter<ReplicationInformationParameters> {
    public final CompanyId companyIdTypeSample = null;
    public final VdcUuid vdcUuidsTypeSample = null;
    public final Instant startTimeTypeSample = null;
    public final Instant endTimeTypeSample = null;
    private final TypeAdapter<CompanyId> companyIdTypeAdapter;
    private final TypeAdapter<VdcUuid> vdcUuidsTypeAdapter;
    private final TypeAdapter<Instant> startTimeTypeAdapter;
    private final TypeAdapter<Instant> endTimeTypeAdapter;
    final String companyIdName;
    final String vdcUuidsName;
    final String startTimeName;
    final String endTimeName;

    @org.immutables.value.Generated(from = "ReplicationInformationParameters", generator = "Gsons")
    static class ReplicationInformationParametersNamingFields {
      public CompanyId companyId;
      public List<VdcUuid> vdcUuids;
      public Optional<Instant> startTime;
      public Optional<Instant> endTime;
    }

    ReplicationInformationParametersTypeAdapter(Gson gson) {
      this.companyIdTypeAdapter = gson.getAdapter( CompanyId.class);
      this.vdcUuidsTypeAdapter = gson.getAdapter( VdcUuid.class);
      this.startTimeTypeAdapter = gson.getAdapter( Instant.class);
      this.endTimeTypeAdapter = gson.getAdapter( Instant.class);
      this.companyIdName = translateName(gson, ReplicationInformationParametersNamingFields.class, "companyId");
      this.vdcUuidsName = translateName(gson, ReplicationInformationParametersNamingFields.class, "vdcUuids");
      this.startTimeName = translateName(gson, ReplicationInformationParametersNamingFields.class, "startTime");
      this.endTimeName = translateName(gson, ReplicationInformationParametersNamingFields.class, "endTime");
    }

    static boolean adapts(TypeToken<?> type) {
      return ReplicationInformationParameters.class == type.getRawType()
          || ImmutableReplicationInformationParameters.class == type.getRawType();
    }

    @Override
    public void write(JsonWriter out, ReplicationInformationParameters value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        writeReplicationInformationParameters(out, value);
      }
    }

    @Override
    public ReplicationInformationParameters read(JsonReader in) throws IOException {
      return readReplicationInformationParameters(in);
    }

    private void writeReplicationInformationParameters(JsonWriter out, ReplicationInformationParameters instance)
        throws IOException {
      out.beginObject();
      out.name(companyIdName);
      companyIdTypeAdapter.write(out, instance.companyId());
      List<VdcUuid> vdcUuidsElements = instance.vdcUuids();
      out.name(vdcUuidsName);
      out.beginArray();
      for (VdcUuid e : vdcUuidsElements) {
        vdcUuidsTypeAdapter.write(out, e);
      }
      out.endArray();
      Optional<Instant> startTimeOptional = instance.startTime();
      if (startTimeOptional.isPresent()) {
        out.name(startTimeName);
        Instant startTimeValue = startTimeOptional.get();
        startTimeTypeAdapter.write(out, startTimeValue);
      } else if (out.getSerializeNulls()) {
        out.name(startTimeName);
        out.nullValue();
      }
      Optional<Instant> endTimeOptional = instance.endTime();
      if (endTimeOptional.isPresent()) {
        out.name(endTimeName);
        Instant endTimeValue = endTimeOptional.get();
        endTimeTypeAdapter.write(out, endTimeValue);
      } else if (out.getSerializeNulls()) {
        out.name(endTimeName);
        out.nullValue();
      }
      out.endObject();
    }

    private ReplicationInformationParameters readReplicationInformationParameters(JsonReader in)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
        return null;
      }
      ImmutableReplicationInformationParameters.Builder builder = ImmutableReplicationInformationParameters.builder();
      in.beginObject();
      while (in.hasNext()) {
        eachAttribute(in, builder);
      }
      in.endObject();
      return builder.build();
    }

    private void eachAttribute(JsonReader in, ImmutableReplicationInformationParameters.Builder builder)
        throws IOException {
      String name = in.nextName();
      if (companyIdName.equals(name)) {
        readInCompanyId(in, builder);
        return;
      }
      if (vdcUuidsName.equals(name)) {
        readInVdcUuids(in, builder);
        return;
      }
      if (startTimeName.equals(name)) {
        readInStartTime(in, builder);
        return;
      }
      if (endTimeName.equals(name)) {
        readInEndTime(in, builder);
        return;
      }
      in.skipValue();
    }

    private void readInCompanyId(JsonReader in, ImmutableReplicationInformationParameters.Builder builder)
        throws IOException {
      CompanyId value = companyIdTypeAdapter.read(in);
      builder.companyId(value);
    }

    private void readInVdcUuids(JsonReader in, ImmutableReplicationInformationParameters.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.BEGIN_ARRAY) {
        in.beginArray();
        while(in.hasNext()) {
          VdcUuid value = vdcUuidsTypeAdapter.read(in);
          builder.addVdcUuids(value);
        }
        in.endArray();
      } else if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        VdcUuid value = vdcUuidsTypeAdapter.read(in);
        builder.addVdcUuids(value);
      }
    }

    private void readInStartTime(JsonReader in, ImmutableReplicationInformationParameters.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        Instant value = startTimeTypeAdapter.read(in);
        builder.startTime(value);
      }
    }

    private void readInEndTime(JsonReader in, ImmutableReplicationInformationParameters.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        Instant value = endTimeTypeAdapter.read(in);
        builder.endTime(value);
      }
    }
  }

  @org.immutables.value.Generated(from = "StorageHistoryItem", generator = "Gsons")
  @SuppressWarnings({"unchecked", "rawtypes"}) // safe unchecked, types are verified in runtime
  private static class StorageHistoryItemTypeAdapter extends TypeAdapter<StorageHistoryItem> {
    public final Instant timestampTypeSample = null;
    public final Long contractedStorageBytesTypeSample = null;
    public final Long storageConsumedBytesTypeSample = null;
    private final TypeAdapter<Instant> timestampTypeAdapter;
    private final TypeAdapter<Long> contractedStorageBytesTypeAdapter;
    private final TypeAdapter<Long> storageConsumedBytesTypeAdapter;
    final String timestampName;
    final String contractedStorageBytesName;
    final String storageConsumedBytesName;

    @org.immutables.value.Generated(from = "StorageHistoryItem", generator = "Gsons")
    static class StorageHistoryItemNamingFields {
      public Optional<Instant> timestamp;
      public Optional<Long> contractedStorageBytes;
      public Optional<Long> storageConsumedBytes;
    }

    StorageHistoryItemTypeAdapter(Gson gson) {
      this.timestampTypeAdapter = gson.getAdapter( Instant.class);
      this.contractedStorageBytesTypeAdapter = gson.getAdapter( Long.class);
      this.storageConsumedBytesTypeAdapter = gson.getAdapter( Long.class);
      this.timestampName = translateName(gson, StorageHistoryItemNamingFields.class, "timestamp");
      this.contractedStorageBytesName = translateName(gson, StorageHistoryItemNamingFields.class, "contractedStorageBytes");
      this.storageConsumedBytesName = translateName(gson, StorageHistoryItemNamingFields.class, "storageConsumedBytes");
    }

    static boolean adapts(TypeToken<?> type) {
      return StorageHistoryItem.class == type.getRawType()
          || ImmutableStorageHistoryItem.class == type.getRawType();
    }

    @Override
    public void write(JsonWriter out, StorageHistoryItem value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        writeStorageHistoryItem(out, value);
      }
    }

    @Override
    public StorageHistoryItem read(JsonReader in) throws IOException {
      return readStorageHistoryItem(in);
    }

    private void writeStorageHistoryItem(JsonWriter out, StorageHistoryItem instance)
        throws IOException {
      out.beginObject();
      Optional<Instant> timestampOptional = instance.timestamp();
      if (timestampOptional.isPresent()) {
        out.name(timestampName);
        Instant timestampValue = timestampOptional.get();
        timestampTypeAdapter.write(out, timestampValue);
      } else if (out.getSerializeNulls()) {
        out.name(timestampName);
        out.nullValue();
      }
      Optional<Long> contractedStorageBytesOptional = instance.contractedStorageBytes();
      if (contractedStorageBytesOptional.isPresent()) {
        out.name(contractedStorageBytesName);
        Long contractedStorageBytesValue = contractedStorageBytesOptional.get();
        contractedStorageBytesTypeAdapter.write(out, contractedStorageBytesValue);
      } else if (out.getSerializeNulls()) {
        out.name(contractedStorageBytesName);
        out.nullValue();
      }
      Optional<Long> storageConsumedBytesOptional = instance.storageConsumedBytes();
      if (storageConsumedBytesOptional.isPresent()) {
        out.name(storageConsumedBytesName);
        Long storageConsumedBytesValue = storageConsumedBytesOptional.get();
        storageConsumedBytesTypeAdapter.write(out, storageConsumedBytesValue);
      } else if (out.getSerializeNulls()) {
        out.name(storageConsumedBytesName);
        out.nullValue();
      }
      out.endObject();
    }

    private StorageHistoryItem readStorageHistoryItem(JsonReader in)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
        return null;
      }
      ImmutableStorageHistoryItem.Builder builder = ImmutableStorageHistoryItem.builder();
      in.beginObject();
      while (in.hasNext()) {
        eachAttribute(in, builder);
      }
      in.endObject();
      return builder.build();
    }

    private void eachAttribute(JsonReader in, ImmutableStorageHistoryItem.Builder builder)
        throws IOException {
      String name = in.nextName();
      if (timestampName.equals(name)) {
        readInTimestamp(in, builder);
        return;
      }
      if (contractedStorageBytesName.equals(name)) {
        readInContractedStorageBytes(in, builder);
        return;
      }
      if (storageConsumedBytesName.equals(name)) {
        readInStorageConsumedBytes(in, builder);
        return;
      }
      in.skipValue();
    }

    private void readInTimestamp(JsonReader in, ImmutableStorageHistoryItem.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        Instant value = timestampTypeAdapter.read(in);
        builder.timestamp(value);
      }
    }

    private void readInContractedStorageBytes(JsonReader in, ImmutableStorageHistoryItem.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        Long value = contractedStorageBytesTypeAdapter.read(in);
        builder.contractedStorageBytes(value);
      }
    }

    private void readInStorageConsumedBytes(JsonReader in, ImmutableStorageHistoryItem.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        Long value = storageConsumedBytesTypeAdapter.read(in);
        builder.storageConsumedBytes(value);
      }
    }
  }

  @org.immutables.value.Generated(from = "StorageHistoryResponse", generator = "Gsons")
  @SuppressWarnings({"unchecked", "rawtypes"}) // safe unchecked, types are verified in runtime
  private static class StorageHistoryResponseTypeAdapter extends TypeAdapter<StorageHistoryResponse> {
    public final StorageHistoryItem itemsTypeSample = null;
    private final TypeAdapter<StorageHistoryItem> itemsTypeAdapter;
    final String itemsName;

    @org.immutables.value.Generated(from = "StorageHistoryResponse", generator = "Gsons")
    static class StorageHistoryResponseNamingFields {
      public List<StorageHistoryItem> items;
    }

    StorageHistoryResponseTypeAdapter(Gson gson) {
      this.itemsTypeAdapter = gson.getAdapter( StorageHistoryItem.class);
      this.itemsName = translateName(gson, StorageHistoryResponseNamingFields.class, "items");
    }

    static boolean adapts(TypeToken<?> type) {
      return StorageHistoryResponse.class == type.getRawType()
          || ImmutableStorageHistoryResponse.class == type.getRawType();
    }

    @Override
    public void write(JsonWriter out, StorageHistoryResponse value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        writeStorageHistoryResponse(out, value);
      }
    }

    @Override
    public StorageHistoryResponse read(JsonReader in) throws IOException {
      return readStorageHistoryResponse(in);
    }

    private void writeStorageHistoryResponse(JsonWriter out, StorageHistoryResponse instance)
        throws IOException {
      out.beginObject();
      List<StorageHistoryItem> itemsElements = instance.items();
      out.name(itemsName);
      out.beginArray();
      for (StorageHistoryItem e : itemsElements) {
        itemsTypeAdapter.write(out, e);
      }
      out.endArray();
      out.endObject();
    }

    private StorageHistoryResponse readStorageHistoryResponse(JsonReader in)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
        return null;
      }
      ImmutableStorageHistoryResponse.Builder builder = ImmutableStorageHistoryResponse.builder();
      in.beginObject();
      while (in.hasNext()) {
        eachAttribute(in, builder);
      }
      in.endObject();
      return builder.build();
    }

    private void eachAttribute(JsonReader in, ImmutableStorageHistoryResponse.Builder builder)
        throws IOException {
      String name = in.nextName();
      if (itemsName.equals(name)) {
        readInItems(in, builder);
        return;
      }
      in.skipValue();
    }

    private void readInItems(JsonReader in, ImmutableStorageHistoryResponse.Builder builder)
        throws IOException {
      if (in.peek() == JsonToken.BEGIN_ARRAY) {
        in.beginArray();
        while(in.hasNext()) {
          StorageHistoryItem value = itemsTypeAdapter.read(in);
          builder.addItems(value);
        }
        in.endArray();
      } else if (in.peek() == JsonToken.NULL) {
        in.nextNull();
      } else {
        StorageHistoryItem value = itemsTypeAdapter.read(in);
        builder.addItems(value);
      }
    }
  }

  @org.immutables.value.Generated(from = "HeliosTenantId", generator = "Gsons")
  @SuppressWarnings({"unchecked", "rawtypes"}) // safe unchecked, types are verified in runtime
  private static class HeliosTenantIdTypeAdapter extends TypeAdapter<HeliosTenantId> {
    public final CompanyId companyIdTypeSample = null;
    private final TypeAdapter<CompanyId> companyIdTypeAdapter;
    final String idName;
    final String companyIdName;

    @org.immutables.value.Generated(from = "HeliosTenantId", generator = "Gsons")
    static class HeliosTenantIdNamingFields {
      public String id;
      public CompanyId companyId;
    }

    HeliosTenantIdTypeAdapter(Gson gson) {
      this.companyIdTypeAdapter = gson.getAdapter( CompanyId.class);
      this.idName = translateName(gson, HeliosTenantIdNamingFields.class, "id");
      this.companyIdName = translateName(gson, HeliosTenantIdNamingFields.class, "companyId");
    }

    static boolean adapts(TypeToken<?> type) {
      return HeliosTenantId.class == type.getRawType()
          || ImmutableHeliosTenantId.class == type.getRawType();
    }

    @Override
    public void write(JsonWriter out, HeliosTenantId value) throws IOException {
      if (value == null) {
        out.nullValue();
      } else {
        writeHeliosTenantId(out, value);
      }
    }

    @Override
    public HeliosTenantId read(JsonReader in) throws IOException {
      return readHeliosTenantId(in);
    }

    private void writeHeliosTenantId(JsonWriter out, HeliosTenantId instance)
        throws IOException {
      out.beginObject();
      out.name(idName);
      out.value(instance.id());
      out.name(companyIdName);
      companyIdTypeAdapter.write(out, instance.companyId());
      out.endObject();
    }

    private HeliosTenantId readHeliosTenantId(JsonReader in)
        throws IOException {
      if (in.peek() == JsonToken.NULL) {
        in.nextNull();
        return null;
      }
      ImmutableHeliosTenantId.Builder builder = ImmutableHeliosTenantId.builder();
      in.beginObject();
      while (in.hasNext()) {
        eachAttribute(in, builder);
      }
      in.endObject();
      return builder.build();
    }

    private void eachAttribute(JsonReader in, ImmutableHeliosTenantId.Builder builder)
        throws IOException {
      String name = in.nextName();
      if (idName.equals(name)) {
        readInId(in, builder);
        return;
      }
      if (companyIdName.equals(name)) {
        readInCompanyId(in, builder);
        return;
      }
      in.skipValue();
    }

    private void readInId(JsonReader in, ImmutableHeliosTenantId.Builder builder)
        throws IOException {
      builder.id(in.nextString());
    }

    private void readInCompanyId(JsonReader in, ImmutableHeliosTenantId.Builder builder)
        throws IOException {
      CompanyId value = companyIdTypeAdapter.read(in);
      builder.companyId(value);
    }
  }

  private static String translateName(Gson gson, Class<?> sampleClass, String fieldName) {
    try {
      return gson.fieldNamingStrategy().translateName(sampleClass.getField(fieldName));
    } catch (NoSuchFieldException noSuchField) {
      throw new AssertionError(noSuchField);
    }
  }
}
