/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vi;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Vm Boot Options Implementation.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class VmBootOptions implements Serializable {

  private static final long serialVersionUID = -2672203763267238439L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(VmBootOptionsField.BOOT_DELAY)
  private final long bootDelay;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(VmBootOptionsField.IS_ENTER_BIOS)
  private final boolean enterBIOS;

  public VmBootOptions(final long bootDelay, final boolean enterBIOS) {
    this.bootDelay = bootDelay;
    this.enterBIOS = enterBIOS;
  }

  /**
   * Get the VM boot delay in milliseconds.
   *
   * @return boot delay in milliseconds
   */
  public long getBootDelay() {
    return bootDelay;
  }

  /**
   * Get whether the VM will force enter BIOS on restart.
   *
   * @return force enter bios on next reboot
   */
  public boolean isEnterBIOS() {
    return enterBIOS;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("VmBootOptions{");
    sb.append("bootDelay=").append(bootDelay);
    sb.append(", enterBIOS=").append(enterBIOS);
    sb.append('}');
    return sb.toString();
  }
}
