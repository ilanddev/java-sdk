/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vac;

import java.io.Serializable;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * VAC Backup Repository.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public final class BaBackupResource implements Serializable {

  private static final long serialVersionUID = -2386462780107563616L;

  private final String id;

  private final String cloudRepositoryName;

  private final double storageQuota;

  private final int vMsQuota;

  private final int serversQuota;

  private final boolean quotasAreUnlimited;

  private final int workstationsQuota;

  private final int trafficQuota;

  private final boolean wanAccelerationEnabled;

  private final double usedStorageQuota;

  private final double usedTrafficQuota;

  private final String intervalStartTime;

  private final String intervalEndTime;

  private final BaBackupRepository backupRepository;

  private final BaWanAccelerator wanAccelerator;

  /**
   * Instantiates a new Ba backup resource.
   *
   * @param id                     the id
   * @param cloudRepositoryName    the cloud repository name
   * @param storageQuota           the storage quota
   * @param vMsQuota               the v ms quota
   * @param serversQuota           the servers quota
   * @param quotasAreUnlimited     the quotas are unlimited
   * @param workstationsQuota      the workstations quota
   * @param trafficQuota           the traffic quota
   * @param wanAccelerationEnabled the wan acceleration enabled
   * @param usedStorageQuota       the used storage quota
   * @param usedTrafficQuota       the used traffic quota
   * @param intervalStartTime      the interval start time
   * @param intervalEndTime        the interval end time
   * @param backupRepository       the backup repository
   * @param wanAccelerator         the wan accelerator
   */
  public BaBackupResource(final String id, final String cloudRepositoryName,
      final double storageQuota, final int vMsQuota, final int serversQuota,
      final boolean quotasAreUnlimited, final int workstationsQuota,
      final int trafficQuota, final boolean wanAccelerationEnabled,
      final double usedStorageQuota, final double usedTrafficQuota,
      final String intervalStartTime, final String intervalEndTime,
      final BaBackupRepository backupRepository,
      final BaWanAccelerator wanAccelerator) {
    this.id = id;
    this.cloudRepositoryName = cloudRepositoryName;
    this.storageQuota = storageQuota;
    this.vMsQuota = vMsQuota;
    this.serversQuota = serversQuota;
    this.quotasAreUnlimited = quotasAreUnlimited;
    this.workstationsQuota = workstationsQuota;
    this.trafficQuota = trafficQuota;
    this.wanAccelerationEnabled = wanAccelerationEnabled;
    this.usedStorageQuota = usedStorageQuota;
    this.usedTrafficQuota = usedTrafficQuota;
    this.intervalStartTime = intervalStartTime;
    this.intervalEndTime = intervalEndTime;
    this.backupRepository = backupRepository;
    this.wanAccelerator = wanAccelerator;
  }

  /**
   * Gets System ID assigned to a backup resource in Veeam Availability Console
   * RESTful API.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Gets name of a cloud repository configured for a company or department.
   *
   * @return the cloud repsitory name
   */
  public String getCloudRepositoryName() {
    return cloudRepositoryName;
  }

  /**
   * Gets amount of storage allocated to a company or department in GB.
   *
   * @return the storage quota
   */
  public double getStorageQuota() {
    return storageQuota;
  }

  /**
   * Gets Number of VMs that a company or department can store on a cloud repository.
   * If quota is unlimited, the property value is 0..
   *
   * @return the ms quota
   */
  public int getvMsQuota() {
    return vMsQuota;
  }

  /**
   * Gets workstations quota.
   *
   * @return the workstations quota
   */
  public int getWorkstationsQuota() {
    return workstationsQuota;
  }

  /**
   * Gets amount of data that a company or department can download from the cloud
   * repository during a billing period in GB. If quota is unlimited, the property value is 0.
   *
   * @return the traffic quota
   */
  public int getTrafficQuota() {
    return trafficQuota;
  }

  /**
   * Indicates whether WAN Accelerator is enabled for data transfer to a cloud repository.
   *
   * @return the boolean
   */
  public boolean isWanAccelerationEnabled() {
    return wanAccelerationEnabled;
  }

  /**
   * Gets amount of allocated storage space already used by a company or department in GB.
   *
   * @return the used storage quota
   */
  public double getUsedStorageQuota() {
    return usedStorageQuota;
  }


  /**
   * Gets amount of data that a company or department has already downloaded
   * from a cloud repository during a billing period in GB. If quota is unlimited,
   * the property value is -1.
   *
   * @return the used traffic quota
   */
  public double getUsedTrafficQuota() {
    return usedTrafficQuota;
  }


  /**
   * Gets interval start time.
   *
   * @return the interval start time
   */
  public String getIntervalStartTime() {
    return intervalStartTime;
  }

  /**
   * Gets interval end time.
   *
   * @return the interval end time
   */
  public String getIntervalEndTime() {
    return intervalEndTime;
  }

  /**
   * Get the backup repository.
   *
   * @return {@link BaBackupRepository} backup repository
   */
  public BaBackupRepository getBackupRepository() {
    return backupRepository;
  }

  /**
   * Get the wan accelerator.
   *
   * @return {@link BaWanAccelerator} wan accelerator
   */
  public BaWanAccelerator getWanAccelerator() {
    return wanAccelerator;
  }

  /**
   * Gets Number of servers that a company can store on a cloud repository.
   *
   * @return the servers quota
   */
  public int getServersQuota() {
    return serversQuota;
  }

  /**
   * Indicates whether a company has unlimited quota for number of VMs, workstations and server
   *
   * @return are quotas unlimited
   */
  public boolean isQuotasAreUnlimited() {
    return quotasAreUnlimited;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BaBackupResource that = (BaBackupResource) o;
    return Double.compare(that.storageQuota, storageQuota) == 0
        && vMsQuota == that.vMsQuota && serversQuota == that.serversQuota
        && quotasAreUnlimited == that.quotasAreUnlimited
        && workstationsQuota == that.workstationsQuota
        && trafficQuota == that.trafficQuota
        && wanAccelerationEnabled == that.wanAccelerationEnabled
        && Double.compare(that.usedStorageQuota, usedStorageQuota) == 0
        && Double.compare(that.usedTrafficQuota, usedTrafficQuota) == 0
        && Objects.equals(id, that.id) && Objects
        .equals(cloudRepositoryName, that.cloudRepositoryName) && Objects
        .equals(intervalStartTime, that.intervalStartTime) && Objects
        .equals(intervalEndTime, that.intervalEndTime) && Objects
        .equals(backupRepository, that.backupRepository) && Objects
        .equals(wanAccelerator, that.wanAccelerator);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(id, cloudRepositoryName, storageQuota, vMsQuota, serversQuota,
            quotasAreUnlimited, workstationsQuota, trafficQuota,
            wanAccelerationEnabled, usedStorageQuota, usedTrafficQuota,
            intervalStartTime, intervalEndTime, backupRepository,
            wanAccelerator);
  }

}
