/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

/**
 * Task.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@XmlRootElement(name = "Task")
public class Task implements Serializable {

  private static final long serialVersionUID = 1731304473130118860L;

  @XmlElement(name = "Links")
  private VeeamLinks links;

  @XmlElement(name = "TaskId")
  private String taskId;

  @XmlElement(name = "State")
  private String state;

  @XmlElement(name = "Operation")
  private String operation;

  @XmlElement(name = "Result")
  private VeeamResult result;

  public Task() {
  }

  public Task(final VeeamLinks links, final String taskId, final String state,
      final String operation, final VeeamResult result) {
    this.links = links;
    this.taskId = taskId;
    this.state = state;
    this.operation = operation;
    this.result = result;
  }

  /**
   * Get the links.
   *
   * @return {@link VeeamLinks} get the associated links
   */
  public VeeamLinks getLinks() {
    return links;
  }

  /**
   * Get the task ID.
   *
   * @return {@link String} task ID
   */
  public String getTaskId() {
    return taskId;
  }

  /**
   * Get the task state.
   *
   * @return {@link String} state
   */
  public String getState() {
    return state;
  }

  /**
   * Get the task operation.
   *
   * @return {@link String} operation
   */
  public String getOperation() {
    return operation;
  }

  /**
   * Get the task result.
   *
   * @return {@link VeeamResult} result
   */
  public VeeamResult getResult() {
    return result;
  }

}
