/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.trend;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.util.IlandSerializedName;

/**
 * Integrity Event.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class IntegrityEvent implements Serializable {

  private static final long serialVersionUID = 8513041025921408996L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.VM_UUID)
  private String vmUuid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.CHANGE)
  private String change;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.DESCRIPTION)
  private String description;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.HOST_ID)
  private Integer hostID;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.HOST_NAME)
  private String hostName;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.EVENT_ID)
  private Long eventId;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.INTEGRITY_RULE_ID)
  private Integer integrityRuleID;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.IS_ENTITY)
  private IntegrityEntity isEntity;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.KEY)
  private String key;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.LOG_TIME)
  private Calendar logTime;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.PROCESS)
  private String process;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.RANK)
  private int rank;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.REASON)
  private String reason;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.SEVERITY)
  private String severity;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.TAGS)
  private String tags;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.TYPE)
  private String type;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.USER)
  private String user;

  @Expose
  @Since(ApiVersion.ZERO_DOT_ONE)
  @IlandSerializedName(IntegrityEventField.WAS_ENTITY)
  private IntegrityEntity wasEntity;

  /**
   * Instantiates a new Integrity event.
   */
  public IntegrityEvent() {
  }

  /**
   * Gets vm uuid.
   *
   * @return the vm uuid
   */
  public String getVmUuid() {
    return vmUuid;
  }

  /**
   * Sets vm uuid.
   *
   * @param vmUuid the vm uuid
   */
  public void setVmUuid(final String vmUuid) {
    this.vmUuid = vmUuid;
  }

  /**
   * Gets change.
   *
   * @return the change
   */
  public String getChange() {
    return change;
  }

  /**
   * Sets change.
   *
   * @param change the change
   */
  public void setChange(final String change) {
    this.change = change;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Sets description.
   *
   * @param description the description
   */
  public void setDescription(final String description) {
    this.description = description;
  }

  /**
   * Gets host ID.
   *
   * @return the host iD
   */
  public Integer getHostID() {
    return hostID;
  }

  /**
   * Sets host ID.
   *
   * @param hostID the host ID
   */
  public void setHostID(final Integer hostID) {
    this.hostID = hostID;
  }

  /**
   * Gets host name.
   *
   * @return the host name
   */
  public String getHostName() {
    return hostName;
  }

  /**
   * Sets host name.
   *
   * @param hostName the host name
   */
  public void setHostName(final String hostName) {
    this.hostName = hostName;
  }

  /**
   * Gets event id.
   *
   * @return the event id
   */
  public Long getEventId() {
    return eventId;
  }

  /**
   * Sets event id.
   *
   * @param eventId the event id
   */
  public void setEventId(final Long eventId) {
    this.eventId = eventId;
  }

  /**
   * Gets integrity rule iD.
   *
   * @return the integrity rule iD
   */
  public Integer getIntegrityRuleID() {
    return integrityRuleID;
  }

  /**
   * Sets integrity rule iD.
   *
   * @param integrityRuleID the integrity rule iD
   */
  public void setIntegrityRuleID(final Integer integrityRuleID) {
    this.integrityRuleID = integrityRuleID;
  }

  /**
   * Gets key.
   *
   * @return the key
   */
  public String getKey() {
    return key;
  }

  /**
   * Sets key.
   *
   * @param key the key
   */
  public void setKey(final String key) {
    this.key = key;
  }

  /**
   * Gets log time.
   *
   * @return the log time
   */
  public Calendar getLogTime() {
    if (logTime == null) {
      final Calendar defaultDate = Calendar.getInstance();
      defaultDate.setTime(new Date(0));
      return defaultDate;
    }
    return logTime;
  }

  /**
   * Sets log time.
   *
   * @param logTime the log time
   */
  public void setLogTime(final Calendar logTime) {
    this.logTime = logTime;
  }

  /**
   * Gets process.
   *
   * @return the process
   */
  public String getProcess() {
    return process;
  }

  /**
   * Sets process.
   *
   * @param process the process
   */
  public void setProcess(final String process) {
    this.process = process;
  }

  /**
   * Gets rank.
   *
   * @return the rank
   */
  public int getRank() {
    return rank;
  }

  /**
   * Sets rank.
   *
   * @param rank the rank
   */
  public void setRank(final int rank) {
    this.rank = rank;
  }

  /**
   * Gets reason.
   *
   * @return the reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * Sets reason.
   *
   * @param reason the reason
   */
  public void setReason(final String reason) {
    this.reason = reason;
  }

  /**
   * Gets severity.
   *
   * @return the severity
   */
  public String getSeverity() {
    return severity;
  }

  /**
   * Sets severity.
   *
   * @param severity the severity
   */
  public void setSeverity(final String severity) {
    this.severity = severity;
  }

  /**
   * Gets tags.
   *
   * @return the tags
   */
  public String getTags() {
    return tags;
  }

  /**
   * Sets tags.
   *
   * @param tags the tags
   */
  public void setTags(final String tags) {
    this.tags = tags;
  }

  /**
   * Gets type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets type.
   *
   * @param type the type
   */
  public void setType(final String type) {
    this.type = type;
  }

  /**
   * Gets user.
   *
   * @return the user
   */
  public String getUser() {
    return user;
  }

  /**
   * Sets user.
   *
   * @param user the user
   */
  public void setUser(final String user) {
    this.user = user;
  }

  /**
   * Gets is entity.
   *
   * @return the is entity
   */
  public IntegrityEntity getIsEntity() {
    return isEntity;
  }

  /**
   * Sets is entity.
   *
   * @param isEntity the is entity
   */
  public void setIsEntity(final IntegrityEntity isEntity) {
    this.isEntity = isEntity;
  }

  /**
   * Gets was entity.
   *
   * @return the was entity
   */
  public IntegrityEntity getWasEntity() {
    return wasEntity;
  }

  /**
   * Sets was entity.
   *
   * @param wasEntity the was entity
   */
  public void setWasEntity(final IntegrityEntity wasEntity) {
    this.wasEntity = wasEntity;
  }

}
