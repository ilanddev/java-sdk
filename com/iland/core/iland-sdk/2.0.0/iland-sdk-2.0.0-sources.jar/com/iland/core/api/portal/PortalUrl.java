/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.portal;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.entity.EntityField;
import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.api.serialization.JsonRequired;

/**
 * Portal URL.
 * <p>
 * Holds the relative URL to an entity in the iland cloud portal.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class PortalUrl implements Serializable {

  private static final long serialVersionUID = 3784710331970004013L;

  public static final String RELATIVE_URL = "relative_url";

  public static final String DASHBOARD = "dashboard";

  public static final String NETWORKING = "networking";

  public static final String CATALOGS = "catalogs";

  @Expose
  @JsonRequired("entity uuid")
  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(EntityField.UUID)
  private final String entityUuid;

  @Expose
  @JsonRequired("portal URL")
  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(RELATIVE_URL)
  private final String entityUrl;

  public PortalUrl(final String entityUuid, final String entityUrl) {
    this.entityUuid = entityUuid;
    this.entityUrl = entityUrl;
  }

  /**
   * Get the entity uuid.
   *
   * @return {@link String} entity uuid
   * @required
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Get the portal URL for the entity.
   *
   * @return {@link String} entity URL
   * @required
   */
  public String getEntityUrl() {
    return entityUrl;
  }

}
