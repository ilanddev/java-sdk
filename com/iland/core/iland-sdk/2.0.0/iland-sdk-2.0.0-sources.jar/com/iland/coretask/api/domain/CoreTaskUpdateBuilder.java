/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.coretask.api.domain;

import static java.util.Objects.requireNonNull;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Stream;

import com.google.common.annotations.VisibleForTesting;
import com.google.protobuf.FieldMask;

import com.iland.coretask.api.grpc.CoreTask;
import com.iland.coretask.api.grpc.CoreTaskUpdateRequest;

/**
 * Helper class that sets correct paths for updated fields. This class is not
 * thread-safe and must be synchronized externally.
 */
public final class CoreTaskUpdateBuilder {

	private final CoreTask coreTask;

	private final CoreTask.Builder coreTaskBuilder;

	private final List<String> paths = new ArrayList<>();

	public CoreTaskUpdateBuilder(final CoreTask coreTask) {
		this.coreTask = requireNonNull(coreTask, "coreTask must not be null");
		this.coreTaskBuilder = coreTask.toBuilder();
	}

	/**
	 * @return the original, unmodified, {@link CoreTask core task}
	 */
	public CoreTask getCoreTask() {
		return coreTask;
	}

	/**
	 * A utility method that updates the appropriate fields to indicate a
	 * cancelled state.
	 */
	public CoreTaskUpdateBuilder withCancelledState() {
		return this.withStatus(CoreTaskStatus.CANCELLED).withEndState();
	}

	/**
	 * A utility method that updates the appropriate fields to indicate an
	 * error state.
	 */
	public CoreTaskUpdateBuilder withErrorState() {
		return this.withStatus(CoreTaskStatus.ERROR).withEndState();
	}

	/**
	 * A utility method that updates the appropriate fields to indicate a
	 * success state.
	 */
	public CoreTaskUpdateBuilder withSuccessState() {
		return this.withStatus(CoreTaskStatus.SUCCESS).withEndState();
	}

	/**
	 * A utility method that updates the end time, active, synced, and progress
	 * fields to indicate an end state.
	 */
	public CoreTaskUpdateBuilder withEndState() {
		return this.withEndTimeNow()
			.withSynced(true)
			.withActive(false)
			.withProgress(100);
	}

	public CoreTaskUpdateBuilder withCrm(final String crm) {
		coreTaskBuilder.setCrm(crm);
		paths.add(CoreTaskPaths.crm);

		return this;
	}

	public CoreTaskUpdateBuilder withLocationId(final String locationId) {
		coreTaskBuilder.setLocationId(locationId);
		paths.add(CoreTaskPaths.locationId);

		return this;
	}

	public CoreTaskUpdateBuilder withTaskId(final String taskId) {
		coreTaskBuilder.setTaskId(taskId);
		paths.add(CoreTaskPaths.taskId);

		return this;
	}

	public CoreTaskUpdateBuilder withStatus(final CoreTaskStatus status) {
		return withStatus(status.getStatus());
	}

	public CoreTaskUpdateBuilder withStatus(final String status) {
		coreTaskBuilder.setStatus(status);
		paths.add(CoreTaskPaths.status);

		return this;
	}

	public CoreTaskUpdateBuilder withOperation(final String operation) {
		coreTaskBuilder.setOperation(operation);
		paths.add(CoreTaskPaths.operation);

		return this;
	}

	public CoreTaskUpdateBuilder withOperationDescription(
		final String description) {
		coreTaskBuilder.setOperationDescription(description);
		paths.add(CoreTaskPaths.operationDescription);

		return this;
	}

	public CoreTaskUpdateBuilder withActive() {
		return withActive(true);
	}

	public CoreTaskUpdateBuilder withActive(final boolean active) {
		coreTaskBuilder.setActive(active);
		paths.add(CoreTaskPaths.active);

		return this;
	}

	public CoreTaskUpdateBuilder withSynced() {
		return withSynced(true);
	}

	public CoreTaskUpdateBuilder withSynced(final boolean synced) {
		coreTaskBuilder.setSynced(synced);
		paths.add(CoreTaskPaths.synced);

		return this;
	}

	public CoreTaskUpdateBuilder withMessage(final String message) {
		coreTaskBuilder.setMessage(message);
		paths.add(CoreTaskPaths.message);

		return this;
	}

	public CoreTaskUpdateBuilder withTaskType(final String taskType) {
		coreTaskBuilder.setTaskType(taskType);
		paths.add(CoreTaskPaths.taskType);

		return this;
	}

	public CoreTaskUpdateBuilder withEntityUuid(final String entityUuid) {
		coreTaskBuilder.setEntityUuid(entityUuid);
		paths.add(CoreTaskPaths.entityUuid);

		return this;
	}

	/**
	 * Update the start time with a Unix timestamp measured in milliseconds.
	 */
	public CoreTaskUpdateBuilder withStartTime(final Long startTime) {
		coreTaskBuilder.setStartTime(startTime);
		paths.add(CoreTaskPaths.startTime);

		return this;
	}

	/**
	 * Update the end time with a Unix timestamp measured in milliseconds.
	 */
	public CoreTaskUpdateBuilder withEndTime(final Optional<Long> endTime) {
		return endTime.map(this::withEndTime).orElse(this);
	}

	/**
	 * Update the end time using the current time.
	 */
	public CoreTaskUpdateBuilder withEndTimeNow() {
		final long epochMilli = Instant.now().toEpochMilli();

		return this.withEndTime(epochMilli);
	}

	/**
	 * Update the end time with a Unix timestamp measured in milliseconds.
	 */
	public CoreTaskUpdateBuilder withEndTime(final long endTime) {
		coreTaskBuilder.setEndTime(endTime);
		paths.add(CoreTaskPaths.endTime);

		return this;
	}

	public CoreTaskUpdateBuilder withOtherAttributes(
		final Map<String, String> otherAttributes) {
		coreTaskBuilder.putAllOtherAttributes(otherAttributes);
		paths.add(CoreTaskPaths.otherAttributes);

		return this;
	}

	public CoreTaskUpdateBuilder withOrgUuid(final String orgUuid) {
		coreTaskBuilder.setOrgUuid(orgUuid);
		paths.add(CoreTaskPaths.orgUuid);

		return this;
	}

	public CoreTaskUpdateBuilder withProgress(final int progress) {
		coreTaskBuilder.setProgress(progress);
		paths.add(CoreTaskPaths.progress);

		return this;
	}

	public CoreTaskUpdateBuilder withUsername(final String username) {
		coreTaskBuilder.setUsername(username);
		paths.add(CoreTaskPaths.username);

		return this;
	}

	public CoreTaskUpdateBuilder withUserFullName(final String userFullName) {
		coreTaskBuilder.setUserFullName(userFullName);
		paths.add(CoreTaskPaths.userFullName);

		return this;
	}

	public CoreTaskUpdateBuilder withParentTask(final CoreTask parentTask) {
		final Optional<String> parentTaskId =
			Optional.of(parentTask).map(CoreTask::getTaskId);

		return withParentTaskUuid(parentTaskId);
	}

	public CoreTaskUpdateBuilder withParentTaskUuid(
		final Optional<String> parentTaskUuid) {
		return parentTaskUuid.map(this::withParentTaskUuid).orElse(this);
	}

	public CoreTaskUpdateBuilder withParentTaskUuid(
		final String parentTaskUuid) {
		coreTaskBuilder.setParentTaskUuid(parentTaskUuid);
		paths.add(CoreTaskPaths.parentTaskUuid);

		return this;
	}

	public CoreTaskUpdateBuilder withSubTasks(final CoreTask... subTasks) {
		final String[] taskIds =
			Stream.of(subTasks).map(CoreTask::getTaskId).toArray(String[]::new);

		return withSubTasks(taskIds);
	}

	public CoreTaskUpdateBuilder withSubTasks(final String... subTasks) {
		coreTaskBuilder.addAllSubTasks(Arrays.asList(subTasks));
		paths.add(CoreTaskPaths.subTasks);

		return this;
	}

	public CoreTaskUpdateBuilder withInitiatedFromEcs(
		final boolean initiatedFromEcs) {
		coreTaskBuilder.setInitiatedFromEcs(initiatedFromEcs);
		paths.add(CoreTaskPaths.initiatedFromEcs);

		return this;
	}

	public CoreTaskUpdateBuilder withEntityName(
		final Optional<String> entityName) {
		return entityName.map(this::withEntityName).orElse(this);
	}

	public CoreTaskUpdateBuilder withEntityName(final String entityName) {
		coreTaskBuilder.setEntityName(entityName);
		paths.add(CoreTaskPaths.entityName);

		return this;
	}

	public CoreTaskUpdateBuilder withSystemUser() {
		return withSystemUser(true);
	}

	public CoreTaskUpdateBuilder withSystemUser(final boolean systemUser) {
		coreTaskBuilder.setSystemUser(systemUser);
		paths.add(CoreTaskPaths.systemUser);

		return this;
	}

	public CoreTaskUpdateBuilder withUuid(final String uuid) {
		coreTaskBuilder.setUuid(uuid);
		paths.add(CoreTaskPaths.uuid);

		return this;
	}

	public CoreTaskUpdateBuilder withInitiationTime(final long initiationTime) {
		coreTaskBuilder.setInitiationTime(initiationTime);
		paths.add(CoreTaskPaths.initiationTime);

		return this;
	}

	public CoreTaskUpdateBuilder withOverrides(
		final Consumer<CoreTaskUpdateBuilder> consumer) {
		consumer.accept(this);

		return this;
	}

	public boolean isModified() {
		return !coreTask.equals(buildCoreTask());
	}

	public CoreTaskUpdateRequest buildCoreTaskUpdateRequest() {
		final CoreTask coreTask = buildCoreTask();
		final FieldMask fieldMask = getFieldMask();

		return CoreTaskUpdateRequest.newBuilder()
			.setCoreTask(coreTask)
			.setUpdateMask(fieldMask)
			.build();
	}

	public CoreTask buildCoreTask() {
		return coreTaskBuilder.build();
	}

	private FieldMask getFieldMask() {
		final FieldMask.Builder builder = FieldMask.newBuilder();
		builder.addAllPaths(paths);

		return builder.build();
	}

	@VisibleForTesting
	List<String> getPaths() {
		return Collections.unmodifiableList(paths);
	}

}
