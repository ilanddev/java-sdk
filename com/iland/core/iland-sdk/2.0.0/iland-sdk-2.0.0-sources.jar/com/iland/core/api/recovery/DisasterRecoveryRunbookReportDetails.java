/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.recovery;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Recovery Runbook Report Details.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class DisasterRecoveryRunbookReportDetails implements Serializable {

  private static final long serialVersionUID = -1254422609395983913L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(DisasterRecoveryRunbookReportDetailsField.LOCATION_ID)
  private String locationId;

  /**
   * The task uuid.
   */
  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(DisasterRecoveryRunbookReportDetailsField.TASK_UUID)
  private String taskUuid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(DisasterRecoveryRunbookReportDetailsField.TYPE)
  private String type;

  /**
   * The task complete timestamp.
   */
  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(DisasterRecoveryRunbookReportDetailsField.TASK_COMPLETE)
  private LocalDateTime taskComplete;

  /**
   * The status.
   */
  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(DisasterRecoveryRunbookReportDetailsField.STATUS)
  private Status status;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(DisasterRecoveryRunbookReportDetailsField.DATA)
  private Map<String, RecoveryGroupReportDetails> data;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(DisasterRecoveryRunbookReportDetailsField.START_TIME)
  private String startTime;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(DisasterRecoveryRunbookReportDetailsField.END_TIME)
  private String endTime;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @SerializedName(DisasterRecoveryRunbookReportDetailsField.PROTECTED_VM_COUNT)
  private int protectedVmCount;

  /**
   * Instantiates a new disaster recovery report details.
   *
   * @param locationId   the location ID
   * @param taskUuid     the task uuid
   * @param taskComplete the task complete timestamp
   * @param status       the status
   * @param data         list of failover report data for each recovery group
   */
  public DisasterRecoveryRunbookReportDetails(final String locationId,
      final String taskUuid, final LocalDateTime taskComplete,
      final Status status, final Map<String, RecoveryGroupReportDetails> data,
      final String type, final String startTime, final String endTime,
      final int protectedVmCount) {
    this.locationId = locationId;
    this.taskUuid = taskUuid;
    this.taskComplete = taskComplete;
    this.status = status;
    this.data = data;
    this.type = type;
    this.startTime = startTime;
    this.endTime = endTime;
    this.protectedVmCount = protectedVmCount;
  }

  /**
   * Gets the task uuid.
   *
   * @return the task uuid
   */
  public String getTaskUuid() {
    return taskUuid;
  }

  /**
   * Gets the task complete timestamp.
   *
   * @return the task complete timestamp
   */
  public LocalDateTime getTaskComplete() {
    return taskComplete;
  }

  /**
   * Gets data.
   *
   * @return the data
   */
  public Map<String, RecoveryGroupReportDetails> getRecoveryGroupDetails() {
    return data;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public Status getStatus() {
    return status;
  }

  /**
   * Gets location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Get the report type.
   *
   * @return report type
   */
  public String getType() {
    return type;
  }

  /**
   * Set the list of failover report data details.
   *
   * @param data {@link Map} of {@link RecoveryGroupReportDetails} failover
   *             report data
   */
  public void setData(final Map<String, RecoveryGroupReportDetails> data) {
    this.data = data;
  }

  /**
   * Get the start time of the runbook operation.
   *
   * @return {@link String} formatted start time
   */
  public String getStartTime() {
    return startTime;
  }

  /**
   * Get the end time of the runbook operation.
   *
   * @return {@link String} formatted end time
   */
  public String getEndTime() {
    return endTime;
  }

  /**
   * Get the total count of protected VMs in the runbook.
   *
   * @return protected VM count
   */
  public int getProtectedVmCount() {
    return protectedVmCount;
  }

  @Override
  public String toString() {
    return String.format(
        "DisasterRecoveryRunbookReportDetails [taskUuid=%s, taskComplete=%s, status=%s, type=%s, startTime=%s, endTime=%s, protectedVMCount=%d]",
        taskUuid, taskComplete, status, type, startTime, endTime,
        protectedVmCount);
  }

  public enum Status {

    WAITING,

    GENERATING,

    READY,

    ERROR

  }

}
