/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.api.serialization.JsonOptional;
import com.iland.core.api.serialization.JsonRequired;
import com.iland.core.api.vcd.Vm;

/**
 * User Vapp Resource Alert Subscription Impl.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class UserVappResourceAlert extends AbstractResourceAlert {

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.VAPP_UUID)
  @JsonOptional("vapp uuid")
  private String vapp;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.THRESHOLD)
  @JsonRequired("alert threshold")
  protected long threshold;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.CLONE_TO_CHILDREN)
  @JsonRequired("whether to clone the alert to child VMs")
  private boolean cloneToChildren = false;

  public UserVappResourceAlert() {
  }

  public UserVappResourceAlert(final String vapp, final String group,
      final String name, final String type, final long threshold) {
    super(group, name, type);
    this.vapp = vapp;
    this.threshold = threshold;
  }

  /**
   * Get the Vapp uuid attached to this alert.
   *
   * @return {@link String} vapp uuid
   */
  public String getVapp() {
    return vapp;
  }

  /**
   * Set the vapp uuid attached to this alert.
   *
   * @param vapp {@link String} vapp uuid
   */
  public void setVapp(final String vapp) {
    this.vapp = vapp;
  }

  /**
   * Create an {@link com.iland.core.api.notification.UserVmResourceAlert} from
   * this Vapp Resource Alert for a given Vm.
   *
   * @param vm {@link Vm} instance
   * @return {@link com.iland.core.api.notification.UserVmResourceAlert}
   * instance
   */
  public UserVmResourceAlert createVmResourceAlert(final Vm vm) {
    final UserVmResourceAlert alert =
        new UserVmResourceAlert(vm.getUuid(), group, name, type, threshold);
    alert.setAction(action);
    alert.setBreachPeriod(breachPeriod);
    alert.setRelation(equalityRelation);
    alert.setEnabled(enabled);
    alert.setUsername(username);
    return alert;
  }

  /**
   * Get the alerting threshold at which the user wants to receive alerts for
   * the counter specified by group, name and type.
   *
   * @return alerting threshold
   */
  public long getThreshold() {
    return threshold;
  }

  /**
   * Set the alerting threshold at which the user wants to receive alerts for
   * the counter specified by group, name and type.
   *
   * @param threshold alerting threshold
   */
  public void setThreshold(final long threshold) {
    this.threshold = threshold;
  }

  /**
   * Whether the alert should be cloned to child VMs.
   *
   * @return is clone to children
   */
  public boolean isCloneToChildren() {
    return cloneToChildren;
  }

  /**
   * Set whether the alert should be cloned to child VMs.
   *
   * @param cloneToChildren clone to children VMs
   */
  public void setCloneToChildren(final boolean cloneToChildren) {
    this.cloneToChildren = cloneToChildren;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final UserVappResourceAlert that = (UserVappResourceAlert) o;
    if (getThreshold() != that.getThreshold())
      return false;
    if (isEnabled() != that.isEnabled())
      return false;
    if (getBreachPeriod() != that.getBreachPeriod())
      return false;
    if (getVapp() != null ?
        !getVapp().equals(that.getVapp()) :
        that.getVapp() != null)
      return false;
    if (getGroup() != null ?
        !getGroup().equals(that.getGroup()) :
        that.getGroup() != null)
      return false;
    if (getName() != null ?
        !getName().equals(that.getName()) :
        that.getName() != null)
      return false;
    if (getType() != null ?
        !getType().equals(that.getType()) :
        that.getType() != null)
      return false;
    if (getUsername() != null ?
        !getUsername().equals(that.getUsername()) :
        that.getUsername() != null)
      return false;
    if (getAction() != null ?
        !getAction().equals(that.getAction()) :
        that.getAction() != null)
      return false;
    return equalityRelation != null ?
        equalityRelation.equals(that.equalityRelation) :
        that.equalityRelation == null;
  }

  @Override
  public int hashCode() {
    int result = getVapp() != null ? getVapp().hashCode() : 0;
    result = 31 * result + (getGroup() != null ? getGroup().hashCode() : 0);
    result = 31 * result + (getName() != null ? getName().hashCode() : 0);
    result = 31 * result + (getType() != null ? getType().hashCode() : 0);
    result = 31 * result + (int) (getThreshold() ^ (getThreshold() >>> 32));
    result =
        31 * result + (getUsername() != null ? getUsername().hashCode() : 0);
    result = 31 * result + (getAction() != null ? getAction().hashCode() : 0);
    result = 31 * result + (equalityRelation != null ?
        equalityRelation.hashCode() :
        0);
    result = 31 * result + (isEnabled() ? 1 : 0);
    result = 31 * result + getBreachPeriod();
    return result;
  }

}

