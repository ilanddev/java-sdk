/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.license.api.grpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@io.grpc.stub.annotations.GrpcGenerated
public final class LicenseServiceGrpc {

  private LicenseServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "io.grpc.LicenseService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest,
      com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse> getGetVeeamLicensesForCompanyByTypeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetVeeamLicensesForCompanyByType",
      requestType = com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest.class,
      responseType = com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest,
      com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse> getGetVeeamLicensesForCompanyByTypeMethod() {
    io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest, com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse> getGetVeeamLicensesForCompanyByTypeMethod;
    if ((getGetVeeamLicensesForCompanyByTypeMethod = LicenseServiceGrpc.getGetVeeamLicensesForCompanyByTypeMethod) == null) {
      synchronized (LicenseServiceGrpc.class) {
        if ((getGetVeeamLicensesForCompanyByTypeMethod = LicenseServiceGrpc.getGetVeeamLicensesForCompanyByTypeMethod) == null) {
          LicenseServiceGrpc.getGetVeeamLicensesForCompanyByTypeMethod = getGetVeeamLicensesForCompanyByTypeMethod =
              io.grpc.MethodDescriptor.<com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest, com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetVeeamLicensesForCompanyByType"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LicenseServiceMethodDescriptorSupplier("GetVeeamLicensesForCompanyByType"))
              .build();
        }
      }
    }
    return getGetVeeamLicensesForCompanyByTypeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest,
      com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse> getGetLicenseUsageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetLicenseUsage",
      requestType = com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest.class,
      responseType = com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest,
      com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse> getGetLicenseUsageMethod() {
    io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest, com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse> getGetLicenseUsageMethod;
    if ((getGetLicenseUsageMethod = LicenseServiceGrpc.getGetLicenseUsageMethod) == null) {
      synchronized (LicenseServiceGrpc.class) {
        if ((getGetLicenseUsageMethod = LicenseServiceGrpc.getGetLicenseUsageMethod) == null) {
          LicenseServiceGrpc.getGetLicenseUsageMethod = getGetLicenseUsageMethod =
              io.grpc.MethodDescriptor.<com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest, com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetLicenseUsage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LicenseServiceMethodDescriptorSupplier("GetLicenseUsage"))
              .build();
        }
      }
    }
    return getGetLicenseUsageMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicenseRequest,
      com.iland.license.api.grpc.GetVeeamLicenseResponse> getGetLicenseMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetLicense",
      requestType = com.iland.license.api.grpc.GetVeeamLicenseRequest.class,
      responseType = com.iland.license.api.grpc.GetVeeamLicenseResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicenseRequest,
      com.iland.license.api.grpc.GetVeeamLicenseResponse> getGetLicenseMethod() {
    io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicenseRequest, com.iland.license.api.grpc.GetVeeamLicenseResponse> getGetLicenseMethod;
    if ((getGetLicenseMethod = LicenseServiceGrpc.getGetLicenseMethod) == null) {
      synchronized (LicenseServiceGrpc.class) {
        if ((getGetLicenseMethod = LicenseServiceGrpc.getGetLicenseMethod) == null) {
          LicenseServiceGrpc.getGetLicenseMethod = getGetLicenseMethod =
              io.grpc.MethodDescriptor.<com.iland.license.api.grpc.GetVeeamLicenseRequest, com.iland.license.api.grpc.GetVeeamLicenseResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetLicense"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.license.api.grpc.GetVeeamLicenseRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.license.api.grpc.GetVeeamLicenseResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LicenseServiceMethodDescriptorSupplier("GetLicense"))
              .build();
        }
      }
    }
    return getGetLicenseMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest,
      com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse> getGetVeeamLicenseInfoForCompanyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetVeeamLicenseInfoForCompany",
      requestType = com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest.class,
      responseType = com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest,
      com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse> getGetVeeamLicenseInfoForCompanyMethod() {
    io.grpc.MethodDescriptor<com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest, com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse> getGetVeeamLicenseInfoForCompanyMethod;
    if ((getGetVeeamLicenseInfoForCompanyMethod = LicenseServiceGrpc.getGetVeeamLicenseInfoForCompanyMethod) == null) {
      synchronized (LicenseServiceGrpc.class) {
        if ((getGetVeeamLicenseInfoForCompanyMethod = LicenseServiceGrpc.getGetVeeamLicenseInfoForCompanyMethod) == null) {
          LicenseServiceGrpc.getGetVeeamLicenseInfoForCompanyMethod = getGetVeeamLicenseInfoForCompanyMethod =
              io.grpc.MethodDescriptor.<com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest, com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetVeeamLicenseInfoForCompany"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LicenseServiceMethodDescriptorSupplier("GetVeeamLicenseInfoForCompany"))
              .build();
        }
      }
    }
    return getGetVeeamLicenseInfoForCompanyMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static LicenseServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<LicenseServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<LicenseServiceStub>() {
        @java.lang.Override
        public LicenseServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new LicenseServiceStub(channel, callOptions);
        }
      };
    return LicenseServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static LicenseServiceBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<LicenseServiceBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<LicenseServiceBlockingV2Stub>() {
        @java.lang.Override
        public LicenseServiceBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new LicenseServiceBlockingV2Stub(channel, callOptions);
        }
      };
    return LicenseServiceBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static LicenseServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<LicenseServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<LicenseServiceBlockingStub>() {
        @java.lang.Override
        public LicenseServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new LicenseServiceBlockingStub(channel, callOptions);
        }
      };
    return LicenseServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static LicenseServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<LicenseServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<LicenseServiceFutureStub>() {
        @java.lang.Override
        public LicenseServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new LicenseServiceFutureStub(channel, callOptions);
        }
      };
    return LicenseServiceFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     */
    default void getVeeamLicensesForCompanyByType(com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest request,
        io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetVeeamLicensesForCompanyByTypeMethod(), responseObserver);
    }

    /**
     */
    default void getLicenseUsage(com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest request,
        io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetLicenseUsageMethod(), responseObserver);
    }

    /**
     */
    default void getLicense(com.iland.license.api.grpc.GetVeeamLicenseRequest request,
        io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicenseResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetLicenseMethod(), responseObserver);
    }

    /**
     */
    default void getVeeamLicenseInfoForCompany(com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest request,
        io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetVeeamLicenseInfoForCompanyMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service LicenseService.
   */
  public static abstract class LicenseServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return LicenseServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service LicenseService.
   */
  public static final class LicenseServiceStub
      extends io.grpc.stub.AbstractAsyncStub<LicenseServiceStub> {
    private LicenseServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected LicenseServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new LicenseServiceStub(channel, callOptions);
    }

    /**
     */
    public void getVeeamLicensesForCompanyByType(com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest request,
        io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetVeeamLicensesForCompanyByTypeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getLicenseUsage(com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest request,
        io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetLicenseUsageMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getLicense(com.iland.license.api.grpc.GetVeeamLicenseRequest request,
        io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicenseResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetLicenseMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getVeeamLicenseInfoForCompany(com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest request,
        io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetVeeamLicenseInfoForCompanyMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service LicenseService.
   */
  public static final class LicenseServiceBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<LicenseServiceBlockingV2Stub> {
    private LicenseServiceBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected LicenseServiceBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new LicenseServiceBlockingV2Stub(channel, callOptions);
    }

    /**
     */
    public com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse getVeeamLicensesForCompanyByType(com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetVeeamLicensesForCompanyByTypeMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse getLicenseUsage(com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetLicenseUsageMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.license.api.grpc.GetVeeamLicenseResponse getLicense(com.iland.license.api.grpc.GetVeeamLicenseRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetLicenseMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse getVeeamLicenseInfoForCompany(com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetVeeamLicenseInfoForCompanyMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service LicenseService.
   */
  public static final class LicenseServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<LicenseServiceBlockingStub> {
    private LicenseServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected LicenseServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new LicenseServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse getVeeamLicensesForCompanyByType(com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetVeeamLicensesForCompanyByTypeMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse getLicenseUsage(com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetLicenseUsageMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.license.api.grpc.GetVeeamLicenseResponse getLicense(com.iland.license.api.grpc.GetVeeamLicenseRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetLicenseMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse getVeeamLicenseInfoForCompany(com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetVeeamLicenseInfoForCompanyMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service LicenseService.
   */
  public static final class LicenseServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<LicenseServiceFutureStub> {
    private LicenseServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected LicenseServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new LicenseServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse> getVeeamLicensesForCompanyByType(
        com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetVeeamLicensesForCompanyByTypeMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse> getLicenseUsage(
        com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetLicenseUsageMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.license.api.grpc.GetVeeamLicenseResponse> getLicense(
        com.iland.license.api.grpc.GetVeeamLicenseRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetLicenseMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse> getVeeamLicenseInfoForCompany(
        com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetVeeamLicenseInfoForCompanyMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_VEEAM_LICENSES_FOR_COMPANY_BY_TYPE = 0;
  private static final int METHODID_GET_LICENSE_USAGE = 1;
  private static final int METHODID_GET_LICENSE = 2;
  private static final int METHODID_GET_VEEAM_LICENSE_INFO_FOR_COMPANY = 3;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_VEEAM_LICENSES_FOR_COMPANY_BY_TYPE:
          serviceImpl.getVeeamLicensesForCompanyByType((com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse>) responseObserver);
          break;
        case METHODID_GET_LICENSE_USAGE:
          serviceImpl.getLicenseUsage((com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse>) responseObserver);
          break;
        case METHODID_GET_LICENSE:
          serviceImpl.getLicense((com.iland.license.api.grpc.GetVeeamLicenseRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicenseResponse>) responseObserver);
          break;
        case METHODID_GET_VEEAM_LICENSE_INFO_FOR_COMPANY:
          serviceImpl.getVeeamLicenseInfoForCompany((com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getGetVeeamLicensesForCompanyByTypeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeRequest,
              com.iland.license.api.grpc.GetVeeamLicensesForCompanyByTypeResponse>(
                service, METHODID_GET_VEEAM_LICENSES_FOR_COMPANY_BY_TYPE)))
        .addMethod(
          getGetLicenseUsageMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.license.api.grpc.GetVeeamLicenseServerUsageRequest,
              com.iland.license.api.grpc.GetVeeamLicenseServerUsageResponse>(
                service, METHODID_GET_LICENSE_USAGE)))
        .addMethod(
          getGetLicenseMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.license.api.grpc.GetVeeamLicenseRequest,
              com.iland.license.api.grpc.GetVeeamLicenseResponse>(
                service, METHODID_GET_LICENSE)))
        .addMethod(
          getGetVeeamLicenseInfoForCompanyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyRequest,
              com.iland.license.api.grpc.GetVeeamLicenseInfoForCompanyResponse>(
                service, METHODID_GET_VEEAM_LICENSE_INFO_FOR_COMPANY)))
        .build();
  }

  private static abstract class LicenseServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    LicenseServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.iland.license.api.grpc.LicenseApi.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("LicenseService");
    }
  }

  private static final class LicenseServiceFileDescriptorSupplier
      extends LicenseServiceBaseDescriptorSupplier {
    LicenseServiceFileDescriptorSupplier() {}
  }

  private static final class LicenseServiceMethodDescriptorSupplier
      extends LicenseServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    LicenseServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (LicenseServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new LicenseServiceFileDescriptorSupplier())
              .addMethod(getGetVeeamLicensesForCompanyByTypeMethod())
              .addMethod(getGetLicenseUsageMethod())
              .addMethod(getGetLicenseMethod())
              .addMethod(getGetVeeamLicenseInfoForCompanyMethod())
              .build();
        }
      }
    }
    return result;
  }
}
