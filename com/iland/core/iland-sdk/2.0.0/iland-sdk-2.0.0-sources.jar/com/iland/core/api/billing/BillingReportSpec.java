/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.google.common.annotations.VisibleForTesting;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;
import org.jboss.resteasy.spi.BadRequestException;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.api.serialization.JsonOptional;
import com.iland.core.api.serialization.JsonRequired;
import com.iland.core.util.IlandSerializedName;

/**
 * Billing Report.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public class BillingReportSpec implements Serializable {

  private static final long serialVersionUID = 231938002395788854L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FOUR)
  @IlandSerializedName(BillingReportField.CUSTOM_COLUMNS)
  @JsonOptional("custom columns")
  private final Map<String, String> customColumns;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FOUR)
  @IlandSerializedName(BillingReportField.ROWS)
  @JsonOptional("rows")
  private final List<String> rows;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FOUR)
  @IlandSerializedName(BillingReportField.DATE)
  @JsonOptional("date")
  private final Long date;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FOUR)
  @IlandSerializedName(BillingReportField.EMAIL)
  @JsonOptional("email")
  private final String email;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FOUR)
  @IlandSerializedName(BillingReportField.FILENAME)
  @JsonOptional("filename for download")
  private final String filename;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FOUR)
  @IlandSerializedName(BillingReportField.TYPE)
  @JsonRequired("type of billing report")
  private final BillingReportType type;

  public BillingReportSpec(final Map<String, String> customColumns,
      final List<String> rows, final Long date, final String email,
      final String filename, final BillingReportType type) {
    this.customColumns = customColumns;
    this.rows = rows;
    this.date = date;
    this.email = email;
    this.filename = filename;
    this.type = type;
  }

  /**
   * Get a String array of column headers for CSV report.
   *
   * @return column headers
   */
  public String[] getColumnHeaders() {
    return generateHeadersInOrder(customColumns);
  }

  /**
   * Gets a String ArrayList of rows.
   *
   * @return {@link List} of {@link String} rows
   */
  public List<String> getRows() {
    return rows;
  }

  /**
   * Gets a map of custom columns.
   *
   * @return {@link Map} of {@link Integer} column numbers and {@link String}
   * column names
   */
  public Map<String, String> getCustomColumns() {
    return customColumns;
  }

  /**
   * Gets the date.
   *
   * @return {@link Long} date
   */
  public Long getDate() {
    return date;
  }

  /**
   * Gets the user email to send the report to.
   *
   * @return {@link String} email
   */
  public String getEmail() {
    return email;
  }

  /**
   * Gets the filename.
   *
   * @return {@link String} filename
   */
  public String getFilename() {
    return filename;
  }

  /**
   * Gets the type of CSV report to return.
   *
   * @return {@link BillingReportType} type
   */
  public BillingReportType getType() {
    return type;
  }

  /**
   * Generates a String array with the column headers in the correct order.
   * Entity Name and Total Cost are always the first and last columns.
   *
   * @param customColumns {@link Map} of {@link Integer} keys and {@link String}
   *                      values
   * @return of column names in user specified order
   */
  private String[] generateHeadersInOrder(
      final Map<String, String> customColumns) {
    if (customColumns != null && customColumns.size() > 0) {
      final int size = customColumns.keySet().size();
      String[] columnToReturn = new String[size + 2];
      columnToReturn[0] = BillingColumn.NAME.getColName();
      for (final String key : customColumns.keySet()) {
        final int i = Integer.parseInt(key);
        if (i > size || i < 0) {
          throw new BadRequestException(String.format(
              "Column number: '%d' is invalid for the number of columns that were specified.",
              i));
        }
        final String header = customColumns.get(key);
        columnToReturn[i] = BillingColumn.fromApiName(header);
      }
      columnToReturn[size + 1] = BillingColumn.TOTAL_COST.getColName();
      return columnToReturn;
    }
    return null;
  }

  /**
   * Gets the value from the bill for the corresponding column.
   *
   * @param apiName {@link String} of the column name
   * @param bill    {@link Bill} bill to get values from
   * @return {@link String} value to return for CSV row
   */
  public String getBillValueForColumn(final String apiName, final Bill bill) {
    if (BillingColumn.getBillingColumnFromName(apiName) != null) {
      switch (BillingColumn.getBillingColumnFromName(apiName)) {
        case CPU_USAGE: {
          return String.valueOf(bill.getCpuUsage());
        }
        case CPU_TOTAL_COST: {
          return String.valueOf(bill.getCpu());
        }
        case CPU_RESERVED_USAGE: {
          return String.valueOf(bill.getCpuResUsage());
        }
        case CPU_RESREVED_COST: {
          return String.valueOf(bill.getCpu() - bill.getCpuBurst());
        }
        case CPU_BURST_USAGE: {
          return String.valueOf(bill.getCpuBurstUsage());
        }
        case CPU_BURST_COST: {
          return String.valueOf(bill.getCpuBurst());
        }
        case RAM_USAGE: {
          return String.valueOf(bill.getMemoryUsage());
        }
        case RAM_TOAL_COST: {
          return String.valueOf(bill.getMemory());
        }
        case RAM_RESERVED_USAGE: {
          return String.valueOf(bill.getMemoryResUsage());
        }
        case RAM_RESERVED_COST: {
          return String.valueOf(bill.getMemory() - bill.getMemoryBurst());
        }
        case RAM_BURST_USAGE: {
          return String.valueOf(bill.getMemoryBurstUsage());
        }
        case RAM_BURST_COST: {
          return String.valueOf(bill.getMemoryBurst());
        }
        case HDD_RESERVED_USAGE: {
          return String.valueOf(bill.getHddResUsage());
        }
        case HDD_RESERVED_COST: {
          return String.valueOf(bill.getHddResCost());
        }
        case HDD_BURST_USAGE: {
          return String.valueOf(bill.getHddBurstUsage());
        }
        case HDD_BURST_COST: {
          return String.valueOf(bill.getHddBurstCost());
        }
        case HDD_TOTAL_USAGE: {
          return String.valueOf(bill.getHddUsage());
        }
        case HDD_TOTAL_COST: {
          return String.valueOf(bill.getHddCost());
        }
        case SSD_RESERVED_USAGE: {
          return String.valueOf(bill.getSsdResUsage());
        }
        case SSD_RESERVED_COST: {
          return String.valueOf(bill.getSsdResCost());
        }
        case SSD_BURST_USAGE: {
          return String.valueOf(bill.getSsdBurstUsage());
        }
        case SSD_BURST_COST: {
          return String.valueOf(bill.getSsdBurstCost());
        }
        case SSD_TOTAL_USAGE: {
          return String.valueOf(bill.getSsdUsage());
        }
        case SSD_TOTAL_COST: {
          return String.valueOf(bill.getSsdCost());
        }
        case ARCHIVE_RESERVED_USAGE: {
          return String.valueOf(bill.getArchiveResUsage());
        }
        case ARCHIVE_RESERVED_COST: {
          return String.valueOf(bill.getArchiveResCost());
        }
        case ARCHIVE_BURST_USAGE: {
          return String.valueOf(bill.getArchiveBurstUsage());
        }
        case ARCHIVE_BURST_COST: {
          return String.valueOf(bill.getArchiveBurstCost());
        }
        case ARCHIVE_TOTAL_USAGE: {
          return String.valueOf(bill.getArchiveUsage());
        }
        case ARCHIVE_TOTAL_COST: {
          return String.valueOf(bill.getArchiveCost());
        }
        case BANDWIDTH_USAGE: {
          return String.valueOf(bill.getBandwidthUsage());
        }
        case BANDWIDTH_TOTAL_COST: {
          return String.valueOf(bill.getBandwidth());
        }
        case BANDWIDTH_RESERVED_COST: {
          return String.valueOf(bill.getBandwidth() - bill.getBandwidthBurst());
        }
        case BANDWIDTH_BURST_COST: {
          return String.valueOf(bill.getBandwidthBurst());
        }
        case TOTAL_COST: {
          return String.valueOf(bill.getTotal());
        }
        case IS_TEST_DRIVE: {
          return String.valueOf(bill.isTestDrive());
        }
        default: {
          return "";
        }
      }
    } else {
      throw new IllegalArgumentException(
          String.format("Column %s is not valid.", apiName));
    }
  }

}
