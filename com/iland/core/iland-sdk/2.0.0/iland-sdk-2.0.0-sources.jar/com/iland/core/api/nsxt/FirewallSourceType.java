/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.nsxt;

import java.util.HashMap;
import java.util.Map;

/**
 * Specifies the type of the Firewall Source/Destination.
 *
 * @author <a href="mailto:spanyam@iland.com">Swetha Panyam</a>
 */
public enum FirewallSourceType {

  IP_SET("ipset"),

  SECURITY_GROUP("securitygroup");

  private final String value;

  public static final Map<String, FirewallSourceType> sourceMap =
      new HashMap<>();

  static {
    for (final FirewallSourceType firewallSourceType : values()) {
      sourceMap.put(firewallSourceType.getValue(), firewallSourceType);
    }
  }


  FirewallSourceType(final String value) {
    this.value = value;
  }


  /**
   * Get the FirewallSourceType of the firewall rule.
   *
   * @return {@link String} FirewallSourceType value
   */
  public String getValue() {
    return this.value;
  }

  /**
   * Get the FirewallSourceType enum given the type value.
   *
   * @param value {@link String} value
   * @return {@link FirewallSourceType} Firewall Source/Destination Type
   */
  public static FirewallSourceType getFirewallSourceType(final String value) {
    return sourceMap.get(value);
  }
}
