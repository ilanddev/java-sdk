/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import java.io.Serializable;

import com.iland.core.api.user.User;
import com.iland.core.api.vcd.Vm;

/**
 * Snapshot Alert.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class SnapshotAlert implements Serializable {

  private static final long serialVersionUID = 6613272024747402589L;

  final Vm vm;

  final User user;

  /**
   * Constructor for creating a SnapshotAlert instance.
   *
   * @param vm   the virtual machine associated with the snapshot alert
   * @param user the user associated with the snapshot alert
   */
  public SnapshotAlert(final Vm vm, final User user) {
    this.vm = vm;
    this.user = user;
  }

  /**
   * Get the vm associated with a snapshot alert.
   *
   * @return {@link Vm} instance
   */
  public Vm getVm() {
    return vm;
  }

  /**
   * Get the user associated with a snapshot alert.
   *
   * @return {@link User} instance
   */
  public User getUser() {
    return user;
  }

}
