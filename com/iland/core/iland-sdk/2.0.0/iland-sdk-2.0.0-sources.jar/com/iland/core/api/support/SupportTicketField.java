/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.support;

/**
 * Support Ticket Fields.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class SupportTicketField {

  public static final String ID = "id";

  public static final String ORG_UUID = "org_uuid";

  public static final String CRM = "crm";

  public static final String CREATOR_FULL_NAME = "creator_full_name";

  public static final String CREATOR_USER_NAME = "creator_user_name";

  public static final String CREATION_DATE = "creation_date";

  public static final String CC_EMAIL_ADDRESSES = "cc_email_addresses";

  public static final String CC_EMAILS_ENABLED = "cc_emails_enabled";

  public static final String REGARDING_ID = "regarding_id";

  public static final String SERVICE_ID = "service_id";

  public static final String CATEGORY_ID = "category_id";

  public static final String SEVERITY = "severity";

  public static final String CONTACT_TYPE = "contact_type";

  public static final String PHONE_NUMBER = "phone_number";

  public static final String PHONE_NUMBER_EXT = "phone_number_ext";

  public static final String REGARDING_NAME = "regarding_name";

  public static final String SERVICE_NAME = "service_name";

  public static final String CATEGORY_NAME = "category_name";

  private SupportTicketField() {
  }

}
