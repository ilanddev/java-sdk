/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * WanAccelerator.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@XmlRootElement(namespace = "http://www.veeam.com/ent/v1.0", name = "WanAccelerator")
public class WanAccelerator implements Serializable {

  private static final long serialVersionUID = 5747864964584344632L;

  @XmlAttribute(name = "UID")
  private String uid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(WanAcceleratorField.NAME)
  @XmlAttribute(name = "Name")
  private String name;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(WanAcceleratorField.DESCRIPTION)
  @XmlElement(name = "Description")
  private String description;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(WanAcceleratorField.OUT_OF_DATE)
  @XmlElement(name = "OutOfDate")
  private boolean outOfDate;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(WanAcceleratorField.VERSION)
  @XmlElement(name = "Version")
  private String version;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(WanAcceleratorField.CAPACITY)
  @XmlElement(name = "Capacity")
  private long capacity;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(WanAcceleratorField.TRAFFIC_PORT)
  @XmlElement(name = "TrafficPort")
  private int trafficPort;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(WanAcceleratorField.CONNECTION_COUNT)
  @XmlElement(name = "ConnectionCount")
  private long connectionCount;

  @Expose
  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @SerializedName(WanAcceleratorField.CACHE_PATH)
  @XmlElement(name = "CachePath")
  private String cachePath;

  public WanAccelerator() {
  }

  public WanAccelerator(final String uid, final String name,
      final String description, final boolean outOfDate, final String version,
      final long capacity, final int trafficPort, final long connectionCount,
      final String cachePath) {
    this.uid = uid;
    this.name = name;
    this.description = description;
    this.outOfDate = outOfDate;
    this.version = version;
    this.capacity = capacity;
    this.trafficPort = trafficPort;
    this.connectionCount = connectionCount;
    this.cachePath = cachePath;
  }

  /**
   * Get the ID.
   *
   * @return ID
   */
  public String getUid() {
    return uid;
  }

  /**
   * Get the name.
   *
   * @return name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the description.
   *
   * @return description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get whether the accelerator is out of date.
   *
   * @return is out of date
   */
  public boolean isOutOfDate() {
    return outOfDate;
  }

  /**
   * Get the version.
   *
   * @return version
   */
  public String getVersion() {
    return version;
  }

  /**
   * Get the capacity.
   *
   * @return capacity
   */
  public long getCapacity() {
    return capacity;
  }

  /**
   * Get the traffic port.
   *
   * @return traffic port
   */
  public int getTrafficPort() {
    return trafficPort;
  }

  /**
   * Get the connection count.
   *
   * @return connection count
   */
  public long getConnectionCount() {
    return connectionCount;
  }

  /**
   * Get the cache path.
   *
   * @return cache path
   */
  public String getCachePath() {
    return cachePath;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final WanAccelerator that = (WanAccelerator) o;

    if (isOutOfDate() != that.isOutOfDate())
      return false;
    if (getCapacity() != that.getCapacity())
      return false;
    if (getTrafficPort() != that.getTrafficPort())
      return false;
    if (getConnectionCount() != that.getConnectionCount())
      return false;
    if (getUid() != null ?
        !getUid().equals(that.getUid()) :
        that.getUid() != null)
      return false;
    if (getName() != null ?
        !getName().equals(that.getName()) :
        that.getName() != null)
      return false;
    if (getDescription() != null ?
        !getDescription().equals(that.getDescription()) :
        that.getDescription() != null)
      return false;
    if (getVersion() != null ?
        !getVersion().equals(that.getVersion()) :
        that.getVersion() != null)
      return false;
    return getCachePath() != null ?
        getCachePath().equals(that.getCachePath()) :
        that.getCachePath() == null;
  }

  @Override
  public int hashCode() {
    int result = getUid() != null ? getUid().hashCode() : 0;
    result = 31 * result + (getName() != null ? getName().hashCode() : 0);
    result = 31 * result + (getDescription() != null ?
        getDescription().hashCode() :
        0);
    result = 31 * result + (isOutOfDate() ? 1 : 0);
    result = 31 * result + (getVersion() != null ? getVersion().hashCode() : 0);
    result = 31 * result + (int) (getCapacity() ^ (getCapacity() >>> 32));
    result = 31 * result + getTrafficPort();
    result = 31 * result + (int) (getConnectionCount() ^ (getConnectionCount()
        >>> 32));
    result =
        31 * result + (getCachePath() != null ? getCachePath().hashCode() : 0);
    return result;
  }

}
