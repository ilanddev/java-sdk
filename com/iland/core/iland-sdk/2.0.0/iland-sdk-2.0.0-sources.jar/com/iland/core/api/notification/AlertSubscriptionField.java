/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

/**
 * Alert Subscription Field.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public final class AlertSubscriptionField {

  public static final String USERNAME = "username";

  public static final String EXTERNAL_NETWORK_UUID = "external_network_uuid";

  public static final String EDGE_UUID = "edge_uuid";

  public static final String VDC_UUID = "vdc_uuid";

  public static final String VAPP_UUID = "vapp_uuid";

  public static final String VM_UUID = "vm_uuid";

  public static final String GROUP = "group";

  public static final String NAME = "name";

  public static final String TYPE = "type";

  public static final String ACTIVE = "active";

  public static final String THRESHOLD = "threshold";

  public static final String EMAILS = "emails";

  public static final String VDC_TYPE = "vdc_type";

  public static final String SENT = "alert_sent";

  public static final String EQUALITY_CONDITION = "equality";

  public static final String ENABLED = "enabled";

  public static final String BREACH = "breach";

  public static final String ACTION = "action";

  public static final String HIT = "hit";

  public static final String USERS = "users";

  public static final String CLONE_TO_CHILDREN = "clone_to_children";

  private AlertSubscriptionField() {
  }

}
