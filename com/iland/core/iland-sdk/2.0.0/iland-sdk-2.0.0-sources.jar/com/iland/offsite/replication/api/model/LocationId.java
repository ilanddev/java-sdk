/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * {@link LocationId}.
 */
public final class LocationId {

	private static final Pattern PATTERN_VALIDATE = Pattern.compile(
		"^(dev-)?[a-z]{3}\\d{2}\\.(iland\\.dev|ilandcloud\\.com|1111systems\\.com)$");
	private static final Pattern PATTERN_SHORT_ID =
		Pattern.compile("([0-9A-Za-z]+).*");

	private final String value;

	public static LocationId of(final String value) {
		return new LocationId(value);
	}

	private LocationId(final String value) {
		this.value = validate(value);
	}

	private static String validate(final String value) {
		final Matcher matcher = PATTERN_VALIDATE.matcher(value);
		if (!matcher.matches()) {
			throw new IllegalArgumentException("invalid location id: " + value);
		}

		return value;
	}

	/**
	 * Returns a short identifier for a location ID.
	 * <p>
	 * For example:
	 * <ul>
	 *   <li>dev-vcd01.iland.dev  => dev</li>
	 *   <li>man01.ilandcloud.com => man01</li>
	 * </ul>
	 */
	public String shortIdentifier() {
		final Matcher matcher = PATTERN_SHORT_ID.matcher(value);

		return matcher.matches() ? matcher.group(1) : value;
	}

	@Override
	public String toString() {
		return value;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o)
			return true;
		if (!(o instanceof LocationId))
			return false;
		final LocationId that = (LocationId) o;
		return Objects.equals(value, that.value);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(value);
	}

}
