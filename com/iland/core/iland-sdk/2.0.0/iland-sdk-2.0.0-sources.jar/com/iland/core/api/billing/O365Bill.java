/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.io.Serializable;

/**
 * Office 365 Bill.
 *
 * @author <a href="mailto:nkasprzakj@iland.com">Nick Kasprzak</a>
 */
public final class O365Bill implements Serializable {

  private static final long serialVersionUID = -3361106822603246010L;

  private int year;

  private int month;

  private double total;

  private double totalCostForUsedLicenses;

  private double fullMonthContractCost;

  private CurrencyCode currencyCode;

  private int numberOfLicenses;

  private int numberOfLicensesUsed;

  private int licensedUserCount;

  private double costPerLicense;

  public O365Bill(final int year, final int month, final double total,
      final double totalCostForUsedLicenses, final double fullMonthContractCost,
      final CurrencyCode currencyCode, final int numberOfLicenses,
      final int numberOfLicensesUsed, final int licensedUserCount,
      final double costPerLicense) {
    this.year = year;
    this.month = month;
    this.total = total;
    this.totalCostForUsedLicenses = totalCostForUsedLicenses;
    this.fullMonthContractCost = fullMonthContractCost;
    this.currencyCode = currencyCode;
    this.numberOfLicenses = numberOfLicenses;
    this.numberOfLicensesUsed = numberOfLicensesUsed;
    this.licensedUserCount = licensedUserCount;
    this.costPerLicense = costPerLicense;
  }

  /**
   * Gets year.
   *
   * @return the year
   */
  public int getYear() {
    return year;
  }

  /**
   * Gets month.
   *
   * @return the month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Gets total.
   *
   * @return the total
   */
  public double getTotal() {
    return total;
  }

  /**
   * Gets full month contract cost.
   *
   * @return the full month contract cost
   */
  public double getFullMonthContractCost() {
    return fullMonthContractCost;
  }

  /**
   * Gets currency code.
   *
   * @return the currency code
   */
  public CurrencyCode getCurrencyCode() {
    return currencyCode;
  }

  /**
   * Gets number of licenses.
   *
   * @return the number of licenses
   */
  public int getNumberOfLicenses() {
    return numberOfLicenses;
  }

  /**
   * Gets cost per license.
   *
   * @return the cost per license
   */
  public double getCostPerLicense() {
    return costPerLicense;
  }

  /**
   * Gets total amount including burst usage
   *
   * @return the total used
   */
  public double getTotalCostForUsedLicenses() { return totalCostForUsedLicenses; }

  /**
   * Gets total number of used licenses including burst
   *
   * @return the number of used licenses
   */
  public int getNumberOfLicensesUsed() { return numberOfLicensesUsed; }

  /**
   * Gets licensed user count including burst
   *
   * @return the licensed user count
   */
  public int getLicensedUserCount() {
    return licensedUserCount;
  }
}
