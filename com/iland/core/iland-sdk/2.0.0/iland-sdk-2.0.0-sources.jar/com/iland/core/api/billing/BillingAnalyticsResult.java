/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * BillingAnalyticsResult.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class BillingAnalyticsResult implements Serializable {

  private static final long serialVersionUID = 1609952248396903147L;

  public static final String CRM = "crm";

  public static final String ENTITY_NAME = "entity_name";

  public static final String ENTITY_UUID = "entity_uuid";

  public static final String ORG_UUID = "org_uuid";

  public static final String ACTUAL_COST = "actual";

  public static final String PREDICTED_COST = "predicted";

  public static final String CURRENCY_CODE = "currency_code";

  public static final String RMSE = "rmse";

  public static final String M = "m";

  public static final String B = "b";

  @Expose
  @SerializedName(CRM)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String crm;

  @Expose
  @SerializedName(ENTITY_NAME)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String entityName;

  @Expose
  @SerializedName(ENTITY_UUID)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String entityUuid;

  @Expose
  @SerializedName(ORG_UUID)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private String orgUuid;

  @Expose
  @SerializedName(CURRENCY_CODE)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private CurrencyCode currencyCode;

  @Expose
  @SerializedName(ACTUAL_COST)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private double actualCost;

  @Expose
  @SerializedName(PREDICTED_COST)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private double predictedCost;

  @Expose
  @SerializedName(RMSE)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private double rmse;

  @Expose
  @SerializedName(M)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private double slope;

  @Expose
  @SerializedName(B)
  @Since(ApiVersion.ZERO_DOT_NINE)
  private double intercept;

  public BillingAnalyticsResult(final String crm, final String entityUuid,
      final String entityName, final String orgUuid,
      final CurrencyCode currencyCode, final double actualCost,
      final double predictedCost, final double rmse, final double slope,
      final double intercept) {
    this.crm = crm;
    this.entityUuid = entityUuid;
    this.entityName = entityName;
    this.orgUuid = orgUuid;
    this.currencyCode = currencyCode;
    this.actualCost = actualCost;
    this.predictedCost = predictedCost;
    this.rmse = rmse;
    this.slope = slope;
    this.intercept = intercept;
  }

  /**
   * Get the CRM number.
   *
   * @return {@link String} CRM number
   */
  public String getCrm() {
    return crm;
  }

  /**
   * Get the entity name.
   *
   * @return entity name
   */
  public String getEntityName() {
    return entityName;
  }

  /**
   * Get the organization UUID.
   *
   * @return organization UUID
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Get the actual cost at this point in time for the given entity.
   *
   * @return actual cost
   */
  public double getActualCost() {
    return actualCost;
  }

  /**
   * Get the predicted cost.
   *
   * @return predicted cost
   */
  public double getPredictedCost() {
    return predictedCost;
  }

  /**
   * Get the RMSE (root mean squared error) from the predicted cost vs actual
   * cost.
   *
   * @return RMSE
   */
  public double getRmse() {
    return rmse;
  }

  /**
   * Get the slope of the linear model used for prediction.
   *
   * @return predicted cost model, linear slope
   */
  public double getSlope() {
    return slope;
  }

  /**
   * Get the intercept of the linear model used for prediction.
   *
   * @return predicted cost model, linear intercept
   */
  public double getIntercept() {
    return intercept;
  }

  /**
   * Get the entity UUID.
   *
   * @return {@link String} entity UUID
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Get the currency code.
   *
   * @return {@link CurrencyCode} currency code
   */
  public CurrencyCode getCurrencyCode() {
    return currencyCode;
  }

}
