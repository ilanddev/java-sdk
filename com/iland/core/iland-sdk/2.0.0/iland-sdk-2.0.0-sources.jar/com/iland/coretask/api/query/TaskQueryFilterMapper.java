/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.coretask.api.query;

import com.iland.common.query.entity.EntityFiltersTuple;
import com.iland.common.query.generation.GenerationFiltersTuple;
import com.iland.common.query.time.TimeFiltersTuple;
import com.iland.common.query.user.UserFiltersTuple;
import com.iland.coretask.api.grpc.GetCoreTasksRequest;
import com.iland.coretask.api.grpc.PagingFilters;
import com.iland.coretask.api.grpc.PagingOrder;
import com.iland.coretask.api.grpc.Synchronized;

/**
 * Maps {@link GetCoreTasksRequest} to and from {@link TaskQueryFilters}.
 */
public final class TaskQueryFilterMapper {
  private TaskQueryFilterMapper() {
  }

  /**
   * Maps a provided {@link GetCoreTasksRequest} to a {@link TaskQueryFilters}.
   *
   * @param request the request to map
   * @return {@link TaskQueryFilters}
   */
  public static TaskQueryFilters fromCoreTasksRequest(
      GetCoreTasksRequest request) {
    final TaskQueryFilters.Builder queryFiltersBuilder =
        new TaskQueryFilters.Builder();
    queryFiltersBuilder.entityFilters(
        EntityFiltersTuple.of(request.getEntityType(),
            request.getEntityUuid()));

    if (request.getSynchronized().equals(Synchronized.TRUE)) {
      queryFiltersBuilder.isSynced(true);
    } else if (request.getSynchronized().equals(Synchronized.FALSE)) {
      queryFiltersBuilder.isSynced(false);
    }

    if (request.hasUsername()) {
      queryFiltersBuilder.userFilters(
          UserFiltersTuple.of(request.getUsername()));
    }

    if (request.hasTaskOperation()) {
      queryFiltersBuilder.taskOperation(request.getTaskOperation());
    }

    queryFiltersBuilder.generationFilters(
        GenerationFiltersTuple.of(request.getIncludeDescendantTasks()));

    final boolean requestHasTimeFilter =
        request.hasTimestampBefore() || request.hasTimestampAfter();
    if (requestHasTimeFilter) {
      final TimeFiltersTuple.Builder timeFiltersBuilder =
          TimeFiltersTuple.builder();
      if (request.hasTimestampBefore()) {
        timeFiltersBuilder.timestampBefore(request.getTimestampBefore());
      }
      if (request.hasTimestampAfter()) {
        timeFiltersBuilder.timestampAfter(request.getTimestampAfter());
      }
      queryFiltersBuilder.timeFilters(timeFiltersBuilder.build());
    }

    if (request.hasPagingFilters()) {
      if (request.getPagingFilters().getPagingOrder().getNumber()
          != PagingOrder.NONE_VALUE) {
        queryFiltersBuilder.order(
            com.iland.common.query.page.PagingOrder.valueOf(
                request.getPagingFilters().getPagingOrder().name()));
      }
      queryFiltersBuilder.limit((long) request.getPagingFilters().getLimit())
          .offset((long) request.getPagingFilters().getOffset());
    }

    return queryFiltersBuilder.build();
  }

  /**
   * Maps a {@link TaskQueryFilters} to a {@link GetCoreTasksRequest}.
   *
   * @param filters the filters to map
   * @return {@link GetCoreTasksRequest}
   */
  public static GetCoreTasksRequest toCoreTasksRequest(
      TaskQueryFilters filters) {
    GetCoreTasksRequest.Builder requestBuilder =
        GetCoreTasksRequest.newBuilder();

    filters.getEntityFilters().ifPresent(
        entityFilters -> requestBuilder.setEntityType(
                entityFilters.getEntityType())
            .setEntityUuid(entityFilters.getEntityUuid()));

    filters.isSynced().ifPresent(isSynced -> {
      if (Boolean.TRUE.equals(isSynced)) {
        requestBuilder.setSynchronized(Synchronized.TRUE);
      } else {
        requestBuilder.setSynchronized(Synchronized.FALSE);
      }
    });

    filters.getUserFilters().ifPresent(
        userFilters -> requestBuilder.setUsername(userFilters.getUsername()));

    filters.getTaskOperation().ifPresent(requestBuilder::setTaskOperation);

    if (filters.getTimeFilters().isPresent()) {
      filters.getTimeFilters().get().getTimestampBefore()
          .ifPresent(requestBuilder::setTimestampBefore);
      filters.getTimeFilters().get().getTimestampAfter()
          .ifPresent(requestBuilder::setTimestampAfter);
    }

    mapPagingFilters(filters, requestBuilder);

    filters.getGenerationFilters().ifPresent(
        generationFilters -> requestBuilder.setIncludeDescendantTasks(
            generationFilters.isIncludeDescendants()));

    return requestBuilder.build();
  }

  private static void mapPagingFilters(
      com.iland.common.query.page.PagingFilters source,
      GetCoreTasksRequest.Builder destination) {
    final PagingFilters.Builder mappedPageFilters = PagingFilters.newBuilder();

    mappedPageFilters.setOffset(Math.toIntExact(source.getOffset()));
    mappedPageFilters.setLimit(Math.toIntExact(source.getLimit()));
    mappedPageFilters.setPagingOrder(
        PagingOrder.valueOf(source.getOrder().name()));

    destination.setPagingFilters(mappedPageFilters.build());
  }
}
