/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlElement;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * NetworkAppliance.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class NetworkAppliance implements Serializable {

  private static final long serialVersionUID = -8673073880859079121L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FIVE)
  @SerializedName(NetworkApplianceField.NAME)
  @XmlElement(name = "Name")
  private String name;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FIVE)
  @SerializedName(NetworkApplianceField.PRODUCTION_NETWORK)
  @XmlElement(name = "ProductionNetwork")
  private String productionNetwork;

  @Expose
  @Since(ApiVersion.ZERO_DOT_FIVE)
  @SerializedName(NetworkApplianceField.OBTAIN_IP_AUTOMATICALLY)
  @XmlElement(name = "ObtainIPAddressAutomatically")
  private boolean obtainIPAddressAutomatically;

  public NetworkAppliance() {
  }

  public NetworkAppliance(final String name, final String productionNetwork,
      final boolean obtainIPAddressAutomatically) {
    this.name = name;
    this.productionNetwork = productionNetwork;
    this.obtainIPAddressAutomatically = obtainIPAddressAutomatically;
  }

  /**
   * Get the name.
   *
   * @return name of network appliance
   */
  public String getName() {
    return name;
  }

  /**
   * Get the production network name.
   *
   * @return network name
   */
  public String getProductionNetwork() {
    return productionNetwork;
  }

  /**
   * Whether its setup to automatically obtain an IP address.
   *
   * @return whether it obtains an IP address automatically
   */
  public boolean isObtainIPAddressAutomatically() {
    return obtainIPAddressAutomatically;
  }

}
