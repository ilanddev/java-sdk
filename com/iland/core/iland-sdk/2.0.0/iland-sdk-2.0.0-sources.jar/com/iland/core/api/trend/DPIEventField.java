/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.trend;

/**
 * DPI Event Field.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public final class DPIEventField {

  public static final String EVENT_ID = "event_id";

  public static final String RULE_ID = "rule_id";

  public static final String ACTION = "action";

  public static final String DATA = "data";

  public static final String DATA_FLAGS = "data_flags";

  public static final String DATA_INDEX = "data_index";

  public static final String DESTINATION_IP = "destination_ip";

  public static final String DESTINATION_MAC = "destination_mac";

  public static final String DESTINATION_PORT = "destination_port";

  public static final String DIRECTION = "direction";

  public static final String DRIVER_TIME = "driver_time";

  public static final String END_TIME = "end_time";

  public static final String EVENT_ORIGIN = "event_origin";

  public static final String FLAGS = "flags";

  public static final String FLOW = "flow";

  public static final String HOST_ID = "host_id";

  public static final String VM_UUID = "vm_uuid";

  public static final String HOST_NAME = "host_name";

  public static final String INTERFACE = "interface";

  public static final String NOTE = "note";

  public static final String PACKET_SIZE = "packet_size";

  public static final String PROTOCOL = "protocol";

  public static final String RANK = "rank";

  public static final String REASON = "reason";

  public static final String REPEAT_COUNT = "repeat_count";

  public static final String SOURCE_IP = "source_ip";

  public static final String SOURCE_MAC = "source_mac";

  public static final String SOURCE_PORT = "source_port";

  public static final String START_TIME = "start_time";

  public static final String STATUS = "status";

  public static final String TAGS = "tags";

  private DPIEventField() {
  }

}
