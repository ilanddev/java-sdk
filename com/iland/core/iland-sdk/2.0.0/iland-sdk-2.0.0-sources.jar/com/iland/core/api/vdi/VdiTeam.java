/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vdi;

import java.util.Objects;
import java.util.Set;
import java.util.UUID;

import com.google.common.base.MoreObjects;

/**
 * VDI Team.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class VdiTeam {

  private static final String URN_PREFIX = "urn:iland:vdi-team";

  private final String orgUuid;

  private final String uuid;

  private final String name;

  private final Set<String> members;

  /**
   * Create vdi team.
   *
   * @param orgUuid the org uuid
   * @param name    the name
   * @param members the members
   * @return the vdi team
   */
  public static VdiTeam create(final String orgUuid, final String name,
      final Set<String> members) {
    final String locationId = orgUuid.split(":")[0];
    final String uuid =
        String.format("%s:%s:%s", locationId, URN_PREFIX, UUID.randomUUID());
    return new VdiTeam(orgUuid, uuid, name, members);
  }

  /**
   * Instantiates a new Vdi team.
   *
   * @param orgUuid the org uuid
   * @param uuid    the uuid
   * @param name    the name
   * @param members the members
   */
  public VdiTeam(final String orgUuid, final String uuid, final String name,
      final Set<String> members) {
    this.orgUuid = orgUuid;
    this.uuid = uuid;
    this.name = name;
    this.members = members;
  }

  /**
   * Gets org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets members.
   *
   * @return the members as a Set of VDI user UUIDs.
   */
  public Set<String> getMembers() {
    return members;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final VdiTeam vdiTeam = (VdiTeam) o;
    return Objects.equals(orgUuid, vdiTeam.orgUuid) && Objects
        .equals(uuid, vdiTeam.uuid) && Objects.equals(name, vdiTeam.name)
        && Objects.equals(members, vdiTeam.members);
  }

  @Override
  public int hashCode() {
    return Objects.hash(orgUuid, uuid, name, members);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("orgUuid", orgUuid)
        .add("uuid", uuid).add("name", name).add("members", members).toString();
  }

}
