/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification.types;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.notification.Alert;
import com.iland.core.api.notification.AlertDeliverySpec;
import com.iland.core.api.notification.AlertType;

/**
 * Object Storage Alert.
 *
 * @author <a href="mailto:spanyam@iland.com">Swetha Panyam</a>
 */
public class ObjectStorageAlert extends Alert {

  public static final String ENTITY_UUID = "entity_uuid";

  public static final String THRESHOLD = "threshold";

  public static final String BREACH = "breach";

  public static final String EQUALITY = "equality";

  @Expose
  @Since(1.0)
  @SerializedName("entity_uuid")
  private String entityUuid;

  @Expose
  @Since(1.0)
  @SerializedName("equality")
  private final ObjectStorageAlert.Equality equality;

  @Expose
  @Since(1.0)
  @SerializedName("alert_threshold")
  private final int threshold;

  @Expose
  @Since(1.0)
  @SerializedName("breach")
  private final int breach;

  public ObjectStorageAlert(final String uuid, final String username,
      final AlertDeliverySpec deliverySpec, final boolean enabled,
      final AlertType type, final String entityUuid, final Equality equality,
      final int threshold, final int breach) {
    super(uuid, username, deliverySpec, enabled, type);
    this.entityUuid = entityUuid;
    this.equality = equality;
    this.threshold = threshold;
    this.breach = breach;
  }

  public ObjectStorageAlert(final String uuid, final ObjectStorageAlert a,
      final AlertType alertType) {
    super(uuid, a.getUsername(), a.getDeliverySpec(), a.isEnabled(), alertType);
    this.entityUuid = a.getEntityUuid();
    this.equality = a.getEqualityRelation();
    this.threshold = a.getThreshold();
    this.breach = a.getBreach();
  }

  @Override
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Get the equality relation.
   *
   * @return {@link IntegrityAlert.EqualityRelation} equality relation
   */
  public ObjectStorageAlert.Equality getEqualityRelation() {
    return equality;
  }

  /**
   * Get the severity threshold.
   *
   * @return {@link IntegrityAlert.Severity} severity threshold
   */
  public int getThreshold() {
    return threshold;
  }

  /**
   * Get the breach period that is required in order for the alert to be
   * triggered.
   * <p>
   * i.e. the number of consecutive periods in which the threshold must be met
   * before alert is sent.
   *
   * @return breach
   */
  public int getBreach() {
    return breach;
  }

  /**
   * Valid Equality Relations for a Integrity Alert.
   */
  public enum Equality {

    @SerializedName(">=") GREATER_THAN_OR_EQUALS(">="),

    @SerializedName("<=") LESS_THAN_OR_EQUALS("<=");

    final String equalityRelation;

    Equality(final String equalityRelation) {
      this.equalityRelation = equalityRelation;
    }
  }
}
