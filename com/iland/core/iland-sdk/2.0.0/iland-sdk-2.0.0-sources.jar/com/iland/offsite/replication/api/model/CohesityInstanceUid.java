/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * {@link InstanceUid} is currently only used as the UID for a protection group run.
 */
public final class CohesityInstanceUid implements InstanceUid {

	private static final Pattern PATTERN = Pattern.compile("(\\d+):(\\d+)");

	private final EntityUid entityUid;

	private final long instanceId;

	private final long startTimeMicros;

	/**
	 * A static factory method for {@link CohesityInstanceUid}.
	 *
	 * @param entityUid an {@link EntityUid}
	 * @param value     a {@link String string} with two colon-separated values
	 * @return a {@link CohesityInstanceUid}
	 */
	public static CohesityInstanceUid of(final EntityUid entityUid,
		final String value) {
		final Matcher matcher = PATTERN.matcher(value);
		if (matcher.matches()) {
			final String instanceId = matcher.group(1);
			final String startTime = matcher.group(2);

			return new CohesityInstanceUid(entityUid,
				Long.parseLong(instanceId), Long.parseLong(startTime));
		}

		throw new IllegalArgumentException("invalid cohesity uid: " + value);
	}

	private CohesityInstanceUid(final EntityUid entityUid,
		final long instanceId, long startTimeMicros) {
		this.entityUid = entityUid;
		this.instanceId = instanceId;
		this.startTimeMicros = startTimeMicros;
	}

	@Override
	public Long clusterId() {
		return entityUid.clusterId();
	}

	@Override
	public Long clusterIncarnationId() {
		return entityUid.clusterIncarnationId();
	}

	@Override
	public long entityId() {
		return entityUid.entityId();
	}

	@Override
	public long instanceId() {
		return this.instanceId;
	}

	@Override
	public long startTimeMicros() {
		return this.startTimeMicros;
	}

	@Override
	public String toString() {
		return "%d:%d:%d:%d:%d".formatted(clusterId(), clusterIncarnationId(),
			entityId(), instanceId(), startTimeMicros());
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o)
			return true;
		if (!(o instanceof final CohesityInstanceUid that))
			return false;
		return instanceId == that.instanceId
			&& startTimeMicros == that.startTimeMicros && Objects.equals(
			entityUid, that.entityUid);
	}

	@Override
	public int hashCode() {
		return Objects.hash(entityUid, instanceId, startTimeMicros);
	}

}
