/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.nsx;

import java.time.Instant;
import java.util.Map;
import java.util.Objects;

import javax.annotation.Nonnull;

import com.iland.core.api.entity.AbstractEntity;
import com.iland.core.api.entity.Entity;
import com.iland.core.api.entity.EntityAncestorUtil;
import com.iland.core.api.entity.LocationEntity;
import com.iland.core.api.net.VcdEdge;
import com.iland.core.web.rest.shared.nsx.NsxEntityType;
import com.iland.vcloud.nsx.common.model.NsxVEdge;

/**
 * EdgeEntity.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class EdgeEntity extends AbstractEntity implements LocationEntity {

  private final String locationId;

  private final String companyId;

  private final String orgUuid;

  private final String vdcUuid;

  private Map<com.iland.common.entity.EntityType, String> ancestors;

  private final NsxVEdge edge;

  public EdgeEntity(final NsxVEdge nsxEdge, final VcdEdge vcdEdge) {
    super(String.format("%s:%s:%s", vcdEdge.getLocationId(),
        com.iland.core.api.vcd.EntityType.GATEWAY, nsxEdge.edgeUuid().uuid()), false, null,
        vcdEdge.getName(), Instant.now());
    this.locationId = vcdEdge.getLocationId();
    this.companyId = vcdEdge.getCompanyId();
    this.vdcUuid = String
        .format("%s:%s:%s", locationId, com.iland.core.api.vcd.EntityType.VDC,
            nsxEdge.vdcUuid());
    this.orgUuid = String
        .format("%s:%s:%s", locationId, com.iland.core.api.vcd.EntityType.ORG,
            vcdEdge.getOrgUuid());
    this.edge = nsxEdge;
  }

  public NsxVEdge getEdge() {
    return edge;
  }

  @Override
  public NsxEntityType getEntityType() {
    return NsxEntityType.IAAS_EDGE;
  }

  @Nonnull
  @Override
  public String getLocationId() {
    return locationId;
  }

  @Nonnull
  @Override
  public String getCompanyId() {
    return companyId;
  }

  public String getOrgUuid() {
    return orgUuid;
  }

  public String getVdcUuid() {
    return vdcUuid;
  }

  @Nonnull
  @Override
  public Map<com.iland.common.entity.EntityType, String> getAncestors() {
    if (ancestors == null || ancestors.isEmpty()) {
      ancestors = new EntityAncestorUtil.VdcAncestors(
              companyId, locationId, orgUuid, vdcUuid).buildAncestors();
    }

    return ancestors;
  }

  @Override
  public int entityHashCode() {
    return Objects.hash(super.entityHashCode(), locationId, companyId);
  }

  @Override
  public boolean entityEquals(final Entity other) {
    if (other == null || !NsxEntityType.IAAS_EDGE.equals(other.getEntityType())) {
      return false;
    }
    final EdgeEntity otherEdge = (EdgeEntity) other;
    return super.entityEquals(otherEdge) && Objects
        .equals(locationId, otherEdge.locationId) && Objects
        .equals(companyId, otherEdge.companyId);
  }

}
