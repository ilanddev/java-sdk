/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.io.Serializable;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.common.annotations.VisibleForTesting;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iland.common.utility.DateUtils;
import com.iland.core.api.entity.AbstractEntityRef;
import com.iland.core.api.entity.Entity;
import com.iland.core.api.entity.EntityType;
import com.iland.core.api.entity.EntityTypeMapper;
import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.util.TimeConstants;

/**
 * Bill.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class Bill implements Serializable {

  private static final Logger log = LoggerFactory.getLogger(Bill.class);

  public static final transient Bill INVALID_BILL =
      new Bill.Builder(-1, -1, -1, new Date(0), false, null)
          .build();

  private static final long serialVersionUID = 451813755507204636L;

  @Since(ApiVersion.ZERO_DOT_NINE)
  @Expose
  @SerializedName(BillingEntityField.YEAR)
  private int year;

  @Since(ApiVersion.ZERO_DOT_NINE)
  @Expose
  @SerializedName(BillingEntityField.MONTH)
  private int month;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.TOTAL)
  private double total;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.CPU)
  private final double cpu;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.MEMORY)
  private final double memory;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.BANDWIDTH)
  private final double bandwidth;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.ESTIMATE)
  private double estimate;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.CPU_USAGE)
  private final double cpuUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.CPU_BURST_USAGE)
  private final double cpuBurstUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.CPU_RES_USAGE)
  private final double cpuResUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.MEMORY_USAGE)
  private final double memoryUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.MEMORY_RES_USAGE)
  private final double memoryResUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.MEMORY_BURST_USAGE)
  private final double memoryBurstUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.BANDWIDTH_USAGE)
  private final double bandwidthUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.CPU_BURST)
  private final double cpuBurst;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.MEMORY_BURST)
  private final double memoryBurst;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.BANDWIDTH_BURST)
  private final double bandwidthBurst;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.CURRENCY_CODE)
  private String currencyCode;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.TIME)
  private final Date timestamp;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.TEST_DRIVE)
  private final boolean testDrive;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.BILLING_MODEL_TYPE)
  private BillingModelType billingModelType;

  /**
   * Bill line items - represents fixed cost types of items (e.g. software
   * licenses, ip addresses, or hardware such as an ASA).
   */
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.LINE_ITEMS)
  private List<BillLineItem> lineItems;

  /**
   * Discount applied to this bill.
   */
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.DISCOUNT)
  private final double discount;

  /**
   * Total disk usage across all tiers of storage.
   */
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.DISK_USAGE)
  private final double diskUsage;

  /**
   * Disk total cost across all storage tiers.
   */
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.DISK)
  private final double disk;

  /**
   * Disk burst total usage across all storage tiers.
   */
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.DISK_BURST_USAGE)
  private double diskBurstUsage;

  /**
   * Disk burst total usage across all storage tiers.
   */
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.DISK_BURST)
  private double diskBurstCost;

  // HDD tier

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.HDD_USAGE)
  private final double hddUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.HDD_COST)
  private final double hddCost;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.HDD_BURST_USAGE)
  private final double hddBurstUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.HDD_BURST_COST)
  private final double hddBurstCost;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.HDD_RES_COST)
  private final double hddResCost;

  // derived from total hdd usage - hdd burst usage
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.HDD_RES_USAGE)
  private final double hddResUsage;

  // SSD tier

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.SSD_USAGE)
  private final double ssdUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.SSD_COST)
  private final double ssdCost;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.SSD_BURST_USAGE)
  private final double ssdBurstUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.SSD_BURST_COST)
  private final double ssdBurstCost;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.SSD_RES_COST)
  private final double ssdResCost;

  // derived from total ssd usage - ssd burst usage
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.SSD_RES_USAGE)
  private final double ssdResUsage;

  // Archive tier

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.ARCHIVE_USAGE)
  private final double archiveUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.ARCHIVE_COST)
  private final double archiveCost;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.ARCHIVE_BURST_USAGE)
  private final double archiveBurstUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.ARCHIVE_BURST_COST)
  private final double archiveBurstCost;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.ARCHIVE_RES_COST)
  private final double archiveResCost;

  // derived from total archive usage - archive burst usage
  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.ARCHIVE_RES_USAGE)
  private final double archiveResUsage;

  // Zerto tiers

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.ZERTO_ARCHIVE_USAGE)
  private final double zertoArchiveUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.ZERTO_ARCHIVE_COST)
  private final double zertoArchiveCost;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.ZERTO_ADVANCED_USAGE)
  private final double zertoAdvancedUsage;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.ZERTO_ADVANCED_COST)
  private final double zertoAdvancedCost;

  @Since(ApiVersion.ZERO_DOT_FIVE)
  @Expose
  @SerializedName(BillingEntityField.ENTITY_UUID)
  private String entityUuid;

  @Since(ApiVersion.ZERO_DOT_FIVE)
  @Expose
  @SerializedName(BillingEntityField.ENTITY_TYPE)
  private EntityType entityType;

  @Since(ApiVersion.ZERO_DOT_FIVE)
  @Expose
  @SerializedName(BillingEntityField.ENTITY_NAME)
  private String entityName;

  @Since(ApiVersion.ZERO_DOT_FIVE)
  @Expose
  @SerializedName(BillingEntityField.BANDWIDTH_RES_USAGE)
  private final double bandwidthResUsage;

  @Since(ApiVersion.ZERO_DOT_FIVE)
  @Expose
  @SerializedName(BillingEntityField.BANDWIDTH_RES_COST)
  private final double bandwidthResCost;

  @Since(ApiVersion.ZERO_DOT_FIVE)
  @Expose
  @SerializedName(BillingEntityField.BANDWIDTH_BURST_USAGE)
  private final double bandwidthBurstUsage;


  public static class Builder {

    // required
    private final double cpu;

    private final double memory;

    private final double bandwidth;

    private final Date timestamp;

    private final boolean testDrive;

    private final BillingModelType billingModelType;

    // optional
    private double cpuUsage = 0.0;

    private double cpuBurstUsage = 0.0;

    private double memoryUsage = 0.0;

    private double memoryBurstUsage = 0.0;

    private double bandwidthUsage = 0.0;

    private double cpuBurst = 0.0;

    private double memoryBurst = 0.0;

    private double bandwidthBurst = 0.0;

    private String currencyCode = "USD";

    private List<BillLineItem> lineItems;

    private double discount;

    // HDD tier

    private double hddUsage = 0;

    private double hddBurstUsage = 0;

    private double hddBurstCost = 0;

    private double hddResCost = 0;

    // SSD tier

    private double ssdUsage = 0;

    private double ssdBurstUsage = 0;

    private double ssdBurstCost = 0;

    private double ssdResCost = 0;

    // Archive tier

    private double archiveUsage = 0;

    private double archiveBurstUsage = 0;

    private double archiveBurstCost = 0;

    private double archiveResCost = 0;

    // Zerto tiers

    private double zertoArchiveCost = 0;

    private double zertoAdvancedCost = 0;

    private double zertoArchiveUsage = 0;

    private double zertoAdvancedUsage = 0;

    private double estimate = 0;

    private DateUtils billingPeriod = null;

    private Bill previousHourBillForEstimate = null;

    private String entityName = null;

    private String entityUuid = null;

    private EntityType entityType = null;

    private double bandwidthResUsage = 0.0;

    private double bandwidthResCost = 0.0;

    private double bandwidthBurstUsage = 0.0;

    public Builder(final Bill other) {
      this.cpu = other.cpu;
      this.memory = other.memory;
      this.bandwidth = other.bandwidth;
      this.bandwidthResUsage = other.bandwidthResUsage;
      this.bandwidthResCost = other.bandwidthResCost;
      this.bandwidthBurstUsage = other.bandwidthBurstUsage;
      this.timestamp = (Date) other.timestamp.clone();
      this.testDrive = other.testDrive;
      this.billingModelType = other.billingModelType;
      this.cpuUsage = other.cpuUsage;
      this.cpuBurstUsage = other.cpuBurstUsage;
      this.memoryUsage = other.memoryUsage;
      this.memoryBurstUsage = other.memoryBurstUsage;
      this.bandwidthUsage = other.bandwidthUsage;
      this.cpuBurst = other.cpuBurst;
      this.memoryBurst = other.memoryBurst;
      this.bandwidthBurst = other.bandwidthBurst;
      this.currencyCode = other.currencyCode;
      this.lineItems = other.lineItems;
      this.discount = other.discount;
      this.hddUsage = other.hddUsage;
      this.hddBurstUsage = other.hddBurstUsage;
      this.hddBurstCost = other.hddBurstCost;
      this.hddResCost = other.hddResCost;
      this.ssdUsage = other.ssdUsage;
      this.ssdBurstUsage = other.ssdBurstUsage;
      this.ssdBurstCost = other.ssdBurstCost;
      this.ssdResCost = other.ssdResCost;
      this.archiveUsage = other.archiveUsage;
      this.archiveBurstUsage = other.archiveBurstUsage;
      this.archiveBurstCost = other.archiveBurstCost;
      this.archiveResCost = other.archiveResCost;
      this.zertoArchiveCost = other.zertoArchiveCost;
      this.zertoAdvancedCost = other.zertoAdvancedCost;
      this.zertoArchiveUsage = other.zertoArchiveUsage;
      this.zertoAdvancedUsage = other.zertoAdvancedUsage;
      this.estimate = other.estimate;
      this.entityName = other.entityName;
      this.entityUuid = other.entityUuid;
      this.entityType = other.entityType;
    }

    public Builder(final double cpu, final double memory,
        final double bandwidth, final Date timestamp, final boolean testDrive,
        final BillingModelType billingModelType) {
      this.cpu = roundToFiveDigits(cpu);
      this.memory = roundToFiveDigits(memory);
      this.bandwidth = roundToFiveDigits(bandwidth);
      if (timestamp == null) {
        this.timestamp = new Date(0);
      } else {
        this.timestamp = timestamp;
      }
      this.testDrive = testDrive;
      this.billingModelType = billingModelType;
    }

    public Builder estimate(final DateUtils p,
        final Bill previousHourBillForEstimate) {
      this.billingPeriod = p;
      this.previousHourBillForEstimate = previousHourBillForEstimate;
      return this;
    }

    public Builder estimate(final double estimate) {
      this.estimate = estimate;
      return this;
    }

    public Builder cpuUsage(final double value) {
      cpuUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder cpuBurstUsage(final double value) {
      cpuBurstUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder memoryUsage(final double value) {
      memoryUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder memoryBurstUsage(final double value) {
      memoryBurstUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder bandwidthUsage(final double value) {
      bandwidthUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder bandwidthResUsage(final double value) {
      bandwidthResUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder bandwidthResCost(final double value) {
      bandwidthResCost = roundToFiveDigits(value);
      return this;
    }

    public Builder cpuBurst(final double value) {
      cpuBurst = roundToFiveDigits(value);
      return this;
    }

    public Builder memoryBurst(final double value) {
      memoryBurst = roundToFiveDigits(value);
      return this;
    }

    public Builder bandwidthBurst(final double value) {
      bandwidthBurst = roundToFiveDigits(value);
      return this;
    }

    public Builder currencyCode(final String value) {
      currencyCode = value;
      return this;
    }

    public Builder lineItems(final List<BillLineItem> value) {
      lineItems = value;
      return this;
    }

    public Builder discount(final double value) {
      discount = roundToFiveDigits(value);
      return this;
    }

    // HDD tiers.

    public Builder hddUsage(final double value) {
      hddUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder hddBurstUsage(final double value) {
      hddBurstUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder hddBurstCost(final double value) {
      hddBurstCost = roundToFiveDigits(value);
      return this;
    }

    public Builder hddResCost(final double value) {
      hddResCost = roundToFiveDigits(value);
      return this;
    }

    // SSD tiers

    public Builder ssdUsage(final double value) {
      ssdUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder ssdBurstUsage(final double value) {
      ssdBurstUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder ssdBurstCost(final double value) {
      ssdBurstCost = roundToFiveDigits(value);
      return this;
    }

    public Builder ssdResCost(final double value) {
      ssdResCost = roundToFiveDigits(value);
      return this;
    }

    // Archive tiers

    public Builder archiveUsage(final double value) {
      archiveUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder archiveBurstUsage(final double value) {
      archiveBurstUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder archiveBurstCost(final double value) {
      archiveBurstCost = roundToFiveDigits(value);
      return this;
    }

    public Builder archiveResCost(final double value) {
      archiveResCost = roundToFiveDigits(value);
      return this;
    }

    // Zerto tiers

    public Builder zertoArchiveCost(final double value) {
      zertoArchiveCost = roundToFiveDigits(value);
      return this;
    }

    public Builder zertoAdvancedCost(final double value) {
      zertoAdvancedCost = roundToFiveDigits(value);
      return this;
    }

    public Builder zertoArchiveUsage(final double value) {
      zertoArchiveUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder zertoAdvancedUsage(final double value) {
      zertoAdvancedUsage = roundToFiveDigits(value);
      return this;
    }

    public Builder entity(final AbstractEntityRef value) {
      entityName = value.getName();
      entityUuid = value.getUuid();
      entityType =
          EntityTypeMapper.toOldCompanyEntityType(value.getEntityType());
      return this;
    }

    private static final ThreadLocal<DecimalFormat> DF =
        new ThreadLocal<DecimalFormat>() {
          @Override
          protected DecimalFormat initialValue() {
            final DecimalFormat df = new DecimalFormat("#.#####");
            df.setRoundingMode(RoundingMode.HALF_UP);
            df.setMinimumIntegerDigits(0);
            df.setMaximumFractionDigits(5);
            df.setMinimumFractionDigits(5);
            return df;
          }
        };

    /**
     * Round a number to five decimal digits.
     *
     * @param number number to be rounded
     * @return rounded number
     */
    static double roundToFiveDigits(final double number) {
      return Double.parseDouble(DF.get().format(number));
    }

    public Bill build() {
      return new Bill(this);
    }
  }

  private Bill(final Builder builder) {
    cpu = builder.cpu;
    memory = builder.memory;
    bandwidth = builder.bandwidth;
    cpuUsage = builder.cpuUsage;
    cpuBurstUsage = builder.cpuBurstUsage;
    cpuResUsage = cpuUsage - cpuBurstUsage;
    memoryUsage = builder.memoryUsage;
    memoryBurstUsage = builder.memoryBurstUsage;
    memoryResUsage = memoryUsage - memoryBurstUsage;
    bandwidthUsage = builder.bandwidthUsage;
    cpuBurst = builder.cpuBurst;
    memoryBurst = builder.memoryBurst;
    bandwidthBurst = builder.bandwidthBurst;
    bandwidthResUsage = builder.bandwidthResUsage;
    bandwidthResCost = builder.bandwidthResCost;
    bandwidthBurstUsage = (bandwidthUsage - bandwidthResUsage) < 0 ?
        0 :
        (bandwidthUsage - bandwidthResUsage);
    timestamp = builder.timestamp;
    final LocalDateTime ldt = DateUtils.toLocalDateTime(timestamp);
    year = ldt.getYear();
    month = ldt.getMonthValue();
    currencyCode = builder.currencyCode;
    testDrive = builder.testDrive;
    billingModelType = builder.billingModelType;
    lineItems = builder.lineItems;
    discount = builder.discount;
    // HDD tier
    hddBurstUsage = builder.hddBurstUsage;
    hddBurstCost = builder.hddBurstCost;
    hddResCost = builder.hddResCost;
    hddUsage = builder.hddUsage;
    hddResUsage = hddUsage - hddBurstUsage;
    hddCost = hddBurstCost + hddResCost;
    // SSD tier
    ssdBurstUsage = builder.ssdBurstUsage;
    ssdBurstCost = builder.ssdBurstCost;
    ssdResCost = builder.ssdResCost;
    ssdUsage = builder.ssdUsage;
    ssdResUsage = ssdUsage - ssdBurstUsage;
    ssdCost = ssdResCost + ssdBurstCost;
    // Archive tier
    archiveBurstUsage = builder.archiveBurstUsage;
    archiveBurstCost = builder.archiveBurstCost;
    archiveResCost = builder.archiveResCost;
    archiveUsage = builder.archiveUsage;
    archiveResUsage = archiveUsage - archiveBurstUsage;
    archiveCost = archiveResCost + archiveBurstCost;
    // Zerto tiers
    zertoAdvancedCost = builder.zertoAdvancedCost;
    zertoArchiveCost = builder.zertoArchiveCost;
    zertoAdvancedUsage = builder.zertoAdvancedUsage;
    zertoArchiveUsage = builder.zertoArchiveUsage;

    entityUuid = builder.entityUuid;
    entityName = builder.entityName;
    entityType = builder.entityType;

    // Derive the total disk cost and usage numbers from the sub tiers
    disk =
        hddCost + ssdCost + archiveCost + zertoAdvancedCost + zertoArchiveCost;
    diskUsage = hddUsage + ssdUsage + archiveUsage + zertoAdvancedUsage
        + zertoArchiveUsage;
    diskBurstUsage = hddBurstUsage + ssdBurstUsage + archiveBurstUsage;
    diskBurstCost = hddBurstCost + ssdBurstCost + archiveBurstCost;
    total = cpu + memory + bandwidth + hddCost + ssdCost + archiveCost
        + zertoAdvancedCost + zertoArchiveCost + getTotalLineItemCost();

    if (total < 0) {
      log.warn(
          "Ahem...someone slept through an important Dreamforce talk and now we have a negative bill.  Fixing total to 0.");
      this.total = 0;
    } else {
      this.total = Bill.Builder.roundToFiveDigits(total);
    }
    if (estimate == 0) {
      if (builder.billingPeriod != null
          && builder.previousHourBillForEstimate != null) {
        estimate = getMonthEstimate(builder.billingPeriod, total,
            builder.previousHourBillForEstimate.getTotal());
      } else {
        estimate = total;
      }
    }
  }

  /**
   * Get the total cost of line items on the given bill.
   *
   * @return total line item cost
   */
  private double getTotalLineItemCost() {
    double total = 0;
    if (lineItems != null) {
      for (final BillLineItem bli : lineItems) {
        total += bli.getCost() * bli.getQuantity();
      }
    }
    return Builder.roundToFiveDigits(total);
  }

  /**
   * Get the year of the invoice period.
   *
   * @return year
   */
  public int getYear() {
    return year;
  }

  /**
   * Get the month of the invoice period.
   *
   * @return month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Return bill total.
   *
   * @return bill total
   */
  public double getTotal() {
    return Builder.roundToFiveDigits(total);
  }

  /**
   * Return cpu cost.
   *
   * @return cpu cost.
   */
  public double getCpu() {
    return Builder.roundToFiveDigits(cpu);
  }

  /**
   * Return memory cost.
   *
   * @return memory cost.
   */
  public double getMemory() {
    return Builder.roundToFiveDigits(memory);
  }

  /**
   * Get CPU burst usage.
   *
   * @return cpu burst usage
   */
  public double getCpuBurstUsage() {
    return cpuBurstUsage;
  }

  /**
   * Get CPU reserved usage.
   *
   * @return cpu reserved usage
   */
  public double getCpuResUsage() {
    return cpuResUsage;
  }

  /**
   * Get memory reserved usage.
   *
   * @return memory reserved usage
   */
  public double getMemoryResUsage() {
    return memoryResUsage;
  }

  /**
   * Get memory burst usage.
   *
   * @return memory burst usage
   */
  public double getMemoryBurstUsage() {
    return memoryBurstUsage;
  }

  /**
   * Return disk cost.
   *
   * @return disk cost
   */
  public double getDisk() {
    return Builder.roundToFiveDigits(disk);
  }

  /**
   * Return bandwidth cost.
   *
   * @return bandwidth cost
   */
  public double getBandwidth() {
    return Builder.roundToFiveDigits(bandwidth);
  }

  /**
   * Return bandwidth reserved usage.
   *
   * @return bandwidth reserved usage
   */
  public double getBandwidthResUsage() {
    return Builder.roundToFiveDigits(bandwidthResUsage);
  }

  /**
   * Return bandwidth reserved cost.
   *
   * @return bandwidth reserved cost
   */
  public double getBandwidthResCost() {
    return Builder.roundToFiveDigits(bandwidthResCost);
  }

  /**
   * Return bandwidth burst usage.
   *
   * @return bandwidth burst usage
   */
  public double getBandwidthBurstUsage() {
    return Builder.roundToFiveDigits(bandwidthBurstUsage);
  }

  /**
   * Return month estimate.
   *
   * @return month estimate cost
   */
  public double getEstimate() {
    return Builder.roundToFiveDigits(estimate);
  }

  /**
   * Return cpu usage.
   *
   * @return cpu usage
   */
  public double getCpuUsage() {
    return Builder.roundToFiveDigits(cpuUsage);
  }

  /**
   * Return memory usage.
   *
   * @return memory usage
   */
  public double getMemoryUsage() {
    return Builder.roundToFiveDigits(memoryUsage);
  }

  /**
   * Return disk usage.
   *
   * @return disk usage
   */
  public double getDiskUsage() {
    return Builder.roundToFiveDigits(diskUsage);
  }

  /**
   * Return bandwidth usage.
   *
   * @return bandwidth usage
   */
  public double getBandwidthUsage() {
    return Builder.roundToFiveDigits(bandwidthUsage);
  }

  /**
   * Return cpu burst cost.
   *
   * @return cpu burst cost
   */
  public double getCpuBurst() {
    return Builder.roundToFiveDigits(cpuBurst);
  }

  /**
   * Return memory burst cost.
   *
   * @return memory burst cost
   */
  public double getMemoryBurst() {
    return Builder.roundToFiveDigits(memoryBurst);
  }

  /**
   * Return bandwidth burst cost.
   *
   * @return bandwidth burst cost
   */
  public double getBandwidthBurst() {
    return Builder.roundToFiveDigits(bandwidthBurst);
  }

  /**
   * Return the bill date.
   *
   * @return an {@link Date} instance
   */
  public Date getTimestamp() {
    return timestamp;
  }

  /**
   * Return the bill currency code.
   *
   * @return an {@link String} instance
   */
  public String getCurrencyCode() {
    return currencyCode;
  }

  /**
   * Set the bill's currency code.
   *
   * @param currencyCode {@link String} currency code
   */
  public void setCurrencyCode(final String currencyCode) {
    this.currencyCode = currencyCode;
  }

  /**
   * Return whether the bill represents a test drive.
   *
   * @return an {@link String} instance
   */
  public boolean isTestDrive() {
    return testDrive;
  }

  /**
   * Returns the billing model type.
   *
   * @return one of {@link BillingModelType}
   */
  public BillingModelType getBillingModelType() {
    return billingModelType;
  }

  /**
   * Sets the billing model type.
   *
   * @param billingModelType: one of {@link BillingModelType}
   */
  public void setBillingModelType(final BillingModelType billingModelType) {
    this.billingModelType = billingModelType;
  }

  /**
   * Return a list of line items associated with this bill. Bill line items -
   * represents fixed cost types of items (e.g. software licenses, ip addresses,
   * or hardware such as an ASA).
   *
   * @return {@link List} of {@link BillLineItem} instances
   */
  public List<BillLineItem> getLineItems() {
    return lineItems;
  }

  /**
   * Return the applied discount associated with this bill.
   *
   * @return bill applied discount
   */
  public double getDiscount() {
    return discount;
  }

  /**
   * Get the SSD based disk usage for this bill.
   *
   * @return ssd usage
   */
  public double getSsdUsage() {
    return Builder.roundToFiveDigits(ssdUsage);
  }

  /**
   * Get the HDD based disk usage for this bill.
   *
   * @return hdd usage
   */
  public double getHddUsage() {
    return Builder.roundToFiveDigits(hddUsage);
  }

  /**
   * Get the SSD based disk cost for this bill.
   *
   * @return ssd cost
   */
  public double getSsdCost() {
    return Builder.roundToFiveDigits(ssdCost);
  }

  /**
   * Get the HDD based disk cost for this bill.
   *
   * @return hdd cost
   */
  public double getHddCost() {
    return Builder.roundToFiveDigits(hddCost);
  }

  /**
   * Get the Archive based disk usage for this bill.
   *
   * @return archive usage
   */
  public double getArchiveUsage() {
    return archiveUsage;
  }

  /**
   * Get the Archive based disk cost for this bill.
   *
   * @return archive cost
   */
  public double getArchiveCost() {
    return archiveCost;
  }

  /**
   * Get the Zerto archive usage.
   *
   * @return zerto archive usage
   */
  public double getZertoArchiveUsage() {
    return zertoArchiveUsage;
  }

  /**
   * Get the zerto advanced usage.
   *
   * @return zerto advanced usage
   */
  public double getZertoAdvancedUsage() {
    return zertoAdvancedUsage;
  }

  /**
   * Get the zerto archive cost.
   *
   * @return zerto archive cost
   */
  public double getZertoArchiveCost() {
    return zertoArchiveCost;
  }

  /**
   * Get the zerto advanced cost.
   *
   * @return zerto advanced cost
   */
  public double getZertoAdvancedCost() {
    return zertoAdvancedCost;
  }

  /**
   * Set the total for the bill.
   *
   * @param total total cost
   */
  public void setTotal(final double total) {
    this.total = total;
  }

  /**
   * Set the year of the bill.
   *
   * @param year bill year
   */
  public void setYear(final int year) {
    this.year = year;
  }

  /**
   * Set the disk burst cost.
   *
   * @param diskBurstCost disk burst cost
   */
  public void setDiskBurstCost(final double diskBurstCost) {
    this.diskBurstCost = diskBurstCost;
  }

  /**
   * Set the disk burst usage.
   *
   * @param diskBurstUsage disk burst usage
   */
  public void setDiskBurstUsage(final double diskBurstUsage) {
    this.diskBurstUsage = diskBurstUsage;
  }

  /**
   * Set the month of the bill.
   *
   * @param month bill month
   */
  public void setMonth(final int month) {
    this.month = month;
  }

  /**
   * Set the list of line items for the bill.
   *
   * @param lineItems {@link BillLineItem} bill line items
   */
  public void setLineItems(final List<BillLineItem> lineItems) {
    this.lineItems = lineItems;
  }

  /**
   * Get an estimate of current month usage based on current month usage so far
   * and the usage in previous hour.
   *
   * @param currentMonth current usage for month to extrapolate
   * @param previousHour previous hour usage
   * @return estimate of current month usage
   */
  @VisibleForTesting
  static double getMonthEstimate(final DateUtils p,
      final double currentMonth, final double previousHour) {
    final Duration remainingInterval =
        Duration.between(p.getNow(), p.getMonthEnd());
    // Linearly extrapolate remainder of month from previous hour
    final double remainingEstimate = previousHour * remainingInterval.toMillis()
        / TimeConstants.ONE_HOUR_IN_MILLIS;
    return currentMonth + remainingEstimate;
  }

  /**
   * Get burst usage for hdd storage.
   *
   * @return hdd storage burst usage
   */
  public double getHddBurstUsage() {
    return hddBurstUsage;
  }

  /**
   * Get burst usage for SSD storage.
   *
   * @return SSD storage burst usage
   */
  public double getSsdBurstUsage() {
    return ssdBurstUsage;
  }

  /**
   * Get burst usage for archive storage.
   *
   * @return archive storage burst usage
   */
  public double getArchiveBurstUsage() {
    return archiveBurstUsage;
  }

  /**
   * Get HDD storage burst cost.
   *
   * @return hdd storage burst cost
   */
  public double getHddBurstCost() {
    return hddBurstCost;
  }

  /**
   * Get SSD storage burst cost.
   *
   * @return SSD storage burst cost
   */
  public double getSsdBurstCost() {
    return ssdBurstCost;
  }

  /**
   * Get archive storage burst cost.
   *
   * @return archive storage burst cost
   */
  public double getArchiveBurstCost() {
    return archiveBurstCost;
  }

  /**
   * Get disk burst cost.
   *
   * @return disk burst cost
   */
  public double getDiskBurstCost() {
    return diskBurstCost;
  }

  /**
   * Get total disk burst usage.
   *
   * @return total disk burst usage
   */
  public double getDiskBurstUsage() {
    return diskBurstUsage;
  }

  /**
   * Get hdd tier reserved cost.
   *
   * @return hdd reserved cost
   */
  public double getHddResCost() {
    return hddResCost;
  }

  /**
   * Get SSD tier reserved cost.
   *
   * @return ssd reserved cost
   */
  public double getSsdResCost() {
    return ssdResCost;
  }

  /**
   * Get archive tier reserved cost.
   *
   * @return archive reserved cost
   */
  public double getArchiveResCost() {
    return archiveResCost;
  }

  /**
   * Get hdd tier reserved usage.
   *
   * @return hdd reserved usage
   */
  public double getHddResUsage() {
    return hddResUsage;
  }

  /**
   * Get the ssd tier reserved usage.
   *
   * @return ssd reserved usage
   */
  public double getSsdResUsage() {
    return ssdResUsage;
  }

  /**
   * Get the archive tier reserved usage.
   *
   * @return archive reserved usage
   */
  public double getArchiveResUsage() {
    return archiveResUsage;
  }

  /**
   * Get the associated entity uuid.
   *
   * @return {@link String} entity uuid
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Get the associated entity type.
   *
   * @return {@link EntityType} the associated entity type
   */
  public EntityType getEntityType() {
    return entityType;
  }

  /**
   * Get the associated entity name.
   *
   * @return {@link String} the entity name
   */
  public String getEntityName() {
    return entityName;
  }

  /**
   * Set the entity associated with the bill.
   *
   * @param entity {@link Entity} entity
   */
  public void setEntity(final AbstractEntityRef entity) {
    this.entityUuid = entity.getUuid();
    this.entityName = entity.getName();
    this.entityType =
        EntityTypeMapper.toOldCompanyEntityType(entity.getEntityType());
  }

  /**
   * Aggregate bills into one bill.
   *
   * @param bills {@link Bill} array of bills
   * @return {@link Bill} aggregated bill
   */
  static Bill aggregateBills(final Bill... bills) {
    double cpu = 0;
    double memory = 0;
    double bandwidth = 0;
    double estimate = 0;
    double cpuUsage = 0;
    double cpuBurstUsage = 0;
    double memoryUsage = 0;
    double memoryBurstUsage = 0;
    double bandwidthUsage = 0;
    double cpuBurst = 0;
    double memoryBurst = 0;
    double bandwidthBurst = 0;
    String currencyCode = null;
    Date timestamp = null;
    boolean testDrive = false;

    final List<BillLineItem> lineItems = new ArrayList<>();
    double discount = 0;
    double hddUsage = 0;
    double hddBurstUsage = 0;
    double hddBurstCost = 0;
    double hddResCost = 0;
    double ssdUsage = 0;
    double ssdBurstUsage = 0;
    double ssdBurstCost = 0;
    double ssdResCost = 0;
    double archiveUsage = 0;
    double archiveBurstUsage = 0;
    double archiveBurstCost = 0;
    double archiveResCost = 0;
    double zertoArchiveUsage = 0;
    double zertoArchiveCost = 0;
    double zertoAdvancedUsage = 0;
    double zertoAdvancedCost = 0;

    // billing model types
    BillingModelType billingModelType = BillingModelType.LEGACY;
    boolean hasLegacy = false;
    boolean hasCurrent = false;
    boolean hasUnsupported = false;
    boolean hasMixed = false;

    for (final Bill b : bills) {
      if (b == null || b == INVALID_BILL) {
        continue;
      }
      estimate += b.getEstimate();
      cpu += b.getCpu();
      memory += b.getMemory();
      bandwidth += b.getBandwidth();
      estimate += b.getEstimate();
      cpuUsage += b.getCpuUsage();
      cpuBurstUsage += b.getCpuBurstUsage();
      memoryUsage += b.getMemoryUsage();
      memoryBurstUsage += b.getMemoryBurstUsage();
      bandwidthUsage += b.getBandwidthUsage();
      cpuBurst += b.getCpuBurst();
      memoryBurst += b.getMemoryBurst();
      bandwidthBurst += b.getBandwidthBurst();
      if (currencyCode == null) {
        currencyCode = b.getCurrencyCode();
      }
      if (timestamp == null) {
        timestamp = b.getTimestamp();
      }
      if (b.isTestDrive()) {
        testDrive = b.isTestDrive();
      }

      // Billing model type
      if (b.getBillingModelType() != null) {
        switch (b.billingModelType) {
          case CURRENT:
            hasCurrent = true;
            break;
          case LEGACY:
            hasLegacy = true;
            break;
          case MIXED:
            hasMixed = true;
            break;
          case UNSUPPORTED:
            hasUnsupported = true;
            break;
        }
        if (hasUnsupported) {
          billingModelType = BillingModelType.UNSUPPORTED;
        } else if (hasMixed || (hasCurrent && hasLegacy)) {
          billingModelType = BillingModelType.MIXED;
        } else if (hasCurrent && !hasLegacy) {
          billingModelType = BillingModelType.CURRENT;
        } else {
          billingModelType = BillingModelType.LEGACY;
        }
      } else {
        billingModelType = BillingModelType.LEGACY;
      }

      if (b.getLineItems() != null) {
        lineItems.addAll(b.getLineItems());
      }
      discount += b.getDiscount();
      hddUsage += b.getHddUsage();
      hddBurstUsage += b.getHddBurstUsage();
      hddBurstCost += b.getHddBurstCost();
      hddResCost += b.getHddResCost();
      ssdUsage += b.getSsdUsage();
      ssdBurstUsage += b.getSsdBurstUsage();
      ssdBurstCost += b.getSsdBurstCost();
      ssdResCost += b.getSsdResCost();
      archiveUsage += b.getArchiveUsage();
      archiveBurstUsage += b.getArchiveBurstUsage();
      archiveBurstCost += b.getArchiveBurstCost();
      archiveResCost += b.getArchiveResCost();
      zertoArchiveUsage += b.getZertoArchiveUsage();
      zertoArchiveCost += b.getZertoArchiveCost();
      zertoAdvancedUsage += b.getZertoAdvancedUsage();
      zertoAdvancedCost += b.getZertoAdvancedCost();
    }
    return new Builder(cpu, memory, bandwidth, timestamp, testDrive,
        billingModelType).cpuUsage(cpuUsage).memoryUsage(memoryUsage)
        .bandwidthUsage(bandwidthUsage).cpuBurst(cpuBurst)
        .cpuBurstUsage(cpuBurstUsage).memoryBurst(memoryBurst)
        .memoryBurstUsage(memoryBurstUsage).bandwidthBurst(bandwidthBurst)
        .currencyCode(currencyCode).lineItems(lineItems).discount(discount)
        .hddUsage(hddUsage).hddBurstCost(hddBurstCost)
        .hddBurstUsage(hddBurstUsage).hddResCost(hddResCost).ssdUsage(ssdUsage)
        .ssdBurstUsage(ssdBurstUsage).ssdBurstCost(ssdBurstCost)
        .ssdResCost(ssdResCost).archiveUsage(archiveUsage)
        .archiveBurstUsage(archiveBurstUsage).archiveBurstCost(archiveBurstCost)
        .archiveResCost(archiveResCost).zertoAdvancedCost(zertoAdvancedCost)
        .zertoAdvancedUsage(zertoAdvancedUsage)
        .zertoArchiveCost(zertoArchiveCost).zertoArchiveUsage(zertoArchiveUsage)
        .estimate(estimate).build();
  }

}
