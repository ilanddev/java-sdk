/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import com.google.common.base.MoreObjects;
import com.google.common.primitives.Longs;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link RunStats}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableRunStats.builder()}.
 */
@Generated(from = "RunStats", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableRunStats implements RunStats {
  private final long cancelled;
  private final long failed;
  private final long ongoing;
  private final long successful;
  private transient final long total;
  private final long slaViolations;

  private ImmutableRunStats(long cancelled, long failed, long ongoing, long successful, long slaViolations) {
    this.cancelled = cancelled;
    this.failed = failed;
    this.ongoing = ongoing;
    this.successful = successful;
    this.slaViolations = slaViolations;
    this.total = RunStats.super.total();
  }

  /**
   * @return The value of the {@code cancelled} attribute
   */
  @Override
  public long cancelled() {
    return cancelled;
  }

  /**
   * @return The value of the {@code failed} attribute
   */
  @Override
  public long failed() {
    return failed;
  }

  /**
   * @return The value of the {@code ongoing} attribute
   */
  @Override
  public long ongoing() {
    return ongoing;
  }

  /**
   * @return The value of the {@code successful} attribute
   */
  @Override
  public long successful() {
    return successful;
  }

  /**
   * @return The computed-at-construction value of the {@code total} attribute
   */
  @Override
  public long total() {
    return total;
  }

  /**
   * @return The value of the {@code slaViolations} attribute
   */
  @Override
  public long slaViolations() {
    return slaViolations;
  }

  /**
   * Copy the current immutable object by setting a value for the {@link RunStats#cancelled() cancelled} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for cancelled
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableRunStats withCancelled(long value) {
    if (this.cancelled == value) return this;
    return new ImmutableRunStats(value, this.failed, this.ongoing, this.successful, this.slaViolations);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link RunStats#failed() failed} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for failed
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableRunStats withFailed(long value) {
    if (this.failed == value) return this;
    return new ImmutableRunStats(this.cancelled, value, this.ongoing, this.successful, this.slaViolations);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link RunStats#ongoing() ongoing} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for ongoing
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableRunStats withOngoing(long value) {
    if (this.ongoing == value) return this;
    return new ImmutableRunStats(this.cancelled, this.failed, value, this.successful, this.slaViolations);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link RunStats#successful() successful} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for successful
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableRunStats withSuccessful(long value) {
    if (this.successful == value) return this;
    return new ImmutableRunStats(this.cancelled, this.failed, this.ongoing, value, this.slaViolations);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link RunStats#slaViolations() slaViolations} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for slaViolations
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableRunStats withSlaViolations(long value) {
    if (this.slaViolations == value) return this;
    return new ImmutableRunStats(this.cancelled, this.failed, this.ongoing, this.successful, value);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableRunStats} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableRunStats
        && equalsByValue((ImmutableRunStats) another);
  }

  private boolean equalsByValue(ImmutableRunStats another) {
    return cancelled == another.cancelled
        && failed == another.failed
        && ongoing == another.ongoing
        && successful == another.successful
        && total == another.total
        && slaViolations == another.slaViolations;
  }

  /**
   * Computes a hash code from attributes: {@code cancelled}, {@code failed}, {@code ongoing}, {@code successful}, {@code total}, {@code slaViolations}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Longs.hashCode(cancelled);
    h += (h << 5) + Longs.hashCode(failed);
    h += (h << 5) + Longs.hashCode(ongoing);
    h += (h << 5) + Longs.hashCode(successful);
    h += (h << 5) + Longs.hashCode(total);
    h += (h << 5) + Longs.hashCode(slaViolations);
    return h;
  }

  /**
   * Prints the immutable value {@code RunStats} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("RunStats")
        .omitNullValues()
        .add("cancelled", cancelled)
        .add("failed", failed)
        .add("ongoing", ongoing)
        .add("successful", successful)
        .add("total", total)
        .add("slaViolations", slaViolations)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link RunStats} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable RunStats instance
   */
  public static ImmutableRunStats copyOf(RunStats instance) {
    if (instance instanceof ImmutableRunStats) {
      return (ImmutableRunStats) instance;
    }
    return ImmutableRunStats.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableRunStats ImmutableRunStats}.
   * <pre>
   * ImmutableRunStats.builder()
   *    .cancelled(long) // required {@link RunStats#cancelled() cancelled}
   *    .failed(long) // required {@link RunStats#failed() failed}
   *    .ongoing(long) // required {@link RunStats#ongoing() ongoing}
   *    .successful(long) // required {@link RunStats#successful() successful}
   *    .slaViolations(long) // required {@link RunStats#slaViolations() slaViolations}
   *    .build();
   * </pre>
   * @return A new ImmutableRunStats builder
   */
  public static ImmutableRunStats.Builder builder() {
    return new ImmutableRunStats.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableRunStats ImmutableRunStats}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "RunStats", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_CANCELLED = 0x1L;
    private static final long INIT_BIT_FAILED = 0x2L;
    private static final long INIT_BIT_ONGOING = 0x4L;
    private static final long INIT_BIT_SUCCESSFUL = 0x8L;
    private static final long INIT_BIT_SLA_VIOLATIONS = 0x10L;
    private long initBits = 0x1fL;

    private long cancelled;
    private long failed;
    private long ongoing;
    private long successful;
    private long slaViolations;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code RunStats} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(RunStats instance) {
      Objects.requireNonNull(instance, "instance");
      this.cancelled(instance.cancelled());
      this.failed(instance.failed());
      this.ongoing(instance.ongoing());
      this.successful(instance.successful());
      this.slaViolations(instance.slaViolations());
      return this;
    }

    /**
     * Initializes the value for the {@link RunStats#cancelled() cancelled} attribute.
     * @param cancelled The value for cancelled 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder cancelled(long cancelled) {
      this.cancelled = cancelled;
      initBits &= ~INIT_BIT_CANCELLED;
      return this;
    }

    /**
     * Initializes the value for the {@link RunStats#failed() failed} attribute.
     * @param failed The value for failed 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder failed(long failed) {
      this.failed = failed;
      initBits &= ~INIT_BIT_FAILED;
      return this;
    }

    /**
     * Initializes the value for the {@link RunStats#ongoing() ongoing} attribute.
     * @param ongoing The value for ongoing 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder ongoing(long ongoing) {
      this.ongoing = ongoing;
      initBits &= ~INIT_BIT_ONGOING;
      return this;
    }

    /**
     * Initializes the value for the {@link RunStats#successful() successful} attribute.
     * @param successful The value for successful 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder successful(long successful) {
      this.successful = successful;
      initBits &= ~INIT_BIT_SUCCESSFUL;
      return this;
    }

    /**
     * Initializes the value for the {@link RunStats#slaViolations() slaViolations} attribute.
     * @param slaViolations The value for slaViolations 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder slaViolations(long slaViolations) {
      this.slaViolations = slaViolations;
      initBits &= ~INIT_BIT_SLA_VIOLATIONS;
      return this;
    }

    /**
     * Builds a new {@link ImmutableRunStats ImmutableRunStats}.
     * @return An immutable instance of RunStats
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableRunStats build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableRunStats(cancelled, failed, ongoing, successful, slaViolations);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_CANCELLED) != 0) attributes.add("cancelled");
      if ((initBits & INIT_BIT_FAILED) != 0) attributes.add("failed");
      if ((initBits & INIT_BIT_ONGOING) != 0) attributes.add("ongoing");
      if ((initBits & INIT_BIT_SUCCESSFUL) != 0) attributes.add("successful");
      if ((initBits & INIT_BIT_SLA_VIOLATIONS) != 0) attributes.add("slaViolations");
      return "Cannot build RunStats, some of required attributes are not set " + attributes;
    }
  }
}
