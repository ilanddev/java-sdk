/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.utils;

import com.google.common.base.MoreObjects;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import com.iland.cohesity.iaas.backups.common.model.BackupGroupUid;
import com.iland.cohesity.iaas.backups.common.model.BackupRunUid;
import com.iland.cohesity.iaas.backups.common.model.CompanyId;
import com.iland.cohesity.iaas.backups.common.model.LocationId;
import com.iland.cohesity.iaas.backups.common.model.OrgUuid;
import com.iland.cohesity.iaas.backups.common.model.ProtectionSourceUid;
import com.iland.cohesity.iaas.backups.common.model.RawCohesityUid;
import com.iland.cohesity.iaas.backups.common.model.SourceUid;
import com.iland.cohesity.iaas.backups.common.model.StorageDomainUid;
import com.iland.cohesity.iaas.backups.common.model.StorageProfileUuid;
import com.iland.cohesity.iaas.backups.common.model.TenantUid;
import com.iland.cohesity.iaas.backups.common.model.VCloudUuid;
import com.iland.cohesity.iaas.backups.common.model.VappUuid;
import com.iland.cohesity.iaas.backups.common.model.VdcUuid;
import com.iland.cohesity.iaas.backups.common.model.VmUuid;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link ErrorContext}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableErrorContext.builder()}.
 */
@Generated(from = "ErrorContext", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableErrorContext implements ErrorContext {
  private final @Nullable String message;
  private final @Nullable LocationId locationId;
  private final @Nullable CompanyId companyId;
  private final @Nullable OrgUuid orgUuid;
  private final @Nullable VdcUuid vdcUuid;
  private final @Nullable TenantUid tenantUid;
  private final @Nullable RawCohesityUid rawCohesityUid;
  private final @Nullable ProtectionSourceUid protectionSourceUid;
  private final @Nullable BackupGroupUid backupGroupUuid;
  private final @Nullable BackupRunUid backupRunUid;
  private final @Nullable VappUuid vappUuid;
  private final @Nullable VCloudUuid vCloudUuid;
  private final @Nullable SourceUid sourceUid;
  private final @Nullable VmUuid vmUuid;
  private final @Nullable StorageDomainUid storageDomainUid;
  private final @Nullable StorageProfileUuid storageProfileUuid;
  private transient final Map<String, Optional<?>> asMap;
  private transient final String asString;

  private ImmutableErrorContext(
      @Nullable String message,
      @Nullable LocationId locationId,
      @Nullable CompanyId companyId,
      @Nullable OrgUuid orgUuid,
      @Nullable VdcUuid vdcUuid,
      @Nullable TenantUid tenantUid,
      @Nullable RawCohesityUid rawCohesityUid,
      @Nullable ProtectionSourceUid protectionSourceUid,
      @Nullable BackupGroupUid backupGroupUuid,
      @Nullable BackupRunUid backupRunUid,
      @Nullable VappUuid vappUuid,
      @Nullable VCloudUuid vCloudUuid,
      @Nullable SourceUid sourceUid,
      @Nullable VmUuid vmUuid,
      @Nullable StorageDomainUid storageDomainUid,
      @Nullable StorageProfileUuid storageProfileUuid) {
    this.message = message;
    this.locationId = locationId;
    this.companyId = companyId;
    this.orgUuid = orgUuid;
    this.vdcUuid = vdcUuid;
    this.tenantUid = tenantUid;
    this.rawCohesityUid = rawCohesityUid;
    this.protectionSourceUid = protectionSourceUid;
    this.backupGroupUuid = backupGroupUuid;
    this.backupRunUid = backupRunUid;
    this.vappUuid = vappUuid;
    this.vCloudUuid = vCloudUuid;
    this.sourceUid = sourceUid;
    this.vmUuid = vmUuid;
    this.storageDomainUid = storageDomainUid;
    this.storageProfileUuid = storageProfileUuid;
    this.asMap = initShim.asMap();
    this.asString = initShim.asString();
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "ErrorContext", generator = "Immutables")
  private final class InitShim {
    private byte asMapBuildStage = STAGE_UNINITIALIZED;
    private Map<String, Optional<?>> asMap;

    Map<String, Optional<?>> asMap() {
      if (asMapBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (asMapBuildStage == STAGE_UNINITIALIZED) {
        asMapBuildStage = STAGE_INITIALIZING;
        Map<String, Optional<?>> computedValue = asMapInitialize();
        this.asMap = Objects.requireNonNull(computedValue, "asMap");
        asMapBuildStage = STAGE_INITIALIZED;
      }
      return this.asMap;
    }

    private byte asStringBuildStage = STAGE_UNINITIALIZED;
    private String asString;

    String asString() {
      if (asStringBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (asStringBuildStage == STAGE_UNINITIALIZED) {
        asStringBuildStage = STAGE_INITIALIZING;
        String computedValue = asStringInitialize();
        this.asString = Objects.requireNonNull(computedValue, "asString");
        asStringBuildStage = STAGE_INITIALIZED;
      }
      return this.asString;
    }

    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      if (asMapBuildStage == STAGE_INITIALIZING) attributes.add("asMap");
      if (asStringBuildStage == STAGE_INITIALIZING) attributes.add("asString");
      return "Cannot build ErrorContext, attribute initializers form cycle " + attributes;
    }
  }

  private Map<String, Optional<?>> asMapInitialize() {
    return ErrorContext.super.asMap();
  }

  private String asStringInitialize() {
    return ErrorContext.super.asString();
  }

  /**
   * @return The value of the {@code message} attribute
   */
  @Override
  public Optional<String> message() {
    return Optional.ofNullable(message);
  }

  /**
   * @return The value of the {@code locationId} attribute
   */
  @Override
  public Optional<LocationId> locationId() {
    return Optional.ofNullable(locationId);
  }

  /**
   * @return The value of the {@code companyId} attribute
   */
  @Override
  public Optional<CompanyId> companyId() {
    return Optional.ofNullable(companyId);
  }

  /**
   * @return The value of the {@code orgUuid} attribute
   */
  @Override
  public Optional<OrgUuid> orgUuid() {
    return Optional.ofNullable(orgUuid);
  }

  /**
   * @return The value of the {@code vdcUuid} attribute
   */
  @Override
  public Optional<VdcUuid> vdcUuid() {
    return Optional.ofNullable(vdcUuid);
  }

  /**
   * @return The value of the {@code tenantUid} attribute
   */
  @Override
  public Optional<TenantUid> tenantUid() {
    return Optional.ofNullable(tenantUid);
  }

  /**
   * @return The value of the {@code rawCohesityUid} attribute
   */
  @Override
  public Optional<RawCohesityUid> rawCohesityUid() {
    return Optional.ofNullable(rawCohesityUid);
  }

  /**
   * @return The value of the {@code protectionSourceUid} attribute
   */
  @Override
  public Optional<ProtectionSourceUid> protectionSourceUid() {
    return Optional.ofNullable(protectionSourceUid);
  }

  /**
   * @return The value of the {@code backupGroupUuid} attribute
   */
  @Override
  public Optional<BackupGroupUid> backupGroupUuid() {
    return Optional.ofNullable(backupGroupUuid);
  }

  /**
   * @return The value of the {@code backupRunUid} attribute
   */
  @Override
  public Optional<BackupRunUid> backupRunUid() {
    return Optional.ofNullable(backupRunUid);
  }

  /**
   * @return The value of the {@code vappUuid} attribute
   */
  @Override
  public Optional<VappUuid> vappUuid() {
    return Optional.ofNullable(vappUuid);
  }

  /**
   * @return The value of the {@code vCloudUuid} attribute
   */
  @Override
  public Optional<VCloudUuid> vCloudUuid() {
    return Optional.ofNullable(vCloudUuid);
  }

  /**
   * @return The value of the {@code sourceUid} attribute
   */
  @Override
  public Optional<SourceUid> sourceUid() {
    return Optional.ofNullable(sourceUid);
  }

  /**
   * @return The value of the {@code vmUuid} attribute
   */
  @Override
  public Optional<VmUuid> vmUuid() {
    return Optional.ofNullable(vmUuid);
  }

  /**
   * @return The value of the {@code storageDomainUid} attribute
   */
  @Override
  public Optional<StorageDomainUid> storageDomainUid() {
    return Optional.ofNullable(storageDomainUid);
  }

  /**
   * @return The value of the {@code storageProfileUuid} attribute
   */
  @Override
  public Optional<StorageProfileUuid> storageProfileUuid() {
    return Optional.ofNullable(storageProfileUuid);
  }

  /**
   * @return a {@link Map map} of entities ordered by subjective prominence
   */
  @Override
  public Map<String, Optional<?>> asMap() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.asMap()
        : this.asMap;
  }

  /**
   * @return The computed-at-construction value of the {@code asString} attribute
   */
  @Override
  public String asString() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.asString()
        : this.asString;
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#message() message} attribute.
   * @param value The value for message
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withMessage(String value) {
    String newValue = Objects.requireNonNull(value, "message");
    if (Objects.equals(this.message, newValue)) return this;
    return new ImmutableErrorContext(
        newValue,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#message() message} attribute.
   * An equality check is used on inner value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for message
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withMessage(Optional<String> optional) {
    @Nullable String value = optional.orElse(null);
    if (Objects.equals(this.message, value)) return this;
    return new ImmutableErrorContext(
        value,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#locationId() locationId} attribute.
   * @param value The value for locationId
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withLocationId(LocationId value) {
    LocationId newValue = Objects.requireNonNull(value, "locationId");
    if (this.locationId == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        newValue,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#locationId() locationId} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for locationId
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withLocationId(Optional<? extends LocationId> optional) {
    @Nullable LocationId value = optional.orElse(null);
    if (this.locationId == value) return this;
    return new ImmutableErrorContext(
        this.message,
        value,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#companyId() companyId} attribute.
   * @param value The value for companyId
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withCompanyId(CompanyId value) {
    CompanyId newValue = Objects.requireNonNull(value, "companyId");
    if (this.companyId == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        newValue,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#companyId() companyId} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for companyId
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withCompanyId(Optional<? extends CompanyId> optional) {
    @Nullable CompanyId value = optional.orElse(null);
    if (this.companyId == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        value,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#orgUuid() orgUuid} attribute.
   * @param value The value for orgUuid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withOrgUuid(OrgUuid value) {
    OrgUuid newValue = Objects.requireNonNull(value, "orgUuid");
    if (this.orgUuid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        newValue,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#orgUuid() orgUuid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for orgUuid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withOrgUuid(Optional<? extends OrgUuid> optional) {
    @Nullable OrgUuid value = optional.orElse(null);
    if (this.orgUuid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        value,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#vdcUuid() vdcUuid} attribute.
   * @param value The value for vdcUuid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withVdcUuid(VdcUuid value) {
    VdcUuid newValue = Objects.requireNonNull(value, "vdcUuid");
    if (this.vdcUuid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        newValue,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#vdcUuid() vdcUuid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for vdcUuid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withVdcUuid(Optional<? extends VdcUuid> optional) {
    @Nullable VdcUuid value = optional.orElse(null);
    if (this.vdcUuid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        value,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#tenantUid() tenantUid} attribute.
   * @param value The value for tenantUid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withTenantUid(TenantUid value) {
    TenantUid newValue = Objects.requireNonNull(value, "tenantUid");
    if (this.tenantUid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        newValue,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#tenantUid() tenantUid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for tenantUid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withTenantUid(Optional<? extends TenantUid> optional) {
    @Nullable TenantUid value = optional.orElse(null);
    if (this.tenantUid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        value,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#rawCohesityUid() rawCohesityUid} attribute.
   * @param value The value for rawCohesityUid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withRawCohesityUid(RawCohesityUid value) {
    RawCohesityUid newValue = Objects.requireNonNull(value, "rawCohesityUid");
    if (this.rawCohesityUid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        newValue,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#rawCohesityUid() rawCohesityUid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for rawCohesityUid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withRawCohesityUid(Optional<? extends RawCohesityUid> optional) {
    @Nullable RawCohesityUid value = optional.orElse(null);
    if (this.rawCohesityUid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        value,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#protectionSourceUid() protectionSourceUid} attribute.
   * @param value The value for protectionSourceUid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withProtectionSourceUid(ProtectionSourceUid value) {
    ProtectionSourceUid newValue = Objects.requireNonNull(value, "protectionSourceUid");
    if (this.protectionSourceUid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        newValue,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#protectionSourceUid() protectionSourceUid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for protectionSourceUid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withProtectionSourceUid(Optional<? extends ProtectionSourceUid> optional) {
    @Nullable ProtectionSourceUid value = optional.orElse(null);
    if (this.protectionSourceUid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        value,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#backupGroupUuid() backupGroupUuid} attribute.
   * @param value The value for backupGroupUuid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withBackupGroupUuid(BackupGroupUid value) {
    BackupGroupUid newValue = Objects.requireNonNull(value, "backupGroupUuid");
    if (this.backupGroupUuid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        newValue,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#backupGroupUuid() backupGroupUuid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for backupGroupUuid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withBackupGroupUuid(Optional<? extends BackupGroupUid> optional) {
    @Nullable BackupGroupUid value = optional.orElse(null);
    if (this.backupGroupUuid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        value,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#backupRunUid() backupRunUid} attribute.
   * @param value The value for backupRunUid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withBackupRunUid(BackupRunUid value) {
    BackupRunUid newValue = Objects.requireNonNull(value, "backupRunUid");
    if (this.backupRunUid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        newValue,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#backupRunUid() backupRunUid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for backupRunUid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withBackupRunUid(Optional<? extends BackupRunUid> optional) {
    @Nullable BackupRunUid value = optional.orElse(null);
    if (this.backupRunUid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        value,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#vappUuid() vappUuid} attribute.
   * @param value The value for vappUuid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withVappUuid(VappUuid value) {
    VappUuid newValue = Objects.requireNonNull(value, "vappUuid");
    if (this.vappUuid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        newValue,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#vappUuid() vappUuid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for vappUuid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withVappUuid(Optional<? extends VappUuid> optional) {
    @Nullable VappUuid value = optional.orElse(null);
    if (this.vappUuid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        value,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#vCloudUuid() vCloudUuid} attribute.
   * @param value The value for vCloudUuid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withVCloudUuid(VCloudUuid value) {
    VCloudUuid newValue = Objects.requireNonNull(value, "vCloudUuid");
    if (this.vCloudUuid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        newValue,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#vCloudUuid() vCloudUuid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for vCloudUuid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withVCloudUuid(Optional<? extends VCloudUuid> optional) {
    @Nullable VCloudUuid value = optional.orElse(null);
    if (this.vCloudUuid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        value,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#sourceUid() sourceUid} attribute.
   * @param value The value for sourceUid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withSourceUid(SourceUid value) {
    SourceUid newValue = Objects.requireNonNull(value, "sourceUid");
    if (this.sourceUid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        newValue,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#sourceUid() sourceUid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for sourceUid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withSourceUid(Optional<? extends SourceUid> optional) {
    @Nullable SourceUid value = optional.orElse(null);
    if (this.sourceUid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        value,
        this.vmUuid,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#vmUuid() vmUuid} attribute.
   * @param value The value for vmUuid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withVmUuid(VmUuid value) {
    VmUuid newValue = Objects.requireNonNull(value, "vmUuid");
    if (this.vmUuid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        newValue,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#vmUuid() vmUuid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for vmUuid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withVmUuid(Optional<? extends VmUuid> optional) {
    @Nullable VmUuid value = optional.orElse(null);
    if (this.vmUuid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        value,
        this.storageDomainUid,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#storageDomainUid() storageDomainUid} attribute.
   * @param value The value for storageDomainUid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withStorageDomainUid(StorageDomainUid value) {
    StorageDomainUid newValue = Objects.requireNonNull(value, "storageDomainUid");
    if (this.storageDomainUid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        newValue,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#storageDomainUid() storageDomainUid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for storageDomainUid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withStorageDomainUid(Optional<? extends StorageDomainUid> optional) {
    @Nullable StorageDomainUid value = optional.orElse(null);
    if (this.storageDomainUid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        value,
        this.storageProfileUuid);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ErrorContext#storageProfileUuid() storageProfileUuid} attribute.
   * @param value The value for storageProfileUuid
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableErrorContext withStorageProfileUuid(StorageProfileUuid value) {
    StorageProfileUuid newValue = Objects.requireNonNull(value, "storageProfileUuid");
    if (this.storageProfileUuid == newValue) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        newValue);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ErrorContext#storageProfileUuid() storageProfileUuid} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for storageProfileUuid
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableErrorContext withStorageProfileUuid(Optional<? extends StorageProfileUuid> optional) {
    @Nullable StorageProfileUuid value = optional.orElse(null);
    if (this.storageProfileUuid == value) return this;
    return new ImmutableErrorContext(
        this.message,
        this.locationId,
        this.companyId,
        this.orgUuid,
        this.vdcUuid,
        this.tenantUid,
        this.rawCohesityUid,
        this.protectionSourceUid,
        this.backupGroupUuid,
        this.backupRunUid,
        this.vappUuid,
        this.vCloudUuid,
        this.sourceUid,
        this.vmUuid,
        this.storageDomainUid,
        value);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableErrorContext} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableErrorContext
        && equalsByValue((ImmutableErrorContext) another);
  }

  private boolean equalsByValue(ImmutableErrorContext another) {
    return Objects.equals(message, another.message)
        && Objects.equals(locationId, another.locationId)
        && Objects.equals(companyId, another.companyId)
        && Objects.equals(orgUuid, another.orgUuid)
        && Objects.equals(vdcUuid, another.vdcUuid)
        && Objects.equals(tenantUid, another.tenantUid)
        && Objects.equals(rawCohesityUid, another.rawCohesityUid)
        && Objects.equals(protectionSourceUid, another.protectionSourceUid)
        && Objects.equals(backupGroupUuid, another.backupGroupUuid)
        && Objects.equals(backupRunUid, another.backupRunUid)
        && Objects.equals(vappUuid, another.vappUuid)
        && Objects.equals(vCloudUuid, another.vCloudUuid)
        && Objects.equals(sourceUid, another.sourceUid)
        && Objects.equals(vmUuid, another.vmUuid)
        && Objects.equals(storageDomainUid, another.storageDomainUid)
        && Objects.equals(storageProfileUuid, another.storageProfileUuid)
        && asMap.equals(another.asMap)
        && asString.equals(another.asString);
  }

  /**
   * Computes a hash code from attributes: {@code message}, {@code locationId}, {@code companyId}, {@code orgUuid}, {@code vdcUuid}, {@code tenantUid}, {@code rawCohesityUid}, {@code protectionSourceUid}, {@code backupGroupUuid}, {@code backupRunUid}, {@code vappUuid}, {@code vCloudUuid}, {@code sourceUid}, {@code vmUuid}, {@code storageDomainUid}, {@code storageProfileUuid}, {@code asMap}, {@code asString}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(message);
    h += (h << 5) + Objects.hashCode(locationId);
    h += (h << 5) + Objects.hashCode(companyId);
    h += (h << 5) + Objects.hashCode(orgUuid);
    h += (h << 5) + Objects.hashCode(vdcUuid);
    h += (h << 5) + Objects.hashCode(tenantUid);
    h += (h << 5) + Objects.hashCode(rawCohesityUid);
    h += (h << 5) + Objects.hashCode(protectionSourceUid);
    h += (h << 5) + Objects.hashCode(backupGroupUuid);
    h += (h << 5) + Objects.hashCode(backupRunUid);
    h += (h << 5) + Objects.hashCode(vappUuid);
    h += (h << 5) + Objects.hashCode(vCloudUuid);
    h += (h << 5) + Objects.hashCode(sourceUid);
    h += (h << 5) + Objects.hashCode(vmUuid);
    h += (h << 5) + Objects.hashCode(storageDomainUid);
    h += (h << 5) + Objects.hashCode(storageProfileUuid);
    h += (h << 5) + asMap.hashCode();
    h += (h << 5) + asString.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code ErrorContext} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("ErrorContext")
        .omitNullValues()
        .add("message", message)
        .add("locationId", locationId)
        .add("companyId", companyId)
        .add("orgUuid", orgUuid)
        .add("vdcUuid", vdcUuid)
        .add("tenantUid", tenantUid)
        .add("rawCohesityUid", rawCohesityUid)
        .add("protectionSourceUid", protectionSourceUid)
        .add("backupGroupUuid", backupGroupUuid)
        .add("backupRunUid", backupRunUid)
        .add("vappUuid", vappUuid)
        .add("vCloudUuid", vCloudUuid)
        .add("sourceUid", sourceUid)
        .add("vmUuid", vmUuid)
        .add("storageDomainUid", storageDomainUid)
        .add("storageProfileUuid", storageProfileUuid)
        .add("asMap", asMap)
        .add("asString", asString)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link ErrorContext} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ErrorContext instance
   */
  public static ImmutableErrorContext copyOf(ErrorContext instance) {
    if (instance instanceof ImmutableErrorContext) {
      return (ImmutableErrorContext) instance;
    }
    return ImmutableErrorContext.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableErrorContext ImmutableErrorContext}.
   * <pre>
   * ImmutableErrorContext.builder()
   *    .message(Optional&lt;String&gt;) // optional {@link ErrorContext#message() message}
   *    .locationId(Optional&lt;com.iland.cohesity.iaas.backups.common.model.LocationId&gt;) // optional {@link ErrorContext#locationId() locationId}
   *    .companyId(Optional&lt;com.iland.cohesity.iaas.backups.common.model.CompanyId&gt;) // optional {@link ErrorContext#companyId() companyId}
   *    .orgUuid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.OrgUuid&gt;) // optional {@link ErrorContext#orgUuid() orgUuid}
   *    .vdcUuid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.VdcUuid&gt;) // optional {@link ErrorContext#vdcUuid() vdcUuid}
   *    .tenantUid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.TenantUid&gt;) // optional {@link ErrorContext#tenantUid() tenantUid}
   *    .rawCohesityUid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.RawCohesityUid&gt;) // optional {@link ErrorContext#rawCohesityUid() rawCohesityUid}
   *    .protectionSourceUid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.ProtectionSourceUid&gt;) // optional {@link ErrorContext#protectionSourceUid() protectionSourceUid}
   *    .backupGroupUuid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.BackupGroupUid&gt;) // optional {@link ErrorContext#backupGroupUuid() backupGroupUuid}
   *    .backupRunUid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.BackupRunUid&gt;) // optional {@link ErrorContext#backupRunUid() backupRunUid}
   *    .vappUuid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.VappUuid&gt;) // optional {@link ErrorContext#vappUuid() vappUuid}
   *    .vCloudUuid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.VCloudUuid&gt;) // optional {@link ErrorContext#vCloudUuid() vCloudUuid}
   *    .sourceUid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.SourceUid&gt;) // optional {@link ErrorContext#sourceUid() sourceUid}
   *    .vmUuid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.VmUuid&gt;) // optional {@link ErrorContext#vmUuid() vmUuid}
   *    .storageDomainUid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.StorageDomainUid&gt;) // optional {@link ErrorContext#storageDomainUid() storageDomainUid}
   *    .storageProfileUuid(Optional&lt;com.iland.cohesity.iaas.backups.common.model.StorageProfileUuid&gt;) // optional {@link ErrorContext#storageProfileUuid() storageProfileUuid}
   *    .build();
   * </pre>
   * @return A new ImmutableErrorContext builder
   */
  public static ImmutableErrorContext.Builder builder() {
    return new ImmutableErrorContext.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableErrorContext ImmutableErrorContext}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "ErrorContext", generator = "Immutables")
  public static final class Builder {
    private @Nullable String message;
    private @Nullable LocationId locationId;
    private @Nullable CompanyId companyId;
    private @Nullable OrgUuid orgUuid;
    private @Nullable VdcUuid vdcUuid;
    private @Nullable TenantUid tenantUid;
    private @Nullable RawCohesityUid rawCohesityUid;
    private @Nullable ProtectionSourceUid protectionSourceUid;
    private @Nullable BackupGroupUid backupGroupUuid;
    private @Nullable BackupRunUid backupRunUid;
    private @Nullable VappUuid vappUuid;
    private @Nullable VCloudUuid vCloudUuid;
    private @Nullable SourceUid sourceUid;
    private @Nullable VmUuid vmUuid;
    private @Nullable StorageDomainUid storageDomainUid;
    private @Nullable StorageProfileUuid storageProfileUuid;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code ErrorContext} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(ErrorContext instance) {
      Objects.requireNonNull(instance, "instance");
      Optional<String> messageOptional = instance.message();
      if (messageOptional.isPresent()) {
        message(messageOptional);
      }
      Optional<LocationId> locationIdOptional = instance.locationId();
      if (locationIdOptional.isPresent()) {
        locationId(locationIdOptional);
      }
      Optional<CompanyId> companyIdOptional = instance.companyId();
      if (companyIdOptional.isPresent()) {
        companyId(companyIdOptional);
      }
      Optional<OrgUuid> orgUuidOptional = instance.orgUuid();
      if (orgUuidOptional.isPresent()) {
        orgUuid(orgUuidOptional);
      }
      Optional<VdcUuid> vdcUuidOptional = instance.vdcUuid();
      if (vdcUuidOptional.isPresent()) {
        vdcUuid(vdcUuidOptional);
      }
      Optional<TenantUid> tenantUidOptional = instance.tenantUid();
      if (tenantUidOptional.isPresent()) {
        tenantUid(tenantUidOptional);
      }
      Optional<RawCohesityUid> rawCohesityUidOptional = instance.rawCohesityUid();
      if (rawCohesityUidOptional.isPresent()) {
        rawCohesityUid(rawCohesityUidOptional);
      }
      Optional<ProtectionSourceUid> protectionSourceUidOptional = instance.protectionSourceUid();
      if (protectionSourceUidOptional.isPresent()) {
        protectionSourceUid(protectionSourceUidOptional);
      }
      Optional<BackupGroupUid> backupGroupUuidOptional = instance.backupGroupUuid();
      if (backupGroupUuidOptional.isPresent()) {
        backupGroupUuid(backupGroupUuidOptional);
      }
      Optional<BackupRunUid> backupRunUidOptional = instance.backupRunUid();
      if (backupRunUidOptional.isPresent()) {
        backupRunUid(backupRunUidOptional);
      }
      Optional<VappUuid> vappUuidOptional = instance.vappUuid();
      if (vappUuidOptional.isPresent()) {
        vappUuid(vappUuidOptional);
      }
      Optional<VCloudUuid> vCloudUuidOptional = instance.vCloudUuid();
      if (vCloudUuidOptional.isPresent()) {
        vCloudUuid(vCloudUuidOptional);
      }
      Optional<SourceUid> sourceUidOptional = instance.sourceUid();
      if (sourceUidOptional.isPresent()) {
        sourceUid(sourceUidOptional);
      }
      Optional<VmUuid> vmUuidOptional = instance.vmUuid();
      if (vmUuidOptional.isPresent()) {
        vmUuid(vmUuidOptional);
      }
      Optional<StorageDomainUid> storageDomainUidOptional = instance.storageDomainUid();
      if (storageDomainUidOptional.isPresent()) {
        storageDomainUid(storageDomainUidOptional);
      }
      Optional<StorageProfileUuid> storageProfileUuidOptional = instance.storageProfileUuid();
      if (storageProfileUuidOptional.isPresent()) {
        storageProfileUuid(storageProfileUuidOptional);
      }
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#message() message} to message.
     * @param message The value for message
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder message(String message) {
      this.message = Objects.requireNonNull(message, "message");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#message() message} to message.
     * @param message The value for message
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder message(Optional<String> message) {
      this.message = message.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#locationId() locationId} to locationId.
     * @param locationId The value for locationId
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder locationId(LocationId locationId) {
      this.locationId = Objects.requireNonNull(locationId, "locationId");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#locationId() locationId} to locationId.
     * @param locationId The value for locationId
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder locationId(Optional<? extends LocationId> locationId) {
      this.locationId = locationId.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#companyId() companyId} to companyId.
     * @param companyId The value for companyId
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder companyId(CompanyId companyId) {
      this.companyId = Objects.requireNonNull(companyId, "companyId");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#companyId() companyId} to companyId.
     * @param companyId The value for companyId
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder companyId(Optional<? extends CompanyId> companyId) {
      this.companyId = companyId.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#orgUuid() orgUuid} to orgUuid.
     * @param orgUuid The value for orgUuid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder orgUuid(OrgUuid orgUuid) {
      this.orgUuid = Objects.requireNonNull(orgUuid, "orgUuid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#orgUuid() orgUuid} to orgUuid.
     * @param orgUuid The value for orgUuid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder orgUuid(Optional<? extends OrgUuid> orgUuid) {
      this.orgUuid = orgUuid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#vdcUuid() vdcUuid} to vdcUuid.
     * @param vdcUuid The value for vdcUuid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder vdcUuid(VdcUuid vdcUuid) {
      this.vdcUuid = Objects.requireNonNull(vdcUuid, "vdcUuid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#vdcUuid() vdcUuid} to vdcUuid.
     * @param vdcUuid The value for vdcUuid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder vdcUuid(Optional<? extends VdcUuid> vdcUuid) {
      this.vdcUuid = vdcUuid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#tenantUid() tenantUid} to tenantUid.
     * @param tenantUid The value for tenantUid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder tenantUid(TenantUid tenantUid) {
      this.tenantUid = Objects.requireNonNull(tenantUid, "tenantUid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#tenantUid() tenantUid} to tenantUid.
     * @param tenantUid The value for tenantUid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder tenantUid(Optional<? extends TenantUid> tenantUid) {
      this.tenantUid = tenantUid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#rawCohesityUid() rawCohesityUid} to rawCohesityUid.
     * @param rawCohesityUid The value for rawCohesityUid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder rawCohesityUid(RawCohesityUid rawCohesityUid) {
      this.rawCohesityUid = Objects.requireNonNull(rawCohesityUid, "rawCohesityUid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#rawCohesityUid() rawCohesityUid} to rawCohesityUid.
     * @param rawCohesityUid The value for rawCohesityUid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder rawCohesityUid(Optional<? extends RawCohesityUid> rawCohesityUid) {
      this.rawCohesityUid = rawCohesityUid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#protectionSourceUid() protectionSourceUid} to protectionSourceUid.
     * @param protectionSourceUid The value for protectionSourceUid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder protectionSourceUid(ProtectionSourceUid protectionSourceUid) {
      this.protectionSourceUid = Objects.requireNonNull(protectionSourceUid, "protectionSourceUid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#protectionSourceUid() protectionSourceUid} to protectionSourceUid.
     * @param protectionSourceUid The value for protectionSourceUid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder protectionSourceUid(Optional<? extends ProtectionSourceUid> protectionSourceUid) {
      this.protectionSourceUid = protectionSourceUid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#backupGroupUuid() backupGroupUuid} to backupGroupUuid.
     * @param backupGroupUuid The value for backupGroupUuid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder backupGroupUuid(BackupGroupUid backupGroupUuid) {
      this.backupGroupUuid = Objects.requireNonNull(backupGroupUuid, "backupGroupUuid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#backupGroupUuid() backupGroupUuid} to backupGroupUuid.
     * @param backupGroupUuid The value for backupGroupUuid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder backupGroupUuid(Optional<? extends BackupGroupUid> backupGroupUuid) {
      this.backupGroupUuid = backupGroupUuid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#backupRunUid() backupRunUid} to backupRunUid.
     * @param backupRunUid The value for backupRunUid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder backupRunUid(BackupRunUid backupRunUid) {
      this.backupRunUid = Objects.requireNonNull(backupRunUid, "backupRunUid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#backupRunUid() backupRunUid} to backupRunUid.
     * @param backupRunUid The value for backupRunUid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder backupRunUid(Optional<? extends BackupRunUid> backupRunUid) {
      this.backupRunUid = backupRunUid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#vappUuid() vappUuid} to vappUuid.
     * @param vappUuid The value for vappUuid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder vappUuid(VappUuid vappUuid) {
      this.vappUuid = Objects.requireNonNull(vappUuid, "vappUuid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#vappUuid() vappUuid} to vappUuid.
     * @param vappUuid The value for vappUuid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder vappUuid(Optional<? extends VappUuid> vappUuid) {
      this.vappUuid = vappUuid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#vCloudUuid() vCloudUuid} to vCloudUuid.
     * @param vCloudUuid The value for vCloudUuid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder vCloudUuid(VCloudUuid vCloudUuid) {
      this.vCloudUuid = Objects.requireNonNull(vCloudUuid, "vCloudUuid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#vCloudUuid() vCloudUuid} to vCloudUuid.
     * @param vCloudUuid The value for vCloudUuid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder vCloudUuid(Optional<? extends VCloudUuid> vCloudUuid) {
      this.vCloudUuid = vCloudUuid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#sourceUid() sourceUid} to sourceUid.
     * @param sourceUid The value for sourceUid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder sourceUid(SourceUid sourceUid) {
      this.sourceUid = Objects.requireNonNull(sourceUid, "sourceUid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#sourceUid() sourceUid} to sourceUid.
     * @param sourceUid The value for sourceUid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder sourceUid(Optional<? extends SourceUid> sourceUid) {
      this.sourceUid = sourceUid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#vmUuid() vmUuid} to vmUuid.
     * @param vmUuid The value for vmUuid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder vmUuid(VmUuid vmUuid) {
      this.vmUuid = Objects.requireNonNull(vmUuid, "vmUuid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#vmUuid() vmUuid} to vmUuid.
     * @param vmUuid The value for vmUuid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder vmUuid(Optional<? extends VmUuid> vmUuid) {
      this.vmUuid = vmUuid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#storageDomainUid() storageDomainUid} to storageDomainUid.
     * @param storageDomainUid The value for storageDomainUid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder storageDomainUid(StorageDomainUid storageDomainUid) {
      this.storageDomainUid = Objects.requireNonNull(storageDomainUid, "storageDomainUid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#storageDomainUid() storageDomainUid} to storageDomainUid.
     * @param storageDomainUid The value for storageDomainUid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder storageDomainUid(Optional<? extends StorageDomainUid> storageDomainUid) {
      this.storageDomainUid = storageDomainUid.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#storageProfileUuid() storageProfileUuid} to storageProfileUuid.
     * @param storageProfileUuid The value for storageProfileUuid
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder storageProfileUuid(StorageProfileUuid storageProfileUuid) {
      this.storageProfileUuid = Objects.requireNonNull(storageProfileUuid, "storageProfileUuid");
      return this;
    }

    /**
     * Initializes the optional value {@link ErrorContext#storageProfileUuid() storageProfileUuid} to storageProfileUuid.
     * @param storageProfileUuid The value for storageProfileUuid
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder storageProfileUuid(Optional<? extends StorageProfileUuid> storageProfileUuid) {
      this.storageProfileUuid = storageProfileUuid.orElse(null);
      return this;
    }

    /**
     * Builds a new {@link ImmutableErrorContext ImmutableErrorContext}.
     * @return An immutable instance of ErrorContext
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableErrorContext build() {
      return new ImmutableErrorContext(
          message,
          locationId,
          companyId,
          orgUuid,
          vdcUuid,
          tenantUid,
          rawCohesityUid,
          protectionSourceUid,
          backupGroupUuid,
          backupRunUid,
          vappUuid,
          vCloudUuid,
          sourceUid,
          vmUuid,
          storageDomainUid,
          storageProfileUuid);
    }
  }
}
