/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Vm Restore Point Impl. Holds a historical restore point retrieved from the
 * Veeam API that represents a snapshot of a Vm at a certain point in time. Can
 * be used to restore a Vm back to a previous state.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class RestorePoint implements Serializable {

  private static final long serialVersionUID = -3249399554619898956L;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(RestorePointField.NAME)
  private final String name;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(RestorePointField.TIME)
  private final Date timestamp;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(RestorePointField.HREF)
  @Expose
  private final String href;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(RestorePointField.RESTORE_HREF)
  @Expose
  private final String restoreHref;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(RestorePointField.BACKUP_SERVER_NAME)
  @Expose
  private final String backupServerName;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(RestorePointField.TYPE)
  @Expose
  private final RestorePointType type;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @SerializedName(RestorePointField.JOB_NAME)
  @Expose
  private final String jobName;

  public RestorePoint(final String name, final Date timestamp,
      final String href, final String restoreHref,
      final String backupServerName, final RestorePointType type,
      final String jobName) {
    this.name = name;
    this.timestamp = timestamp;
    this.href = href;
    this.restoreHref = restoreHref;
    this.backupServerName = backupServerName;
    this.type = type;
    this.jobName = jobName;
  }

  public String getName() {
    return name;
  }

  public Date getTimestamp() {
    return timestamp;
  }

  public String getHref() {
    return href;
  }

  public String getRestoreHref() {
    return restoreHref;
  }

  public String getBackupServerName() {
    return backupServerName;
  }

  @Override
  public boolean equals(final Object other) {
    if (this == other) {
      return true;
    }
    if (other == null || other.getClass() != this.getClass()) {
      return false;
    }
    if (getRestoreHref() != null) {
      final RestorePoint orp = (RestorePoint) other;
      return getRestoreHref().equals(orp.getRestoreHref());
    }
    return super.equals(other);
  }

  @Override
  public int hashCode() {
    return getRestoreHref() != null ?
        getRestoreHref().hashCode() :
        super.hashCode();
  }

  /**
   * Returns the restore point type.
   *
   * @return one of {@link RestorePointType} enum value
   */
  public RestorePointType getType() {
    return type;
  }

  /**
   * Returns the name of the corresponding backup job.
   *
   * @return the corresponding backup job name
   */
  public String getJobName() {
    return jobName;
  }

}
