/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.recovery;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.api.serialization.JsonRequired;

/**
 * Recovery Group Descriptor.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class RecoveryGroupDescriptor implements Serializable {

  private static final long serialVersionUID = -3869179964019130300L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @JsonRequired("recovery group name")
  @SerializedName(RecoveryRunbookField.NAME)
  private String name;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @JsonRequired("recovery group uuid")
  @SerializedName(RecoveryRunbookField.UUID)
  private String uuid;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @JsonRequired("recovery group type")
  @SerializedName(RecoveryRunbookField.TYPE)
  private RecoveryGroupType type;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @JsonRequired("recovery group order index")
  @SerializedName(RecoveryRunbookField.ORDER_INDEX)
  private int orderIndex;

  public RecoveryGroupDescriptor(final String name, final String uuid,
      final RecoveryGroupType type, final int orderIndex) {
    this.name = name;
    this.uuid = uuid;
    this.type = type;
    this.orderIndex = orderIndex;
  }

  /**
   * Get the recovery group name.
   *
   * @return recovery group name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the recovery group UUID.
   *
   * @return plan UUID
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Get the recovery group type.
   *
   * @return {@link RecoveryGroupType} group type
   */
  public RecoveryGroupType getType() {
    return type;
  }

  /**
   * Get the order index for the recovery group.
   *
   * @return recovery group order index
   */
  public int getOrderIndex() {
    return orderIndex;
  }

}
