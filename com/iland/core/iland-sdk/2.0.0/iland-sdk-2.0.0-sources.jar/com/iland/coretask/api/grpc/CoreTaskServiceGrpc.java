/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.coretask.api.grpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.53.0)",
    comments = "Source: core-task-api.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class CoreTaskServiceGrpc {

  private CoreTaskServiceGrpc() {}

  public static final String SERVICE_NAME = "io.grpc.CoreTaskService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.CoreTask,
      com.iland.coretask.api.grpc.CoreTask> getCreateCoreTaskMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateCoreTask",
      requestType = com.iland.coretask.api.grpc.CoreTask.class,
      responseType = com.iland.coretask.api.grpc.CoreTask.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.CoreTask,
      com.iland.coretask.api.grpc.CoreTask> getCreateCoreTaskMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.CoreTask, com.iland.coretask.api.grpc.CoreTask> getCreateCoreTaskMethod;
    if ((getCreateCoreTaskMethod = CoreTaskServiceGrpc.getCreateCoreTaskMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getCreateCoreTaskMethod = CoreTaskServiceGrpc.getCreateCoreTaskMethod) == null) {
          CoreTaskServiceGrpc.getCreateCoreTaskMethod = getCreateCoreTaskMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.CoreTask, com.iland.coretask.api.grpc.CoreTask>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateCoreTask"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTask.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTask.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("CreateCoreTask"))
              .build();
        }
      }
    }
    return getCreateCoreTaskMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.CoreTaskUpdateRequest,
      com.iland.coretask.api.grpc.CoreTask> getUpdateCoreTaskMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateCoreTask",
      requestType = com.iland.coretask.api.grpc.CoreTaskUpdateRequest.class,
      responseType = com.iland.coretask.api.grpc.CoreTask.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.CoreTaskUpdateRequest,
      com.iland.coretask.api.grpc.CoreTask> getUpdateCoreTaskMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.CoreTaskUpdateRequest, com.iland.coretask.api.grpc.CoreTask> getUpdateCoreTaskMethod;
    if ((getUpdateCoreTaskMethod = CoreTaskServiceGrpc.getUpdateCoreTaskMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getUpdateCoreTaskMethod = CoreTaskServiceGrpc.getUpdateCoreTaskMethod) == null) {
          CoreTaskServiceGrpc.getUpdateCoreTaskMethod = getUpdateCoreTaskMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.CoreTaskUpdateRequest, com.iland.coretask.api.grpc.CoreTask>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateCoreTask"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTaskUpdateRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTask.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("UpdateCoreTask"))
              .build();
        }
      }
    }
    return getUpdateCoreTaskMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTaskRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetCoreTaskMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetCoreTask",
      requestType = com.iland.coretask.api.grpc.GetCoreTaskRequest.class,
      responseType = com.iland.coretask.api.grpc.CoreTask.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTaskRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetCoreTaskMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTaskRequest, com.iland.coretask.api.grpc.CoreTask> getGetCoreTaskMethod;
    if ((getGetCoreTaskMethod = CoreTaskServiceGrpc.getGetCoreTaskMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getGetCoreTaskMethod = CoreTaskServiceGrpc.getGetCoreTaskMethod) == null) {
          CoreTaskServiceGrpc.getGetCoreTaskMethod = getGetCoreTaskMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.GetCoreTaskRequest, com.iland.coretask.api.grpc.CoreTask>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetCoreTask"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.GetCoreTaskRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTask.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("GetCoreTask"))
              .build();
        }
      }
    }
    return getGetCoreTaskMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTaskRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetCoreTaskByNativeIdMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetCoreTaskByNativeId",
      requestType = com.iland.coretask.api.grpc.GetCoreTaskRequest.class,
      responseType = com.iland.coretask.api.grpc.CoreTask.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTaskRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetCoreTaskByNativeIdMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTaskRequest, com.iland.coretask.api.grpc.CoreTask> getGetCoreTaskByNativeIdMethod;
    if ((getGetCoreTaskByNativeIdMethod = CoreTaskServiceGrpc.getGetCoreTaskByNativeIdMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getGetCoreTaskByNativeIdMethod = CoreTaskServiceGrpc.getGetCoreTaskByNativeIdMethod) == null) {
          CoreTaskServiceGrpc.getGetCoreTaskByNativeIdMethod = getGetCoreTaskByNativeIdMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.GetCoreTaskRequest, com.iland.coretask.api.grpc.CoreTask>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetCoreTaskByNativeId"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.GetCoreTaskRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTask.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("GetCoreTaskByNativeId"))
              .build();
        }
      }
    }
    return getGetCoreTaskByNativeIdMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.GetCoreTasksPage> getGetCoreTasksMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetCoreTasks",
      requestType = com.iland.coretask.api.grpc.GetCoreTasksRequest.class,
      responseType = com.iland.coretask.api.grpc.GetCoreTasksPage.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.GetCoreTasksPage> getGetCoreTasksMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.GetCoreTasksPage> getGetCoreTasksMethod;
    if ((getGetCoreTasksMethod = CoreTaskServiceGrpc.getGetCoreTasksMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getGetCoreTasksMethod = CoreTaskServiceGrpc.getGetCoreTasksMethod) == null) {
          CoreTaskServiceGrpc.getGetCoreTasksMethod = getGetCoreTasksMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.GetCoreTasksPage>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetCoreTasks"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.GetCoreTasksRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.GetCoreTasksPage.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("GetCoreTasks"))
              .build();
        }
      }
    }
    return getGetCoreTasksMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetSynchronizedTasksInOrgMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetSynchronizedTasksInOrg",
      requestType = com.iland.coretask.api.grpc.GetCoreTasksRequest.class,
      responseType = com.iland.coretask.api.grpc.CoreTask.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetSynchronizedTasksInOrgMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask> getGetSynchronizedTasksInOrgMethod;
    if ((getGetSynchronizedTasksInOrgMethod = CoreTaskServiceGrpc.getGetSynchronizedTasksInOrgMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getGetSynchronizedTasksInOrgMethod = CoreTaskServiceGrpc.getGetSynchronizedTasksInOrgMethod) == null) {
          CoreTaskServiceGrpc.getGetSynchronizedTasksInOrgMethod = getGetSynchronizedTasksInOrgMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetSynchronizedTasksInOrg"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.GetCoreTasksRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTask.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("GetSynchronizedTasksInOrg"))
              .build();
        }
      }
    }
    return getGetSynchronizedTasksInOrgMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetUnsynchronizedTasksMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetUnsynchronizedTasks",
      requestType = com.iland.coretask.api.grpc.GetCoreTasksRequest.class,
      responseType = com.iland.coretask.api.grpc.CoreTask.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetUnsynchronizedTasksMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask> getGetUnsynchronizedTasksMethod;
    if ((getGetUnsynchronizedTasksMethod = CoreTaskServiceGrpc.getGetUnsynchronizedTasksMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getGetUnsynchronizedTasksMethod = CoreTaskServiceGrpc.getGetUnsynchronizedTasksMethod) == null) {
          CoreTaskServiceGrpc.getGetUnsynchronizedTasksMethod = getGetUnsynchronizedTasksMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetUnsynchronizedTasks"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.GetCoreTasksRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTask.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("GetUnsynchronizedTasks"))
              .build();
        }
      }
    }
    return getGetUnsynchronizedTasksMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetUnsynchronizedTasksInOrgMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetUnsynchronizedTasksInOrg",
      requestType = com.iland.coretask.api.grpc.GetCoreTasksRequest.class,
      responseType = com.iland.coretask.api.grpc.CoreTask.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetUnsynchronizedTasksInOrgMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask> getGetUnsynchronizedTasksInOrgMethod;
    if ((getGetUnsynchronizedTasksInOrgMethod = CoreTaskServiceGrpc.getGetUnsynchronizedTasksInOrgMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getGetUnsynchronizedTasksInOrgMethod = CoreTaskServiceGrpc.getGetUnsynchronizedTasksInOrgMethod) == null) {
          CoreTaskServiceGrpc.getGetUnsynchronizedTasksInOrgMethod = getGetUnsynchronizedTasksInOrgMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetUnsynchronizedTasksInOrg"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.GetCoreTasksRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTask.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("GetUnsynchronizedTasksInOrg"))
              .build();
        }
      }
    }
    return getGetUnsynchronizedTasksInOrgMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetUnsynchronizedTasksForLocationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetUnsynchronizedTasksForLocation",
      requestType = com.iland.coretask.api.grpc.GetCoreTasksRequest.class,
      responseType = com.iland.coretask.api.grpc.CoreTask.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetUnsynchronizedTasksForLocationMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask> getGetUnsynchronizedTasksForLocationMethod;
    if ((getGetUnsynchronizedTasksForLocationMethod = CoreTaskServiceGrpc.getGetUnsynchronizedTasksForLocationMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getGetUnsynchronizedTasksForLocationMethod = CoreTaskServiceGrpc.getGetUnsynchronizedTasksForLocationMethod) == null) {
          CoreTaskServiceGrpc.getGetUnsynchronizedTasksForLocationMethod = getGetUnsynchronizedTasksForLocationMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetUnsynchronizedTasksForLocation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.GetCoreTasksRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTask.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("GetUnsynchronizedTasksForLocation"))
              .build();
        }
      }
    }
    return getGetUnsynchronizedTasksForLocationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTaskUuidsResponse> getGetTaskUuidsFromNativeIdMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetTaskUuidsFromNativeId",
      requestType = com.iland.coretask.api.grpc.GetCoreTasksRequest.class,
      responseType = com.iland.coretask.api.grpc.CoreTaskUuidsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTaskUuidsResponse> getGetTaskUuidsFromNativeIdMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTaskUuidsResponse> getGetTaskUuidsFromNativeIdMethod;
    if ((getGetTaskUuidsFromNativeIdMethod = CoreTaskServiceGrpc.getGetTaskUuidsFromNativeIdMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getGetTaskUuidsFromNativeIdMethod = CoreTaskServiceGrpc.getGetTaskUuidsFromNativeIdMethod) == null) {
          CoreTaskServiceGrpc.getGetTaskUuidsFromNativeIdMethod = getGetTaskUuidsFromNativeIdMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTaskUuidsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetTaskUuidsFromNativeId"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.GetCoreTasksRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTaskUuidsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("GetTaskUuidsFromNativeId"))
              .build();
        }
      }
    }
    return getGetTaskUuidsFromNativeIdMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetTasksForEntityMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetTasksForEntity",
      requestType = com.iland.coretask.api.grpc.GetCoreTasksRequest.class,
      responseType = com.iland.coretask.api.grpc.CoreTask.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetTasksForEntityMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask> getGetTasksForEntityMethod;
    if ((getGetTasksForEntityMethod = CoreTaskServiceGrpc.getGetTasksForEntityMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getGetTasksForEntityMethod = CoreTaskServiceGrpc.getGetTasksForEntityMethod) == null) {
          CoreTaskServiceGrpc.getGetTasksForEntityMethod = getGetTasksForEntityMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetTasksForEntity"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.GetCoreTasksRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTask.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("GetTasksForEntity"))
              .build();
        }
      }
    }
    return getGetTasksForEntityMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetContinuityTasksForOrgMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetContinuityTasksForOrg",
      requestType = com.iland.coretask.api.grpc.GetCoreTasksRequest.class,
      responseType = com.iland.coretask.api.grpc.CoreTask.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest,
      com.iland.coretask.api.grpc.CoreTask> getGetContinuityTasksForOrgMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask> getGetContinuityTasksForOrgMethod;
    if ((getGetContinuityTasksForOrgMethod = CoreTaskServiceGrpc.getGetContinuityTasksForOrgMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getGetContinuityTasksForOrgMethod = CoreTaskServiceGrpc.getGetContinuityTasksForOrgMethod) == null) {
          CoreTaskServiceGrpc.getGetContinuityTasksForOrgMethod = getGetContinuityTasksForOrgMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.GetCoreTasksRequest, com.iland.coretask.api.grpc.CoreTask>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetContinuityTasksForOrg"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.GetCoreTasksRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.CoreTask.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("GetContinuityTasksForOrg"))
              .build();
        }
      }
    }
    return getGetContinuityTasksForOrgMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.WaitForTaskRequest,
      com.google.protobuf.Empty> getWaitForTaskMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "WaitForTask",
      requestType = com.iland.coretask.api.grpc.WaitForTaskRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.WaitForTaskRequest,
      com.google.protobuf.Empty> getWaitForTaskMethod() {
    io.grpc.MethodDescriptor<com.iland.coretask.api.grpc.WaitForTaskRequest, com.google.protobuf.Empty> getWaitForTaskMethod;
    if ((getWaitForTaskMethod = CoreTaskServiceGrpc.getWaitForTaskMethod) == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        if ((getWaitForTaskMethod = CoreTaskServiceGrpc.getWaitForTaskMethod) == null) {
          CoreTaskServiceGrpc.getWaitForTaskMethod = getWaitForTaskMethod =
              io.grpc.MethodDescriptor.<com.iland.coretask.api.grpc.WaitForTaskRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "WaitForTask"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.coretask.api.grpc.WaitForTaskRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new CoreTaskServiceMethodDescriptorSupplier("WaitForTask"))
              .build();
        }
      }
    }
    return getWaitForTaskMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static CoreTaskServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<CoreTaskServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<CoreTaskServiceStub>() {
        @java.lang.Override
        public CoreTaskServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new CoreTaskServiceStub(channel, callOptions);
        }
      };
    return CoreTaskServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static CoreTaskServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<CoreTaskServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<CoreTaskServiceBlockingStub>() {
        @java.lang.Override
        public CoreTaskServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new CoreTaskServiceBlockingStub(channel, callOptions);
        }
      };
    return CoreTaskServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static CoreTaskServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<CoreTaskServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<CoreTaskServiceFutureStub>() {
        @java.lang.Override
        public CoreTaskServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new CoreTaskServiceFutureStub(channel, callOptions);
        }
      };
    return CoreTaskServiceFutureStub.newStub(factory, channel);
  }

  /**
   */
  public static abstract class CoreTaskServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void createCoreTask(com.iland.coretask.api.grpc.CoreTask request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateCoreTaskMethod(), responseObserver);
    }

    /**
     */
    public void updateCoreTask(com.iland.coretask.api.grpc.CoreTaskUpdateRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateCoreTaskMethod(), responseObserver);
    }

    /**
     */
    public void getCoreTask(com.iland.coretask.api.grpc.GetCoreTaskRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetCoreTaskMethod(), responseObserver);
    }

    /**
     */
    public void getCoreTaskByNativeId(com.iland.coretask.api.grpc.GetCoreTaskRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetCoreTaskByNativeIdMethod(), responseObserver);
    }

    /**
     */
    public void getCoreTasks(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.GetCoreTasksPage> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetCoreTasksMethod(), responseObserver);
    }

    /**
     */
    public void getSynchronizedTasksInOrg(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetSynchronizedTasksInOrgMethod(), responseObserver);
    }

    /**
     */
    public void getUnsynchronizedTasks(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetUnsynchronizedTasksMethod(), responseObserver);
    }

    /**
     */
    public void getUnsynchronizedTasksInOrg(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetUnsynchronizedTasksInOrgMethod(), responseObserver);
    }

    /**
     */
    public void getUnsynchronizedTasksForLocation(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetUnsynchronizedTasksForLocationMethod(), responseObserver);
    }

    /**
     */
    public void getTaskUuidsFromNativeId(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTaskUuidsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetTaskUuidsFromNativeIdMethod(), responseObserver);
    }

    /**
     */
    public void getTasksForEntity(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetTasksForEntityMethod(), responseObserver);
    }

    /**
     */
    public void getContinuityTasksForOrg(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetContinuityTasksForOrgMethod(), responseObserver);
    }

    /**
     */
    public void waitForTask(com.iland.coretask.api.grpc.WaitForTaskRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getWaitForTaskMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getCreateCoreTaskMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.CoreTask,
                com.iland.coretask.api.grpc.CoreTask>(
                  this, METHODID_CREATE_CORE_TASK)))
          .addMethod(
            getUpdateCoreTaskMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.CoreTaskUpdateRequest,
                com.iland.coretask.api.grpc.CoreTask>(
                  this, METHODID_UPDATE_CORE_TASK)))
          .addMethod(
            getGetCoreTaskMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.GetCoreTaskRequest,
                com.iland.coretask.api.grpc.CoreTask>(
                  this, METHODID_GET_CORE_TASK)))
          .addMethod(
            getGetCoreTaskByNativeIdMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.GetCoreTaskRequest,
                com.iland.coretask.api.grpc.CoreTask>(
                  this, METHODID_GET_CORE_TASK_BY_NATIVE_ID)))
          .addMethod(
            getGetCoreTasksMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.GetCoreTasksRequest,
                com.iland.coretask.api.grpc.GetCoreTasksPage>(
                  this, METHODID_GET_CORE_TASKS)))
          .addMethod(
            getGetSynchronizedTasksInOrgMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.GetCoreTasksRequest,
                com.iland.coretask.api.grpc.CoreTask>(
                  this, METHODID_GET_SYNCHRONIZED_TASKS_IN_ORG)))
          .addMethod(
            getGetUnsynchronizedTasksMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.GetCoreTasksRequest,
                com.iland.coretask.api.grpc.CoreTask>(
                  this, METHODID_GET_UNSYNCHRONIZED_TASKS)))
          .addMethod(
            getGetUnsynchronizedTasksInOrgMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.GetCoreTasksRequest,
                com.iland.coretask.api.grpc.CoreTask>(
                  this, METHODID_GET_UNSYNCHRONIZED_TASKS_IN_ORG)))
          .addMethod(
            getGetUnsynchronizedTasksForLocationMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.GetCoreTasksRequest,
                com.iland.coretask.api.grpc.CoreTask>(
                  this, METHODID_GET_UNSYNCHRONIZED_TASKS_FOR_LOCATION)))
          .addMethod(
            getGetTaskUuidsFromNativeIdMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.GetCoreTasksRequest,
                com.iland.coretask.api.grpc.CoreTaskUuidsResponse>(
                  this, METHODID_GET_TASK_UUIDS_FROM_NATIVE_ID)))
          .addMethod(
            getGetTasksForEntityMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.GetCoreTasksRequest,
                com.iland.coretask.api.grpc.CoreTask>(
                  this, METHODID_GET_TASKS_FOR_ENTITY)))
          .addMethod(
            getGetContinuityTasksForOrgMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.GetCoreTasksRequest,
                com.iland.coretask.api.grpc.CoreTask>(
                  this, METHODID_GET_CONTINUITY_TASKS_FOR_ORG)))
          .addMethod(
            getWaitForTaskMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.iland.coretask.api.grpc.WaitForTaskRequest,
                com.google.protobuf.Empty>(
                  this, METHODID_WAIT_FOR_TASK)))
          .build();
    }
  }

  /**
   */
  public static final class CoreTaskServiceStub extends io.grpc.stub.AbstractAsyncStub<CoreTaskServiceStub> {
    private CoreTaskServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CoreTaskServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new CoreTaskServiceStub(channel, callOptions);
    }

    /**
     */
    public void createCoreTask(com.iland.coretask.api.grpc.CoreTask request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateCoreTaskMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateCoreTask(com.iland.coretask.api.grpc.CoreTaskUpdateRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateCoreTaskMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getCoreTask(com.iland.coretask.api.grpc.GetCoreTaskRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetCoreTaskMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getCoreTaskByNativeId(com.iland.coretask.api.grpc.GetCoreTaskRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetCoreTaskByNativeIdMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getCoreTasks(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.GetCoreTasksPage> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetCoreTasksMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getSynchronizedTasksInOrg(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getGetSynchronizedTasksInOrgMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getUnsynchronizedTasks(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getGetUnsynchronizedTasksMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getUnsynchronizedTasksInOrg(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getGetUnsynchronizedTasksInOrgMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getUnsynchronizedTasksForLocation(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getGetUnsynchronizedTasksForLocationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getTaskUuidsFromNativeId(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTaskUuidsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetTaskUuidsFromNativeIdMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getTasksForEntity(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getGetTasksForEntityMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getContinuityTasksForOrg(com.iland.coretask.api.grpc.GetCoreTasksRequest request,
        io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getGetContinuityTasksForOrgMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void waitForTask(com.iland.coretask.api.grpc.WaitForTaskRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getWaitForTaskMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class CoreTaskServiceBlockingStub extends io.grpc.stub.AbstractBlockingStub<CoreTaskServiceBlockingStub> {
    private CoreTaskServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CoreTaskServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new CoreTaskServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.iland.coretask.api.grpc.CoreTask createCoreTask(com.iland.coretask.api.grpc.CoreTask request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateCoreTaskMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.coretask.api.grpc.CoreTask updateCoreTask(com.iland.coretask.api.grpc.CoreTaskUpdateRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateCoreTaskMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.coretask.api.grpc.CoreTask getCoreTask(com.iland.coretask.api.grpc.GetCoreTaskRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetCoreTaskMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.coretask.api.grpc.CoreTask getCoreTaskByNativeId(com.iland.coretask.api.grpc.GetCoreTaskRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetCoreTaskByNativeIdMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.coretask.api.grpc.GetCoreTasksPage getCoreTasks(com.iland.coretask.api.grpc.GetCoreTasksRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetCoreTasksMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.iland.coretask.api.grpc.CoreTask> getSynchronizedTasksInOrg(
        com.iland.coretask.api.grpc.GetCoreTasksRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getGetSynchronizedTasksInOrgMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.iland.coretask.api.grpc.CoreTask> getUnsynchronizedTasks(
        com.iland.coretask.api.grpc.GetCoreTasksRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getGetUnsynchronizedTasksMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.iland.coretask.api.grpc.CoreTask> getUnsynchronizedTasksInOrg(
        com.iland.coretask.api.grpc.GetCoreTasksRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getGetUnsynchronizedTasksInOrgMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.iland.coretask.api.grpc.CoreTask> getUnsynchronizedTasksForLocation(
        com.iland.coretask.api.grpc.GetCoreTasksRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getGetUnsynchronizedTasksForLocationMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.coretask.api.grpc.CoreTaskUuidsResponse getTaskUuidsFromNativeId(com.iland.coretask.api.grpc.GetCoreTasksRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetTaskUuidsFromNativeIdMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.iland.coretask.api.grpc.CoreTask> getTasksForEntity(
        com.iland.coretask.api.grpc.GetCoreTasksRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getGetTasksForEntityMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.iland.coretask.api.grpc.CoreTask> getContinuityTasksForOrg(
        com.iland.coretask.api.grpc.GetCoreTasksRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getGetContinuityTasksForOrgMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty waitForTask(com.iland.coretask.api.grpc.WaitForTaskRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getWaitForTaskMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class CoreTaskServiceFutureStub extends io.grpc.stub.AbstractFutureStub<CoreTaskServiceFutureStub> {
    private CoreTaskServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected CoreTaskServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new CoreTaskServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.coretask.api.grpc.CoreTask> createCoreTask(
        com.iland.coretask.api.grpc.CoreTask request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateCoreTaskMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.coretask.api.grpc.CoreTask> updateCoreTask(
        com.iland.coretask.api.grpc.CoreTaskUpdateRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateCoreTaskMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.coretask.api.grpc.CoreTask> getCoreTask(
        com.iland.coretask.api.grpc.GetCoreTaskRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetCoreTaskMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.coretask.api.grpc.CoreTask> getCoreTaskByNativeId(
        com.iland.coretask.api.grpc.GetCoreTaskRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetCoreTaskByNativeIdMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.coretask.api.grpc.GetCoreTasksPage> getCoreTasks(
        com.iland.coretask.api.grpc.GetCoreTasksRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetCoreTasksMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.coretask.api.grpc.CoreTaskUuidsResponse> getTaskUuidsFromNativeId(
        com.iland.coretask.api.grpc.GetCoreTasksRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetTaskUuidsFromNativeIdMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> waitForTask(
        com.iland.coretask.api.grpc.WaitForTaskRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getWaitForTaskMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_CORE_TASK = 0;
  private static final int METHODID_UPDATE_CORE_TASK = 1;
  private static final int METHODID_GET_CORE_TASK = 2;
  private static final int METHODID_GET_CORE_TASK_BY_NATIVE_ID = 3;
  private static final int METHODID_GET_CORE_TASKS = 4;
  private static final int METHODID_GET_SYNCHRONIZED_TASKS_IN_ORG = 5;
  private static final int METHODID_GET_UNSYNCHRONIZED_TASKS = 6;
  private static final int METHODID_GET_UNSYNCHRONIZED_TASKS_IN_ORG = 7;
  private static final int METHODID_GET_UNSYNCHRONIZED_TASKS_FOR_LOCATION = 8;
  private static final int METHODID_GET_TASK_UUIDS_FROM_NATIVE_ID = 9;
  private static final int METHODID_GET_TASKS_FOR_ENTITY = 10;
  private static final int METHODID_GET_CONTINUITY_TASKS_FOR_ORG = 11;
  private static final int METHODID_WAIT_FOR_TASK = 12;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final CoreTaskServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(CoreTaskServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_CORE_TASK:
          serviceImpl.createCoreTask((com.iland.coretask.api.grpc.CoreTask) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask>) responseObserver);
          break;
        case METHODID_UPDATE_CORE_TASK:
          serviceImpl.updateCoreTask((com.iland.coretask.api.grpc.CoreTaskUpdateRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask>) responseObserver);
          break;
        case METHODID_GET_CORE_TASK:
          serviceImpl.getCoreTask((com.iland.coretask.api.grpc.GetCoreTaskRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask>) responseObserver);
          break;
        case METHODID_GET_CORE_TASK_BY_NATIVE_ID:
          serviceImpl.getCoreTaskByNativeId((com.iland.coretask.api.grpc.GetCoreTaskRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask>) responseObserver);
          break;
        case METHODID_GET_CORE_TASKS:
          serviceImpl.getCoreTasks((com.iland.coretask.api.grpc.GetCoreTasksRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.GetCoreTasksPage>) responseObserver);
          break;
        case METHODID_GET_SYNCHRONIZED_TASKS_IN_ORG:
          serviceImpl.getSynchronizedTasksInOrg((com.iland.coretask.api.grpc.GetCoreTasksRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask>) responseObserver);
          break;
        case METHODID_GET_UNSYNCHRONIZED_TASKS:
          serviceImpl.getUnsynchronizedTasks((com.iland.coretask.api.grpc.GetCoreTasksRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask>) responseObserver);
          break;
        case METHODID_GET_UNSYNCHRONIZED_TASKS_IN_ORG:
          serviceImpl.getUnsynchronizedTasksInOrg((com.iland.coretask.api.grpc.GetCoreTasksRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask>) responseObserver);
          break;
        case METHODID_GET_UNSYNCHRONIZED_TASKS_FOR_LOCATION:
          serviceImpl.getUnsynchronizedTasksForLocation((com.iland.coretask.api.grpc.GetCoreTasksRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask>) responseObserver);
          break;
        case METHODID_GET_TASK_UUIDS_FROM_NATIVE_ID:
          serviceImpl.getTaskUuidsFromNativeId((com.iland.coretask.api.grpc.GetCoreTasksRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTaskUuidsResponse>) responseObserver);
          break;
        case METHODID_GET_TASKS_FOR_ENTITY:
          serviceImpl.getTasksForEntity((com.iland.coretask.api.grpc.GetCoreTasksRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask>) responseObserver);
          break;
        case METHODID_GET_CONTINUITY_TASKS_FOR_ORG:
          serviceImpl.getContinuityTasksForOrg((com.iland.coretask.api.grpc.GetCoreTasksRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.coretask.api.grpc.CoreTask>) responseObserver);
          break;
        case METHODID_WAIT_FOR_TASK:
          serviceImpl.waitForTask((com.iland.coretask.api.grpc.WaitForTaskRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class CoreTaskServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    CoreTaskServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.iland.coretask.api.grpc.CoreTaskApi.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("CoreTaskService");
    }
  }

  private static final class CoreTaskServiceFileDescriptorSupplier
      extends CoreTaskServiceBaseDescriptorSupplier {
    CoreTaskServiceFileDescriptorSupplier() {}
  }

  private static final class CoreTaskServiceMethodDescriptorSupplier
      extends CoreTaskServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    CoreTaskServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (CoreTaskServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new CoreTaskServiceFileDescriptorSupplier())
              .addMethod(getCreateCoreTaskMethod())
              .addMethod(getUpdateCoreTaskMethod())
              .addMethod(getGetCoreTaskMethod())
              .addMethod(getGetCoreTaskByNativeIdMethod())
              .addMethod(getGetCoreTasksMethod())
              .addMethod(getGetSynchronizedTasksInOrgMethod())
              .addMethod(getGetUnsynchronizedTasksMethod())
              .addMethod(getGetUnsynchronizedTasksInOrgMethod())
              .addMethod(getGetUnsynchronizedTasksForLocationMethod())
              .addMethod(getGetTaskUuidsFromNativeIdMethod())
              .addMethod(getGetTasksForEntityMethod())
              .addMethod(getGetContinuityTasksForOrgMethod())
              .addMethod(getWaitForTaskMethod())
              .build();
        }
      }
    }
    return result;
  }
}
