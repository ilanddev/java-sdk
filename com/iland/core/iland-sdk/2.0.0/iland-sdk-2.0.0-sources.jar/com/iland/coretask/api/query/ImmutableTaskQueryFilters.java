/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.coretask.api.query;

import com.google.common.base.MoreObjects;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import com.iland.common.query.entity.EntityFilters;
import com.iland.common.query.generation.GenerationFilters;
import com.iland.common.query.page.PagingFilters;
import com.iland.common.query.page.PagingOrder;
import com.iland.common.query.time.TimeFilters;
import com.iland.common.query.user.UserFilters;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import javax.annotation.concurrent.NotThreadSafe;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link TaskQueryFilters}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code new TaskQueryFilters.Builder()}.
 */
@Generated(from = "TaskQueryFilters", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableTaskQueryFilters implements TaskQueryFilters {
  private final @Nullable EntityFilters entityFilters;
  private final @Nullable TimeFilters timeFilters;
  private final @Nullable GenerationFilters generationFilters;
  private final Long offset;
  private final Long limit;
  private final PagingOrder order;
  private final @Nullable UserFilters userFilters;
  private final @Nullable Boolean isSynced;
  private final @Nullable String taskOperation;

  private ImmutableTaskQueryFilters(ImmutableTaskQueryFilters.Builder builder) {
    this.entityFilters = builder.entityFilters;
    this.timeFilters = builder.timeFilters;
    this.generationFilters = builder.generationFilters;
    this.userFilters = builder.userFilters;
    this.isSynced = builder.isSynced;
    this.taskOperation = builder.taskOperation;
    if (builder.offset != null) {
      initShim.offset(builder.offset);
    }
    if (builder.limit != null) {
      initShim.limit(builder.limit);
    }
    if (builder.order != null) {
      initShim.order(builder.order);
    }
    this.offset = initShim.getOffset();
    this.limit = initShim.getLimit();
    this.order = initShim.getOrder();
    this.initShim = null;
  }

  private ImmutableTaskQueryFilters(
      @Nullable EntityFilters entityFilters,
      @Nullable TimeFilters timeFilters,
      @Nullable GenerationFilters generationFilters,
      Long offset,
      Long limit,
      PagingOrder order,
      @Nullable UserFilters userFilters,
      @Nullable Boolean isSynced,
      @Nullable String taskOperation) {
    this.entityFilters = entityFilters;
    this.timeFilters = timeFilters;
    this.generationFilters = generationFilters;
    this.offset = offset;
    this.limit = limit;
    this.order = order;
    this.userFilters = userFilters;
    this.isSynced = isSynced;
    this.taskOperation = taskOperation;
    this.initShim = null;
  }

  private static final byte STAGE_INITIALIZING = -1;
  private static final byte STAGE_UNINITIALIZED = 0;
  private static final byte STAGE_INITIALIZED = 1;
  @SuppressWarnings("Immutable")
  private transient volatile InitShim initShim = new InitShim();

  @Generated(from = "TaskQueryFilters", generator = "Immutables")
  private final class InitShim {
    private byte offsetBuildStage = STAGE_UNINITIALIZED;
    private Long offset;

    Long getOffset() {
      if (offsetBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (offsetBuildStage == STAGE_UNINITIALIZED) {
        offsetBuildStage = STAGE_INITIALIZING;
        this.offset = Objects.requireNonNull(getOffsetInitialize(), "offset");
        offsetBuildStage = STAGE_INITIALIZED;
      }
      return this.offset;
    }

    void offset(Long offset) {
      this.offset = offset;
      offsetBuildStage = STAGE_INITIALIZED;
    }

    private byte limitBuildStage = STAGE_UNINITIALIZED;
    private Long limit;

    Long getLimit() {
      if (limitBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (limitBuildStage == STAGE_UNINITIALIZED) {
        limitBuildStage = STAGE_INITIALIZING;
        this.limit = Objects.requireNonNull(getLimitInitialize(), "limit");
        limitBuildStage = STAGE_INITIALIZED;
      }
      return this.limit;
    }

    void limit(Long limit) {
      this.limit = limit;
      limitBuildStage = STAGE_INITIALIZED;
    }

    private byte orderBuildStage = STAGE_UNINITIALIZED;
    private PagingOrder order;

    PagingOrder getOrder() {
      if (orderBuildStage == STAGE_INITIALIZING) throw new IllegalStateException(formatInitCycleMessage());
      if (orderBuildStage == STAGE_UNINITIALIZED) {
        orderBuildStage = STAGE_INITIALIZING;
        this.order = Objects.requireNonNull(getOrderInitialize(), "order");
        orderBuildStage = STAGE_INITIALIZED;
      }
      return this.order;
    }

    void order(PagingOrder order) {
      this.order = order;
      orderBuildStage = STAGE_INITIALIZED;
    }

    private String formatInitCycleMessage() {
      List<String> attributes = new ArrayList<>();
      if (offsetBuildStage == STAGE_INITIALIZING) attributes.add("offset");
      if (limitBuildStage == STAGE_INITIALIZING) attributes.add("limit");
      if (orderBuildStage == STAGE_INITIALIZING) attributes.add("order");
      return "Cannot build TaskQueryFilters, attribute initializers form cycle " + attributes;
    }
  }

  private Long getOffsetInitialize() {
    return TaskQueryFilters.super.getOffset();
  }

  private Long getLimitInitialize() {
    return TaskQueryFilters.super.getLimit();
  }

  private PagingOrder getOrderInitialize() {
    return TaskQueryFilters.super.getOrder();
  }

  /**
   * Get the entity related filters.
   * @return {@link EntityFilters} the entity filters
   */
  @Override
  public Optional<EntityFilters> getEntityFilters() {
    return Optional.ofNullable(entityFilters);
  }

  /**
   * Get the time related filters.
   * @return {@link Optional<TimeFilters>} the time filters
   */
  @Override
  public Optional<TimeFilters> getTimeFilters() {
    return Optional.ofNullable(timeFilters);
  }

  /**
   * Whether descendant tasks should be included.
   * Only relevant if the COMPANY entity type is supplied.
   * @return {@link Optional<GenerationFilters>} the generation filters
   */
  @Override
  public Optional<GenerationFilters> getGenerationFilters() {
    return Optional.ofNullable(generationFilters);
  }

  /**
   * @return The value of the {@code offset} attribute
   */
  @Override
  public Long getOffset() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.getOffset()
        : this.offset;
  }

  /**
   * @return The value of the {@code limit} attribute
   */
  @Override
  public Long getLimit() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.getLimit()
        : this.limit;
  }

  /**
   * @return The value of the {@code order} attribute
   */
  @Override
  public PagingOrder getOrder() {
    InitShim shim = this.initShim;
    return shim != null
        ? shim.getOrder()
        : this.order;
  }

  /**
   * Get the user related filters.
   * @return {@link Optional<UserFilters>} the user filters
   */
  @Override
  public Optional<UserFilters> getUserFilters() {
    return Optional.ofNullable(userFilters);
  }

  /**
   * Whether to return synced or unsynced tasks.
   * An absent value indicates both should be returned.
   * @return {@link Optional<Boolean>} is synced
   */
  @Override
  public Optional<Boolean> isSynced() {
    return Optional.ofNullable(isSynced);
  }

  /**
   * Get the task operation to filter results with.
   * @return {@link Optional<String>} task operation
   */
  @Override
  public Optional<String> getTaskOperation() {
    return Optional.ofNullable(taskOperation);
  }

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#getEntityFilters() entityFilters} attribute.
   * @param value The value for entityFilters
   * @return A modified copy of {@code this} object
   */
  public final ImmutableTaskQueryFilters withEntityFilters(EntityFilters value) {
    @Nullable EntityFilters newValue = Objects.requireNonNull(value, "entityFilters");
    if (this.entityFilters == newValue) return this;
    return new ImmutableTaskQueryFilters(
        newValue,
        this.timeFilters,
        this.generationFilters,
        this.offset,
        this.limit,
        this.order,
        this.userFilters,
        this.isSynced,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#getEntityFilters() entityFilters} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional A value for entityFilters
   * @return A modified copy of {@code this} object
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableTaskQueryFilters withEntityFilters(Optional<? extends EntityFilters> optional) {
    @Nullable EntityFilters value = optional.orElse(null);
    if (this.entityFilters == value) return this;
    return new ImmutableTaskQueryFilters(
        value,
        this.timeFilters,
        this.generationFilters,
        this.offset,
        this.limit,
        this.order,
        this.userFilters,
        this.isSynced,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#getTimeFilters() timeFilters} attribute.
   * @param value The value for timeFilters
   * @return A modified copy of {@code this} object
   */
  public final ImmutableTaskQueryFilters withTimeFilters(TimeFilters value) {
    @Nullable TimeFilters newValue = Objects.requireNonNull(value, "timeFilters");
    if (this.timeFilters == newValue) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        newValue,
        this.generationFilters,
        this.offset,
        this.limit,
        this.order,
        this.userFilters,
        this.isSynced,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#getTimeFilters() timeFilters} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional A value for timeFilters
   * @return A modified copy of {@code this} object
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableTaskQueryFilters withTimeFilters(Optional<? extends TimeFilters> optional) {
    @Nullable TimeFilters value = optional.orElse(null);
    if (this.timeFilters == value) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        value,
        this.generationFilters,
        this.offset,
        this.limit,
        this.order,
        this.userFilters,
        this.isSynced,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#getGenerationFilters() generationFilters} attribute.
   * @param value The value for generationFilters
   * @return A modified copy of {@code this} object
   */
  public final ImmutableTaskQueryFilters withGenerationFilters(GenerationFilters value) {
    @Nullable GenerationFilters newValue = Objects.requireNonNull(value, "generationFilters");
    if (this.generationFilters == newValue) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        this.timeFilters,
        newValue,
        this.offset,
        this.limit,
        this.order,
        this.userFilters,
        this.isSynced,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#getGenerationFilters() generationFilters} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional A value for generationFilters
   * @return A modified copy of {@code this} object
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableTaskQueryFilters withGenerationFilters(Optional<? extends GenerationFilters> optional) {
    @Nullable GenerationFilters value = optional.orElse(null);
    if (this.generationFilters == value) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        this.timeFilters,
        value,
        this.offset,
        this.limit,
        this.order,
        this.userFilters,
        this.isSynced,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link TaskQueryFilters#getOffset() offset} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for offset
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableTaskQueryFilters withOffset(Long value) {
    Long newValue = Objects.requireNonNull(value, "offset");
    if (this.offset.equals(newValue)) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        this.timeFilters,
        this.generationFilters,
        newValue,
        this.limit,
        this.order,
        this.userFilters,
        this.isSynced,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link TaskQueryFilters#getLimit() limit} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for limit
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableTaskQueryFilters withLimit(Long value) {
    Long newValue = Objects.requireNonNull(value, "limit");
    if (this.limit.equals(newValue)) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        this.timeFilters,
        this.generationFilters,
        this.offset,
        newValue,
        this.order,
        this.userFilters,
        this.isSynced,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link TaskQueryFilters#getOrder() order} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for order
   * @return A modified copy of the {@code this} object
   */
  public final ImmutableTaskQueryFilters withOrder(PagingOrder value) {
    PagingOrder newValue = Objects.requireNonNull(value, "order");
    if (this.order == newValue) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        this.timeFilters,
        this.generationFilters,
        this.offset,
        this.limit,
        newValue,
        this.userFilters,
        this.isSynced,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#getUserFilters() userFilters} attribute.
   * @param value The value for userFilters
   * @return A modified copy of {@code this} object
   */
  public final ImmutableTaskQueryFilters withUserFilters(UserFilters value) {
    @Nullable UserFilters newValue = Objects.requireNonNull(value, "userFilters");
    if (this.userFilters == newValue) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        this.timeFilters,
        this.generationFilters,
        this.offset,
        this.limit,
        this.order,
        newValue,
        this.isSynced,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#getUserFilters() userFilters} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional A value for userFilters
   * @return A modified copy of {@code this} object
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableTaskQueryFilters withUserFilters(Optional<? extends UserFilters> optional) {
    @Nullable UserFilters value = optional.orElse(null);
    if (this.userFilters == value) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        this.timeFilters,
        this.generationFilters,
        this.offset,
        this.limit,
        this.order,
        value,
        this.isSynced,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#isSynced() isSynced} attribute.
   * @param value The value for isSynced
   * @return A modified copy of {@code this} object
   */
  public final ImmutableTaskQueryFilters withIsSynced(boolean value) {
    @Nullable Boolean newValue = value;
    if (Objects.equals(this.isSynced, newValue)) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        this.timeFilters,
        this.generationFilters,
        this.offset,
        this.limit,
        this.order,
        this.userFilters,
        newValue,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#isSynced() isSynced} attribute.
   * An equality check is used on inner nullable value to prevent copying of the same value by returning {@code this}.
   * @param optional A value for isSynced
   * @return A modified copy of {@code this} object
   */
  public final ImmutableTaskQueryFilters withIsSynced(Optional<Boolean> optional) {
    @Nullable Boolean value = optional.orElse(null);
    if (Objects.equals(this.isSynced, value)) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        this.timeFilters,
        this.generationFilters,
        this.offset,
        this.limit,
        this.order,
        this.userFilters,
        value,
        this.taskOperation);
  }

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link TaskQueryFilters#getTaskOperation() taskOperation} attribute.
   * @param value The value for taskOperation
   * @return A modified copy of {@code this} object
   */
  public final ImmutableTaskQueryFilters withTaskOperation(String value) {
    @Nullable String newValue = Objects.requireNonNull(value, "taskOperation");
    if (Objects.equals(this.taskOperation, newValue)) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        this.timeFilters,
        this.generationFilters,
        this.offset,
        this.limit,
        this.order,
        this.userFilters,
        this.isSynced,
        newValue);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link TaskQueryFilters#getTaskOperation() taskOperation} attribute.
   * An equality check is used on inner nullable value to prevent copying of the same value by returning {@code this}.
   * @param optional A value for taskOperation
   * @return A modified copy of {@code this} object
   */
  public final ImmutableTaskQueryFilters withTaskOperation(Optional<String> optional) {
    @Nullable String value = optional.orElse(null);
    if (Objects.equals(this.taskOperation, value)) return this;
    return new ImmutableTaskQueryFilters(
        this.entityFilters,
        this.timeFilters,
        this.generationFilters,
        this.offset,
        this.limit,
        this.order,
        this.userFilters,
        this.isSynced,
        value);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableTaskQueryFilters} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableTaskQueryFilters
        && equalTo(0, (ImmutableTaskQueryFilters) another);
  }

  private boolean equalTo(int synthetic, ImmutableTaskQueryFilters another) {
    return Objects.equals(entityFilters, another.entityFilters)
        && Objects.equals(timeFilters, another.timeFilters)
        && Objects.equals(generationFilters, another.generationFilters)
        && offset.equals(another.offset)
        && limit.equals(another.limit)
        && order.equals(another.order)
        && Objects.equals(userFilters, another.userFilters)
        && Objects.equals(isSynced, another.isSynced)
        && Objects.equals(taskOperation, another.taskOperation);
  }

  /**
   * Computes a hash code from attributes: {@code entityFilters}, {@code timeFilters}, {@code generationFilters}, {@code offset}, {@code limit}, {@code order}, {@code userFilters}, {@code isSynced}, {@code taskOperation}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(entityFilters);
    h += (h << 5) + Objects.hashCode(timeFilters);
    h += (h << 5) + Objects.hashCode(generationFilters);
    h += (h << 5) + offset.hashCode();
    h += (h << 5) + limit.hashCode();
    h += (h << 5) + order.hashCode();
    h += (h << 5) + Objects.hashCode(userFilters);
    h += (h << 5) + Objects.hashCode(isSynced);
    h += (h << 5) + Objects.hashCode(taskOperation);
    return h;
  }

  /**
   * Prints the immutable value {@code TaskQueryFilters} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("TaskQueryFilters")
        .omitNullValues()
        .add("entityFilters", entityFilters)
        .add("timeFilters", timeFilters)
        .add("generationFilters", generationFilters)
        .add("offset", offset)
        .add("limit", limit)
        .add("order", order)
        .add("userFilters", userFilters)
        .add("isSynced", isSynced)
        .add("taskOperation", taskOperation)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link TaskQueryFilters} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable TaskQueryFilters instance
   */
  public static ImmutableTaskQueryFilters copyOf(TaskQueryFilters instance) {
    if (instance instanceof ImmutableTaskQueryFilters) {
      return (ImmutableTaskQueryFilters) instance;
    }
    return new TaskQueryFilters.Builder()
        .from(instance)
        .build();
  }

  /**
   * Builds instances of type {@link ImmutableTaskQueryFilters ImmutableTaskQueryFilters}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "TaskQueryFilters", generator = "Immutables")
  @NotThreadSafe
  public static class Builder {
    private @Nullable EntityFilters entityFilters;
    private @Nullable TimeFilters timeFilters;
    private @Nullable GenerationFilters generationFilters;
    private @Nullable Long offset;
    private @Nullable Long limit;
    private @Nullable PagingOrder order;
    private @Nullable UserFilters userFilters;
    private @Nullable Boolean isSynced;
    private @Nullable String taskOperation;

    /**
     * Creates a builder for {@link ImmutableTaskQueryFilters ImmutableTaskQueryFilters} instances.
     * <pre>
     * new TaskQueryFilters.Builder()
     *    .entityFilters(com.iland.common.query.entity.EntityFilters) // optional {@link TaskQueryFilters#getEntityFilters() entityFilters}
     *    .timeFilters(com.iland.common.query.time.TimeFilters) // optional {@link TaskQueryFilters#getTimeFilters() timeFilters}
     *    .generationFilters(com.iland.common.query.generation.GenerationFilters) // optional {@link TaskQueryFilters#getGenerationFilters() generationFilters}
     *    .offset(Long) // optional {@link TaskQueryFilters#getOffset() offset}
     *    .limit(Long) // optional {@link TaskQueryFilters#getLimit() limit}
     *    .order(com.iland.common.query.page.PagingOrder) // optional {@link TaskQueryFilters#getOrder() order}
     *    .userFilters(com.iland.common.query.user.UserFilters) // optional {@link TaskQueryFilters#getUserFilters() userFilters}
     *    .isSynced(Boolean) // optional {@link TaskQueryFilters#isSynced() isSynced}
     *    .taskOperation(String) // optional {@link TaskQueryFilters#getTaskOperation() taskOperation}
     *    .build();
     * </pre>
     */
    public Builder() {
      if (!(this instanceof TaskQueryFilters.Builder)) {
        throw new UnsupportedOperationException("Use: new TaskQueryFilters.Builder()");
      }
    }

    /**
     * Fill a builder with attribute values from the provided {@code com.iland.coretask.api.query.TaskQueryFilters} instance.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder from(TaskQueryFilters instance) {
      Objects.requireNonNull(instance, "instance");
      from((Object) instance);
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Fill a builder with attribute values from the provided {@code com.iland.common.query.page.PagingFilters} instance.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder from(PagingFilters instance) {
      Objects.requireNonNull(instance, "instance");
      from((Object) instance);
      return (TaskQueryFilters.Builder) this;
    }

    private void from(Object object) {
      @Var long bits = 0;
      if (object instanceof TaskQueryFilters) {
        TaskQueryFilters instance = (TaskQueryFilters) object;
        Optional<UserFilters> userFiltersOptional = instance.getUserFilters();
        if (userFiltersOptional.isPresent()) {
          userFilters(userFiltersOptional);
        }
        Optional<Boolean> isSyncedOptional = instance.isSynced();
        if (isSyncedOptional.isPresent()) {
          isSynced(isSyncedOptional);
        }
        if ((bits & 0x1L) == 0) {
          offset(instance.getOffset());
          bits |= 0x1L;
        }
        Optional<EntityFilters> entityFiltersOptional = instance.getEntityFilters();
        if (entityFiltersOptional.isPresent()) {
          entityFilters(entityFiltersOptional);
        }
        if ((bits & 0x2L) == 0) {
          limit(instance.getLimit());
          bits |= 0x2L;
        }
        Optional<String> taskOperationOptional = instance.getTaskOperation();
        if (taskOperationOptional.isPresent()) {
          taskOperation(taskOperationOptional);
        }
        Optional<TimeFilters> timeFiltersOptional = instance.getTimeFilters();
        if (timeFiltersOptional.isPresent()) {
          timeFilters(timeFiltersOptional);
        }
        Optional<GenerationFilters> generationFiltersOptional = instance.getGenerationFilters();
        if (generationFiltersOptional.isPresent()) {
          generationFilters(generationFiltersOptional);
        }
        if ((bits & 0x4L) == 0) {
          order(instance.getOrder());
          bits |= 0x4L;
        }
      }
      if (object instanceof PagingFilters) {
        PagingFilters instance = (PagingFilters) object;
        if ((bits & 0x1L) == 0) {
          offset(instance.getOffset());
          bits |= 0x1L;
        }
        if ((bits & 0x2L) == 0) {
          limit(instance.getLimit());
          bits |= 0x2L;
        }
        if ((bits & 0x4L) == 0) {
          order(instance.getOrder());
          bits |= 0x4L;
        }
      }
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#getEntityFilters() entityFilters} to entityFilters.
     * @param entityFilters The value for entityFilters
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder entityFilters(EntityFilters entityFilters) {
      this.entityFilters = Objects.requireNonNull(entityFilters, "entityFilters");
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#getEntityFilters() entityFilters} to entityFilters.
     * @param entityFilters The value for entityFilters
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder entityFilters(Optional<? extends EntityFilters> entityFilters) {
      this.entityFilters = entityFilters.orElse(null);
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#getTimeFilters() timeFilters} to timeFilters.
     * @param timeFilters The value for timeFilters
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder timeFilters(TimeFilters timeFilters) {
      this.timeFilters = Objects.requireNonNull(timeFilters, "timeFilters");
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#getTimeFilters() timeFilters} to timeFilters.
     * @param timeFilters The value for timeFilters
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder timeFilters(Optional<? extends TimeFilters> timeFilters) {
      this.timeFilters = timeFilters.orElse(null);
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#getGenerationFilters() generationFilters} to generationFilters.
     * @param generationFilters The value for generationFilters
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder generationFilters(GenerationFilters generationFilters) {
      this.generationFilters = Objects.requireNonNull(generationFilters, "generationFilters");
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#getGenerationFilters() generationFilters} to generationFilters.
     * @param generationFilters The value for generationFilters
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder generationFilters(Optional<? extends GenerationFilters> generationFilters) {
      this.generationFilters = generationFilters.orElse(null);
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the value for the {@link TaskQueryFilters#getOffset() offset} attribute.
     * <p><em>If not set, this attribute will have a default value as returned by the initializer of {@link TaskQueryFilters#getOffset() offset}.</em>
     * @param offset The value for offset 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder offset(Long offset) {
      this.offset = Objects.requireNonNull(offset, "offset");
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the value for the {@link TaskQueryFilters#getLimit() limit} attribute.
     * <p><em>If not set, this attribute will have a default value as returned by the initializer of {@link TaskQueryFilters#getLimit() limit}.</em>
     * @param limit The value for limit 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder limit(Long limit) {
      this.limit = Objects.requireNonNull(limit, "limit");
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the value for the {@link TaskQueryFilters#getOrder() order} attribute.
     * <p><em>If not set, this attribute will have a default value as returned by the initializer of {@link TaskQueryFilters#getOrder() order}.</em>
     * @param order The value for order 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder order(PagingOrder order) {
      this.order = Objects.requireNonNull(order, "order");
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#getUserFilters() userFilters} to userFilters.
     * @param userFilters The value for userFilters
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder userFilters(UserFilters userFilters) {
      this.userFilters = Objects.requireNonNull(userFilters, "userFilters");
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#getUserFilters() userFilters} to userFilters.
     * @param userFilters The value for userFilters
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder userFilters(Optional<? extends UserFilters> userFilters) {
      this.userFilters = userFilters.orElse(null);
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#isSynced() isSynced} to isSynced.
     * @param isSynced The value for isSynced
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder isSynced(boolean isSynced) {
      this.isSynced = isSynced;
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#isSynced() isSynced} to isSynced.
     * @param isSynced The value for isSynced
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder isSynced(Optional<Boolean> isSynced) {
      this.isSynced = isSynced.orElse(null);
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#getTaskOperation() taskOperation} to taskOperation.
     * @param taskOperation The value for taskOperation
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder taskOperation(String taskOperation) {
      this.taskOperation = Objects.requireNonNull(taskOperation, "taskOperation");
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Initializes the optional value {@link TaskQueryFilters#getTaskOperation() taskOperation} to taskOperation.
     * @param taskOperation The value for taskOperation
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final TaskQueryFilters.Builder taskOperation(Optional<String> taskOperation) {
      this.taskOperation = taskOperation.orElse(null);
      return (TaskQueryFilters.Builder) this;
    }

    /**
     * Builds a new {@link ImmutableTaskQueryFilters ImmutableTaskQueryFilters}.
     * @return An immutable instance of TaskQueryFilters
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableTaskQueryFilters build() {
      return new ImmutableTaskQueryFilters(this);
    }
  }
}
