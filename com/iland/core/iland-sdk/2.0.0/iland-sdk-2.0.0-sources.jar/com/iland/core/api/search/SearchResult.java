/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.search;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Search Result.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class SearchResult implements Serializable {

  private static final long serialVersionUID = -6839216299682693390L;

  @Expose
  @SerializedName(SearchResultField.QUERY)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final String query;

  @Expose
  @SerializedName(SearchResultField.OFFSET)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final int offset;

  @Expose
  @SerializedName(SearchResultField.LIMIT)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final int limit;

  @Expose
  @SerializedName(SearchResultField.RETURNED_HITS)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final int returnedHits;

  @Expose
  @SerializedName(SearchResultField.TOTAL_HITS)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final int totalHits;

  @Expose
  @SerializedName(SearchResultField.RESULTS)
  @Since(ApiVersion.ZERO_DOT_ONE)
  private final List<Map<String, String>> results;

  public SearchResult(final String query, final int offst, final int limit,
      final int returnedHits, final int totalHits,
      final List<Map<String, String>> results) {
    this.query = query;
    this.offset = offst;
    this.limit = limit;
    this.returnedHits = returnedHits;
    this.totalHits = totalHits;
    this.results = results;
  }

  /**
   * Get the query string for the search.
   *
   * @return {@link String} query string
   * @requiredField
   */
  public String getQuery() {
    return query;
  }

  /**
   * Get the number of hits returned.
   *
   * @return number of hits returned
   * @requiredField
   */
  public int getReturnedHits() {
    return returnedHits;
  }

  /**
   * A list of search results as a map of properties in the returned document.
   *
   * @return search results list
   * @requiredField
   */
  public List<Map<String, String>> getResults() {
    return results;
  }

  /**
   * Get the total number of hits from query.
   *
   * @return total hits
   * @requiredField
   */
  public int getTotalHits() {
    return totalHits;
  }

  /**
   * Return the top scoring search result.
   *
   * @return top search result
   * @exclude
   */
  public Map<String, String> getTopResult() {
    if (results.size() > 0) {
      return results.get(0);
    } else {
      return new HashMap<>();
    }
  }

  /**
   * Get the page offset of search results.
   *
   * @return page offset
   * @requiredField
   */
  public int getOffset() {
    return offset;
  }

  /**
   * Get the page limit of search results.
   *
   * @return page limit
   * @requiredField
   */
  public int getLimit() {
    return limit;
  }

}
