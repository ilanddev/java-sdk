/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import com.google.common.base.MoreObjects;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link StorageHistoryItem}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableStorageHistoryItem.builder()}.
 */
@Generated(from = "StorageHistoryItem", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableStorageHistoryItem
    implements StorageHistoryItem {
  private final @Nullable Instant timestamp;
  private final @Nullable Long contractedStorageBytes;
  private final @Nullable Long storageConsumedBytes;

  private ImmutableStorageHistoryItem(
      @Nullable Instant timestamp,
      @Nullable Long contractedStorageBytes,
      @Nullable Long storageConsumedBytes) {
    this.timestamp = timestamp;
    this.contractedStorageBytes = contractedStorageBytes;
    this.storageConsumedBytes = storageConsumedBytes;
  }

  /**
   * @return The value of the {@code timestamp} attribute
   */
  @Override
  public Optional<Instant> timestamp() {
    return Optional.ofNullable(timestamp);
  }

  /**
   * @return The value of the {@code contractedStorageBytes} attribute
   */
  @Override
  public Optional<Long> contractedStorageBytes() {
    return Optional.ofNullable(contractedStorageBytes);
  }

  /**
   * @return The value of the {@code storageConsumedBytes} attribute
   */
  @Override
  public Optional<Long> storageConsumedBytes() {
    return Optional.ofNullable(storageConsumedBytes);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link StorageHistoryItem#timestamp() timestamp} attribute.
   * @param value The value for timestamp
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableStorageHistoryItem withTimestamp(Instant value) {
    Instant newValue = Objects.requireNonNull(value, "timestamp");
    if (this.timestamp == newValue) return this;
    return new ImmutableStorageHistoryItem(newValue, this.contractedStorageBytes, this.storageConsumedBytes);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link StorageHistoryItem#timestamp() timestamp} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for timestamp
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableStorageHistoryItem withTimestamp(Optional<? extends Instant> optional) {
    @Nullable Instant value = optional.orElse(null);
    if (this.timestamp == value) return this;
    return new ImmutableStorageHistoryItem(value, this.contractedStorageBytes, this.storageConsumedBytes);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link StorageHistoryItem#contractedStorageBytes() contractedStorageBytes} attribute.
   * @param value The value for contractedStorageBytes
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableStorageHistoryItem withContractedStorageBytes(long value) {
    @Nullable Long newValue = value;
    if (Objects.equals(this.contractedStorageBytes, newValue)) return this;
    return new ImmutableStorageHistoryItem(this.timestamp, newValue, this.storageConsumedBytes);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link StorageHistoryItem#contractedStorageBytes() contractedStorageBytes} attribute.
   * An equality check is used on inner value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for contractedStorageBytes
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableStorageHistoryItem withContractedStorageBytes(Optional<Long> optional) {
    @Nullable Long value = optional.orElse(null);
    if (Objects.equals(this.contractedStorageBytes, value)) return this;
    return new ImmutableStorageHistoryItem(this.timestamp, value, this.storageConsumedBytes);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link StorageHistoryItem#storageConsumedBytes() storageConsumedBytes} attribute.
   * @param value The value for storageConsumedBytes
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableStorageHistoryItem withStorageConsumedBytes(long value) {
    @Nullable Long newValue = value;
    if (Objects.equals(this.storageConsumedBytes, newValue)) return this;
    return new ImmutableStorageHistoryItem(this.timestamp, this.contractedStorageBytes, newValue);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link StorageHistoryItem#storageConsumedBytes() storageConsumedBytes} attribute.
   * An equality check is used on inner value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for storageConsumedBytes
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableStorageHistoryItem withStorageConsumedBytes(Optional<Long> optional) {
    @Nullable Long value = optional.orElse(null);
    if (Objects.equals(this.storageConsumedBytes, value)) return this;
    return new ImmutableStorageHistoryItem(this.timestamp, this.contractedStorageBytes, value);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableStorageHistoryItem} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableStorageHistoryItem
        && equalsByValue((ImmutableStorageHistoryItem) another);
  }

  private boolean equalsByValue(ImmutableStorageHistoryItem another) {
    return Objects.equals(timestamp, another.timestamp)
        && Objects.equals(contractedStorageBytes, another.contractedStorageBytes)
        && Objects.equals(storageConsumedBytes, another.storageConsumedBytes);
  }

  /**
   * Computes a hash code from attributes: {@code timestamp}, {@code contractedStorageBytes}, {@code storageConsumedBytes}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(timestamp);
    h += (h << 5) + Objects.hashCode(contractedStorageBytes);
    h += (h << 5) + Objects.hashCode(storageConsumedBytes);
    return h;
  }

  /**
   * Prints the immutable value {@code StorageHistoryItem} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("StorageHistoryItem")
        .omitNullValues()
        .add("timestamp", timestamp)
        .add("contractedStorageBytes", contractedStorageBytes)
        .add("storageConsumedBytes", storageConsumedBytes)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link StorageHistoryItem} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable StorageHistoryItem instance
   */
  public static ImmutableStorageHistoryItem copyOf(StorageHistoryItem instance) {
    if (instance instanceof ImmutableStorageHistoryItem) {
      return (ImmutableStorageHistoryItem) instance;
    }
    return ImmutableStorageHistoryItem.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableStorageHistoryItem ImmutableStorageHistoryItem}.
   * <pre>
   * ImmutableStorageHistoryItem.builder()
   *    .timestamp(Optional&lt;java.time.Instant&gt;) // optional {@link StorageHistoryItem#timestamp() timestamp}
   *    .contractedStorageBytes(Optional&lt;Long&gt;) // optional {@link StorageHistoryItem#contractedStorageBytes() contractedStorageBytes}
   *    .storageConsumedBytes(Optional&lt;Long&gt;) // optional {@link StorageHistoryItem#storageConsumedBytes() storageConsumedBytes}
   *    .build();
   * </pre>
   * @return A new ImmutableStorageHistoryItem builder
   */
  public static ImmutableStorageHistoryItem.Builder builder() {
    return new ImmutableStorageHistoryItem.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableStorageHistoryItem ImmutableStorageHistoryItem}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "StorageHistoryItem", generator = "Immutables")
  public static final class Builder {
    private @Nullable Instant timestamp;
    private @Nullable Long contractedStorageBytes;
    private @Nullable Long storageConsumedBytes;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code StorageHistoryItem} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(StorageHistoryItem instance) {
      Objects.requireNonNull(instance, "instance");
      Optional<Instant> timestampOptional = instance.timestamp();
      if (timestampOptional.isPresent()) {
        timestamp(timestampOptional);
      }
      Optional<Long> contractedStorageBytesOptional = instance.contractedStorageBytes();
      if (contractedStorageBytesOptional.isPresent()) {
        contractedStorageBytes(contractedStorageBytesOptional);
      }
      Optional<Long> storageConsumedBytesOptional = instance.storageConsumedBytes();
      if (storageConsumedBytesOptional.isPresent()) {
        storageConsumedBytes(storageConsumedBytesOptional);
      }
      return this;
    }

    /**
     * Initializes the optional value {@link StorageHistoryItem#timestamp() timestamp} to timestamp.
     * @param timestamp The value for timestamp
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder timestamp(Instant timestamp) {
      this.timestamp = Objects.requireNonNull(timestamp, "timestamp");
      return this;
    }

    /**
     * Initializes the optional value {@link StorageHistoryItem#timestamp() timestamp} to timestamp.
     * @param timestamp The value for timestamp
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder timestamp(Optional<? extends Instant> timestamp) {
      this.timestamp = timestamp.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link StorageHistoryItem#contractedStorageBytes() contractedStorageBytes} to contractedStorageBytes.
     * @param contractedStorageBytes The value for contractedStorageBytes
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder contractedStorageBytes(long contractedStorageBytes) {
      this.contractedStorageBytes = contractedStorageBytes;
      return this;
    }

    /**
     * Initializes the optional value {@link StorageHistoryItem#contractedStorageBytes() contractedStorageBytes} to contractedStorageBytes.
     * @param contractedStorageBytes The value for contractedStorageBytes
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder contractedStorageBytes(Optional<Long> contractedStorageBytes) {
      this.contractedStorageBytes = contractedStorageBytes.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link StorageHistoryItem#storageConsumedBytes() storageConsumedBytes} to storageConsumedBytes.
     * @param storageConsumedBytes The value for storageConsumedBytes
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder storageConsumedBytes(long storageConsumedBytes) {
      this.storageConsumedBytes = storageConsumedBytes;
      return this;
    }

    /**
     * Initializes the optional value {@link StorageHistoryItem#storageConsumedBytes() storageConsumedBytes} to storageConsumedBytes.
     * @param storageConsumedBytes The value for storageConsumedBytes
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder storageConsumedBytes(Optional<Long> storageConsumedBytes) {
      this.storageConsumedBytes = storageConsumedBytes.orElse(null);
      return this;
    }

    /**
     * Builds a new {@link ImmutableStorageHistoryItem ImmutableStorageHistoryItem}.
     * @return An immutable instance of StorageHistoryItem
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableStorageHistoryItem build() {
      return new ImmutableStorageHistoryItem(timestamp, contractedStorageBytes, storageConsumedBytes);
    }
  }
}
