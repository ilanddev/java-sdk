/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.iaas.protectionsource;

import java.util.Map;

import javax.annotation.Nonnull;

import com.iland.cohesity.iaas.backups.protectionsources.PublicProtectionSource;
import com.iland.core.api.entity.AbstractEntity;
import com.iland.core.api.entity.Entity;
import com.iland.core.api.entity.EntityAncestorUtil;
import com.iland.core.api.entity.LocationEntity;
import com.iland.core.model.EntityType;

/**
 * Entity Wrapper for {@link PublicProtectionSource}.
 */
public final class ProtectionSourceEntity extends AbstractEntity
	implements LocationEntity {

	private final PublicProtectionSource protectionSource;

	private Map<com.iland.common.entity.EntityType, String> ancestors;

	public ProtectionSourceEntity(
		final PublicProtectionSource protectionSource) {
		super(protectionSource.uid().value(), false, null,
			protectionSource.name(), protectionSource.lastRefresh());
		this.protectionSource = protectionSource;
	}

	@Override
	public EntityType getEntityType() {
		return EntityType.IAAS_PROTECTION_SOURCE;
	}

	@Override
	public boolean entityEquals(final Entity other) {
		if (other == null || !EntityType.IAAS_PROTECTION_SOURCE.equals(
			other.getEntityType())) {
			return false;
		}

		return ((ProtectionSourceEntity) other).getProtectionSource()
			.equals(getProtectionSource());
	}

	/**
	 * Gets the {@link PublicProtectionSource protection source}.
	 *
	 * @return {@link PublicProtectionSource}
	 */
	public PublicProtectionSource getProtectionSource() {
		return protectionSource;
	}

	@Nonnull
	@Override
	public String getLocationId() {
		return protectionSource.locationId().value();
	}

	@Nonnull
	@Override
	public String getCompanyId() {
		return protectionSource.companyId().value();
	}

	@Nonnull
	@Override
	public Map<com.iland.common.entity.EntityType, String> getAncestors() {
		if (ancestors == null || ancestors.isEmpty()) {
			ancestors = new EntityAncestorUtil.VdcAncestors(
					getCompanyId(), getLocationId(),
					protectionSource.orgUuid().value(),
					protectionSource.vdcUuid().value()).buildAncestors();
		}

		return ancestors;
	}

}
