/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.iaas.backup;

import java.time.Instant;
import java.util.Map;

import javax.annotation.Nonnull;

import com.iland.cohesity.iaas.backups.backupgroups.api.model.BackupGroup;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.BackupGroupV2;
import com.iland.core.api.entity.AbstractEntity;
import com.iland.core.api.entity.Entity;
import com.iland.core.api.entity.EntityAncestorUtil;
import com.iland.core.api.entity.LocationEntity;
import com.iland.core.model.EntityType;

/**
 * Entity Wrapper for {@link BackupGroupV2}.
 *
 * @author <a href="mailto:tspilman@iland.com">Tag Spilman</a>
 */
public final class BackupGroupV2Entity extends AbstractEntity
	implements LocationEntity {

	private final BackupGroupV2 backupGroup;

	private Map<com.iland.common.entity.EntityType, String> ancestors;

	public BackupGroupV2Entity(final BackupGroupV2 backupGroup) {
		super(backupGroup.uid().value(), backupGroup.isDeleted().orElse(false),
			backupGroup.isDeleted().orElse(false) ?
				backupGroup.modifiedTime()
					.orElse(backupGroup.creationTime().orElse(Instant.now())) :
				null, backupGroup.name(), backupGroup.modifiedTime()
				.orElse(backupGroup.creationTime().orElse(Instant.now())));
		this.backupGroup = backupGroup;
	}

	@Override
	public EntityType getEntityType() {
		return EntityType.IAAS_BACKUP_GROUP;
	}

	@Override
	public boolean entityEquals(final Entity other) {
		if (other == null || !EntityType.IAAS_BACKUP_GROUP.equals(
			other.getEntityType())) {
			return false;
		}
		return ((BackupGroupV2Entity) other).getBackupGroup()
			.equals(getBackupGroup());
	}

	/**
	 * Gets the backup group.
	 *
	 * @return {@link BackupGroup}
	 */
	public BackupGroupV2 getBackupGroup() {
		return backupGroup;
	}

	@Nonnull
	@Override
	public String getLocationId() {
		return backupGroup.locationId().value();
	}

	@Nonnull
	@Override
	public String getCompanyId() {
		return backupGroup.companyId().value();
	}

	@Nonnull
	@Override
	public Map<com.iland.common.entity.EntityType, String> getAncestors() {
		if (ancestors == null || ancestors.isEmpty()) {
			ancestors = new EntityAncestorUtil.VdcAncestors(
					getCompanyId(), getLocationId(),
					backupGroup.orgUuid().value(),
					backupGroup.vdcUuid().value()).buildAncestors();
		}

		return ancestors;
	}

}
