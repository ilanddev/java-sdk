/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.netanalysis;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.util.IlandSerializedName;

/**
 * FirewallTrafficDrop.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class FirewallTrafficLog implements Serializable {

  private static final long serialVersionUID = -440122733075099792L;

  @Expose
  @IlandSerializedName(FirewallTrafficLogField.EDGE_UUID)
  @Since(ApiVersion.ZERO_DOT_TWO)
  private final String edgeUuid;

  @Expose
  @IlandSerializedName(FirewallTrafficLogField.TIME)
  @Since(ApiVersion.ZERO_DOT_TWO)
  private final Date timestamp;

  @Expose
  @IlandSerializedName(FirewallTrafficLogField.DESTINATION_PORT)
  @Since(ApiVersion.ZERO_DOT_TWO)
  private Integer destinationPort;

  @Expose
  @IlandSerializedName(FirewallTrafficLogField.COUNT)
  @Since(ApiVersion.ZERO_DOT_TWO)
  private final int count;

  @Expose
  @IlandSerializedName(FirewallTrafficLogField.DESTINATION_IP)
  @Since(ApiVersion.ZERO_DOT_TWO)
  private final String destinationIp;

  @Expose
  @IlandSerializedName(FirewallTrafficLogField.ACTION)
  @Since(ApiVersion.ZERO_DOT_TWO)
  private String action;

  @Expose
  @IlandSerializedName(FirewallTrafficLogField.SOURCE_IP)
  @Since(ApiVersion.ZERO_DOT_TWO)
  private String sourceIp;

  @Expose
  @IlandSerializedName(FirewallTrafficLogField.PROTOCOL)
  @Since(ApiVersion.ZERO_DOT_TWO)
  private String protocol;

  public FirewallTrafficLog(final String edgeUuid, final Date timestamp,
      final int destinationPort, final int count, final String destinationIp,
      final String sourceIp, final String protocol) {
    this.edgeUuid = edgeUuid;
    this.timestamp = timestamp;
    this.destinationPort = destinationPort;
    this.count = count;
    this.destinationIp = destinationIp;
    this.sourceIp = sourceIp;
    this.protocol = protocol;
  }

  /**
   * Get the edge uuid.
   *
   * @return {@link String} edge uuid
   */
  public String getEdgeUuid() {
    return edgeUuid;
  }

  /**
   * Get the timestamp when traffic occured.
   *
   * @return {@link Date} time stamp
   */
  public Date getTimestamp() {
    return timestamp;
  }

  /**
   * Get the destination port.
   *
   * @return destination port number (-1 for no port)
   */
  public Integer getDestinationPort() {
    return destinationPort;
  }

  /**
   * Get the count of how many times it occured during the discrete interval.
   *
   * @return count
   */
  public int getCount() {
    return count;
  }

  /**
   * Get the destination IP address.
   *
   * @return {@link String} destination IP address
   */
  public String getDestinationIp() {
    return destinationIp;
  }

  /**
   * Get the firewall action.
   *
   * @return {@link String} action
   */
  public String getAction() {
    return action;
  }

  /**
   * Get the source IP address.
   *
   * @return {@link String} source IP address
   */
  public String getSourceIp() {
    return sourceIp;
  }

  /**
   * Get the protocol.
   *
   * @return {@link String} protocol
   */
  public String getProtocol() {
    return protocol;
  }

  /**
   * Set the firewall action.
   *
   * @param action {@link String} action
   */
  public void setAction(final String action) {
    this.action = action;
  }

}
