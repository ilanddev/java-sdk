/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.recovery;

/**
 * Recovery Runbook Field.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public abstract class RecoveryRunbookField {

  public static final String NAME = "name";

  public static final String DESCRIPTION = "description";

  public static final String RECOVERY_GROUPS = "recovery_groups";

  public static final String UUID = "uuid";

  public static final String TYPE = "type";

  public static final String ORDER_INDEX = "order_index";

  public static final String CRM = "crm";

  public static final String LOCATION_ID = "location_id";

  public static final String ORG_UUID = "org_uuid";

  public static final String UPDATED_DATE = "updated_date";

  public static final String CREATED_DATE = "created_date";

  public static final String LAST_TEST = "last_test";

  public static final String RUNBOOK_TAG = "runbook_tag";

  public static final String SHUTDOWN_POLICY = "shutdown_policy";

  public static final String FINALIZE_OPTION = "finalize_option";

  public static final String FINALIZE_STAGE = "finalize_stage";

  public static final String FINALIZE_STATUS = "finalize_status";

  public static final String FINALIZE_USER = "finalize_user";

  public static final String REPORT_GENERATION_INITIATED =
      "report_gen_initiated";

  public static final String REPORT_EVALUATION_DONE = "report_eval_done";

}
