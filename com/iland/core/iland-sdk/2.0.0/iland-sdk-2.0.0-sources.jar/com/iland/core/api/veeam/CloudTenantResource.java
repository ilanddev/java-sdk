/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * CloudTenantResource.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class CloudTenantResource implements Serializable {

  private static final long serialVersionUID = 3301147676515306424L;

  @XmlAttribute(name = "Type")
  private String type = "CloudTenantResource";

  @XmlAttribute(name = "Id")
  private String id;

  @XmlAttribute(name = "Href")
  private String href;

  @Since(ApiVersion.ZERO_DOT_SEVEN)
  @Expose
  @SerializedName("repository")
  @XmlElement(name = "RepositoryQuota")
  private CloudRepository repository;

  public CloudTenantResource() {
  }

  public CloudTenantResource(final String id, final String href,
      final CloudRepository repository) {
    this.id = id;
    this.href = href;
    this.repository = repository;
  }

  /**
   * Get the ID.
   *
   * @return ID
   */
  public String getId() {
    return id;
  }

  /**
   * Get the cloud tenant resource ID.
   *
   * @return {@link String} uid
   */
  public String getUid() {
    return "urn:veeam:cloudtenantresource:" + id;
  }

  /**
   * Get the HREF.
   *
   * @return href
   */
  public String getHref() {
    return href;
  }

  /**
   * Get the list of cloud repositories.
   *
   * @return {@link CloudRepository} cloud repository
   */
  public CloudRepository getRepository() {
    return repository;
  }

  /**
   * Get the type.
   *
   * @return {@link String} type
   */
  public String getType() {
    return type;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final CloudTenantResource that = (CloudTenantResource) o;

    if (getType() != null ?
        !getType().equals(that.getType()) :
        that.getType() != null)
      return false;
    if (getId() != null ? !getId().equals(that.getId()) : that.getId() != null)
      return false;
    if (getHref() != null ?
        !getHref().equals(that.getHref()) :
        that.getHref() != null)
      return false;
    return getRepository() != null ?
        getRepository().equals(that.getRepository()) :
        that.getRepository() == null;
  }

  @Override
  public int hashCode() {
    int result = getType() != null ? getType().hashCode() : 0;
    result = 31 * result + (getId() != null ? getId().hashCode() : 0);
    result = 31 * result + (getHref() != null ? getHref().hashCode() : 0);
    result = 31 * result + (getRepository() != null ?
        getRepository().hashCode() :
        0);
    return result;
  }

}
