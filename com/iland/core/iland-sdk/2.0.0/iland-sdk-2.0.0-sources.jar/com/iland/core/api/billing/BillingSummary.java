/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.entity.AbstractEntityRef;
import com.iland.core.api.entity.Entity;
import com.iland.core.api.serialization.ApiVersion;

/**
 * Billing Summary.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
public class BillingSummary implements Serializable {

  private static final long serialVersionUID = -317287225448747776L;

  public static final transient BillingSummary INVALID_BILLING_SUMMARY =
      new BillingSummary.Builder(false).currentHour(null).previousHour(null)
          .currentMonth(null).previousMonth(null).build();

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.PREVIOUS_MONTH)
  private Bill previousMonth;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.CURRENT_MONTH)
  private Bill currentMonth;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.PREVIOUS_HOUR)
  private final Bill previousHour;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.CURRENT_HOUR)
  private final Bill currentHour;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(BillingEntityField.TEST_DRIVE)
  private boolean testDrive = false;


  public static class Builder {

    // required
    private final boolean testDrive;

    // optional
    private Bill previousMonth;

    private Bill currentMonth;

    private Bill previousHour;

    private Bill currentHour;

    public Builder(final boolean testDrive) {
      this.testDrive = testDrive;
    }

    public Builder previousMonth(final Bill value) {
      previousMonth = value;
      return this;
    }

    public Builder currentMonth(final Bill value) {
      currentMonth = value;
      return this;
    }

    public Builder previousHour(final Bill value) {
      previousHour = value;
      return this;
    }

    public Builder currentHour(final Bill value) {
      currentHour = value;
      return this;
    }

    public BillingSummary build() {
      return new BillingSummary(this);
    }

  }

  private BillingSummary(final Builder builder) {
    testDrive = builder.testDrive;
    previousMonth = builder.previousMonth;
    currentMonth = builder.currentMonth;
    previousHour = builder.previousHour;
    currentHour = builder.currentHour;
  }

  /**
   * Return whether the billing summary represents a test drive.
   *
   * @return test drive flag
   */
  public boolean isTestDrive() {
    return testDrive;
  }

  /**
   * Get previous month billing summary.
   *
   * @return an {@link Bill} previous month bill
   */
  public Bill getPreviousMonth() {
    return previousMonth;
  }

  /**
   * Get current month billing summary.
   *
   * @return an {@link Bill} current month bill
   */
  public Bill getCurrentMonth() {
    return currentMonth;
  }

  /**
   * Get previous hour billing summary.
   *
   * @return an {@link Bill} previous hour bill
   */
  public Bill getPreviousHour() {
    return previousHour;
  }

  /**
   * Get current hour billing summary.
   *
   * @return an {@link Bill} current hour bill
   */
  public Bill getCurrentHour() {
    return currentHour;
  }

  /**
   * Set the entity for the bills.
   *
   * @param entity {@link Entity} entity
   */
  public void setEntity(final AbstractEntityRef entity) {
    if (this.currentMonth != null) {
      this.currentMonth.setEntity(entity);
    }
    if (this.currentHour != null) {
      this.currentHour.setEntity(entity);
    }
    if (this.previousMonth != null) {
      this.previousMonth.setEntity(entity);
    }
    if (this.previousHour != null) {
      this.previousHour.setEntity(entity);
    }
  }

  /**
   * Aggregate a list of Billing Summaries.
   *
   * @param summaries array of summaries to aggregate
   * @return {@link BillingSummary} aggregate billing summary
   */
  public static BillingSummary aggregateBillingSummaries(
      final BillingSummary... summaries) {
    if (summaries.length == 0) {
      return INVALID_BILLING_SUMMARY;
    }
    final Bill[] currentMonthBills = new Bill[summaries.length];
    final Bill[] previousMonthBills = new Bill[summaries.length];
    final Bill[] currentHourBills = new Bill[summaries.length];
    final Bill[] previousHourBills = new Bill[summaries.length];
    for (int i = 0; i < summaries.length; i++) {
      currentMonthBills[i] = summaries[i].getCurrentMonth();
      previousMonthBills[i] = summaries[i].getPreviousMonth();
      currentHourBills[i] = summaries[i].getCurrentHour();
      previousHourBills[i] = summaries[i].getPreviousHour();
    }
    final Bill currentMonth = Bill.aggregateBills(currentMonthBills);
    final Bill previousMonth = Bill.aggregateBills(previousMonthBills);
    final Bill currentHour = Bill.aggregateBills(currentHourBills);
    final Bill previousHour = Bill.aggregateBills(previousHourBills);
    return new BillingSummary.Builder(currentMonth.isTestDrive())
        .currentMonth(currentMonth).previousMonth(previousMonth)
        .currentHour(currentHour).previousHour(previousHour).build();
  }

  /**
   * Set the previous month bill.
   *
   * @param previousMonth {@link Bill} previous month
   */
  public void setPreviousMonth(final Bill previousMonth) {
    this.previousMonth = previousMonth;
  }

  /**
   * Set the current month bill.
   *
   * @param currentMonth {@link Bill} current month
   */
  public void setCurrentMonth(final Bill currentMonth) {
    this.currentMonth = currentMonth;
  }

}
