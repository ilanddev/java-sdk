/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vi;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import org.jetbrains.annotations.NotNull;

import com.google.gson.annotations.SerializedName;

/**
 * StoragePod.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class StoragePod implements Serializable {

  public static final String ID = "storage_pod_ref";

  public static final String LOCATION_ID = "location_id";

  public static final String NAME = "name";

  public static final String DATASTORE_LIST = "datastore_list";

  @SerializedName(ID)
  private String id;

  @SerializedName(LOCATION_ID)
  private String locationId;

  @SerializedName(NAME)
  private String name;

  @SerializedName(DATASTORE_LIST)
  private List<String> childDatastoreIdList;

  public StoragePod(final String locationId, final String id, final String name,
      final List<String> childDatastoreIdList) {
    this.id = id;
    this.locationId = locationId;
    this.name = name;
    if (childDatastoreIdList == null) {
      this.childDatastoreIdList = Collections.emptyList();
    } else {
      this.childDatastoreIdList = childDatastoreIdList;
    }
  }

  /**
   * Get the name of the storage pod.
   *
   * @return {@link String} storage pod name
   */
  public String getName() {
    return name;
  }

  /**
   * List of child datastore IDs linked to this storage pod.
   *
   * @return {@link List} of {@link String} datastore IDs
   */
  @NotNull
  public List<String> getChildDatastoreIdList() {
    return childDatastoreIdList;
  }

  /**
   * Get the storage pod reference ID.
   *
   * @return {@link String} storage pod ID
   */
  public String getId() {
    return id;
  }

  /**
   * Get the location ID.
   *
   * @return {@link String} location ID
   */
  public String getLocationId() {
    return locationId;
  }

}
