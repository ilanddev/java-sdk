/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import java.io.Serializable;
import java.util.Set;

import com.iland.core.api.net.NetworkPerfSample;

/**
 * Network Resource Alert.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class NetworkResourceAlert
    implements Serializable, Comparable<NetworkResourceAlert> {

  private static final long serialVersionUID = -7702031374876345071L;

  // Counter for alert in question (e.g. mem, consumed, average)
  private final String[] counter;

  // The corresponding PerfSample that raised the alert
  private final NetworkPerfSample sample;

  // What type of comparison - e.g. <= threshold or >= threshold
  private String equalityRelation = null;

  // Set of subscriber emails for this alert
  private Set<String> subscribers;

  // Unit of measure for PerfSample value attached to this alert (e.g. GB or
  // KBps, etc)
  private String unit;

  public NetworkResourceAlert(final String[] counter,
      final NetworkPerfSample sample) {
    this.counter = counter;
    this.sample = sample;
  }

  public NetworkResourceAlert(final String[] counter,
      final NetworkPerfSample sample, final String equalityRelation) {
    this(counter, sample);
    this.equalityRelation = equalityRelation;
  }

  /**
   * Get the performance counter attached to this alert.
   *
   * @return array containing counter
   */
  public String[] getCounter() {
    return counter;
  }

  /**
   * Return the performance sample which caused an alert / potential alert to be
   * created.
   *
   * @return {@link NetworkPerfSample} instance
   */
  public NetworkPerfSample getPerfSample() {
    return sample;
  }

  /**
   * Return a set of subscriber email addresses tied to this alert.
   *
   * @return {@link Set} of {@link String} email addresses
   */
  public Set<String> getSubscribers() {
    return subscribers;
  }

  /**
   * Set the set of subscriber email addresses for this alert.
   *
   * @param subscribers {@link Set} of {@link String} subscriber emails
   */
  public void setSubscribers(final Set<String> subscribers) {
    this.subscribers = subscribers;
  }

  /**
   * Get the unit corresponding to the performance sample attached to this
   * alert. e.g. GB or KBps
   *
   * @return {@link String} unit
   */
  public String getUnit() {
    return unit;
  }

  /**
   * Set the unit corresponding to the performance sample attached to this
   * alert. e.g. GB or KBps
   *
   * @param unit {@link String} unit
   */
  public void setUnit(final String unit) {
    this.unit = unit;
  }

  /**
   * Get the equality relation for comparing the alert to determine if
   * triggered.
   * <p>
   * e.g. '<=' or '>='
   *
   * @return {@link String} equality relation
   */
  public String getRelation() {
    return equalityRelation;
  }

  /**
   * Set the equality relation for comparing the alert to determine if
   * triggered.
   * <p>
   * e.g. '<=' or '>='
   */
  public void setRelation(final String equalityRelation) {
    this.equalityRelation = equalityRelation;
  }

  @Override
  public int compareTo(final NetworkResourceAlert o) {
    // Sort alerts in descending order based on time
    return (int) (o.getPerfSample().getTimestamp().getTime() - sample
        .getTimestamp().getTime());
  }

}
