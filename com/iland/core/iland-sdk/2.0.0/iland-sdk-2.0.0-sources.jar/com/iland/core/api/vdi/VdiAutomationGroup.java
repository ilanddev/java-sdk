/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vdi;

import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import javax.annotation.Nullable;

import com.google.common.base.MoreObjects;

/**
 * VDI Automation Group.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class VdiAutomationGroup implements Serializable {

  private static final long serialVersionUID = -4930976014813143829L;

  private static final String URN_PREFIX = "urn:iland:vdi-automation-group";

  private final String orgUuid;

  private final String uuid;

  private final String name;

  private final String description;

  private final String vappTemplateUuid;

  private final String vmTemplateUuid;

  private final String deploymentVdcUuid;

  private final String orgVdcNetworkUuid;

  private final NetworkConnectionType networkConnectionType;

  private final String teamUuid;

  private final String publicRdpIp;

  private final String edgeUuid;

  private final boolean joinDomainEnabled;

  private final String domainToJoin;

  private final boolean guestPasswordResetRequired;

  @Nullable
  private final String storageProfileUuid;

  /**
   * Create vdi automation group.
   *
   * @param orgUuid                    the org uuid
   * @param name                       the name
   * @param description                the description
   * @param vappTemplateUuid           the vapp template uuid
   * @param vmTemplateUuid             the vm template uuid
   * @param deploymentVdcUuid          the deployment vdc uuid
   * @param orgVdcNetworkUuid          the org vdc network uuid
   * @param networkConnectionType      the network connection type
   * @param domainToJoin               the domain to join
   * @param teamUuid                   the team uuid
   * @param publicRdpIp                the public rdp ip
   * @param edgeUuid                   the edge uuid
   * @param joinDomainEnabled          the join domain enabled
   * @param guestPasswordResetRequired the guest password reset required
   * @param storageProfileUuid         the storage profile uuid
   * @return the vdi automation group
   */
  public static VdiAutomationGroup create(final String orgUuid,
      final String name, @Nullable final String description,
      final String vappTemplateUuid, final String vmTemplateUuid,
      final String deploymentVdcUuid, final String orgVdcNetworkUuid,
      final NetworkConnectionType networkConnectionType,
      @Nullable final String domainToJoin, final String teamUuid,
      final String publicRdpIp, final String edgeUuid,
      final boolean joinDomainEnabled, final boolean guestPasswordResetRequired,
      @Nullable final String storageProfileUuid) {
    final String locationId = orgUuid.split(":")[0];
    final String uuid =
        String.format("%s:%s:%s", locationId, URN_PREFIX, UUID.randomUUID());
    return new VdiAutomationGroup(orgUuid, uuid, name, description,
        vappTemplateUuid, vmTemplateUuid, deploymentVdcUuid, orgVdcNetworkUuid,
        networkConnectionType, domainToJoin, teamUuid, publicRdpIp, edgeUuid,
        joinDomainEnabled, guestPasswordResetRequired, storageProfileUuid);
  }

  /**
   * Instantiates a new Vdi automation group.
   *
   * @param orgUuid                    the org uuid
   * @param uuid                       the uuid
   * @param name                       the name
   * @param description                the description
   * @param vappTemplateUuid           the vapp template uuid
   * @param vmTemplateUuid             the vm template uuid
   * @param deploymentVdcUuid          the deployment vdc uuid
   * @param orgVdcNetworkUuid          the org vdc network uuid
   * @param networkConnectionType      the network connection type
   * @param domainToJoin               the domain to join
   * @param teamUuid                   the team uuid
   * @param publicRdpIp                the public rdp ip
   * @param edgeUuid                   the edge uuid
   * @param joinDomainEnabled          the join domain enabled
   * @param guestPasswordResetRequired the guest password reset required
   * @param storageProfileUuid         the storage profile uuid
   */
  public VdiAutomationGroup(final String orgUuid, final String uuid,
      final String name, @Nullable final String description,
      final String vappTemplateUuid, final String vmTemplateUuid,
      final String deploymentVdcUuid, final String orgVdcNetworkUuid,
      final NetworkConnectionType networkConnectionType,
      @Nullable final String domainToJoin, final String teamUuid,
      final String publicRdpIp, final String edgeUuid,
      final boolean joinDomainEnabled, final boolean guestPasswordResetRequired,
      @Nullable final String storageProfileUuid) {
    this.uuid = uuid;
    this.vappTemplateUuid = vappTemplateUuid;
    this.networkConnectionType = networkConnectionType;
    this.joinDomainEnabled = joinDomainEnabled;
    this.guestPasswordResetRequired = guestPasswordResetRequired;
    this.orgUuid = orgUuid;
    this.name = name;
    this.description = description;
    this.vmTemplateUuid = vmTemplateUuid;
    this.deploymentVdcUuid = deploymentVdcUuid;
    this.orgVdcNetworkUuid = orgVdcNetworkUuid;
    this.domainToJoin = domainToJoin;
    this.teamUuid = teamUuid;
    this.publicRdpIp = publicRdpIp;
    this.edgeUuid = edgeUuid;
    this.storageProfileUuid = storageProfileUuid;
  }

  /**
   * Gets org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets vm template uuid.
   *
   * @return the vm template uuid
   */
  public String getVmTemplateUuid() {
    return vmTemplateUuid;
  }

  /**
   * Gets deployment vdc uuid.
   *
   * @return the deployment vdc uuid
   */
  public String getDeploymentVdcUuid() {
    return deploymentVdcUuid;
  }

  /**
   * Gets org vdc network uuid.
   *
   * @return the org vdc network uuid
   */
  public String getOrgVdcNetworkUuid() {
    return orgVdcNetworkUuid;
  }

  /**
   * Gets domain to join.
   *
   * @return the domain to join
   */
  public String getDomainToJoin() {
    return domainToJoin;
  }

  /**
   * Gets team uuid.
   *
   * @return the team uuid
   */
  public String getTeamUuid() {
    return teamUuid;
  }

  /**
   * Gets public rdp ip.
   *
   * @return the public rdp ip
   */
  public String getPublicRdpIp() {
    return publicRdpIp;
  }

  /**
   * Gets edge uuid.
   *
   * @return the edge uuid
   */
  public String getEdgeUuid() {
    return edgeUuid;
  }

  /**
   * Gets network connection type.
   *
   * @return the network connection type
   */
  public NetworkConnectionType getNetworkConnectionType() {
    return networkConnectionType;
  }

  /**
   * Is join domain enabled boolean.
   *
   * @return the boolean
   */
  public boolean isJoinDomainEnabled() {
    return joinDomainEnabled;
  }

  /**
   * Is guest password reset required boolean.
   *
   * @return the boolean
   */
  public boolean isGuestPasswordResetRequired() {
    return guestPasswordResetRequired;
  }

  /**
   * Gets vapp template uuid.
   *
   * @return the vapp template uuid
   */
  public String getVappTemplateUuid() {
    return vappTemplateUuid;
  }

  @Override
  public int hashCode() {
    return Objects.hash(orgUuid, uuid, name, description, vappTemplateUuid,
        vmTemplateUuid, deploymentVdcUuid, orgVdcNetworkUuid,
        networkConnectionType, teamUuid, publicRdpIp, edgeUuid,
        joinDomainEnabled, domainToJoin, guestPasswordResetRequired,
        storageProfileUuid);
  }

  /**
   * Gets storage profile uuid.
   *
   * @return the storage profile uuid
   */
  public Optional<String> getStorageProfileUuid() {
    return Optional.ofNullable(storageProfileUuid);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("orgUuid", orgUuid)
        .add("uuid", uuid).add("name", name).add("description", description)
        .add("vappTemplateUuid", vappTemplateUuid)
        .add("vmTemplateUuid", vmTemplateUuid)
        .add("deploymentVdcUuid", deploymentVdcUuid)
        .add("orgVdcNetworkUuid", orgVdcNetworkUuid)
        .add("networkConnectionType", networkConnectionType)
        .add("teamUuid", teamUuid).add("publicRdpIp", publicRdpIp)
        .add("edgeUuid", edgeUuid).add("joinDomainEnabled", joinDomainEnabled)
        .add("domainToJoin", domainToJoin)
        .add("guestPasswordResetRequired", guestPasswordResetRequired)
        .add("storageProfileUuid", storageProfileUuid).toString();
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final VdiAutomationGroup that = (VdiAutomationGroup) o;
    return joinDomainEnabled == that.joinDomainEnabled
        && guestPasswordResetRequired == that.guestPasswordResetRequired
        && Objects.equals(orgUuid, that.orgUuid) && Objects
        .equals(uuid, that.uuid) && Objects.equals(name, that.name) && Objects
        .equals(description, that.description) && Objects
        .equals(vappTemplateUuid, that.vappTemplateUuid) && Objects
        .equals(vmTemplateUuid, that.vmTemplateUuid) && Objects
        .equals(deploymentVdcUuid, that.deploymentVdcUuid) && Objects
        .equals(orgVdcNetworkUuid, that.orgVdcNetworkUuid)
        && networkConnectionType == that.networkConnectionType && Objects
        .equals(teamUuid, that.teamUuid) && Objects
        .equals(publicRdpIp, that.publicRdpIp) && Objects
        .equals(edgeUuid, that.edgeUuid) && Objects
        .equals(domainToJoin, that.domainToJoin) && Objects
        .equals(storageProfileUuid, that.storageProfileUuid);
  }
}
