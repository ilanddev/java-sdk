/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableList;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link JobReplicationData}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableJobReplicationData.builder()}.
 */
@Generated(from = "JobReplicationData", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableJobReplicationData
    implements JobReplicationData {
  private final @Nullable String name;
  private final @Nullable Long protectedObjects;
  private final @Nullable Boolean isCompliant;
  private final ImmutableList<TargetData> targets;

  private ImmutableJobReplicationData(
      @Nullable String name,
      @Nullable Long protectedObjects,
      @Nullable Boolean isCompliant,
      ImmutableList<TargetData> targets) {
    this.name = name;
    this.protectedObjects = protectedObjects;
    this.isCompliant = isCompliant;
    this.targets = targets;
  }

  /**
   * The name of the backup group.
   */
  @Override
  public Optional<String> name() {
    return Optional.ofNullable(name);
  }

  /**
   * The number of objects successfully backed up last run.
   */
  @Override
  public Optional<Long> protectedObjects() {
    return Optional.ofNullable(protectedObjects);
  }

  /**
   * Whether the SLA has been violated.
   */
  @Override
  public Optional<Boolean> isCompliant() {
    return Optional.ofNullable(isCompliant);
  }

  /**
   * The status of each replication target.
   */
  @Override
  public ImmutableList<TargetData> targets() {
    return targets;
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link JobReplicationData#name() name} attribute.
   * @param value The value for name
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableJobReplicationData withName(String value) {
    String newValue = Objects.requireNonNull(value, "name");
    if (Objects.equals(this.name, newValue)) return this;
    return new ImmutableJobReplicationData(newValue, this.protectedObjects, this.isCompliant, this.targets);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link JobReplicationData#name() name} attribute.
   * An equality check is used on inner value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for name
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableJobReplicationData withName(Optional<String> optional) {
    @Nullable String value = optional.orElse(null);
    if (Objects.equals(this.name, value)) return this;
    return new ImmutableJobReplicationData(value, this.protectedObjects, this.isCompliant, this.targets);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link JobReplicationData#protectedObjects() protectedObjects} attribute.
   * @param value The value for protectedObjects
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableJobReplicationData withProtectedObjects(long value) {
    @Nullable Long newValue = value;
    if (Objects.equals(this.protectedObjects, newValue)) return this;
    return new ImmutableJobReplicationData(this.name, newValue, this.isCompliant, this.targets);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link JobReplicationData#protectedObjects() protectedObjects} attribute.
   * An equality check is used on inner value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for protectedObjects
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableJobReplicationData withProtectedObjects(Optional<Long> optional) {
    @Nullable Long value = optional.orElse(null);
    if (Objects.equals(this.protectedObjects, value)) return this;
    return new ImmutableJobReplicationData(this.name, value, this.isCompliant, this.targets);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link JobReplicationData#isCompliant() isCompliant} attribute.
   * @param value The value for isCompliant
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableJobReplicationData withIsCompliant(boolean value) {
    @Nullable Boolean newValue = value;
    if (Objects.equals(this.isCompliant, newValue)) return this;
    return new ImmutableJobReplicationData(this.name, this.protectedObjects, newValue, this.targets);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link JobReplicationData#isCompliant() isCompliant} attribute.
   * An equality check is used on inner value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for isCompliant
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableJobReplicationData withIsCompliant(Optional<Boolean> optional) {
    @Nullable Boolean value = optional.orElse(null);
    if (Objects.equals(this.isCompliant, value)) return this;
    return new ImmutableJobReplicationData(this.name, this.protectedObjects, value, this.targets);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link JobReplicationData#targets() targets}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final ImmutableJobReplicationData withTargets(TargetData... elements) {
    ImmutableList<TargetData> newValue = ImmutableList.copyOf(elements);
    return new ImmutableJobReplicationData(this.name, this.protectedObjects, this.isCompliant, newValue);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link JobReplicationData#targets() targets}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of targets elements to set
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableJobReplicationData withTargets(Iterable<? extends TargetData> elements) {
    if (this.targets == elements) return this;
    ImmutableList<TargetData> newValue = ImmutableList.copyOf(elements);
    return new ImmutableJobReplicationData(this.name, this.protectedObjects, this.isCompliant, newValue);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableJobReplicationData} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableJobReplicationData
        && equalsByValue((ImmutableJobReplicationData) another);
  }

  private boolean equalsByValue(ImmutableJobReplicationData another) {
    return Objects.equals(name, another.name)
        && Objects.equals(protectedObjects, another.protectedObjects)
        && Objects.equals(isCompliant, another.isCompliant)
        && targets.equals(another.targets);
  }

  /**
   * Computes a hash code from attributes: {@code name}, {@code protectedObjects}, {@code isCompliant}, {@code targets}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(name);
    h += (h << 5) + Objects.hashCode(protectedObjects);
    h += (h << 5) + Objects.hashCode(isCompliant);
    h += (h << 5) + targets.hashCode();
    return h;
  }

  /**
   * Prints the immutable value {@code JobReplicationData} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("JobReplicationData")
        .omitNullValues()
        .add("name", name)
        .add("protectedObjects", protectedObjects)
        .add("isCompliant", isCompliant)
        .add("targets", targets)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link JobReplicationData} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable JobReplicationData instance
   */
  public static ImmutableJobReplicationData copyOf(JobReplicationData instance) {
    if (instance instanceof ImmutableJobReplicationData) {
      return (ImmutableJobReplicationData) instance;
    }
    return ImmutableJobReplicationData.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableJobReplicationData ImmutableJobReplicationData}.
   * <pre>
   * ImmutableJobReplicationData.builder()
   *    .name(Optional&lt;String&gt;) // optional {@link JobReplicationData#name() name}
   *    .protectedObjects(Optional&lt;Long&gt;) // optional {@link JobReplicationData#protectedObjects() protectedObjects}
   *    .isCompliant(Optional&lt;Boolean&gt;) // optional {@link JobReplicationData#isCompliant() isCompliant}
   *    .addTargets|addAllTargets(com.iland.offsite.replication.api.model.TargetData) // {@link JobReplicationData#targets() targets} elements
   *    .build();
   * </pre>
   * @return A new ImmutableJobReplicationData builder
   */
  public static ImmutableJobReplicationData.Builder builder() {
    return new ImmutableJobReplicationData.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableJobReplicationData ImmutableJobReplicationData}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "JobReplicationData", generator = "Immutables")
  public static final class Builder {
    private @Nullable String name;
    private @Nullable Long protectedObjects;
    private @Nullable Boolean isCompliant;
    private ImmutableList.Builder<TargetData> targets = ImmutableList.builder();

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code JobReplicationData} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * Collection elements and entries will be added, not replaced.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(JobReplicationData instance) {
      Objects.requireNonNull(instance, "instance");
      Optional<String> nameOptional = instance.name();
      if (nameOptional.isPresent()) {
        name(nameOptional);
      }
      Optional<Long> protectedObjectsOptional = instance.protectedObjects();
      if (protectedObjectsOptional.isPresent()) {
        protectedObjects(protectedObjectsOptional);
      }
      Optional<Boolean> isCompliantOptional = instance.isCompliant();
      if (isCompliantOptional.isPresent()) {
        isCompliant(isCompliantOptional);
      }
      addAllTargets(instance.targets());
      return this;
    }

    /**
     * Initializes the optional value {@link JobReplicationData#name() name} to name.
     * @param name The value for name
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder name(String name) {
      this.name = Objects.requireNonNull(name, "name");
      return this;
    }

    /**
     * Initializes the optional value {@link JobReplicationData#name() name} to name.
     * @param name The value for name
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder name(Optional<String> name) {
      this.name = name.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link JobReplicationData#protectedObjects() protectedObjects} to protectedObjects.
     * @param protectedObjects The value for protectedObjects
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder protectedObjects(long protectedObjects) {
      this.protectedObjects = protectedObjects;
      return this;
    }

    /**
     * Initializes the optional value {@link JobReplicationData#protectedObjects() protectedObjects} to protectedObjects.
     * @param protectedObjects The value for protectedObjects
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder protectedObjects(Optional<Long> protectedObjects) {
      this.protectedObjects = protectedObjects.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link JobReplicationData#isCompliant() isCompliant} to isCompliant.
     * @param isCompliant The value for isCompliant
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder isCompliant(boolean isCompliant) {
      this.isCompliant = isCompliant;
      return this;
    }

    /**
     * Initializes the optional value {@link JobReplicationData#isCompliant() isCompliant} to isCompliant.
     * @param isCompliant The value for isCompliant
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder isCompliant(Optional<Boolean> isCompliant) {
      this.isCompliant = isCompliant.orElse(null);
      return this;
    }

    /**
     * Adds one element to {@link JobReplicationData#targets() targets} list.
     * @param element A targets element
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addTargets(TargetData element) {
      this.targets.add(element);
      return this;
    }

    /**
     * Adds elements to {@link JobReplicationData#targets() targets} list.
     * @param elements An array of targets elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addTargets(TargetData... elements) {
      this.targets.add(elements);
      return this;
    }


    /**
     * Sets or replaces all elements for {@link JobReplicationData#targets() targets} list.
     * @param elements An iterable of targets elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder targets(Iterable<? extends TargetData> elements) {
      this.targets = ImmutableList.builder();
      return addAllTargets(elements);
    }

    /**
     * Adds elements to {@link JobReplicationData#targets() targets} list.
     * @param elements An iterable of targets elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addAllTargets(Iterable<? extends TargetData> elements) {
      this.targets.addAll(elements);
      return this;
    }

    /**
     * Builds a new {@link ImmutableJobReplicationData ImmutableJobReplicationData}.
     * @return An immutable instance of JobReplicationData
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableJobReplicationData build() {
      return new ImmutableJobReplicationData(name, protectedObjects, isCompliant, targets.build());
    }
  }
}
