/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableList;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link ReplicationInformationParameters}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableReplicationInformationParameters.builder()}.
 */
@Generated(from = "ReplicationInformationParameters", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableReplicationInformationParameters
    implements ReplicationInformationParameters {
  private final CompanyId companyId;
  private final ImmutableList<VdcUuid> vdcUuids;
  private final @Nullable Instant startTime;
  private final @Nullable Instant endTime;

  private ImmutableReplicationInformationParameters(
      CompanyId companyId,
      ImmutableList<VdcUuid> vdcUuids,
      @Nullable Instant startTime,
      @Nullable Instant endTime) {
    this.companyId = companyId;
    this.vdcUuids = vdcUuids;
    this.startTime = startTime;
    this.endTime = endTime;
  }

  /**
   * Specify the {@link CompanyId company ID}.
   */
  @Override
  public CompanyId companyId() {
    return companyId;
  }

  /**
   * Specify the {@link VdcUuid VDC UUIDs}.
   */
  @Override
  public ImmutableList<VdcUuid> vdcUuids() {
    return vdcUuids;
  }

  /**
   * Specify the optional start time, inclusive.
   */
  @Override
  public Optional<Instant> startTime() {
    return Optional.ofNullable(startTime);
  }

  /**
   * Specify the optional end time, exclusive.
   */
  @Override
  public Optional<Instant> endTime() {
    return Optional.ofNullable(endTime);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link ReplicationInformationParameters#companyId() companyId} attribute.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for companyId
   * @return A modified copy or the {@code this} object
   */
  public final ImmutableReplicationInformationParameters withCompanyId(CompanyId value) {
    if (this.companyId == value) return this;
    CompanyId newValue = Objects.requireNonNull(value, "companyId");
    return new ImmutableReplicationInformationParameters(newValue, this.vdcUuids, this.startTime, this.endTime);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link ReplicationInformationParameters#vdcUuids() vdcUuids}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final ImmutableReplicationInformationParameters withVdcUuids(VdcUuid... elements) {
    ImmutableList<VdcUuid> newValue = ImmutableList.copyOf(elements);
    return new ImmutableReplicationInformationParameters(this.companyId, newValue, this.startTime, this.endTime);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link ReplicationInformationParameters#vdcUuids() vdcUuids}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of vdcUuids elements to set
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableReplicationInformationParameters withVdcUuids(Iterable<? extends VdcUuid> elements) {
    if (this.vdcUuids == elements) return this;
    ImmutableList<VdcUuid> newValue = ImmutableList.copyOf(elements);
    return new ImmutableReplicationInformationParameters(this.companyId, newValue, this.startTime, this.endTime);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ReplicationInformationParameters#startTime() startTime} attribute.
   * @param value The value for startTime
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableReplicationInformationParameters withStartTime(Instant value) {
    Instant newValue = Objects.requireNonNull(value, "startTime");
    if (this.startTime == newValue) return this;
    return new ImmutableReplicationInformationParameters(this.companyId, this.vdcUuids, newValue, this.endTime);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ReplicationInformationParameters#startTime() startTime} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for startTime
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableReplicationInformationParameters withStartTime(Optional<? extends Instant> optional) {
    @Nullable Instant value = optional.orElse(null);
    if (this.startTime == value) return this;
    return new ImmutableReplicationInformationParameters(this.companyId, this.vdcUuids, value, this.endTime);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link ReplicationInformationParameters#endTime() endTime} attribute.
   * @param value The value for endTime
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableReplicationInformationParameters withEndTime(Instant value) {
    Instant newValue = Objects.requireNonNull(value, "endTime");
    if (this.endTime == newValue) return this;
    return new ImmutableReplicationInformationParameters(this.companyId, this.vdcUuids, this.startTime, newValue);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link ReplicationInformationParameters#endTime() endTime} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for endTime
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableReplicationInformationParameters withEndTime(Optional<? extends Instant> optional) {
    @Nullable Instant value = optional.orElse(null);
    if (this.endTime == value) return this;
    return new ImmutableReplicationInformationParameters(this.companyId, this.vdcUuids, this.startTime, value);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableReplicationInformationParameters} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableReplicationInformationParameters
        && equalsByValue((ImmutableReplicationInformationParameters) another);
  }

  private boolean equalsByValue(ImmutableReplicationInformationParameters another) {
    return companyId.equals(another.companyId)
        && vdcUuids.equals(another.vdcUuids)
        && Objects.equals(startTime, another.startTime)
        && Objects.equals(endTime, another.endTime);
  }

  /**
   * Computes a hash code from attributes: {@code companyId}, {@code vdcUuids}, {@code startTime}, {@code endTime}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + companyId.hashCode();
    h += (h << 5) + vdcUuids.hashCode();
    h += (h << 5) + Objects.hashCode(startTime);
    h += (h << 5) + Objects.hashCode(endTime);
    return h;
  }

  /**
   * Prints the immutable value {@code ReplicationInformationParameters} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("ReplicationInformationParameters")
        .omitNullValues()
        .add("companyId", companyId)
        .add("vdcUuids", vdcUuids)
        .add("startTime", startTime)
        .add("endTime", endTime)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link ReplicationInformationParameters} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable ReplicationInformationParameters instance
   */
  public static ImmutableReplicationInformationParameters copyOf(ReplicationInformationParameters instance) {
    if (instance instanceof ImmutableReplicationInformationParameters) {
      return (ImmutableReplicationInformationParameters) instance;
    }
    return ImmutableReplicationInformationParameters.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableReplicationInformationParameters ImmutableReplicationInformationParameters}.
   * <pre>
   * ImmutableReplicationInformationParameters.builder()
   *    .companyId(com.iland.offsite.replication.api.model.CompanyId) // required {@link ReplicationInformationParameters#companyId() companyId}
   *    .addVdcUuids|addAllVdcUuids(com.iland.offsite.replication.api.model.VdcUuid) // {@link ReplicationInformationParameters#vdcUuids() vdcUuids} elements
   *    .startTime(Optional&lt;java.time.Instant&gt;) // optional {@link ReplicationInformationParameters#startTime() startTime}
   *    .endTime(Optional&lt;java.time.Instant&gt;) // optional {@link ReplicationInformationParameters#endTime() endTime}
   *    .build();
   * </pre>
   * @return A new ImmutableReplicationInformationParameters builder
   */
  public static ImmutableReplicationInformationParameters.Builder builder() {
    return new ImmutableReplicationInformationParameters.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableReplicationInformationParameters ImmutableReplicationInformationParameters}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "ReplicationInformationParameters", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_COMPANY_ID = 0x1L;
    private long initBits = 0x1L;

    private @Nullable CompanyId companyId;
    private ImmutableList.Builder<VdcUuid> vdcUuids = ImmutableList.builder();
    private @Nullable Instant startTime;
    private @Nullable Instant endTime;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code ReplicationInformationParameters} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * Collection elements and entries will be added, not replaced.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(ReplicationInformationParameters instance) {
      Objects.requireNonNull(instance, "instance");
      this.companyId(instance.companyId());
      addAllVdcUuids(instance.vdcUuids());
      Optional<Instant> startTimeOptional = instance.startTime();
      if (startTimeOptional.isPresent()) {
        startTime(startTimeOptional);
      }
      Optional<Instant> endTimeOptional = instance.endTime();
      if (endTimeOptional.isPresent()) {
        endTime(endTimeOptional);
      }
      return this;
    }

    /**
     * Initializes the value for the {@link ReplicationInformationParameters#companyId() companyId} attribute.
     * @param companyId The value for companyId 
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder companyId(CompanyId companyId) {
      this.companyId = Objects.requireNonNull(companyId, "companyId");
      initBits &= ~INIT_BIT_COMPANY_ID;
      return this;
    }

    /**
     * Adds one element to {@link ReplicationInformationParameters#vdcUuids() vdcUuids} list.
     * @param element A vdcUuids element
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addVdcUuids(VdcUuid element) {
      this.vdcUuids.add(element);
      return this;
    }

    /**
     * Adds elements to {@link ReplicationInformationParameters#vdcUuids() vdcUuids} list.
     * @param elements An array of vdcUuids elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addVdcUuids(VdcUuid... elements) {
      this.vdcUuids.add(elements);
      return this;
    }


    /**
     * Sets or replaces all elements for {@link ReplicationInformationParameters#vdcUuids() vdcUuids} list.
     * @param elements An iterable of vdcUuids elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder vdcUuids(Iterable<? extends VdcUuid> elements) {
      this.vdcUuids = ImmutableList.builder();
      return addAllVdcUuids(elements);
    }

    /**
     * Adds elements to {@link ReplicationInformationParameters#vdcUuids() vdcUuids} list.
     * @param elements An iterable of vdcUuids elements
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder addAllVdcUuids(Iterable<? extends VdcUuid> elements) {
      this.vdcUuids.addAll(elements);
      return this;
    }

    /**
     * Initializes the optional value {@link ReplicationInformationParameters#startTime() startTime} to startTime.
     * @param startTime The value for startTime
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder startTime(Instant startTime) {
      this.startTime = Objects.requireNonNull(startTime, "startTime");
      return this;
    }

    /**
     * Initializes the optional value {@link ReplicationInformationParameters#startTime() startTime} to startTime.
     * @param startTime The value for startTime
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder startTime(Optional<? extends Instant> startTime) {
      this.startTime = startTime.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link ReplicationInformationParameters#endTime() endTime} to endTime.
     * @param endTime The value for endTime
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder endTime(Instant endTime) {
      this.endTime = Objects.requireNonNull(endTime, "endTime");
      return this;
    }

    /**
     * Initializes the optional value {@link ReplicationInformationParameters#endTime() endTime} to endTime.
     * @param endTime The value for endTime
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder endTime(Optional<? extends Instant> endTime) {
      this.endTime = endTime.orElse(null);
      return this;
    }

    /**
     * Builds a new {@link ImmutableReplicationInformationParameters ImmutableReplicationInformationParameters}.
     * @return An immutable instance of ReplicationInformationParameters
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableReplicationInformationParameters build() {
      if (initBits != 0) {
        throw new IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutableReplicationInformationParameters(companyId, vdcUuids.build(), startTime, endTime);
    }

    private String formatRequiredAttributesMessage() {
      List<String> attributes = new ArrayList<>();
      if ((initBits & INIT_BIT_COMPANY_ID) != 0) attributes.add("companyId");
      return "Cannot build ReplicationInformationParameters, some of required attributes are not set " + attributes;
    }
  }
}
