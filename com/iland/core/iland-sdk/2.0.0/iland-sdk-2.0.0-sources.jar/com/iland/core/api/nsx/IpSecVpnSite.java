/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.nsx;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.SerializedName;

/**
 * IpSecVpnSite.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class IpSecVpnSite implements Serializable {

  private static final long serialVersionUID = -6915848052893945591L;

  @SerializedName("enabled")
  private boolean enabled;

  @SerializedName("name")
  private String name;

  @SerializedName("description")
  private String description;

  @SerializedName("local_id")
  private String localId;

  @SerializedName("local_ip")
  private String localIp;

  @SerializedName("peer_id")
  private String peerId;

  @SerializedName("peer_ip")
  private String peerIp;

  @SerializedName("psk")
  private String psk;

  @SerializedName("encryption_algorithm")
  private EncryptionAlgorithm encryptionAlgorithm;

  @SerializedName("authentication_mode")
  private AuthenticationMode authenticationMode;

  @SerializedName("enable_pfs")
  private boolean enablePfs;

  @SerializedName("dh_group")
  private DHGroup dhGroup;

  @SerializedName("local_subnets")
  private List<String> localSubnets;

  @SerializedName("peer_subnets")
  private List<String> peerSubnets;

  public IpSecVpnSite() {
  }

  public IpSecVpnSite(final boolean enabled, final String name,
      final String description, final String localId, final String localIp,
      final String peerId, final String peerIp, final String psk,
      final EncryptionAlgorithm encryptionAlgorithm,
      final AuthenticationMode authenticationMode, final boolean enablePfs,
      final DHGroup dhGroup, final List<String> localSubnets,
      final List<String> peerSubnets) {
    this.enabled = enabled;
    this.name = name;
    this.description = description;
    this.localId = localId;
    this.localIp = localIp;
    this.peerId = peerId;
    this.peerIp = peerIp;
    this.psk = psk;
    this.encryptionAlgorithm = encryptionAlgorithm;
    this.authenticationMode = authenticationMode;
    this.enablePfs = enablePfs;
    this.dhGroup = dhGroup;
    this.localSubnets = localSubnets;
    this.peerSubnets = peerSubnets;
  }

  /**
   * Get whether the IPSec VPN site is enabled.
   *
   * @return enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Get the name.
   *
   * @return {@link String} site name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the site description.
   *
   * @return {@link String} site description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get the site local ID.
   *
   * @return {@link String} local ID
   */
  public String getLocalId() {
    return localId;
  }

  /**
   * Get the site local IP.
   *
   * @return {@link String} local IP
   */
  public String getLocalIp() {
    return localIp;
  }

  /**
   * Get the peer ID.
   *
   * @return {@link String} peer ID
   */
  public String getPeerId() {
    return peerId;
  }

  /**
   * Get the peer IP.
   *
   * @return {@link String} peer IP
   */
  public String getPeerIp() {
    return peerIp;
  }

  /**
   * Get the pre shared key.
   *
   * @return {@link String} pre shared key
   */
  public String getPsk() {
    return psk;
  }

  /**
   * Get the site encryption algorithm.
   *
   * @return {@link EncryptionAlgorithm} encryption algorithm
   */
  public EncryptionAlgorithm getEncryptionAlgorithm() {
    return encryptionAlgorithm;
  }

  /**
   * Get the authentication mode.
   *
   * @return {@link AuthenticationMode} authentication mode
   */
  public AuthenticationMode getAuthenticationMode() {
    return authenticationMode;
  }

  /**
   * Get whether perfect forward secrecy is enabled.
   *
   * @return pfs enabled
   */
  public boolean isEnablePfs() {
    return enablePfs;
  }

  /**
   * Get the diffie-hellman group.
   *
   * @return {@link DHGroup} diffie-hellman group
   */
  public DHGroup getDhGroup() {
    return dhGroup;
  }

  /**
   * Get the list of local subnets.
   *
   * @return {@link String} local subnets
   */
  public List<String> getLocalSubnets() {
    return localSubnets;
  }

  /**
   * Get the list of peer subnets.
   *
   * @return {@link String} peer subnets
   */
  public List<String> getPeerSubnets() {
    return peerSubnets;
  }

}
