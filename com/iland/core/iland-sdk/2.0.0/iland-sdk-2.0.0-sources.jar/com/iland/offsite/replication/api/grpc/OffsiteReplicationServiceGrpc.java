/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.grpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@io.grpc.stub.annotations.GrpcGenerated
public final class OffsiteReplicationServiceGrpc {

  private OffsiteReplicationServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "io.grpc.OffsiteReplicationService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.iland.offsite.replication.api.grpc.ReplicationInformationRequest,
      com.iland.offsite.replication.api.grpc.SerializedResponse> getGetReplicationInformationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetReplicationInformation",
      requestType = com.iland.offsite.replication.api.grpc.ReplicationInformationRequest.class,
      responseType = com.iland.offsite.replication.api.grpc.SerializedResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.offsite.replication.api.grpc.ReplicationInformationRequest,
      com.iland.offsite.replication.api.grpc.SerializedResponse> getGetReplicationInformationMethod() {
    io.grpc.MethodDescriptor<com.iland.offsite.replication.api.grpc.ReplicationInformationRequest, com.iland.offsite.replication.api.grpc.SerializedResponse> getGetReplicationInformationMethod;
    if ((getGetReplicationInformationMethod = OffsiteReplicationServiceGrpc.getGetReplicationInformationMethod) == null) {
      synchronized (OffsiteReplicationServiceGrpc.class) {
        if ((getGetReplicationInformationMethod = OffsiteReplicationServiceGrpc.getGetReplicationInformationMethod) == null) {
          OffsiteReplicationServiceGrpc.getGetReplicationInformationMethod = getGetReplicationInformationMethod =
              io.grpc.MethodDescriptor.<com.iland.offsite.replication.api.grpc.ReplicationInformationRequest, com.iland.offsite.replication.api.grpc.SerializedResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetReplicationInformation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.offsite.replication.api.grpc.ReplicationInformationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.offsite.replication.api.grpc.SerializedResponse.getDefaultInstance()))
              .setSchemaDescriptor(new OffsiteReplicationServiceMethodDescriptorSupplier("GetReplicationInformation"))
              .build();
        }
      }
    }
    return getGetReplicationInformationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.offsite.replication.api.grpc.StorageHistoryRequest,
      com.iland.offsite.replication.api.grpc.SerializedResponse> getGetStorageHistoryMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetStorageHistory",
      requestType = com.iland.offsite.replication.api.grpc.StorageHistoryRequest.class,
      responseType = com.iland.offsite.replication.api.grpc.SerializedResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.offsite.replication.api.grpc.StorageHistoryRequest,
      com.iland.offsite.replication.api.grpc.SerializedResponse> getGetStorageHistoryMethod() {
    io.grpc.MethodDescriptor<com.iland.offsite.replication.api.grpc.StorageHistoryRequest, com.iland.offsite.replication.api.grpc.SerializedResponse> getGetStorageHistoryMethod;
    if ((getGetStorageHistoryMethod = OffsiteReplicationServiceGrpc.getGetStorageHistoryMethod) == null) {
      synchronized (OffsiteReplicationServiceGrpc.class) {
        if ((getGetStorageHistoryMethod = OffsiteReplicationServiceGrpc.getGetStorageHistoryMethod) == null) {
          OffsiteReplicationServiceGrpc.getGetStorageHistoryMethod = getGetStorageHistoryMethod =
              io.grpc.MethodDescriptor.<com.iland.offsite.replication.api.grpc.StorageHistoryRequest, com.iland.offsite.replication.api.grpc.SerializedResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetStorageHistory"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.offsite.replication.api.grpc.StorageHistoryRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.offsite.replication.api.grpc.SerializedResponse.getDefaultInstance()))
              .setSchemaDescriptor(new OffsiteReplicationServiceMethodDescriptorSupplier("GetStorageHistory"))
              .build();
        }
      }
    }
    return getGetStorageHistoryMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.offsite.replication.api.grpc.StorageHistoryRequest,
      com.iland.offsite.replication.api.grpc.FileData> getGetStorageReportMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetStorageReport",
      requestType = com.iland.offsite.replication.api.grpc.StorageHistoryRequest.class,
      responseType = com.iland.offsite.replication.api.grpc.FileData.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.iland.offsite.replication.api.grpc.StorageHistoryRequest,
      com.iland.offsite.replication.api.grpc.FileData> getGetStorageReportMethod() {
    io.grpc.MethodDescriptor<com.iland.offsite.replication.api.grpc.StorageHistoryRequest, com.iland.offsite.replication.api.grpc.FileData> getGetStorageReportMethod;
    if ((getGetStorageReportMethod = OffsiteReplicationServiceGrpc.getGetStorageReportMethod) == null) {
      synchronized (OffsiteReplicationServiceGrpc.class) {
        if ((getGetStorageReportMethod = OffsiteReplicationServiceGrpc.getGetStorageReportMethod) == null) {
          OffsiteReplicationServiceGrpc.getGetStorageReportMethod = getGetStorageReportMethod =
              io.grpc.MethodDescriptor.<com.iland.offsite.replication.api.grpc.StorageHistoryRequest, com.iland.offsite.replication.api.grpc.FileData>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetStorageReport"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.offsite.replication.api.grpc.StorageHistoryRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.offsite.replication.api.grpc.FileData.getDefaultInstance()))
              .setSchemaDescriptor(new OffsiteReplicationServiceMethodDescriptorSupplier("GetStorageReport"))
              .build();
        }
      }
    }
    return getGetStorageReportMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static OffsiteReplicationServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<OffsiteReplicationServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<OffsiteReplicationServiceStub>() {
        @java.lang.Override
        public OffsiteReplicationServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new OffsiteReplicationServiceStub(channel, callOptions);
        }
      };
    return OffsiteReplicationServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static OffsiteReplicationServiceBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<OffsiteReplicationServiceBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<OffsiteReplicationServiceBlockingV2Stub>() {
        @java.lang.Override
        public OffsiteReplicationServiceBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new OffsiteReplicationServiceBlockingV2Stub(channel, callOptions);
        }
      };
    return OffsiteReplicationServiceBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static OffsiteReplicationServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<OffsiteReplicationServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<OffsiteReplicationServiceBlockingStub>() {
        @java.lang.Override
        public OffsiteReplicationServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new OffsiteReplicationServiceBlockingStub(channel, callOptions);
        }
      };
    return OffsiteReplicationServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static OffsiteReplicationServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<OffsiteReplicationServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<OffsiteReplicationServiceFutureStub>() {
        @java.lang.Override
        public OffsiteReplicationServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new OffsiteReplicationServiceFutureStub(channel, callOptions);
        }
      };
    return OffsiteReplicationServiceFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     */
    default void getReplicationInformation(com.iland.offsite.replication.api.grpc.ReplicationInformationRequest request,
        io.grpc.stub.StreamObserver<com.iland.offsite.replication.api.grpc.SerializedResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetReplicationInformationMethod(), responseObserver);
    }

    /**
     */
    default void getStorageHistory(com.iland.offsite.replication.api.grpc.StorageHistoryRequest request,
        io.grpc.stub.StreamObserver<com.iland.offsite.replication.api.grpc.SerializedResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetStorageHistoryMethod(), responseObserver);
    }

    /**
     */
    default void getStorageReport(com.iland.offsite.replication.api.grpc.StorageHistoryRequest request,
        io.grpc.stub.StreamObserver<com.iland.offsite.replication.api.grpc.FileData> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetStorageReportMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service OffsiteReplicationService.
   */
  public static abstract class OffsiteReplicationServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return OffsiteReplicationServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service OffsiteReplicationService.
   */
  public static final class OffsiteReplicationServiceStub
      extends io.grpc.stub.AbstractAsyncStub<OffsiteReplicationServiceStub> {
    private OffsiteReplicationServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected OffsiteReplicationServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new OffsiteReplicationServiceStub(channel, callOptions);
    }

    /**
     */
    public void getReplicationInformation(com.iland.offsite.replication.api.grpc.ReplicationInformationRequest request,
        io.grpc.stub.StreamObserver<com.iland.offsite.replication.api.grpc.SerializedResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetReplicationInformationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getStorageHistory(com.iland.offsite.replication.api.grpc.StorageHistoryRequest request,
        io.grpc.stub.StreamObserver<com.iland.offsite.replication.api.grpc.SerializedResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetStorageHistoryMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getStorageReport(com.iland.offsite.replication.api.grpc.StorageHistoryRequest request,
        io.grpc.stub.StreamObserver<com.iland.offsite.replication.api.grpc.FileData> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getGetStorageReportMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service OffsiteReplicationService.
   */
  public static final class OffsiteReplicationServiceBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<OffsiteReplicationServiceBlockingV2Stub> {
    private OffsiteReplicationServiceBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected OffsiteReplicationServiceBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new OffsiteReplicationServiceBlockingV2Stub(channel, callOptions);
    }

    /**
     */
    public com.iland.offsite.replication.api.grpc.SerializedResponse getReplicationInformation(com.iland.offsite.replication.api.grpc.ReplicationInformationRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetReplicationInformationMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.offsite.replication.api.grpc.SerializedResponse getStorageHistory(com.iland.offsite.replication.api.grpc.StorageHistoryRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetStorageHistoryMethod(), getCallOptions(), request);
    }

    /**
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<?, com.iland.offsite.replication.api.grpc.FileData>
        getStorageReport(com.iland.offsite.replication.api.grpc.StorageHistoryRequest request) {
      return io.grpc.stub.ClientCalls.blockingV2ServerStreamingCall(
          getChannel(), getGetStorageReportMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service OffsiteReplicationService.
   */
  public static final class OffsiteReplicationServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<OffsiteReplicationServiceBlockingStub> {
    private OffsiteReplicationServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected OffsiteReplicationServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new OffsiteReplicationServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.iland.offsite.replication.api.grpc.SerializedResponse getReplicationInformation(com.iland.offsite.replication.api.grpc.ReplicationInformationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetReplicationInformationMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.offsite.replication.api.grpc.SerializedResponse getStorageHistory(com.iland.offsite.replication.api.grpc.StorageHistoryRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetStorageHistoryMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.iland.offsite.replication.api.grpc.FileData> getStorageReport(
        com.iland.offsite.replication.api.grpc.StorageHistoryRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getGetStorageReportMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service OffsiteReplicationService.
   */
  public static final class OffsiteReplicationServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<OffsiteReplicationServiceFutureStub> {
    private OffsiteReplicationServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected OffsiteReplicationServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new OffsiteReplicationServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.offsite.replication.api.grpc.SerializedResponse> getReplicationInformation(
        com.iland.offsite.replication.api.grpc.ReplicationInformationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetReplicationInformationMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.offsite.replication.api.grpc.SerializedResponse> getStorageHistory(
        com.iland.offsite.replication.api.grpc.StorageHistoryRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetStorageHistoryMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_REPLICATION_INFORMATION = 0;
  private static final int METHODID_GET_STORAGE_HISTORY = 1;
  private static final int METHODID_GET_STORAGE_REPORT = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_REPLICATION_INFORMATION:
          serviceImpl.getReplicationInformation((com.iland.offsite.replication.api.grpc.ReplicationInformationRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.offsite.replication.api.grpc.SerializedResponse>) responseObserver);
          break;
        case METHODID_GET_STORAGE_HISTORY:
          serviceImpl.getStorageHistory((com.iland.offsite.replication.api.grpc.StorageHistoryRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.offsite.replication.api.grpc.SerializedResponse>) responseObserver);
          break;
        case METHODID_GET_STORAGE_REPORT:
          serviceImpl.getStorageReport((com.iland.offsite.replication.api.grpc.StorageHistoryRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.offsite.replication.api.grpc.FileData>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getGetReplicationInformationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.offsite.replication.api.grpc.ReplicationInformationRequest,
              com.iland.offsite.replication.api.grpc.SerializedResponse>(
                service, METHODID_GET_REPLICATION_INFORMATION)))
        .addMethod(
          getGetStorageHistoryMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.offsite.replication.api.grpc.StorageHistoryRequest,
              com.iland.offsite.replication.api.grpc.SerializedResponse>(
                service, METHODID_GET_STORAGE_HISTORY)))
        .addMethod(
          getGetStorageReportMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.iland.offsite.replication.api.grpc.StorageHistoryRequest,
              com.iland.offsite.replication.api.grpc.FileData>(
                service, METHODID_GET_STORAGE_REPORT)))
        .build();
  }

  private static abstract class OffsiteReplicationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    OffsiteReplicationServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.iland.offsite.replication.api.grpc.CohesityoffsitereplicationApi.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("OffsiteReplicationService");
    }
  }

  private static final class OffsiteReplicationServiceFileDescriptorSupplier
      extends OffsiteReplicationServiceBaseDescriptorSupplier {
    OffsiteReplicationServiceFileDescriptorSupplier() {}
  }

  private static final class OffsiteReplicationServiceMethodDescriptorSupplier
      extends OffsiteReplicationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    OffsiteReplicationServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (OffsiteReplicationServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new OffsiteReplicationServiceFileDescriptorSupplier())
              .addMethod(getGetReplicationInformationMethod())
              .addMethod(getGetStorageHistoryMethod())
              .addMethod(getGetStorageReportMethod())
              .build();
        }
      }
    }
    return result;
  }
}
