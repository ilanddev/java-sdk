/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlElement;

/**
 * GuestProcessingIptions.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class GuestProcessingOptions implements Serializable {

  private static final long serialVersionUID = 6465467536398523691L;

  @XmlElement(name = "VssSnapshotOptions")
  private VssSnapshotOptions vssSnapshotOptions;

  @XmlElement(name = "WindowsGuestFSIndexingOptions")
  private GuestFSIndexingOptions windowsGuestFSIndexingOptions;

  @XmlElement(name = "LinuxGuestFSIndexingOptions")
  private GuestFSIndexingOptions linuxGuestFSIndexingOptions;

  @XmlElement(name = "SqlBackupOptions")
  private SqlBackupOptions sqlBackupOptions;

  @XmlElement(name = "WindowsCredentialsId")
  private String windowsCredentialsId;

  @XmlElement(name = "LinuxCredentialsId")
  private String linuxCredentialsId;

  public GuestProcessingOptions() {
  }

  public GuestProcessingOptions(final VssSnapshotOptions vssSnapshotMode,
      final GuestFSIndexingOptions guestFSIndexingOptions,
      final GuestFSIndexingOptions linuxGuestFSIndexingOptions,
      final SqlBackupOptions sqlBackupOptions,
      final String windowsCredentialsId, final String linuxCredentialsId) {
    this.vssSnapshotOptions = vssSnapshotOptions;
    this.windowsGuestFSIndexingOptions = guestFSIndexingOptions;
    this.linuxGuestFSIndexingOptions = linuxGuestFSIndexingOptions;
    this.sqlBackupOptions = sqlBackupOptions;
    this.windowsCredentialsId = windowsCredentialsId;
    this.linuxCredentialsId = linuxCredentialsId;
  }

  /**
   * Get the VSS Snapshot options.
   *
   * @return {@link VssSnapshotOptions} vss snapshot options
   */
  public VssSnapshotOptions getVssSnapshotOptions() {
    return vssSnapshotOptions;
  }

  /**
   * Get the windows guest filesystem indexing options.
   *
   * @return {@link GuestFSIndexingOptions} windows guest FS indexing options
   */
  public GuestFSIndexingOptions getWindowsGuestFSIndexingOptions() {
    return windowsGuestFSIndexingOptions;
  }

  /**
   * Get the linux guest filesystem indexing options.
   *
   * @return {@link GuestFSIndexingOptions} linux guest FS indexing options
   */
  public GuestFSIndexingOptions getLinuxGuestFSIndexingOptions() {
    return linuxGuestFSIndexingOptions;
  }

  /**
   * Get the SQL backup options.
   *
   * @return {@link SqlBackupOptions} SQL backup options
   */
  public SqlBackupOptions getSqlBackupOptions() {
    return sqlBackupOptions;
  }

  /**
   * Get the windows crednetials ID.
   *
   * @return windows credentials ID
   */
  public String getWindowsCredentialsId() {
    return windowsCredentialsId;
  }

  /**
   * Get the linux credentials ID.
   *
   * @return linux credentials ID
   */
  public String getLinuxCredentialsId() {
    return linuxCredentialsId;
  }

}
