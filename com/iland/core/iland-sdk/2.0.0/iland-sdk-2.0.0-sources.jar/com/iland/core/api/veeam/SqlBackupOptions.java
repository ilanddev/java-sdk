/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlElement;

/**
 * SqlBackupOptions.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class SqlBackupOptions implements Serializable {

  private static final long serialVersionUID = -3991410642922123506L;

  @XmlElement(name = "TransactionLogsProcessing")
  private String transactionLogsProcessing;

  @XmlElement(name = "BackupLogsFrequencyMin")
  private long backupLogsFrequencyMin;

  @XmlElement(name = "UseDbBackupRetention")
  private boolean useDbBackupRetention;

  @XmlElement(name = "RetainDays")
  private long retentionDays;

  public SqlBackupOptions() {
  }

  public SqlBackupOptions(final String transactionLogsProcessing,
      final long backupLogsFrequencyMin, final boolean useDbBackupRetention,
      final long retentionDays) {
    this.transactionLogsProcessing = transactionLogsProcessing;
    this.backupLogsFrequencyMin = backupLogsFrequencyMin;
    this.useDbBackupRetention = useDbBackupRetention;
    this.retentionDays = retentionDays;
  }

  /**
   * Get the transaction log processing.
   *
   * @return transaction log processing
   */
  public String getTransactionLogsProcessing() {
    return transactionLogsProcessing;
  }

  /**
   * Get the backup logs frequency in minutes.
   *
   * @return backup log frequency
   */
  public long getBackupLogsFrequencyMin() {
    return backupLogsFrequencyMin;
  }

  /**
   * Use DB backup retention?
   *
   * @return use db backup retention
   */
  public boolean isUseDbBackupRetention() {
    return useDbBackupRetention;
  }

  /**
   * Get number of retention days.
   *
   * @return retention in days
   */
  public long getRetentionDays() {
    return retentionDays;
  }

}
