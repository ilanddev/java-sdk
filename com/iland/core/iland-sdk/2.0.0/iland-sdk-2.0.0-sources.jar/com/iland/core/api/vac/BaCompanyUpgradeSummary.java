/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vac;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Optional;

import com.iland.core.api.billing.VccBill;
import com.iland.core.api.company.Company;
import com.iland.core.api.salesforce.SalesforceAccount;
import com.iland.core.api.user.User;

/**
 * BaCompanyUpgradeSummary.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public final class BaCompanyUpgradeSummary implements Serializable {

  private static final long serialVersionUID = -3366959742893852311L;

  private final String crm;

  private final long additionalStorageInGB;

  private final User initiatingUser;

  private final Company company;

  private final VspcCompany baCompany;

  private final LocalDateTime time;

  private final VccBill currentBill;

  private final Optional<SalesforceAccount> account;

  private final String locationId;

  private final String contractUuid;

  /**
   * Instantiates a new Upgrade ba company contract summary.
   *
   * @param additionalStorageInGB the additional storage in gb
   * @param initiatingUser        the initiating user
   * @param company               the company
   * @param baCompany             the ba company
   * @param time                  the time
   * @param currentBill           the current bill
   * @param account               the account
   * @param locationId            the location id
   * @param contractUuid            the contract uuid
   */
  public BaCompanyUpgradeSummary(final long additionalStorageInGB,
      final User initiatingUser, final Company company,
      final VspcCompany baCompany, final LocalDateTime time,
      final VccBill currentBill, final Optional<SalesforceAccount> account,
      final String locationId, final String contractUuid) {
    this.crm = company.getCompanyId();
    this.additionalStorageInGB = additionalStorageInGB;
    this.initiatingUser = initiatingUser;
    this.company = company;
    this.baCompany = baCompany;
    this.time = time;
    this.currentBill = currentBill;
    this.account = account;
    this.locationId = locationId;
    this.contractUuid = contractUuid;
  }

  /**
   * Gets crm.
   *
   * @return the crm
   */
  public String getCrm() {
    return crm;
  }

  /**
   * Gets additional storage in gb.
   *
   * @return the additional storage in gb
   */
  public long getAdditionalStorageInGB() {
    return additionalStorageInGB;
  }

  /**
   * Gets initiating user.
   *
   * @return the initiating user
   */
  public User getInitiatingUser() {
    return initiatingUser;
  }

  /**
   * Gets ba company.
   *
   * @return the company
   */
  public Company getCompany() {
    return company;
  }

  /**
   * Gets ba company.
   *
   * @return the ba company
   */
  public VspcCompany getBaCompany() {
    return baCompany;
  }

  /**
   * Gets time.
   *
   * @return the time
   */
  public LocalDateTime getTime() {
    return time;
  }

  /**
   * Gets current bill.
   *
   * @return the current bill
   */
  public VccBill getCurrentBill() {
    return currentBill;
  }

  /**
   * Gets account.
   *
   * @return the account
   */
  public Optional<SalesforceAccount> getAccount() {
    return account;
  }

  /**
   * Gets the location id.
   *
   * @return {@link String} location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Get the contract uuid.
   *
   * @return {@link String} contract uuid
   */
  public String getContractUuid() {
    return contractUuid;
  }
}
