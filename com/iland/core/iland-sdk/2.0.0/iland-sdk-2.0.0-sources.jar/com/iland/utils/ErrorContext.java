/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.utils;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import com.google.common.base.MoreObjects;
import org.immutables.value.Value;

import com.iland.cohesity.iaas.backups.common.model.BackupGroupUid;
import com.iland.cohesity.iaas.backups.common.model.BackupRunUid;
import com.iland.cohesity.iaas.backups.common.model.CompanyId;
import com.iland.cohesity.iaas.backups.common.model.LocationId;
import com.iland.cohesity.iaas.backups.common.model.OrgUuid;
import com.iland.cohesity.iaas.backups.common.model.ProtectionSourceUid;
import com.iland.cohesity.iaas.backups.common.model.RawCohesityUid;
import com.iland.cohesity.iaas.backups.common.model.SourceUid;
import com.iland.cohesity.iaas.backups.common.model.StorageDomainUid;
import com.iland.cohesity.iaas.backups.common.model.StorageProfileUuid;
import com.iland.cohesity.iaas.backups.common.model.TenantUid;
import com.iland.cohesity.iaas.backups.common.model.VCloudUuid;
import com.iland.cohesity.iaas.backups.common.model.VappUuid;
import com.iland.cohesity.iaas.backups.common.model.VdcUuid;
import com.iland.cohesity.iaas.backups.common.model.VmUuid;

/**
 * Holds information useful for debugging an error.
 */
@Value.Immutable
public interface ErrorContext {

	Optional<String> message();

	Optional<LocationId> locationId();

	Optional<CompanyId> companyId();

	Optional<OrgUuid> orgUuid();

	Optional<VdcUuid> vdcUuid();

	Optional<TenantUid> tenantUid();

	Optional<RawCohesityUid> rawCohesityUid();

	Optional<ProtectionSourceUid> protectionSourceUid();

	Optional<BackupGroupUid> backupGroupUuid();

	Optional<BackupRunUid> backupRunUid();

	Optional<VappUuid> vappUuid();

	Optional<VCloudUuid> vCloudUuid();

	Optional<SourceUid> sourceUid();

	Optional<VmUuid> vmUuid();

	Optional<StorageDomainUid> storageDomainUid();

	Optional<StorageProfileUuid> storageProfileUuid();

	/**
	 * @return a {@link Map map} of entities ordered by subjective prominence
	 */
	@Value.Derived
	default Map<String, Optional<?>> asMap() {
		final Map<String, Optional<?>> map = new LinkedHashMap<>();
		map.put("locationId", locationId());
		map.put("companyId", companyId());
		map.put("orgUuid", orgUuid());
		map.put("vdcUuid", vdcUuid());
		map.put("tenantUid", tenantUid());
		map.put("rawCohesityUid", rawCohesityUid());
		map.put("protectionSourceUid", protectionSourceUid());
		map.put("backupGroupUuid", backupGroupUuid());
		map.put("backupRunUid", backupRunUid());
		map.put("vappUuid", vappUuid());
		map.put("vCloudUuid", vCloudUuid());
		map.put("sourceUid", sourceUid());
		map.put("vmUuid", vmUuid());
		map.put("storageDomainUid", storageDomainUid());
		map.put("storageProfileUuid", storageProfileUuid());

		return map;
	}

	@Value.Derived
	default String asString() {
		final MoreObjects.ToStringHelper stringHelper =
			MoreObjects.toStringHelper(getClass());
		asMap().forEach((name, optionalEntity) -> optionalEntity.ifPresent(
			entity -> stringHelper.add(name, entity)));

		return stringHelper.toString();
	}

}
