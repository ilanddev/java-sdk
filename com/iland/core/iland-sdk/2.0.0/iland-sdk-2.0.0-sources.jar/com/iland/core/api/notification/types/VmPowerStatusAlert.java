/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification.types;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.notification.Alert;
import com.iland.core.api.notification.AlertDeliverySpec;
import com.iland.core.api.notification.AlertType;

/**
 * Vm Power Status Alert.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public class VmPowerStatusAlert extends Alert {

  @Expose
  @Since(0.1)
  @SerializedName(PowerStatusAlertField.VM_UUID)
  private String vmUuid;

  public VmPowerStatusAlert(final String uuid, final String username,
      final AlertDeliverySpec spec, final boolean enabled,
      final String vmUuid) {
    super(uuid, username, spec, enabled, AlertType.vm_power_status);
    this.vmUuid = vmUuid;
  }

  public VmPowerStatusAlert(final String uuid, final VmPowerStatusAlert a) {
    super(uuid, a.getUsername(), a.getDeliverySpec(), a.isEnabled(),
        AlertType.vm_power_status);
    this.vmUuid = a.getEntityUuid();
  }

  /**
   * Get the VM uuid.
   *
   * @return {@link String} vm uuid
   */
  public String getEntityUuid() {
    return vmUuid;
  }

}
