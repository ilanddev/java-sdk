/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.monocle.api.grpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@io.grpc.stub.annotations.GrpcGenerated
public final class MonocleServiceGrpc {

  private MonocleServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "io.grpc.MonocleService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.PurgeVboUsersRequest,
      com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getPurgeVboUsersMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "purgeVboUsers",
      requestType = com.iland.monocle.api.grpc.PurgeVboUsersRequest.class,
      responseType = com.iland.monocle.api.grpc.BaseMonocleTaskStatus.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.PurgeVboUsersRequest,
      com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getPurgeVboUsersMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.PurgeVboUsersRequest, com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getPurgeVboUsersMethod;
    if ((getPurgeVboUsersMethod = MonocleServiceGrpc.getPurgeVboUsersMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getPurgeVboUsersMethod = MonocleServiceGrpc.getPurgeVboUsersMethod) == null) {
          MonocleServiceGrpc.getPurgeVboUsersMethod = getPurgeVboUsersMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.PurgeVboUsersRequest, com.iland.monocle.api.grpc.BaseMonocleTaskStatus>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "purgeVboUsers"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.PurgeVboUsersRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.BaseMonocleTaskStatus.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("purgeVboUsers"))
              .build();
        }
      }
    }
    return getPurgeVboUsersMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest,
      com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getGet0365PurgeTaskStatusMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "get0365PurgeTaskStatus",
      requestType = com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest.class,
      responseType = com.iland.monocle.api.grpc.BaseMonocleTaskStatus.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest,
      com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getGet0365PurgeTaskStatusMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest, com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getGet0365PurgeTaskStatusMethod;
    if ((getGet0365PurgeTaskStatusMethod = MonocleServiceGrpc.getGet0365PurgeTaskStatusMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getGet0365PurgeTaskStatusMethod = MonocleServiceGrpc.getGet0365PurgeTaskStatusMethod) == null) {
          MonocleServiceGrpc.getGet0365PurgeTaskStatusMethod = getGet0365PurgeTaskStatusMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest, com.iland.monocle.api.grpc.BaseMonocleTaskStatus>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "get0365PurgeTaskStatus"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.BaseMonocleTaskStatus.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("get0365PurgeTaskStatus"))
              .build();
        }
      }
    }
    return getGet0365PurgeTaskStatusMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetSupportTicketsRequest,
      com.iland.monocle.api.grpc.GetSupportTicketsResponse> getGetSupportTicketsForCompanyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "getSupportTicketsForCompany",
      requestType = com.iland.monocle.api.grpc.GetSupportTicketsRequest.class,
      responseType = com.iland.monocle.api.grpc.GetSupportTicketsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetSupportTicketsRequest,
      com.iland.monocle.api.grpc.GetSupportTicketsResponse> getGetSupportTicketsForCompanyMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetSupportTicketsRequest, com.iland.monocle.api.grpc.GetSupportTicketsResponse> getGetSupportTicketsForCompanyMethod;
    if ((getGetSupportTicketsForCompanyMethod = MonocleServiceGrpc.getGetSupportTicketsForCompanyMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getGetSupportTicketsForCompanyMethod = MonocleServiceGrpc.getGetSupportTicketsForCompanyMethod) == null) {
          MonocleServiceGrpc.getGetSupportTicketsForCompanyMethod = getGetSupportTicketsForCompanyMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.GetSupportTicketsRequest, com.iland.monocle.api.grpc.GetSupportTicketsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "getSupportTicketsForCompany"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetSupportTicketsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetSupportTicketsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("getSupportTicketsForCompany"))
              .build();
        }
      }
    }
    return getGetSupportTicketsForCompanyMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.SubmitSupportTicketRequest,
      com.iland.monocle.api.grpc.SupportTicket> getSubmitSupportTicketMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "submitSupportTicket",
      requestType = com.iland.monocle.api.grpc.SubmitSupportTicketRequest.class,
      responseType = com.iland.monocle.api.grpc.SupportTicket.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.SubmitSupportTicketRequest,
      com.iland.monocle.api.grpc.SupportTicket> getSubmitSupportTicketMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.SubmitSupportTicketRequest, com.iland.monocle.api.grpc.SupportTicket> getSubmitSupportTicketMethod;
    if ((getSubmitSupportTicketMethod = MonocleServiceGrpc.getSubmitSupportTicketMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getSubmitSupportTicketMethod = MonocleServiceGrpc.getSubmitSupportTicketMethod) == null) {
          MonocleServiceGrpc.getSubmitSupportTicketMethod = getSubmitSupportTicketMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.SubmitSupportTicketRequest, com.iland.monocle.api.grpc.SupportTicket>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "submitSupportTicket"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.SubmitSupportTicketRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.SupportTicket.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("submitSupportTicket"))
              .build();
        }
      }
    }
    return getSubmitSupportTicketMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.TaskStatusRequest,
      com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getGetTaskStatusMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "getTaskStatus",
      requestType = com.iland.monocle.api.grpc.TaskStatusRequest.class,
      responseType = com.iland.monocle.api.grpc.BaseMonocleTaskStatus.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.TaskStatusRequest,
      com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getGetTaskStatusMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.TaskStatusRequest, com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getGetTaskStatusMethod;
    if ((getGetTaskStatusMethod = MonocleServiceGrpc.getGetTaskStatusMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getGetTaskStatusMethod = MonocleServiceGrpc.getGetTaskStatusMethod) == null) {
          MonocleServiceGrpc.getGetTaskStatusMethod = getGetTaskStatusMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.TaskStatusRequest, com.iland.monocle.api.grpc.BaseMonocleTaskStatus>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "getTaskStatus"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.TaskStatusRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.BaseMonocleTaskStatus.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("getTaskStatus"))
              .build();
        }
      }
    }
    return getGetTaskStatusMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.CreateAwsTenantRequest,
      com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getCreateAwsTenantMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "createAwsTenant",
      requestType = com.iland.monocle.api.grpc.CreateAwsTenantRequest.class,
      responseType = com.iland.monocle.api.grpc.BaseMonocleTaskStatus.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.CreateAwsTenantRequest,
      com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getCreateAwsTenantMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.CreateAwsTenantRequest, com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getCreateAwsTenantMethod;
    if ((getCreateAwsTenantMethod = MonocleServiceGrpc.getCreateAwsTenantMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getCreateAwsTenantMethod = MonocleServiceGrpc.getCreateAwsTenantMethod) == null) {
          MonocleServiceGrpc.getCreateAwsTenantMethod = getCreateAwsTenantMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.CreateAwsTenantRequest, com.iland.monocle.api.grpc.BaseMonocleTaskStatus>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "createAwsTenant"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.CreateAwsTenantRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.BaseMonocleTaskStatus.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("createAwsTenant"))
              .build();
        }
      }
    }
    return getCreateAwsTenantMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.UpdateStorageQuotaRequest,
      com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getUpdateAwsTenantStorageQuotaMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "updateAwsTenantStorageQuota",
      requestType = com.iland.monocle.api.grpc.UpdateStorageQuotaRequest.class,
      responseType = com.iland.monocle.api.grpc.BaseMonocleTaskStatus.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.UpdateStorageQuotaRequest,
      com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getUpdateAwsTenantStorageQuotaMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.UpdateStorageQuotaRequest, com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getUpdateAwsTenantStorageQuotaMethod;
    if ((getUpdateAwsTenantStorageQuotaMethod = MonocleServiceGrpc.getUpdateAwsTenantStorageQuotaMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getUpdateAwsTenantStorageQuotaMethod = MonocleServiceGrpc.getUpdateAwsTenantStorageQuotaMethod) == null) {
          MonocleServiceGrpc.getUpdateAwsTenantStorageQuotaMethod = getUpdateAwsTenantStorageQuotaMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.UpdateStorageQuotaRequest, com.iland.monocle.api.grpc.BaseMonocleTaskStatus>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "updateAwsTenantStorageQuota"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.UpdateStorageQuotaRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.BaseMonocleTaskStatus.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("updateAwsTenantStorageQuota"))
              .build();
        }
      }
    }
    return getUpdateAwsTenantStorageQuotaMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.VeeamPulseLicenseRequest,
      com.iland.monocle.api.grpc.VeeamPulseLicenseResponse> getDownloadVeeamPulseLicenseMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "downloadVeeamPulseLicense",
      requestType = com.iland.monocle.api.grpc.VeeamPulseLicenseRequest.class,
      responseType = com.iland.monocle.api.grpc.VeeamPulseLicenseResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.VeeamPulseLicenseRequest,
      com.iland.monocle.api.grpc.VeeamPulseLicenseResponse> getDownloadVeeamPulseLicenseMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.VeeamPulseLicenseRequest, com.iland.monocle.api.grpc.VeeamPulseLicenseResponse> getDownloadVeeamPulseLicenseMethod;
    if ((getDownloadVeeamPulseLicenseMethod = MonocleServiceGrpc.getDownloadVeeamPulseLicenseMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getDownloadVeeamPulseLicenseMethod = MonocleServiceGrpc.getDownloadVeeamPulseLicenseMethod) == null) {
          MonocleServiceGrpc.getDownloadVeeamPulseLicenseMethod = getDownloadVeeamPulseLicenseMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.VeeamPulseLicenseRequest, com.iland.monocle.api.grpc.VeeamPulseLicenseResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "downloadVeeamPulseLicense"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.VeeamPulseLicenseRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.VeeamPulseLicenseResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("downloadVeeamPulseLicense"))
              .build();
        }
      }
    }
    return getDownloadVeeamPulseLicenseMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeysRequest,
      com.iland.monocle.api.grpc.GetAwsAccountKeysResponse> getGetAwsAccountKeysMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "getAwsAccountKeys",
      requestType = com.iland.monocle.api.grpc.GetAwsAccountKeysRequest.class,
      responseType = com.iland.monocle.api.grpc.GetAwsAccountKeysResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeysRequest,
      com.iland.monocle.api.grpc.GetAwsAccountKeysResponse> getGetAwsAccountKeysMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeysRequest, com.iland.monocle.api.grpc.GetAwsAccountKeysResponse> getGetAwsAccountKeysMethod;
    if ((getGetAwsAccountKeysMethod = MonocleServiceGrpc.getGetAwsAccountKeysMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getGetAwsAccountKeysMethod = MonocleServiceGrpc.getGetAwsAccountKeysMethod) == null) {
          MonocleServiceGrpc.getGetAwsAccountKeysMethod = getGetAwsAccountKeysMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.GetAwsAccountKeysRequest, com.iland.monocle.api.grpc.GetAwsAccountKeysResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "getAwsAccountKeys"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetAwsAccountKeysRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetAwsAccountKeysResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("getAwsAccountKeys"))
              .build();
        }
      }
    }
    return getGetAwsAccountKeysMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest,
      com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> getGenerateAwsAccountKeysMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "generateAwsAccountKeys",
      requestType = com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest.class,
      responseType = com.iland.monocle.api.grpc.GetAwsAccountKeyResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest,
      com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> getGenerateAwsAccountKeysMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest, com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> getGenerateAwsAccountKeysMethod;
    if ((getGenerateAwsAccountKeysMethod = MonocleServiceGrpc.getGenerateAwsAccountKeysMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getGenerateAwsAccountKeysMethod = MonocleServiceGrpc.getGenerateAwsAccountKeysMethod) == null) {
          MonocleServiceGrpc.getGenerateAwsAccountKeysMethod = getGenerateAwsAccountKeysMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest, com.iland.monocle.api.grpc.GetAwsAccountKeyResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "generateAwsAccountKeys"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetAwsAccountKeyResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("generateAwsAccountKeys"))
              .build();
        }
      }
    }
    return getGenerateAwsAccountKeysMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest,
      com.google.protobuf.Empty> getUpdateAwsAccountKeyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "updateAwsAccountKey",
      requestType = com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest,
      com.google.protobuf.Empty> getUpdateAwsAccountKeyMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest, com.google.protobuf.Empty> getUpdateAwsAccountKeyMethod;
    if ((getUpdateAwsAccountKeyMethod = MonocleServiceGrpc.getUpdateAwsAccountKeyMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getUpdateAwsAccountKeyMethod = MonocleServiceGrpc.getUpdateAwsAccountKeyMethod) == null) {
          MonocleServiceGrpc.getUpdateAwsAccountKeyMethod = getUpdateAwsAccountKeyMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "updateAwsAccountKey"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("updateAwsAccountKey"))
              .build();
        }
      }
    }
    return getUpdateAwsAccountKeyMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest,
      com.google.protobuf.Empty> getEnableAwsAccountKeyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "enableAwsAccountKey",
      requestType = com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest,
      com.google.protobuf.Empty> getEnableAwsAccountKeyMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest, com.google.protobuf.Empty> getEnableAwsAccountKeyMethod;
    if ((getEnableAwsAccountKeyMethod = MonocleServiceGrpc.getEnableAwsAccountKeyMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getEnableAwsAccountKeyMethod = MonocleServiceGrpc.getEnableAwsAccountKeyMethod) == null) {
          MonocleServiceGrpc.getEnableAwsAccountKeyMethod = getEnableAwsAccountKeyMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "enableAwsAccountKey"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("enableAwsAccountKey"))
              .build();
        }
      }
    }
    return getEnableAwsAccountKeyMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest,
      com.google.protobuf.Empty> getDisableAwsAccountKeyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "disableAwsAccountKey",
      requestType = com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest,
      com.google.protobuf.Empty> getDisableAwsAccountKeyMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest, com.google.protobuf.Empty> getDisableAwsAccountKeyMethod;
    if ((getDisableAwsAccountKeyMethod = MonocleServiceGrpc.getDisableAwsAccountKeyMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getDisableAwsAccountKeyMethod = MonocleServiceGrpc.getDisableAwsAccountKeyMethod) == null) {
          MonocleServiceGrpc.getDisableAwsAccountKeyMethod = getDisableAwsAccountKeyMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "disableAwsAccountKey"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("disableAwsAccountKey"))
              .build();
        }
      }
    }
    return getDisableAwsAccountKeyMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest,
      com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> getRotateAwsAccountKeyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "rotateAwsAccountKey",
      requestType = com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest.class,
      responseType = com.iland.monocle.api.grpc.GetAwsAccountKeyResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest,
      com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> getRotateAwsAccountKeyMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest, com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> getRotateAwsAccountKeyMethod;
    if ((getRotateAwsAccountKeyMethod = MonocleServiceGrpc.getRotateAwsAccountKeyMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getRotateAwsAccountKeyMethod = MonocleServiceGrpc.getRotateAwsAccountKeyMethod) == null) {
          MonocleServiceGrpc.getRotateAwsAccountKeyMethod = getRotateAwsAccountKeyMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest, com.iland.monocle.api.grpc.GetAwsAccountKeyResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "rotateAwsAccountKey"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetAwsAccountKeyResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("rotateAwsAccountKey"))
              .build();
        }
      }
    }
    return getRotateAwsAccountKeyMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest,
      com.google.protobuf.Empty> getDeleteAwsAccountKeyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "deleteAwsAccountKey",
      requestType = com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest,
      com.google.protobuf.Empty> getDeleteAwsAccountKeyMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest, com.google.protobuf.Empty> getDeleteAwsAccountKeyMethod;
    if ((getDeleteAwsAccountKeyMethod = MonocleServiceGrpc.getDeleteAwsAccountKeyMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getDeleteAwsAccountKeyMethod = MonocleServiceGrpc.getDeleteAwsAccountKeyMethod) == null) {
          MonocleServiceGrpc.getDeleteAwsAccountKeyMethod = getDeleteAwsAccountKeyMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "deleteAwsAccountKey"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("deleteAwsAccountKey"))
              .build();
        }
      }
    }
    return getDeleteAwsAccountKeyMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetS3BucketsRequest,
      com.iland.monocle.api.grpc.GetS3BucketSetResponse> getGetS3BucketsForAccountMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "getS3BucketsForAccount",
      requestType = com.iland.monocle.api.grpc.GetS3BucketsRequest.class,
      responseType = com.iland.monocle.api.grpc.GetS3BucketSetResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetS3BucketsRequest,
      com.iland.monocle.api.grpc.GetS3BucketSetResponse> getGetS3BucketsForAccountMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.GetS3BucketsRequest, com.iland.monocle.api.grpc.GetS3BucketSetResponse> getGetS3BucketsForAccountMethod;
    if ((getGetS3BucketsForAccountMethod = MonocleServiceGrpc.getGetS3BucketsForAccountMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getGetS3BucketsForAccountMethod = MonocleServiceGrpc.getGetS3BucketsForAccountMethod) == null) {
          MonocleServiceGrpc.getGetS3BucketsForAccountMethod = getGetS3BucketsForAccountMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.GetS3BucketsRequest, com.iland.monocle.api.grpc.GetS3BucketSetResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "getS3BucketsForAccount"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetS3BucketsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetS3BucketSetResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("getS3BucketsForAccount"))
              .build();
        }
      }
    }
    return getGetS3BucketsForAccountMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest,
      com.google.protobuf.Empty> getCreateS3BucketForAccountMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "createS3BucketForAccount",
      requestType = com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest,
      com.google.protobuf.Empty> getCreateS3BucketForAccountMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest, com.google.protobuf.Empty> getCreateS3BucketForAccountMethod;
    if ((getCreateS3BucketForAccountMethod = MonocleServiceGrpc.getCreateS3BucketForAccountMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getCreateS3BucketForAccountMethod = MonocleServiceGrpc.getCreateS3BucketForAccountMethod) == null) {
          MonocleServiceGrpc.getCreateS3BucketForAccountMethod = getCreateS3BucketForAccountMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "createS3BucketForAccount"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("createS3BucketForAccount"))
              .build();
        }
      }
    }
    return getCreateS3BucketForAccountMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.S3PriceIncreaseRequest,
      com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse> getGetPriceIncreaseCalculationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "getPriceIncreaseCalculation",
      requestType = com.iland.monocle.api.grpc.S3PriceIncreaseRequest.class,
      responseType = com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.S3PriceIncreaseRequest,
      com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse> getGetPriceIncreaseCalculationMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.S3PriceIncreaseRequest, com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse> getGetPriceIncreaseCalculationMethod;
    if ((getGetPriceIncreaseCalculationMethod = MonocleServiceGrpc.getGetPriceIncreaseCalculationMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getGetPriceIncreaseCalculationMethod = MonocleServiceGrpc.getGetPriceIncreaseCalculationMethod) == null) {
          MonocleServiceGrpc.getGetPriceIncreaseCalculationMethod = getGetPriceIncreaseCalculationMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.S3PriceIncreaseRequest, com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "getPriceIncreaseCalculation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.S3PriceIncreaseRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("getPriceIncreaseCalculation"))
              .build();
        }
      }
    }
    return getGetPriceIncreaseCalculationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.S3PriceIncreaseRequest,
      com.google.protobuf.Empty> getIncreaseS3StorageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "increaseS3Storage",
      requestType = com.iland.monocle.api.grpc.S3PriceIncreaseRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.S3PriceIncreaseRequest,
      com.google.protobuf.Empty> getIncreaseS3StorageMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.S3PriceIncreaseRequest, com.google.protobuf.Empty> getIncreaseS3StorageMethod;
    if ((getIncreaseS3StorageMethod = MonocleServiceGrpc.getIncreaseS3StorageMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getIncreaseS3StorageMethod = MonocleServiceGrpc.getIncreaseS3StorageMethod) == null) {
          MonocleServiceGrpc.getIncreaseS3StorageMethod = getIncreaseS3StorageMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.S3PriceIncreaseRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "increaseS3Storage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.S3PriceIncreaseRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("increaseS3Storage"))
              .build();
        }
      }
    }
    return getIncreaseS3StorageMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest,
      com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse> getGetContactEmailsForS3IncreaseStorageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "getContactEmailsForS3IncreaseStorage",
      requestType = com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest.class,
      responseType = com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest,
      com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse> getGetContactEmailsForS3IncreaseStorageMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest, com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse> getGetContactEmailsForS3IncreaseStorageMethod;
    if ((getGetContactEmailsForS3IncreaseStorageMethod = MonocleServiceGrpc.getGetContactEmailsForS3IncreaseStorageMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getGetContactEmailsForS3IncreaseStorageMethod = MonocleServiceGrpc.getGetContactEmailsForS3IncreaseStorageMethod) == null) {
          MonocleServiceGrpc.getGetContactEmailsForS3IncreaseStorageMethod = getGetContactEmailsForS3IncreaseStorageMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest, com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "getContactEmailsForS3IncreaseStorage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("getContactEmailsForS3IncreaseStorage"))
              .build();
        }
      }
    }
    return getGetContactEmailsForS3IncreaseStorageMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.AwsAccountCreationRequest,
      com.iland.monocle.api.grpc.AwsAccountCreationResponse> getCreateAwsAccountMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "createAwsAccount",
      requestType = com.iland.monocle.api.grpc.AwsAccountCreationRequest.class,
      responseType = com.iland.monocle.api.grpc.AwsAccountCreationResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.AwsAccountCreationRequest,
      com.iland.monocle.api.grpc.AwsAccountCreationResponse> getCreateAwsAccountMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.AwsAccountCreationRequest, com.iland.monocle.api.grpc.AwsAccountCreationResponse> getCreateAwsAccountMethod;
    if ((getCreateAwsAccountMethod = MonocleServiceGrpc.getCreateAwsAccountMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getCreateAwsAccountMethod = MonocleServiceGrpc.getCreateAwsAccountMethod) == null) {
          MonocleServiceGrpc.getCreateAwsAccountMethod = getCreateAwsAccountMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.AwsAccountCreationRequest, com.iland.monocle.api.grpc.AwsAccountCreationResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "createAwsAccount"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.AwsAccountCreationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.AwsAccountCreationResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("createAwsAccount"))
              .build();
        }
      }
    }
    return getCreateAwsAccountMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest,
      com.google.protobuf.Empty> getUpdateAwsAccountNameMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "updateAwsAccountName",
      requestType = com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest,
      com.google.protobuf.Empty> getUpdateAwsAccountNameMethod() {
    io.grpc.MethodDescriptor<com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest, com.google.protobuf.Empty> getUpdateAwsAccountNameMethod;
    if ((getUpdateAwsAccountNameMethod = MonocleServiceGrpc.getUpdateAwsAccountNameMethod) == null) {
      synchronized (MonocleServiceGrpc.class) {
        if ((getUpdateAwsAccountNameMethod = MonocleServiceGrpc.getUpdateAwsAccountNameMethod) == null) {
          MonocleServiceGrpc.getUpdateAwsAccountNameMethod = getUpdateAwsAccountNameMethod =
              io.grpc.MethodDescriptor.<com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "updateAwsAccountName"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new MonocleServiceMethodDescriptorSupplier("updateAwsAccountName"))
              .build();
        }
      }
    }
    return getUpdateAwsAccountNameMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static MonocleServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MonocleServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MonocleServiceStub>() {
        @java.lang.Override
        public MonocleServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MonocleServiceStub(channel, callOptions);
        }
      };
    return MonocleServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static MonocleServiceBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MonocleServiceBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MonocleServiceBlockingV2Stub>() {
        @java.lang.Override
        public MonocleServiceBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MonocleServiceBlockingV2Stub(channel, callOptions);
        }
      };
    return MonocleServiceBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static MonocleServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MonocleServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MonocleServiceBlockingStub>() {
        @java.lang.Override
        public MonocleServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MonocleServiceBlockingStub(channel, callOptions);
        }
      };
    return MonocleServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static MonocleServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MonocleServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MonocleServiceFutureStub>() {
        @java.lang.Override
        public MonocleServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MonocleServiceFutureStub(channel, callOptions);
        }
      };
    return MonocleServiceFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     */
    default void purgeVboUsers(com.iland.monocle.api.grpc.PurgeVboUsersRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getPurgeVboUsersMethod(), responseObserver);
    }

    /**
     */
    default void get0365PurgeTaskStatus(com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGet0365PurgeTaskStatusMethod(), responseObserver);
    }

    /**
     */
    default void getSupportTicketsForCompany(com.iland.monocle.api.grpc.GetSupportTicketsRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetSupportTicketsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetSupportTicketsForCompanyMethod(), responseObserver);
    }

    /**
     */
    default void submitSupportTicket(com.iland.monocle.api.grpc.SubmitSupportTicketRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.SupportTicket> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSubmitSupportTicketMethod(), responseObserver);
    }

    /**
     */
    default void getTaskStatus(com.iland.monocle.api.grpc.TaskStatusRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetTaskStatusMethod(), responseObserver);
    }

    /**
     */
    default void createAwsTenant(com.iland.monocle.api.grpc.CreateAwsTenantRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateAwsTenantMethod(), responseObserver);
    }

    /**
     */
    default void updateAwsTenantStorageQuota(com.iland.monocle.api.grpc.UpdateStorageQuotaRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateAwsTenantStorageQuotaMethod(), responseObserver);
    }

    /**
     */
    default void downloadVeeamPulseLicense(com.iland.monocle.api.grpc.VeeamPulseLicenseRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.VeeamPulseLicenseResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDownloadVeeamPulseLicenseMethod(), responseObserver);
    }

    /**
     */
    default void getAwsAccountKeys(com.iland.monocle.api.grpc.GetAwsAccountKeysRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetAwsAccountKeysResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetAwsAccountKeysMethod(), responseObserver);
    }

    /**
     */
    default void generateAwsAccountKeys(com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGenerateAwsAccountKeysMethod(), responseObserver);
    }

    /**
     */
    default void updateAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateAwsAccountKeyMethod(), responseObserver);
    }

    /**
     */
    default void enableAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getEnableAwsAccountKeyMethod(), responseObserver);
    }

    /**
     */
    default void disableAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDisableAwsAccountKeyMethod(), responseObserver);
    }

    /**
     */
    default void rotateAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRotateAwsAccountKeyMethod(), responseObserver);
    }

    /**
     */
    default void deleteAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteAwsAccountKeyMethod(), responseObserver);
    }

    /**
     */
    default void getS3BucketsForAccount(com.iland.monocle.api.grpc.GetS3BucketsRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetS3BucketSetResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetS3BucketsForAccountMethod(), responseObserver);
    }

    /**
     */
    default void createS3BucketForAccount(com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateS3BucketForAccountMethod(), responseObserver);
    }

    /**
     */
    default void getPriceIncreaseCalculation(com.iland.monocle.api.grpc.S3PriceIncreaseRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetPriceIncreaseCalculationMethod(), responseObserver);
    }

    /**
     */
    default void increaseS3Storage(com.iland.monocle.api.grpc.S3PriceIncreaseRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getIncreaseS3StorageMethod(), responseObserver);
    }

    /**
     */
    default void getContactEmailsForS3IncreaseStorage(com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetContactEmailsForS3IncreaseStorageMethod(), responseObserver);
    }

    /**
     */
    default void createAwsAccount(com.iland.monocle.api.grpc.AwsAccountCreationRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.AwsAccountCreationResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateAwsAccountMethod(), responseObserver);
    }

    /**
     */
    default void updateAwsAccountName(com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateAwsAccountNameMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service MonocleService.
   */
  public static abstract class MonocleServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return MonocleServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service MonocleService.
   */
  public static final class MonocleServiceStub
      extends io.grpc.stub.AbstractAsyncStub<MonocleServiceStub> {
    private MonocleServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MonocleServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MonocleServiceStub(channel, callOptions);
    }

    /**
     */
    public void purgeVboUsers(com.iland.monocle.api.grpc.PurgeVboUsersRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getPurgeVboUsersMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void get0365PurgeTaskStatus(com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGet0365PurgeTaskStatusMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getSupportTicketsForCompany(com.iland.monocle.api.grpc.GetSupportTicketsRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetSupportTicketsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetSupportTicketsForCompanyMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void submitSupportTicket(com.iland.monocle.api.grpc.SubmitSupportTicketRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.SupportTicket> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getSubmitSupportTicketMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getTaskStatus(com.iland.monocle.api.grpc.TaskStatusRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetTaskStatusMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createAwsTenant(com.iland.monocle.api.grpc.CreateAwsTenantRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateAwsTenantMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateAwsTenantStorageQuota(com.iland.monocle.api.grpc.UpdateStorageQuotaRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateAwsTenantStorageQuotaMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void downloadVeeamPulseLicense(com.iland.monocle.api.grpc.VeeamPulseLicenseRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.VeeamPulseLicenseResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDownloadVeeamPulseLicenseMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getAwsAccountKeys(com.iland.monocle.api.grpc.GetAwsAccountKeysRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetAwsAccountKeysResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetAwsAccountKeysMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void generateAwsAccountKeys(com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGenerateAwsAccountKeysMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateAwsAccountKeyMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void enableAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getEnableAwsAccountKeyMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void disableAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDisableAwsAccountKeyMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void rotateAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRotateAwsAccountKeyMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteAwsAccountKeyMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getS3BucketsForAccount(com.iland.monocle.api.grpc.GetS3BucketsRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetS3BucketSetResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetS3BucketsForAccountMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createS3BucketForAccount(com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateS3BucketForAccountMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getPriceIncreaseCalculation(com.iland.monocle.api.grpc.S3PriceIncreaseRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetPriceIncreaseCalculationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void increaseS3Storage(com.iland.monocle.api.grpc.S3PriceIncreaseRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getIncreaseS3StorageMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getContactEmailsForS3IncreaseStorage(com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetContactEmailsForS3IncreaseStorageMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createAwsAccount(com.iland.monocle.api.grpc.AwsAccountCreationRequest request,
        io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.AwsAccountCreationResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateAwsAccountMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateAwsAccountName(com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateAwsAccountNameMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service MonocleService.
   */
  public static final class MonocleServiceBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<MonocleServiceBlockingV2Stub> {
    private MonocleServiceBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MonocleServiceBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MonocleServiceBlockingV2Stub(channel, callOptions);
    }

    /**
     */
    public com.iland.monocle.api.grpc.BaseMonocleTaskStatus purgeVboUsers(com.iland.monocle.api.grpc.PurgeVboUsersRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getPurgeVboUsersMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.BaseMonocleTaskStatus get0365PurgeTaskStatus(com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGet0365PurgeTaskStatusMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetSupportTicketsResponse getSupportTicketsForCompany(com.iland.monocle.api.grpc.GetSupportTicketsRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetSupportTicketsForCompanyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.SupportTicket submitSupportTicket(com.iland.monocle.api.grpc.SubmitSupportTicketRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getSubmitSupportTicketMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.BaseMonocleTaskStatus getTaskStatus(com.iland.monocle.api.grpc.TaskStatusRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetTaskStatusMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.BaseMonocleTaskStatus createAwsTenant(com.iland.monocle.api.grpc.CreateAwsTenantRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getCreateAwsTenantMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.BaseMonocleTaskStatus updateAwsTenantStorageQuota(com.iland.monocle.api.grpc.UpdateStorageQuotaRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getUpdateAwsTenantStorageQuotaMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.VeeamPulseLicenseResponse downloadVeeamPulseLicense(com.iland.monocle.api.grpc.VeeamPulseLicenseRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getDownloadVeeamPulseLicenseMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetAwsAccountKeysResponse getAwsAccountKeys(com.iland.monocle.api.grpc.GetAwsAccountKeysRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetAwsAccountKeysMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetAwsAccountKeyResponse generateAwsAccountKeys(com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGenerateAwsAccountKeysMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty updateAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getUpdateAwsAccountKeyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty enableAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getEnableAwsAccountKeyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty disableAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getDisableAwsAccountKeyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetAwsAccountKeyResponse rotateAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getRotateAwsAccountKeyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getDeleteAwsAccountKeyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetS3BucketSetResponse getS3BucketsForAccount(com.iland.monocle.api.grpc.GetS3BucketsRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetS3BucketsForAccountMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty createS3BucketForAccount(com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getCreateS3BucketForAccountMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse getPriceIncreaseCalculation(com.iland.monocle.api.grpc.S3PriceIncreaseRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetPriceIncreaseCalculationMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty increaseS3Storage(com.iland.monocle.api.grpc.S3PriceIncreaseRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getIncreaseS3StorageMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse getContactEmailsForS3IncreaseStorage(com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetContactEmailsForS3IncreaseStorageMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.AwsAccountCreationResponse createAwsAccount(com.iland.monocle.api.grpc.AwsAccountCreationRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getCreateAwsAccountMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty updateAwsAccountName(com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getUpdateAwsAccountNameMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service MonocleService.
   */
  public static final class MonocleServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<MonocleServiceBlockingStub> {
    private MonocleServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MonocleServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MonocleServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.iland.monocle.api.grpc.BaseMonocleTaskStatus purgeVboUsers(com.iland.monocle.api.grpc.PurgeVboUsersRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPurgeVboUsersMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.BaseMonocleTaskStatus get0365PurgeTaskStatus(com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGet0365PurgeTaskStatusMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetSupportTicketsResponse getSupportTicketsForCompany(com.iland.monocle.api.grpc.GetSupportTicketsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetSupportTicketsForCompanyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.SupportTicket submitSupportTicket(com.iland.monocle.api.grpc.SubmitSupportTicketRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSubmitSupportTicketMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.BaseMonocleTaskStatus getTaskStatus(com.iland.monocle.api.grpc.TaskStatusRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetTaskStatusMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.BaseMonocleTaskStatus createAwsTenant(com.iland.monocle.api.grpc.CreateAwsTenantRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateAwsTenantMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.BaseMonocleTaskStatus updateAwsTenantStorageQuota(com.iland.monocle.api.grpc.UpdateStorageQuotaRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateAwsTenantStorageQuotaMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.VeeamPulseLicenseResponse downloadVeeamPulseLicense(com.iland.monocle.api.grpc.VeeamPulseLicenseRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDownloadVeeamPulseLicenseMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetAwsAccountKeysResponse getAwsAccountKeys(com.iland.monocle.api.grpc.GetAwsAccountKeysRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetAwsAccountKeysMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetAwsAccountKeyResponse generateAwsAccountKeys(com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGenerateAwsAccountKeysMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty updateAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateAwsAccountKeyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty enableAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getEnableAwsAccountKeyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty disableAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDisableAwsAccountKeyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetAwsAccountKeyResponse rotateAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRotateAwsAccountKeyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteAwsAccountKey(com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteAwsAccountKeyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetS3BucketSetResponse getS3BucketsForAccount(com.iland.monocle.api.grpc.GetS3BucketsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetS3BucketsForAccountMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty createS3BucketForAccount(com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateS3BucketForAccountMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse getPriceIncreaseCalculation(com.iland.monocle.api.grpc.S3PriceIncreaseRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetPriceIncreaseCalculationMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty increaseS3Storage(com.iland.monocle.api.grpc.S3PriceIncreaseRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getIncreaseS3StorageMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse getContactEmailsForS3IncreaseStorage(com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetContactEmailsForS3IncreaseStorageMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.iland.monocle.api.grpc.AwsAccountCreationResponse createAwsAccount(com.iland.monocle.api.grpc.AwsAccountCreationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateAwsAccountMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty updateAwsAccountName(com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateAwsAccountNameMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service MonocleService.
   */
  public static final class MonocleServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<MonocleServiceFutureStub> {
    private MonocleServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MonocleServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MonocleServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> purgeVboUsers(
        com.iland.monocle.api.grpc.PurgeVboUsersRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getPurgeVboUsersMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> get0365PurgeTaskStatus(
        com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGet0365PurgeTaskStatusMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.GetSupportTicketsResponse> getSupportTicketsForCompany(
        com.iland.monocle.api.grpc.GetSupportTicketsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetSupportTicketsForCompanyMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.SupportTicket> submitSupportTicket(
        com.iland.monocle.api.grpc.SubmitSupportTicketRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getSubmitSupportTicketMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> getTaskStatus(
        com.iland.monocle.api.grpc.TaskStatusRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetTaskStatusMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> createAwsTenant(
        com.iland.monocle.api.grpc.CreateAwsTenantRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateAwsTenantMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.BaseMonocleTaskStatus> updateAwsTenantStorageQuota(
        com.iland.monocle.api.grpc.UpdateStorageQuotaRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateAwsTenantStorageQuotaMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.VeeamPulseLicenseResponse> downloadVeeamPulseLicense(
        com.iland.monocle.api.grpc.VeeamPulseLicenseRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDownloadVeeamPulseLicenseMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.GetAwsAccountKeysResponse> getAwsAccountKeys(
        com.iland.monocle.api.grpc.GetAwsAccountKeysRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetAwsAccountKeysMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> generateAwsAccountKeys(
        com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGenerateAwsAccountKeysMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> updateAwsAccountKey(
        com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateAwsAccountKeyMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> enableAwsAccountKey(
        com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getEnableAwsAccountKeyMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> disableAwsAccountKey(
        com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDisableAwsAccountKeyMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.GetAwsAccountKeyResponse> rotateAwsAccountKey(
        com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRotateAwsAccountKeyMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteAwsAccountKey(
        com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteAwsAccountKeyMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.GetS3BucketSetResponse> getS3BucketsForAccount(
        com.iland.monocle.api.grpc.GetS3BucketsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetS3BucketsForAccountMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> createS3BucketForAccount(
        com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateS3BucketForAccountMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse> getPriceIncreaseCalculation(
        com.iland.monocle.api.grpc.S3PriceIncreaseRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetPriceIncreaseCalculationMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> increaseS3Storage(
        com.iland.monocle.api.grpc.S3PriceIncreaseRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getIncreaseS3StorageMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse> getContactEmailsForS3IncreaseStorage(
        com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetContactEmailsForS3IncreaseStorageMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.iland.monocle.api.grpc.AwsAccountCreationResponse> createAwsAccount(
        com.iland.monocle.api.grpc.AwsAccountCreationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateAwsAccountMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> updateAwsAccountName(
        com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateAwsAccountNameMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_PURGE_VBO_USERS = 0;
  private static final int METHODID_GET0365PURGE_TASK_STATUS = 1;
  private static final int METHODID_GET_SUPPORT_TICKETS_FOR_COMPANY = 2;
  private static final int METHODID_SUBMIT_SUPPORT_TICKET = 3;
  private static final int METHODID_GET_TASK_STATUS = 4;
  private static final int METHODID_CREATE_AWS_TENANT = 5;
  private static final int METHODID_UPDATE_AWS_TENANT_STORAGE_QUOTA = 6;
  private static final int METHODID_DOWNLOAD_VEEAM_PULSE_LICENSE = 7;
  private static final int METHODID_GET_AWS_ACCOUNT_KEYS = 8;
  private static final int METHODID_GENERATE_AWS_ACCOUNT_KEYS = 9;
  private static final int METHODID_UPDATE_AWS_ACCOUNT_KEY = 10;
  private static final int METHODID_ENABLE_AWS_ACCOUNT_KEY = 11;
  private static final int METHODID_DISABLE_AWS_ACCOUNT_KEY = 12;
  private static final int METHODID_ROTATE_AWS_ACCOUNT_KEY = 13;
  private static final int METHODID_DELETE_AWS_ACCOUNT_KEY = 14;
  private static final int METHODID_GET_S3BUCKETS_FOR_ACCOUNT = 15;
  private static final int METHODID_CREATE_S3BUCKET_FOR_ACCOUNT = 16;
  private static final int METHODID_GET_PRICE_INCREASE_CALCULATION = 17;
  private static final int METHODID_INCREASE_S3STORAGE = 18;
  private static final int METHODID_GET_CONTACT_EMAILS_FOR_S3INCREASE_STORAGE = 19;
  private static final int METHODID_CREATE_AWS_ACCOUNT = 20;
  private static final int METHODID_UPDATE_AWS_ACCOUNT_NAME = 21;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_PURGE_VBO_USERS:
          serviceImpl.purgeVboUsers((com.iland.monocle.api.grpc.PurgeVboUsersRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus>) responseObserver);
          break;
        case METHODID_GET0365PURGE_TASK_STATUS:
          serviceImpl.get0365PurgeTaskStatus((com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus>) responseObserver);
          break;
        case METHODID_GET_SUPPORT_TICKETS_FOR_COMPANY:
          serviceImpl.getSupportTicketsForCompany((com.iland.monocle.api.grpc.GetSupportTicketsRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetSupportTicketsResponse>) responseObserver);
          break;
        case METHODID_SUBMIT_SUPPORT_TICKET:
          serviceImpl.submitSupportTicket((com.iland.monocle.api.grpc.SubmitSupportTicketRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.SupportTicket>) responseObserver);
          break;
        case METHODID_GET_TASK_STATUS:
          serviceImpl.getTaskStatus((com.iland.monocle.api.grpc.TaskStatusRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus>) responseObserver);
          break;
        case METHODID_CREATE_AWS_TENANT:
          serviceImpl.createAwsTenant((com.iland.monocle.api.grpc.CreateAwsTenantRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus>) responseObserver);
          break;
        case METHODID_UPDATE_AWS_TENANT_STORAGE_QUOTA:
          serviceImpl.updateAwsTenantStorageQuota((com.iland.monocle.api.grpc.UpdateStorageQuotaRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.BaseMonocleTaskStatus>) responseObserver);
          break;
        case METHODID_DOWNLOAD_VEEAM_PULSE_LICENSE:
          serviceImpl.downloadVeeamPulseLicense((com.iland.monocle.api.grpc.VeeamPulseLicenseRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.VeeamPulseLicenseResponse>) responseObserver);
          break;
        case METHODID_GET_AWS_ACCOUNT_KEYS:
          serviceImpl.getAwsAccountKeys((com.iland.monocle.api.grpc.GetAwsAccountKeysRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetAwsAccountKeysResponse>) responseObserver);
          break;
        case METHODID_GENERATE_AWS_ACCOUNT_KEYS:
          serviceImpl.generateAwsAccountKeys((com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetAwsAccountKeyResponse>) responseObserver);
          break;
        case METHODID_UPDATE_AWS_ACCOUNT_KEY:
          serviceImpl.updateAwsAccountKey((com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_ENABLE_AWS_ACCOUNT_KEY:
          serviceImpl.enableAwsAccountKey((com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_DISABLE_AWS_ACCOUNT_KEY:
          serviceImpl.disableAwsAccountKey((com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_ROTATE_AWS_ACCOUNT_KEY:
          serviceImpl.rotateAwsAccountKey((com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetAwsAccountKeyResponse>) responseObserver);
          break;
        case METHODID_DELETE_AWS_ACCOUNT_KEY:
          serviceImpl.deleteAwsAccountKey((com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_S3BUCKETS_FOR_ACCOUNT:
          serviceImpl.getS3BucketsForAccount((com.iland.monocle.api.grpc.GetS3BucketsRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetS3BucketSetResponse>) responseObserver);
          break;
        case METHODID_CREATE_S3BUCKET_FOR_ACCOUNT:
          serviceImpl.createS3BucketForAccount((com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_PRICE_INCREASE_CALCULATION:
          serviceImpl.getPriceIncreaseCalculation((com.iland.monocle.api.grpc.S3PriceIncreaseRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse>) responseObserver);
          break;
        case METHODID_INCREASE_S3STORAGE:
          serviceImpl.increaseS3Storage((com.iland.monocle.api.grpc.S3PriceIncreaseRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_CONTACT_EMAILS_FOR_S3INCREASE_STORAGE:
          serviceImpl.getContactEmailsForS3IncreaseStorage((com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse>) responseObserver);
          break;
        case METHODID_CREATE_AWS_ACCOUNT:
          serviceImpl.createAwsAccount((com.iland.monocle.api.grpc.AwsAccountCreationRequest) request,
              (io.grpc.stub.StreamObserver<com.iland.monocle.api.grpc.AwsAccountCreationResponse>) responseObserver);
          break;
        case METHODID_UPDATE_AWS_ACCOUNT_NAME:
          serviceImpl.updateAwsAccountName((com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getPurgeVboUsersMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.PurgeVboUsersRequest,
              com.iland.monocle.api.grpc.BaseMonocleTaskStatus>(
                service, METHODID_PURGE_VBO_USERS)))
        .addMethod(
          getGet0365PurgeTaskStatusMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.Get0365PurgeTaskStatusRequest,
              com.iland.monocle.api.grpc.BaseMonocleTaskStatus>(
                service, METHODID_GET0365PURGE_TASK_STATUS)))
        .addMethod(
          getGetSupportTicketsForCompanyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.GetSupportTicketsRequest,
              com.iland.monocle.api.grpc.GetSupportTicketsResponse>(
                service, METHODID_GET_SUPPORT_TICKETS_FOR_COMPANY)))
        .addMethod(
          getSubmitSupportTicketMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.SubmitSupportTicketRequest,
              com.iland.monocle.api.grpc.SupportTicket>(
                service, METHODID_SUBMIT_SUPPORT_TICKET)))
        .addMethod(
          getGetTaskStatusMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.TaskStatusRequest,
              com.iland.monocle.api.grpc.BaseMonocleTaskStatus>(
                service, METHODID_GET_TASK_STATUS)))
        .addMethod(
          getCreateAwsTenantMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.CreateAwsTenantRequest,
              com.iland.monocle.api.grpc.BaseMonocleTaskStatus>(
                service, METHODID_CREATE_AWS_TENANT)))
        .addMethod(
          getUpdateAwsTenantStorageQuotaMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.UpdateStorageQuotaRequest,
              com.iland.monocle.api.grpc.BaseMonocleTaskStatus>(
                service, METHODID_UPDATE_AWS_TENANT_STORAGE_QUOTA)))
        .addMethod(
          getDownloadVeeamPulseLicenseMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.VeeamPulseLicenseRequest,
              com.iland.monocle.api.grpc.VeeamPulseLicenseResponse>(
                service, METHODID_DOWNLOAD_VEEAM_PULSE_LICENSE)))
        .addMethod(
          getGetAwsAccountKeysMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.GetAwsAccountKeysRequest,
              com.iland.monocle.api.grpc.GetAwsAccountKeysResponse>(
                service, METHODID_GET_AWS_ACCOUNT_KEYS)))
        .addMethod(
          getGenerateAwsAccountKeysMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.GetAwsAccountKeyGenerationRequest,
              com.iland.monocle.api.grpc.GetAwsAccountKeyResponse>(
                service, METHODID_GENERATE_AWS_ACCOUNT_KEYS)))
        .addMethod(
          getUpdateAwsAccountKeyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.GetAwsAccountKeyUpdateRequest,
              com.google.protobuf.Empty>(
                service, METHODID_UPDATE_AWS_ACCOUNT_KEY)))
        .addMethod(
          getEnableAwsAccountKeyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.GetAwsAccountKeyEnableRequest,
              com.google.protobuf.Empty>(
                service, METHODID_ENABLE_AWS_ACCOUNT_KEY)))
        .addMethod(
          getDisableAwsAccountKeyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.GetAwsAccountKeyDisableRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DISABLE_AWS_ACCOUNT_KEY)))
        .addMethod(
          getRotateAwsAccountKeyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.GetAwsAccountKeyRotateRequest,
              com.iland.monocle.api.grpc.GetAwsAccountKeyResponse>(
                service, METHODID_ROTATE_AWS_ACCOUNT_KEY)))
        .addMethod(
          getDeleteAwsAccountKeyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.GetAwsAccountKeyDeleteRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_AWS_ACCOUNT_KEY)))
        .addMethod(
          getGetS3BucketsForAccountMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.GetS3BucketsRequest,
              com.iland.monocle.api.grpc.GetS3BucketSetResponse>(
                service, METHODID_GET_S3BUCKETS_FOR_ACCOUNT)))
        .addMethod(
          getCreateS3BucketForAccountMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.CreateAwsAccountKeyGenerationRequest,
              com.google.protobuf.Empty>(
                service, METHODID_CREATE_S3BUCKET_FOR_ACCOUNT)))
        .addMethod(
          getGetPriceIncreaseCalculationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.S3PriceIncreaseRequest,
              com.iland.monocle.api.grpc.GetS3PriceIncreaseInfoResponse>(
                service, METHODID_GET_PRICE_INCREASE_CALCULATION)))
        .addMethod(
          getIncreaseS3StorageMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.S3PriceIncreaseRequest,
              com.google.protobuf.Empty>(
                service, METHODID_INCREASE_S3STORAGE)))
        .addMethod(
          getGetContactEmailsForS3IncreaseStorageMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.S3PriceIncreaseEmailContactRequest,
              com.iland.monocle.api.grpc.GetS3PriceIncreaseEmailContactResponse>(
                service, METHODID_GET_CONTACT_EMAILS_FOR_S3INCREASE_STORAGE)))
        .addMethod(
          getCreateAwsAccountMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.AwsAccountCreationRequest,
              com.iland.monocle.api.grpc.AwsAccountCreationResponse>(
                service, METHODID_CREATE_AWS_ACCOUNT)))
        .addMethod(
          getUpdateAwsAccountNameMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.iland.monocle.api.grpc.UpdateAwsAccountNameRequest,
              com.google.protobuf.Empty>(
                service, METHODID_UPDATE_AWS_ACCOUNT_NAME)))
        .build();
  }

  private static abstract class MonocleServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    MonocleServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.iland.monocle.api.grpc.MonocleApi.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("MonocleService");
    }
  }

  private static final class MonocleServiceFileDescriptorSupplier
      extends MonocleServiceBaseDescriptorSupplier {
    MonocleServiceFileDescriptorSupplier() {}
  }

  private static final class MonocleServiceMethodDescriptorSupplier
      extends MonocleServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    MonocleServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (MonocleServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new MonocleServiceFileDescriptorSupplier())
              .addMethod(getPurgeVboUsersMethod())
              .addMethod(getGet0365PurgeTaskStatusMethod())
              .addMethod(getGetSupportTicketsForCompanyMethod())
              .addMethod(getSubmitSupportTicketMethod())
              .addMethod(getGetTaskStatusMethod())
              .addMethod(getCreateAwsTenantMethod())
              .addMethod(getUpdateAwsTenantStorageQuotaMethod())
              .addMethod(getDownloadVeeamPulseLicenseMethod())
              .addMethod(getGetAwsAccountKeysMethod())
              .addMethod(getGenerateAwsAccountKeysMethod())
              .addMethod(getUpdateAwsAccountKeyMethod())
              .addMethod(getEnableAwsAccountKeyMethod())
              .addMethod(getDisableAwsAccountKeyMethod())
              .addMethod(getRotateAwsAccountKeyMethod())
              .addMethod(getDeleteAwsAccountKeyMethod())
              .addMethod(getGetS3BucketsForAccountMethod())
              .addMethod(getCreateS3BucketForAccountMethod())
              .addMethod(getGetPriceIncreaseCalculationMethod())
              .addMethod(getIncreaseS3StorageMethod())
              .addMethod(getGetContactEmailsForS3IncreaseStorageMethod())
              .addMethod(getCreateAwsAccountMethod())
              .addMethod(getUpdateAwsAccountNameMethod())
              .build();
        }
      }
    }
    return result;
  }
}
