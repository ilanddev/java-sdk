/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * User Broad Vdc Resource Alert Subscription Impl.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class UserBroadVdcResourceAlert implements Serializable {

  private static final long serialVersionUID = 3382219790740408828L;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.USERNAME)
  private String username;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.VDC_UUID)
  private String vdcUuid;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.GROUP)
  private String group;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.NAME)
  private String name;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.TYPE)
  private String type;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.ACTIVE)
  private boolean active = true;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.THRESHOLD)
  private int threshold;

  @Since(ApiVersion.ZERO_DOT_ONE)
  @Expose
  @SerializedName(AlertSubscriptionField.VDC_TYPE)
  private String vdcType;

  public UserBroadVdcResourceAlert() {
  }

  public UserBroadVdcResourceAlert(String username, String vdcUuid,
      String group, String name, String type, boolean active, int threshold,
      String vdcType) {
    this.username = username;
    this.vdcUuid = vdcUuid;
    this.group = group;
    this.name = name;
    this.type = type;
    this.active = active;
    this.threshold = threshold;
    this.vdcType = vdcType;
  }

  public String getVdcUuid() {
    return vdcUuid;
  }

  public void setVdcUuid(String vdc) {
    this.vdcUuid = vdc;
  }

  public String getGroup() {
    return group;
  }

  public void setGroup(String group) {
    this.group = group;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  public int getThreshold() {
    return threshold;
  }

  public void setThreshold(long threshold) {
    this.threshold = (int) threshold;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getVdcType() {
    return vdcType;
  }

  public void setVdcType(String vdcType) {
    this.vdcType = vdcType;
  }

}
