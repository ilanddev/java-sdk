/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.vac;

/**
 * Vspc Create Backup Resource.
 * <p>
 * This object is serialized in the otherAttributes map of a core task to do
 * async actions related to the VSPC company site resource creation, formerly called VAC company create.
 * <p>
 * The fields are used to either create the backup resource needed for a new VSPC company site resource.
 * Or they are used to store the newly created company site resource in Cassandra through the microservice.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public final class VspcCreateBackupResource {

  private long storageInBytes;

  private String vspcConnectionHref;

  private String createdVspcCompanyUid;

  private String locationSiteUid;

  private String createCompanyActionId;

  private String createBackupResourceActionId;

  private String backupRepositoryUid;

  private String backupRepositoryName;

  private String locationId;

  private String companyId;

  public VspcCreateBackupResource(
      final VspcCreateBackupResourceBuilder builder) {
    this.storageInBytes = builder.storageInBytes;
    this.vspcConnectionHref = builder.vspcConnectionHref;
    this.createdVspcCompanyUid = builder.createdVspcCompanyUid;
    this.locationSiteUid = builder.locationSiteUid;
    this.createCompanyActionId = builder.createCompanyActionId;
    this.backupRepositoryUid = builder.backupRepositoryUid;
    this.backupRepositoryName = builder.backupRepositoryName;
    this.locationId = builder.locationId;
    this.companyId = builder.companyId;
  }

  public void setCreateBackupResourceActionId(
      final String createBackupResourceActionId) {
    this.createBackupResourceActionId = createBackupResourceActionId;
  }

  public long getStorageInBytes() {
    return storageInBytes;
  }

  public String getVspcConnectionHref() {
    return vspcConnectionHref;
  }

  public String getCreatedVspcCompanyUid() {
    return createdVspcCompanyUid;
  }

  public String getLocationSiteUid() {
    return locationSiteUid;
  }

  public String getCreateCompanyActionId() {
    return createCompanyActionId;
  }

  public String getCreateBackupResourceActionId() {
    return createBackupResourceActionId;
  }

  public String getBackupRepositoryUid() {
    return backupRepositoryUid;
  }

  public String getBackupRepositoryName() {
    return backupRepositoryName;
  }

  public String getLocationId() {
    return locationId;
  }

  public String getCompanyId() {
    return companyId;
  }

  public static class VspcCreateBackupResourceBuilder {

    private long storageInBytes;

    private String vspcConnectionHref;

    private String createdVspcCompanyUid;

    private String locationSiteUid;

    private String createCompanyActionId;

    private String backupRepositoryUid;

    private String backupRepositoryName;

    private String locationId;

    private String companyId;

    public VspcCreateBackupResourceBuilder storageInBytes(
        final long storageInBytes) {
      this.storageInBytes = storageInBytes;
      return this;
    }

    public VspcCreateBackupResourceBuilder vspcConnectionHref(
        final String vspcConnectionHref) {
      this.vspcConnectionHref = vspcConnectionHref;
      return this;
    }

    public VspcCreateBackupResourceBuilder createdVspcCompanyUid(
        final String createdVspcCompanyUid) {
      this.createdVspcCompanyUid = createdVspcCompanyUid;
      return this;
    }

    public VspcCreateBackupResourceBuilder locationSiteUid(
        final String locationSiteUid) {
      this.locationSiteUid = locationSiteUid;
      return this;
    }

    public VspcCreateBackupResourceBuilder createCompanyActionId(
        final String createCompanyActionId) {
      this.createCompanyActionId = createCompanyActionId;
      return this;
    }

    public VspcCreateBackupResourceBuilder backupRepositoryUid(
        final String backupRepositoryUid) {
      this.backupRepositoryUid = backupRepositoryUid;
      return this;
    }

    public VspcCreateBackupResourceBuilder backupRepositoryName(
        final String backupRepositoryName) {
      this.backupRepositoryName = backupRepositoryName;
      return this;
    }

    public VspcCreateBackupResourceBuilder locationId(final String locationId) {
      this.locationId = locationId;
      return this;
    }

    public VspcCreateBackupResourceBuilder companyId(final String companyId) {
      this.companyId = companyId;
      return this;
    }

    public VspcCreateBackupResource build() {
      return new VspcCreateBackupResource(this);
    }
  }
}
