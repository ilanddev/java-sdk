/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.coretask.api.domain;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.immutables.value.Value;

/**
 * Represents a platform datacenter location identifier.
 * Adheres to the format of: ${location}.${domain}.${top-level domain}
 * e.g. dal25.ilandcloud.com.
 */
@Value.Immutable
@Value.Style(
    // Generate construction method using all attributes as parameters
    allParameters = true,
    // Change generated name
    typeImmutable = "*Tuple",
    // Disable builder generation
    defaults = @Value.Immutable(builder = false),
    visibility = Value.Style.ImplementationVisibility.PACKAGE)
public interface LocationId {
  String value();

  static LocationId of(String value) {
    return LocationIdTuple.of(value);
  }

  /**
   * Returns a short identifier for a location ID.
   * <p>
   * For example:
   * <ul>
   *   <li>dev-vcd01.iland.dev  => dev</li>
   * </ul>
   */
  @Value.Derived
  @Value.Auxiliary
  default String shortIdentifier() {
    final int dotIdx = value().indexOf(".");
    final int dashIdx = value().indexOf("-");
    final int endIdx = dashIdx == -1 ? dotIdx : Math.min(dotIdx, dashIdx);

    return value().substring(0, endIdx);
  }

  @Value.Check
  default void check() {
    final Matcher matcher =
        Pattern.compile("^[a-z0-9\\-]+.[a-z]+.[a-z]+$").matcher(value());

    if (!matcher.matches()) {
      throw new IllegalStateException(
          ("Location ID=%s does not match the expected format: "
              + "${location}.${domain}.${top-level domain}"
              + " e.g. dal25.ilandcloud.com.").formatted(value()));
    }
  }
}
