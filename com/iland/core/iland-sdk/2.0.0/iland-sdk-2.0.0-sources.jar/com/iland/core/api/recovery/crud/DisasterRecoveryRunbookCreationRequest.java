/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.recovery.crud;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.recovery.RecoveryGroupDescriptor;
import com.iland.core.api.recovery.RecoveryRunbookField;
import com.iland.core.api.serialization.ApiVersion;
import com.iland.core.api.serialization.JsonOptional;
import com.iland.core.api.serialization.JsonRequired;

/**
 * Recovery Runbook.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class DisasterRecoveryRunbookCreationRequest implements Serializable {

  private static final long serialVersionUID = 5820151414669246910L;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @JsonRequired("recovery runbook name")
  @SerializedName(RecoveryRunbookField.NAME)
  private String name;

  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @JsonOptional("recovery runbook description")
  @SerializedName(RecoveryRunbookField.DESCRIPTION)
  private String description;

  // list of VPG uuids for now since one recovery group is equivalent to one VPG
  // this is an ordered list - where order denotes recovery order
  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  @JsonRequired("recovery runbook recovery group descriptors")
  @SerializedName(RecoveryRunbookField.RECOVERY_GROUPS)
  private List<RecoveryGroupDescriptor> recoveryGroupDescriptorList;

  public DisasterRecoveryRunbookCreationRequest(final String name,
      final String description,
      final List<RecoveryGroupDescriptor> recoveryGroupDescriptorList) {
    this.name = name;
    this.description = description;
    this.recoveryGroupDescriptorList = recoveryGroupDescriptorList;
  }

  /**
   * Get the runbook name.
   *
   * @return {@link String} runbook name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the runbook description.
   *
   * @return {@link String} description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get the list of recovery plan descriptors.
   *
   * @return {@link List} of {@link RecoveryGroupDescriptor} recovery plan
   * descriptors
   */
  public List<RecoveryGroupDescriptor> getRecoveryGroupDescriptorList() {
    return recoveryGroupDescriptorList;
  }

  /**
   * Validate the recovery runbook specification.
   *
   * @throws IllegalArgumentException if the runbook groups do not pass
   *                                  validation constraints
   */
  public void validateSpecification() throws IllegalArgumentException {
    // make sure the orderIndexes are in order, start at 0 and do not repeat
    if (recoveryGroupDescriptorList == null
        || recoveryGroupDescriptorList.size() < 1) {
      throw new IllegalArgumentException(
          "Must have at least 1 recovery plan in the runbook!");
    }
    if (recoveryGroupDescriptorList.get(0).getOrderIndex() != 0) {
      throw new IllegalArgumentException(
          "The first recovery plan order index must start at 0.");
    }
    final Set<String> recoveryPlanUuids = new HashSet<>();
    for (int i = 0; i < recoveryGroupDescriptorList.size(); i++) {
      if (recoveryGroupDescriptorList.get(i).getOrderIndex() != i) {
        throw new IllegalArgumentException(
            "The recovery plan order index must match the list index of the given recovery plan.");
      }
      recoveryPlanUuids.add(recoveryGroupDescriptorList.get(i).getUuid());
    }
    // also make sure that each recovery plan is only referenced once in this
    // runbook
    if (recoveryPlanUuids.size() != recoveryGroupDescriptorList.size()) {
      throw new IllegalArgumentException(
          "A recovery plan cannot be referenced more than once in a recovery runbook definition.");
    }
    for (final String vpgUuid : recoveryPlanUuids) {
      if (!vpgUuid.contains("urn:zerto:vpg")) {
        throw new IllegalArgumentException(
            String.format("Invalid recovery plan UUID: %s.", vpgUuid));
      }
    }
  }

}
