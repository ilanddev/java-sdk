/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.security;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.serialization.ApiVersion;

/**
 * Application Daily Request Count.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class ApplicationDailyRequestCount implements Serializable {

  /**
   * The Constant serialVersionUID.
   */
  private static final long serialVersionUID = -658175617016396162L;

  /**
   * The application name.
   */
  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  private final String applicationName;

  /**
   * The day.
   */
  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  private final Date day;

  /**
   * The count.
   */
  @Expose
  @Since(ApiVersion.ZERO_DOT_NINE)
  private final int count;

  /**
   * Instantiates a new application daily request count.
   *
   * @param applicationName the application name
   * @param day             the day
   * @param count           the count
   */
  public ApplicationDailyRequestCount(String applicationName, Date day,
      int count) {
    this.applicationName = applicationName;
    this.day = day;
    this.count = count;
  }

  /**
   * Gets the application name.
   *
   * @return the application name
   */
  public String getApplicationName() {
    return applicationName;
  }

  /**
   * Gets the day.
   *
   * @return the day
   */
  public Date getDay() {
    if (day != null) {
      return (Date) day.clone();
    }
    return null;
  }

  /**
   * Gets the count.
   *
   * @return the count
   */
  public int getCount() {
    return count;
  }

}
