/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.util;

import static java.util.Objects.requireNonNull;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * Units of bytes.
 */
public enum ByteUnit {

	B(1L),
	/**
	 * Kilobyte.
	 */
	KB(1_000L),
	/**
	 * Kibibyte.
	 */
	KiB(1_024L),
	/**
	 * Megabyte.
	 */
	MB(1_000L, 2),
	/**
	 * Mebibyte.
	 */
	MiB(1_024L, 2),
	/**
	 * Gigabyte.
	 */
	GB(1_000L, 3),
	/**
	 * Gibibyte.
	 */
	GiB(1_024L, 3),
	/**
	 * Terabyte.
	 */
	TB(1_000L, 4),
	/**
	 * Tebibyte.
	 */
	TiB(1_024L, 4),
	/**
	 * Petabyte.
	 */
	PB(1_000L, 5),
	/**
	 * Pebibyte.
	 */
	PiB(1_024L, 5);

	private final Long value;

	ByteUnit(long value) {
		this.value = value;
	}

	ByteUnit(long value, int power) {
		this.value = (long) Math.pow(value, power);
	}

	/**
	 * @return the value measured in bytes
	 */
	public long toBytes() {
		return value;
	}

	/**
	 * @return the value measured in bytes
	 */
	public long toBytes(final long amount) {
		return value * amount;
	}

	public static Optional<ByteUnit> fromValue(final String name) {
		requireNonNull(name, "name must not be null");

		return Stream.of(ByteUnit.values())
			.filter(byteUnit -> byteUnit.name().equalsIgnoreCase(name))
			.findFirst();
	}

	/**
	 * Convert bytes to human-readable string.
	 *
	 * @param bytes the number of bytes
	 * @return the formatted number of bytes
	 */
	public static String toString(final long bytes) {
		if (bytes == 0) {
			return "0 B";
		}

		final String prefix = bytes < 0 ? "-" : "";
		final long b = Math.abs(bytes);
		return Stream.of(values())
			.filter(bu -> (b / bu.toBytes()) < 1_000)
			.findFirst()
			.map(bu -> "%s%.2f %s".formatted(prefix, (b * 1D) / bu.toBytes(),
				bu.name()))
			.orElseGet(() -> "%s%d %s".formatted(prefix, b, ByteUnit.B.name()));
	}

}
