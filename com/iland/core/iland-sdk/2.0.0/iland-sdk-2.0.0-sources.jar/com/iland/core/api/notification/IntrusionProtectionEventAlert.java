/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import java.io.Serializable;

import com.iland.core.api.notification.types.IntrusionProtectionAlert;
import com.iland.core.api.trend.DPIEvent;
import com.iland.core.api.vcd.Org;
import com.iland.core.api.vcd.Vm;

/**
 * Intrusion Protection Event Alert.
 * <p>
 * Holds an {@link DPIEvent} and {@link IntrusionProtectionAlert} that are to be
 * used for sending a firewall event alert to a given user.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class IntrusionProtectionEventAlert implements Serializable {

  private static final long serialVersionUID = 3739514062662581911L;

  private final IntrusionProtectionAlert alert;

  private final DPIEvent event;

  private final Org org;

  private final Vm vm;

  private final String link;

  public IntrusionProtectionEventAlert(final IntrusionProtectionAlert alert,
      final DPIEvent event, final Org org, final Vm vm, final String link) {
    this.alert = alert;
    this.event = event;
    this.org = org;
    this.vm = vm;
    this.link = link;
  }

  /**
   * Get the intrusion protection alert.
   *
   * @return intrusion protection alert
   */
  public IntrusionProtectionAlert getAlert() {
    return alert;
  }

  /**
   * Get the intrusion protection event.
   *
   * @return intrusion protection event
   */
  public DPIEvent getEvent() {
    return event;
  }

  /**
   * Get the organization associated with the event.
   *
   * @return {@link Org} organization
   */
  public Org getOrg() {
    return org;
  }

  /**
   * Get the VM associated with the event.
   *
   * @return {@link Vm} virtual machine
   */
  public Vm getVm() {
    return vm;
  }

  /**
   * Get the dashboard URL link to the VM entity for the ECS console.
   *
   * @return {@link String} URL link
   */
  public String getLink() {
    return link;
  }

}
