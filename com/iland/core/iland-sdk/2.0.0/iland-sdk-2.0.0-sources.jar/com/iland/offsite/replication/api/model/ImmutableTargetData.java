/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.offsite.replication.api.model;

import com.google.common.base.MoreObjects;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.Var;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import org.immutables.value.Generated;

/**
 * Immutable implementation of {@link TargetData}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutableTargetData.builder()}.
 */
@Generated(from = "TargetData", generator = "Immutables")
@SuppressWarnings({"all"})
@ParametersAreNonnullByDefault
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
@Immutable
@CheckReturnValue
public final class ImmutableTargetData implements TargetData {
  private final @Nullable JobStatus status;
  private final @Nullable Instant startTime;
  private final @Nullable Instant endTime;

  private ImmutableTargetData(
      @Nullable JobStatus status,
      @Nullable Instant startTime,
      @Nullable Instant endTime) {
    this.status = status;
    this.startTime = startTime;
    this.endTime = endTime;
  }

  /**
   * The {@link JobStatus status} of the job.
   */
  @Override
  public Optional<JobStatus> status() {
    return Optional.ofNullable(status);
  }

  /**
   * The time that the replication task started.
   */
  @Override
  public Optional<Instant> startTime() {
    return Optional.ofNullable(startTime);
  }

  /**
   * The time that the replication task finished.
   */
  @Override
  public Optional<Instant> endTime() {
    return Optional.ofNullable(endTime);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link TargetData#status() status} attribute.
   * @param value The value for status
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableTargetData withStatus(JobStatus value) {
    JobStatus newValue = Objects.requireNonNull(value, "status");
    if (this.status == newValue) return this;
    return new ImmutableTargetData(newValue, this.startTime, this.endTime);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link TargetData#status() status} attribute.
   * An equality check is used on inner value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for status
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableTargetData withStatus(Optional<? extends JobStatus> optional) {
    @Nullable JobStatus value = optional.orElse(null);
    if (this.status == value) return this;
    return new ImmutableTargetData(value, this.startTime, this.endTime);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link TargetData#startTime() startTime} attribute.
   * @param value The value for startTime
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableTargetData withStartTime(Instant value) {
    Instant newValue = Objects.requireNonNull(value, "startTime");
    if (this.startTime == newValue) return this;
    return new ImmutableTargetData(this.status, newValue, this.endTime);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link TargetData#startTime() startTime} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for startTime
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableTargetData withStartTime(Optional<? extends Instant> optional) {
    @Nullable Instant value = optional.orElse(null);
    if (this.startTime == value) return this;
    return new ImmutableTargetData(this.status, value, this.endTime);
  }

  /**
   * Copy the current immutable object by setting a <em>present</em> value for the optional {@link TargetData#endTime() endTime} attribute.
   * @param value The value for endTime
   * @return A modified copy or {@code this} if not changed
   */
  public final ImmutableTargetData withEndTime(Instant value) {
    Instant newValue = Objects.requireNonNull(value, "endTime");
    if (this.endTime == newValue) return this;
    return new ImmutableTargetData(this.status, this.startTime, newValue);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link TargetData#endTime() endTime} attribute.
   * A shallow reference equality check is used on unboxed optional value to prevent copying of the same value by returning {@code this}.
   * @param optional An optional value for endTime
   * @return A modified copy or {@code this} if not changed
   */
  @SuppressWarnings("unchecked") // safe covariant cast
  public final ImmutableTargetData withEndTime(Optional<? extends Instant> optional) {
    @Nullable Instant value = optional.orElse(null);
    if (this.endTime == value) return this;
    return new ImmutableTargetData(this.status, this.startTime, value);
  }

  /**
   * This instance is equal to all instances of {@code ImmutableTargetData} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(@Nullable Object another) {
    if (this == another) return true;
    return another instanceof ImmutableTargetData
        && equalsByValue((ImmutableTargetData) another);
  }

  private boolean equalsByValue(ImmutableTargetData another) {
    return Objects.equals(status, another.status)
        && Objects.equals(startTime, another.startTime)
        && Objects.equals(endTime, another.endTime);
  }

  /**
   * Computes a hash code from attributes: {@code status}, {@code startTime}, {@code endTime}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    @Var int h = 5381;
    h += (h << 5) + Objects.hashCode(status);
    h += (h << 5) + Objects.hashCode(startTime);
    h += (h << 5) + Objects.hashCode(endTime);
    return h;
  }

  /**
   * Prints the immutable value {@code TargetData} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    return MoreObjects.toStringHelper("TargetData")
        .omitNullValues()
        .add("status", status)
        .add("startTime", startTime)
        .add("endTime", endTime)
        .toString();
  }

  /**
   * Creates an immutable copy of a {@link TargetData} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable TargetData instance
   */
  public static ImmutableTargetData copyOf(TargetData instance) {
    if (instance instanceof ImmutableTargetData) {
      return (ImmutableTargetData) instance;
    }
    return ImmutableTargetData.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutableTargetData ImmutableTargetData}.
   * <pre>
   * ImmutableTargetData.builder()
   *    .status(Optional&lt;com.iland.offsite.replication.api.model.JobStatus&gt;) // optional {@link TargetData#status() status}
   *    .startTime(Optional&lt;java.time.Instant&gt;) // optional {@link TargetData#startTime() startTime}
   *    .endTime(Optional&lt;java.time.Instant&gt;) // optional {@link TargetData#endTime() endTime}
   *    .build();
   * </pre>
   * @return A new ImmutableTargetData builder
   */
  public static ImmutableTargetData.Builder builder() {
    return new ImmutableTargetData.Builder();
  }

  /**
   * Builds instances of type {@link ImmutableTargetData ImmutableTargetData}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @Generated(from = "TargetData", generator = "Immutables")
  public static final class Builder {
    private @Nullable JobStatus status;
    private @Nullable Instant startTime;
    private @Nullable Instant endTime;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code TargetData} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder from(TargetData instance) {
      Objects.requireNonNull(instance, "instance");
      Optional<JobStatus> statusOptional = instance.status();
      if (statusOptional.isPresent()) {
        status(statusOptional);
      }
      Optional<Instant> startTimeOptional = instance.startTime();
      if (startTimeOptional.isPresent()) {
        startTime(startTimeOptional);
      }
      Optional<Instant> endTimeOptional = instance.endTime();
      if (endTimeOptional.isPresent()) {
        endTime(endTimeOptional);
      }
      return this;
    }

    /**
     * Initializes the optional value {@link TargetData#status() status} to status.
     * @param status The value for status
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder status(JobStatus status) {
      this.status = Objects.requireNonNull(status, "status");
      return this;
    }

    /**
     * Initializes the optional value {@link TargetData#status() status} to status.
     * @param status The value for status
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder status(Optional<? extends JobStatus> status) {
      this.status = status.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link TargetData#startTime() startTime} to startTime.
     * @param startTime The value for startTime
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder startTime(Instant startTime) {
      this.startTime = Objects.requireNonNull(startTime, "startTime");
      return this;
    }

    /**
     * Initializes the optional value {@link TargetData#startTime() startTime} to startTime.
     * @param startTime The value for startTime
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder startTime(Optional<? extends Instant> startTime) {
      this.startTime = startTime.orElse(null);
      return this;
    }

    /**
     * Initializes the optional value {@link TargetData#endTime() endTime} to endTime.
     * @param endTime The value for endTime
     * @return {@code this} builder for chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder endTime(Instant endTime) {
      this.endTime = Objects.requireNonNull(endTime, "endTime");
      return this;
    }

    /**
     * Initializes the optional value {@link TargetData#endTime() endTime} to endTime.
     * @param endTime The value for endTime
     * @return {@code this} builder for use in a chained invocation
     */
    @CanIgnoreReturnValue 
    public final Builder endTime(Optional<? extends Instant> endTime) {
      this.endTime = endTime.orElse(null);
      return this;
    }

    /**
     * Builds a new {@link ImmutableTargetData ImmutableTargetData}.
     * @return An immutable instance of TargetData
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutableTargetData build() {
      return new ImmutableTargetData(status, startTime, endTime);
    }
  }
}
