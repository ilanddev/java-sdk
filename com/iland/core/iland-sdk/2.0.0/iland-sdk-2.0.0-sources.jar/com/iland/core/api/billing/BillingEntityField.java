/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.billing;

/**
 * Billing Entity Fields.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public final class BillingEntityField {

  public static final String CPU = "cpu";

  public static final String CPU_USAGE = "cpu_usage";

  public static final String CPU_BURST_USAGE = "cpu_burst_usage";

  public static final String MEMORY_BURST_USAGE = "mem_burst_usage";

  public static final String CPU_RES_USAGE = "cpu_res_usage";

  public static final String MEMORY_RES_USAGE = "mem_res_usage";

  public static final String CPU_BURST = "cpu_burst";

  public static final String MEMORY = "mem";

  public static final String MEMORY_USAGE = "mem_usage";

  public static final String MEMORY_BURST = "mem_burst";

  public static final String DISK = "disk";

  public static final String DISK_USAGE = "disk_usage";

  public static final String DISK_BURST = "disk_burst";

  public static final String DISK_BURST_COST = "disk_burst_cost";

  public static final String DISK_BURST_USAGE = "disk_burst_usage";

  public static final String BANDWIDTH = "bandwidth";

  public static final String BANDWIDTH_USAGE = "bandwidth_usage";

  public static final String BANDWIDTH_BURST = "bandwidth_burst";

  public static final String BANDWIDTH_RES_USAGE = "bandwidth_reserved_usage";

  public static final String BANDWIDTH_BURST_USAGE = "bandwidth_burst_usage";

  public static final String BANDWIDTH_RES_COST = "bandwidth_reserved_cost";

  public static final String TOTAL = "total";

  public static final String TIME = "time";

  public static final String CURRENCY_CODE = "currency_code";

  public static final String TEST_DRIVE = "test_drive";

  public static final String BILLING_MODEL_TYPE = "billing_model";

  public static final String DISCOUNT = "discount";

  public static final String SSD_USAGE = "ssd_usage";

  public static final String HDD_USAGE = "hdd_usage";

  public static final String SSD_COST = "ssd_cost";

  public static final String HDD_COST = "hdd_cost";

  public static final String LINE_ITEMS = "line_items";

  public static final String PREVIOUS_MONTH = "previous_month";

  public static final String CURRENT_MONTH = "current_month";

  public static final String PREVIOUS_HOUR = "previous_hour";

  public static final String CURRENT_HOUR = "current_hour";

  public static final String ESTIMATE = "estimate";

  public static final String ARCHIVE_USAGE = "archive_usage";

  public static final String ARCHIVE_COST = "archive_cost";

  public static final String ZERTO_ARCHIVE_USAGE = "zerto_archive_usage";

  public static final String ZERTO_ARCHIVE_COST = "zerto_archive_cost";

  public static final String ZERTO_ADVANCED_USAGE = "zerto_advanced_usage";

  public static final String ZERTO_ADVANCED_COST = "zerto_advanced_cost";

  public static final String HDD_BURST_USAGE = "hdd_burst_usage";

  public static final String SSD_BURST_USAGE = "ssd_burst_usage";

  public static final String ARCHIVE_BURST_USAGE = "archive_burst_usage";

  public static final String HDD_BURST_COST = "hdd_burst_cost";

  public static final String SSD_BURST_COST = "ssd_burst_cost";

  public static final String ARCHIVE_BURST_COST = "archive_burst_cost";

  public static final String HDD_RES_COST = "hdd_reserved_cost";

  public static final String SSD_RES_COST = "ssd_reserved_cost";

  public static final String ARCHIVE_RES_COST = "archive_reserved_cost";

  public static final String HDD_RES_USAGE = "hdd_reserved_usage";

  public static final String SSD_RES_USAGE = "ssd_reserved_usage";

  public static final String ARCHIVE_RES_USAGE = "archive_reserved_usage";

  public static final String ENTITY_UUID = "entity_uuid";

  public static final String ENTITY_TYPE = "entity_type";

  public static final String ENTITY_NAME = "entity_name";

  public static final String YEAR = "year";

  public static final String MONTH = "month";

  private BillingEntityField() {
  }

}
