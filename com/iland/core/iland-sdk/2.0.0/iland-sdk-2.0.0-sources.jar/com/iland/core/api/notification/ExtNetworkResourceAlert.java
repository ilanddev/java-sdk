/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification;

import com.iland.core.api.net.ExternalNetwork;
import com.iland.core.api.net.NetworkPerfSample;

/**
 * External Network Resource Alert.
 * <p>
 * Wraps objects necessary to send a check for a External Resource Alert. As
 * well as information that can be used in alerting email.
 * <p>
 * This object is serialized and deserialized into Redis between processing.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public final class ExtNetworkResourceAlert extends NetworkResourceAlert {

  private static final long serialVersionUID = -2188027123039051517L;

  // Entity in which alert was raised for
  private final ExternalNetwork externalNetwork;

  public ExtNetworkResourceAlert(final String[] counter,
      final ExternalNetwork externalNetwork, final NetworkPerfSample sample) {
    super(counter, sample);
    this.externalNetwork = externalNetwork;
  }

  public ExtNetworkResourceAlert(final String[] counter,
      final ExternalNetwork externalNetwork, final NetworkPerfSample sample,
      final String equalityRelation) {
    super(counter, sample, equalityRelation);
    this.externalNetwork = externalNetwork;
  }

  /**
   * Get the external network attached to the alert.
   *
   * @return {@link ExternalNetwork} external network
   */
  public ExternalNetwork getExternalNetwork() {
    return externalNetwork;
  }

}
