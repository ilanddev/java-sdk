/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.nsx;

import java.io.Serializable;
import java.util.List;

/**
 * NsxIpSecVpnService.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class IpSecVpnService implements Serializable {

  private static final long serialVersionUID = 6904477404606878485L;

  public static final String EDGE_UUID = "edge_uuid";

  public static final String VPN = "vpn";

  private String edgeUuid;

  private boolean enabled;

  private LoggingSettings loggingSettings;

  private GlobalSettings globalSettings;

  private List<IpSecVpnSite> sites;

  public IpSecVpnService() {
  }

  public IpSecVpnService(final String edgeUuid, final boolean enabled,
      final LoggingSettings loggingSettings,
      final GlobalSettings globalSettings, final List<IpSecVpnSite> sites) {
    this.edgeUuid = edgeUuid;
    this.enabled = enabled;
    this.loggingSettings = loggingSettings;
    this.globalSettings = globalSettings;
    this.sites = sites;
  }

  /**
   * Get the edge UUID.
   *
   * @return {@link String} edge UUID
   */
  public String getEdgeUuid() {
    return edgeUuid;
  }

  /**
   * Get whether the VPN is enabled.
   *
   * @return is enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Get the logging setttings.
   *
   * @return {@link LoggingSettings} logging settings
   */
  public LoggingSettings getLoggingSettings() {
    return loggingSettings;
  }

  /**
   * Get the global settings.
   *
   * @return {@link GlobalSettings} global settings
   */
  public GlobalSettings getGlobalSettings() {
    return globalSettings;
  }

  /**
   * Get the list of VPN sites.
   *
   * @return {@link List} of {@link IpSecVpnSite} sites
   */
  public List<IpSecVpnSite> getSites() {
    return sites;
  }

}
