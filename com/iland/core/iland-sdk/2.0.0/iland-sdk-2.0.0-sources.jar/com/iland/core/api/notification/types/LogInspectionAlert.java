/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.notification.types;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.api.notification.Alert;
import com.iland.core.api.notification.AlertDeliverySpec;
import com.iland.core.api.notification.AlertType;

/**
 * Log Inspection Alert.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class LogInspectionAlert extends Alert {

  private static final long serialVersionUID = -452853951738258226L;

  @Expose
  @Since(0.1)
  @SerializedName(LogInspectionAlertField.ORG_UUID)
  private String orgUuid;

  @Expose
  @Since(0.1)
  @SerializedName(LogInspectionAlertField.EQUALITY)
  private final EqualityRelation equalityRelation;

  @Expose
  @Since(0.1)
  @SerializedName(LogInspectionAlertField.SEVERITY)
  private final Severity severityThreshold;

  public LogInspectionAlert(final String uuid, final String username,
      final AlertDeliverySpec spec, final boolean enabled, final String orgUuid,
      final EqualityRelation equalityRelation,
      final Severity severityThreshold) {
    super(uuid, username, spec, enabled, AlertType.log_inspection);
    this.orgUuid = orgUuid;
    this.equalityRelation = equalityRelation;
    this.severityThreshold = severityThreshold;
  }

  public LogInspectionAlert(final String uuid, final LogInspectionAlert a) {
    super(uuid, a.getUsername(), a.getDeliverySpec(), a.isEnabled(),
        AlertType.log_inspection);
    this.orgUuid = a.getEntityUuid();
    this.equalityRelation = a.getEqualityRelation();
    this.severityThreshold = a.getSeverityThreshold();
  }

  @Override
  public String getEntityUuid() {
    return orgUuid;
  }

  /**
   * Get the equality relation.
   *
   * @return {@link EqualityRelation} equality relation
   */
  public EqualityRelation getEqualityRelation() {
    return equalityRelation;
  }

  /**
   * Get the severity threshold.
   *
   * @return {@link Severity} severity threshold
   */
  public Severity getSeverityThreshold() {
    return severityThreshold;
  }

  /**
   * Valid severities for a Log Inspection Alert.
   */
  public enum Severity {

    @SerializedName("info") INFO("info", 0),

    @SerializedName("low") LOW("low", 1),

    @SerializedName("medium") MEDIUM("medium", 2),

    @SerializedName("high") HIGH("high", 3),

    @SerializedName("critical") CRITICAL("critical", 4);

    final String severity;

    final int severityCode;

    Severity(final String severity, final int severityCode) {
      this.severity = severity;
      this.severityCode = severityCode;
    }

    /**
     * Get the severity code associated with the alert.
     *
     * @return severity threshold
     */
    public int getSeverityCode() {
      return severityCode;
    }

    /**
     * Get the Severity associated with the given index.
     *
     * @param index severity index
     * @return {@link Severity}
     */
    public static Severity getByIndex(final int index) {
      for (final Severity s : Severity.values()) {
        if (s.getSeverityCode() == index) {
          return s;
        }
      }
      return Severity.INFO;
    }

    /**
     * Get severity name by severity code.
     *
     * @param severityCode code
     * @return {@link String} severity name
     */
    // FIXME: dead code
    public static String getSeverityNameByCode(final int severityCode) {
      for (final Severity s : Severity.values()) {
        if (s.getSeverityCode() == severityCode) {
          return s.name();
        }
      }
      return Severity.INFO.name();
    }

  }


  /**
   * Valid Equality Relations for a Log Inspection Alert.
   */
  public enum EqualityRelation {

    @SerializedName(">=") GREATER_THAN_OR_EQUALS(">="),

    @SerializedName("=") EQUALS("=");

    final String equalityRelation;

    EqualityRelation(final String equalityRelation) {
      this.equalityRelation = equalityRelation;
    }

  }

}
