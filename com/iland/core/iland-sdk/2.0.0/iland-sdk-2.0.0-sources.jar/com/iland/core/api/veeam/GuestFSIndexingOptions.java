/*
 * Copyright (c) 2026, 11:11 Systems Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of 11:11 Systems Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.iland.core.api.veeam;

import java.io.Serializable;
import java.util.List;

import jakarta.xml.bind.annotation.XmlElement;

/**
 * WindowsGuestFSIndexingOptions.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class GuestFSIndexingOptions implements Serializable {

  private static final long serialVersionUID = 8066388203845801018L;

  @XmlElement(name = "FileSystemIndexingMode")
  private String fileSystemIndexingMode;

  @XmlElement(name = "IncludedIndexingFolders")
  private List<String> includedIndexingFolders;

  @XmlElement(name = "ExcludedIndexingFolders")
  private List<String> excludedIndexingFolders;

  public GuestFSIndexingOptions() {
  }

  public GuestFSIndexingOptions(final String fileSystemIndexingMode,
      final List<String> includedIndexingFolders,
      final List<String> excludedIndexingFolders) {
    this.fileSystemIndexingMode = fileSystemIndexingMode;
    this.includedIndexingFolders = includedIndexingFolders;
    this.excludedIndexingFolders = excludedIndexingFolders;
  }

  /**
   * Get the file system indexing mode.
   *
   * @return file system indexing mode
   */
  public String getFileSystemIndexingMode() {
    return fileSystemIndexingMode;
  }

  /**
   * Get the list of included indexing folders.
   *
   * @return {@link List} of {@link String} paths to included indexing folders
   */
  public List<String> getIncludedIndexingFolders() {
    return includedIndexingFolders;
  }

  /**
   * Get the list of excluded indexing folders.
   *
   * @return {@link List} of {@link String} paths to excluded indexing folders
   */
  public List<String> getExcludedIndexingFolders() {
    return excludedIndexingFolders;
  }

}
