/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vdi;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.ListResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VDI Automation Group Deployment Summary Response.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public class VdiOrgDeploymentSummaryResponse
    extends ListResponse<VdiAutomationGroupDeploymentSummaryResponse> {

  @Expose
  @JsonRequired("The total number of pending deploys in the org.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int numberOfPendingDeploysInOrg;

  @Expose
  @JsonRequired("The total number of ready deployments in the org.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int numberOfReadyDeploymentsInOrg;

  @Expose
  @JsonRequired("The total number of pending undeployments in the org.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int numberOfPendingUndeploysInOrg;

  @Expose
  @JsonRequired("The total number of failed deployments in the org.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int numberOfFailedDeploysInOrg;


  /**
   * Instantiates a new Vdi org deployment summary response.
   *
   * @param data the data
   */
  public VdiOrgDeploymentSummaryResponse(
      final List<VdiAutomationGroupDeploymentSummaryResponse> data) {
    super(data);
    this.numberOfPendingDeploysInOrg = data.stream().map(
        VdiAutomationGroupDeploymentSummaryResponse::getNumberOfPendingDeploys)
        .reduce(0, Integer::sum);
    this.numberOfReadyDeploymentsInOrg = data.stream().map(
        VdiAutomationGroupDeploymentSummaryResponse::getNumberOfReadyDeployments)
        .reduce(0, Integer::sum);
    this.numberOfPendingUndeploysInOrg = data.stream().map(
        VdiAutomationGroupDeploymentSummaryResponse::getNumberOfPendingUndeploys)
        .reduce(0, Integer::sum);
    this.numberOfFailedDeploysInOrg = data.stream().map(
        VdiAutomationGroupDeploymentSummaryResponse::getNumberOfFailedDeploys)
        .reduce(0, Integer::sum);
  }

  /**
   * Gets number of pending deploys in org.
   *
   * @return the number of pending deploys in org
   */
  public int getNumberOfPendingDeploysInOrg() {
    return numberOfPendingDeploysInOrg;
  }

  /**
   * Gets number of ready deployments in org.
   *
   * @return the number of ready deployments in org
   */
  public int getNumberOfReadyDeploymentsInOrg() {
    return numberOfReadyDeploymentsInOrg;
  }

  /**
   * Gets number of pending undeploys in org.
   *
   * @return the number of pending undeploys in org
   */
  public int getNumberOfPendingUndeploysInOrg() {
    return numberOfPendingUndeploysInOrg;
  }

  /**
   * Gets number of failed deploys in org.
   *
   * @return the number of failed deploys in org
   */
  public int getNumberOfFailedDeploysInOrg() {
    return numberOfFailedDeploysInOrg;
  }
}
