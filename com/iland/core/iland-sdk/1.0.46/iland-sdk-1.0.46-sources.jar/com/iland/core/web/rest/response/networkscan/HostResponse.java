/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscan;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Host Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public final class HostResponse {

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int hostId;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String hostIndex;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int hostName;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String progress;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int critical;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int high;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int medium;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int low;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int info;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int totalChecksConsidered;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int numChecksConsidered;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int scanProgressTotal;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int scanProgressCurrent;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int score;

	public HostResponse(final int hostId, final String hostIndex,
		final int hostName, final String progress, final int critical,
		final int high, final int medium, final int low, final int info,
		final int totalChecksConsidered, final int numChecksConsidered,
		final int scanProgressTotal, final int scanProgressCurrent,
		final int score) {
		this.hostId = hostId;
		this.hostIndex = hostIndex;
		this.hostName = hostName;
		this.progress = progress;
		this.critical = critical;
		this.high = high;
		this.medium = medium;
		this.low = low;
		this.info = info;
		this.totalChecksConsidered = totalChecksConsidered;
		this.numChecksConsidered = numChecksConsidered;
		this.scanProgressTotal = scanProgressTotal;
		this.scanProgressCurrent = scanProgressCurrent;
		this.score = score;
	}

	/**
	 * Get the host ID.
	 *
	 * @return host id
	 */
	public int getHostId() {
		return hostId;
	}

	/**
	 * Get the host index.
	 *
	 * @return {@link String} host index
	 */
	public String getHostIndex() {
		return hostIndex;
	}

	/**
	 * Get the host name.
	 *
	 * @return host name
	 */
	public int getHostName() {
		return hostName;
	}

	/**
	 * Get the progress.
	 *
	 * @return {@link String} progress
	 */
	public String getProgress() {
		return progress;
	}

	/**
	 * Get the number of critical items.
	 *
	 * @return critical item count
	 */
	public int getCritical() {
		return critical;
	}

	/**
	 * Get the number of high items.
	 *
	 * @return high item count
	 */
	public int getHigh() {
		return high;
	}

	/**
	 * Get the number of medium items.
	 *
	 * @return medium item count
	 */
	public int getMedium() {
		return medium;
	}

	/**
	 * Get the number of low items.
	 *
	 * @return low item count
	 */
	public int getLow() {
		return low;
	}

	/**
	 * Get the number of info items.
	 *
	 * @return high info count
	 */
	public int getInfo() {
		return info;
	}

	/**
	 * The total number of checks considered on the host.
	 *
	 * @return total checks considered on host
	 */
	public int getTotalChecksConsidered() {
		return totalChecksConsidered;
	}

	/**
	 * The number of checks considered on the host.
	 *
	 * @return number of checks considered
	 */
	public int getNumChecksConsidered() {
		return numChecksConsidered;
	}

	/**
	 * Get the total scan progress on the host.
	 *
	 * @return scan progress on host
	 */
	public int getScanProgressTotal() {
		return scanProgressTotal;
	}

	/**
	 * Get the current scan progress for the host.
	 *
	 * @return current scan progress
	 */
	public int getScanProgressCurrent() {
		return scanProgressCurrent;
	}

	/**
	 * Get the overall score for the host.
	 *
	 * @return host overall score
	 */
	public int getScore() {
		return score;
	}

}
