/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.vbo;

import com.google.gson.annotations.Expose;

import com.iland.core.web.rest.response.common.SetResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Response for opening a Search Backups session. Combines the search
 * restore session, the restore point it reads from, and the mailbox
 * picker contents.
 *
 * @param searchRestoreSession the search restore session
 * @param restorePoint         the restore point the search reads from
 * @param mailboxes            the mailbox picker contents
 */
@APIDoc
public record O365SearchSessionResponse(
    @Expose O365SearchRestoreSessionResponse searchRestoreSession,
    @Expose O365RestorePointResponse restorePoint,
    @Expose SetResponse<O365SearchMailboxResponse> mailboxes) {
}
