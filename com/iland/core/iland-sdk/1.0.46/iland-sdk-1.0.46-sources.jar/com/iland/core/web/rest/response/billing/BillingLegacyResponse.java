/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Helper for UI developers to determine if whether or not an ORG or VDC has
 * had legacy billing at any point in the past?
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class BillingLegacyResponse {

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Does the entity has legacy billing?")
  private final boolean hasLegacyBilling;

  public BillingLegacyResponse(final boolean hasLegacyBilling) {
    this.hasLegacyBilling = hasLegacyBilling;
  }

  /**
   * Does the entity has legacy billing?
   *
   * @return true or false
   */
  public boolean isHasLegacyBilling() {
    return hasLegacyBilling;
  }

}
