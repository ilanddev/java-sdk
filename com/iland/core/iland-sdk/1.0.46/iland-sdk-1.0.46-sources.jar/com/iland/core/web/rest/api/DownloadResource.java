/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.iland.core.web.rest.annotations.Anonymous;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Download Resource V1.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIProperties(name = "Downloads")
@Path("/downloads")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface DownloadResource {

  /**
   * Download a report for the given file uuid.
   *
   * @param reportUuid report uuid
   * @param filename   filename for downloaded file
   * @return the report
   */
  @GET
  @Path("/reports/{reportUuid}")
  InputStream downloadReport(@PathParam("reportUuid") String reportUuid,
      @QueryParam("filename") String filename);

  /**
   * Download a file that was previously prepared for download. The token is
   * an opaque, HMAC-signed string returned in the {@code download_token}
   * attribute of the prepare-download task; it both identifies the file and
   * authorizes the request, so the URL is safe to embed in an HTML
   * {@code <a href>}. Supports resumable downloads via the HTTP {@code Range}
   * header.
   *
   * @param token     the prepared-download token from the prepare task
   * @param byteRange the byte range if resuming a download, or {@code null}
   *                  to download the whole file
   * @return the full file (200) or a byte range (206 Partial Content)
   */
  @GET
  @Path("/prepared-downloads/{token}")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  @Anonymous
  Response downloadPreparedDownload(
      @PathParam("token") String token,
      @HeaderParam("Range") String byteRange);

}
