/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.network;

import java.time.Instant;
import java.util.List;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.NetworkIpScopeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * External Network Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class ExternalNetworkResponse {

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean deleted;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant deletedDate;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant updatedDate;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String graphId1;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String graphId2;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private NetworkIpScopeResponse ipScope;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private List<NetworkIpScopeResponse> ipScopes;

  public ExternalNetworkResponse(final String uuid, final String name,
      final boolean deleted, final Instant deletedDate,
      final Instant updatedDate, final String graphId1, final String graphId2,
      final NetworkIpScopeResponse ipScope,
      final List<NetworkIpScopeResponse> ipScopes) {
    this.uuid = uuid;
    this.name = name;
    this.deleted = deleted;
    this.deletedDate = deletedDate;
    this.updatedDate = updatedDate;
    this.graphId1 = graphId1;
    this.graphId2 = graphId2;
    this.ipScope = ipScope;
    this.ipScopes = ipScopes;
  }

  /**
   * Get the entity uuid
   *
   * @return {@link String} uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Get the entity name
   *
   * @return entity name
   */
  public String getName() {
    return name;
  }

  /**
   * Get is deleted entity
   *
   * @return boolean value
   */
  public boolean isDeleted() {
    return deleted;
  }

  /**
   * Get the deleted date of entity
   *
   * @return {@link Instant} deleted date
   */
  public Instant getDeletedDate() {
    return deletedDate;
  }

  /**
   * Get the updated date of entity
   *
   * @return {@link Instant} updated date
   */
  public Instant getUpdatedDate() {
    return updatedDate;
  }

  /**
   * Get the graph id1.
   *
   * @return graph id1
   */
  public String getGraphId1() {
    return graphId1;
  }


  /**
   * Get the graph id2.
   *
   * @return graph id2
   */
  public String getGraphId2() {
    return graphId2;
  }

  /**
   * Gets the IP scope of the network.
   *
   * @return {@link NetworkIpScopeResponse}
   */
  public NetworkIpScopeResponse getIpScope() {
    return ipScope;
  }

  /**
   * Get the ip scopes.
   *
   * @return {@link List} of {@link NetworkIpScopeResponse} responses
   */
  public List<NetworkIpScopeResponse> getIpScopes() {
    return ipScopes;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final ExternalNetworkResponse that = (ExternalNetworkResponse) o;
    return isDeleted() == that.isDeleted() && Objects
        .equals(getUuid(), that.getUuid()) && Objects
        .equals(getName(), that.getName()) && Objects
        .equals(getDeletedDate(), that.getDeletedDate()) && Objects
        .equals(getUpdatedDate(), that.getUpdatedDate()) && Objects
        .equals(getGraphId1(), that.getGraphId1()) && Objects
        .equals(getGraphId2(), that.getGraphId2()) && Objects
        .equals(getIpScope(), that.getIpScope()) && Objects
        .equals(getIpScopes(), that.getIpScopes());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getUuid(), getName(), isDeleted(), getDeletedDate(),
        getUpdatedDate(), getGraphId1(), getGraphId2(), getIpScope(),
        getIpScopes());
  }

  @Override
  public String toString() {
    return "ExternalNetworkResponse{" + "uuid='" + uuid + '\'' + ", name='"
        + name + '\'' + ", deleted=" + deleted + ", deletedDate=" + deletedDate
        + ", updatedDate=" + updatedDate + ", graphId1='" + graphId1 + '\''
        + ", graphId2='" + graphId2 + '\'' + ", ipScope=" + ipScope
        + ", ipScopes=" + ipScopes + '}';
  }

}
