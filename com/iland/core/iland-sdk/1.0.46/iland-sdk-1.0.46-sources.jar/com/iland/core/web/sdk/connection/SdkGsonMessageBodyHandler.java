/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.sdk.connection;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.MessageBodyWriter;

import com.google.gson.JsonParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iland.core.web.rest.serialization.SerializationUtil;

/**
 * GSON serialization and deserialization for use with JAX RS.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@Produces("application/*+json")
@Consumes("application/*+json")
public class SdkGsonMessageBodyHandler<T>
    implements MessageBodyWriter<T>, MessageBodyReader<T> {

  private static final Logger log =
      LoggerFactory.getLogger(SdkGsonMessageBodyHandler.class);

  private static final Pattern pattern =
      Pattern.compile("vnd.ilandcloud.api.v([0-9]+\\.[0-9]+)\\+json");

  private static final String UTF_8 = "UTF-8";

  private double getVersionFromMediaType(final MediaType mediaType) {
    if (mediaType.isCompatible(MediaType.APPLICATION_JSON_TYPE)) {
      return SerializationUtil.V1_DEFAULT_API_VERSION;
    } else {
      final Matcher matcher = pattern.matcher(mediaType.getSubtype());
      if (matcher.find()) {
        return Double.valueOf(matcher.group(1));
      }
      return SerializationUtil.V1_DEFAULT_API_VERSION;
    }
  }

  @Override
  public boolean isReadable(final Class<?> type, final Type genericType,
      final Annotation[] annotations, final MediaType mediaType) {
    return true;
  }

  @Override
  public T readFrom(final Class<T> type, final Type genericType,
      final Annotation[] annotations, final MediaType mediaType,
      final MultivaluedMap<String, String> httpHeaders,
      final InputStream entityStream)
      throws IOException, WebApplicationException {
    final Reader streamReader = new InputStreamReader(entityStream, UTF_8);
    try {
      Type targetType;
      if (Collection.class.isAssignableFrom(type)) {
        targetType = genericType;
      } else if (genericType instanceof java.lang.reflect.ParameterizedType) {
        targetType = genericType;
      } else {
        targetType = type;
      }
      final T t =
          SerializationUtil.getGson(getVersionFromMediaType(mediaType), false)
              .fromJson(streamReader, targetType);
      if (t == null) {
        throw new NullPointerException();
      }
      return t;
    } catch (final JsonParseException e) {
      log.debug("", e);
      throw new IllegalStateException(e.getMessage(), e);
    } finally {
      streamReader.close();
    }
  }

  @Override
  public boolean isWriteable(final Class<?> type, final Type genericType,
      final Annotation[] annotations, final MediaType mediaType) {
    return true;
  }

  @Override
  public long getSize(final T t, final Class<?> type, final Type genericType,
      final Annotation[] annotations, final MediaType mediaType) {
    return -1;
  }

  @Override
  public void writeTo(final T t, final Class<?> type, final Type genericType,
      final Annotation[] annotations, final MediaType mediaType,
      final MultivaluedMap<String, Object> httpHeaders,
      final OutputStream entityStream)
      throws IOException, WebApplicationException {
    String jsonStr;
    if (String.class.isAssignableFrom(type)) {
      jsonStr = ((String) t);
    } else if (genericType instanceof java.lang.reflect.ParameterizedType) {
      jsonStr =
          SerializationUtil.getGson(getVersionFromMediaType(mediaType), false)
              .toJson(t, genericType);
    } else {
      jsonStr =
          SerializationUtil.getGson(getVersionFromMediaType(mediaType), false)
              .toJson(t);
    }
    entityStream.write(jsonStr.getBytes());
  }

}
