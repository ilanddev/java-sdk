/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vm;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Restore Point Respoonse.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class RestorePointResponse implements Serializable {

  private static final long serialVersionUID = -3249399554619898956L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String name;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final Instant time;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final RestorePointTypeResponse type;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String jobName;

  public RestorePointResponse(final String name, final Instant time,
      final RestorePointTypeResponse type, final String jobName) {
    this.name = name;
    this.time = time;
    this.type = type;
    this.jobName = jobName;
  }

  /**
   * Get the restore point name.
   *
   * @return {@link String} name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the restore point timestamp.
   *
   * @return {@link Instant} timestamp
   */
  public Instant getTimestamp() {
    return time;
  }

  /**
   * Returns the restore point type.
   *
   * @return one of {@link RestorePointTypeResponse} enum value
   */
  public RestorePointTypeResponse getType() {
    return type;
  }

  /**
   * Returns the name of the corresponding backup job.
   *
   * @return the name of the corresponding backup job.
   */
  public String getJobName() {
    return jobName;
  }

}
