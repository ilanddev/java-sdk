/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.media;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * MediaResponse.
 *
 * @author <a href="mailto:aquinones@iland.com">Ari Quinones</a>
 */
@APIDoc
public class MediaResponse extends EntityResponse implements Serializable {

  private static final long serialVersionUID = -6928971508873929826L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int status;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double size;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean isPublic = false;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String orgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String catalogUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String storageProfileUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vdcUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vcloudHref;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant createdDate;

  public MediaResponse(final String uuid, final String companyId,
      final String name, final boolean deleted, final Instant deletedDate,
      final Instant updatedDate, final int status, final double size,
      final boolean isPublic, final String locationId, final String orgUuid,
      final String catalogUuid, final String storageProfileUuid,
      final String vdcUuid, final String description, final String vcloudHref,
      final Instant createdDate) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.status = status;
    this.size = size;
    this.isPublic = isPublic;
    this.locationId = locationId;
    this.orgUuid = orgUuid;
    this.catalogUuid = catalogUuid;
    this.storageProfileUuid = storageProfileUuid;
    this.vdcUuid = vdcUuid;
    this.description = description;
    this.vcloudHref = vcloudHref;
    this.createdDate = createdDate;
  }

  /**
   * Get status of media response
   *
   * @return {@link int} status
   */
  public int getStatus() {
    return status;
  }

  /**
   * Get the size of media response
   *
   * @return {@link double} size
   */
  public double getSize() {
    return size;
  }

  /**
   * Get is public of media response
   *
   * @return {@link boolean} is public
   */
  public boolean isPublic() {
    return isPublic;
  }

  /**
   * Get the location id of media response
   *
   * @return {@link String} location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Get the org uuid of media response
   *
   * @return {@link String} org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Get the catalog uuid of media response
   *
   * @return {@link String} catalog uuid
   */
  public String getCatalogUuid() {
    return catalogUuid;
  }

  /**
   * Get the storage profile uuid of media response
   *
   * @return {@link String} storage profile uuid
   */
  public String getStorageProfileUuid() {
    return storageProfileUuid;
  }

  /**
   * Get the vdc uuid of media response
   *
   * @return {@link String} vdc uuid
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Get media response description
   *
   * @return {@link String} description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get the vcloud href of media response
   *
   * @return {@link String} vcloud href
   */
  public String getVcloudHref() {
    return vcloudHref;
  }

  /**
   * Get the created date of media response
   *
   * @return {@link Instant} created date
   */
  public Instant getCreatedDate() {
    return createdDate;
  }

  @Override
  public boolean equals(Object object) {
    if (this == object)
      return true;
    if (object == null || getClass() != object.getClass())
      return false;
    if (!super.equals(object))
      return false;
    MediaResponse that = (MediaResponse) object;
    if (getStatus() != that.getStatus())
      return false;
    if (Double.compare(that.getSize(), getSize()) != 0)
      return false;
    if (isPublic() != that.isPublic())
      return false;
    if (getLocationId() != null ?
        !getLocationId().equals(that.getLocationId()) :
        that.getLocationId() != null)
      return false;
    if (getOrgUuid() != null ?
        !getOrgUuid().equals(that.getOrgUuid()) :
        that.getOrgUuid() != null)
      return false;
    if (getCatalogUuid() != null ?
        !getCatalogUuid().equals(that.getCatalogUuid()) :
        that.getCatalogUuid() != null)
      return false;
    if (getStorageProfileUuid() != null ?
        !getStorageProfileUuid().equals(that.getStorageProfileUuid()) :
        that.getStorageProfileUuid() != null)
      return false;
    if (getVdcUuid() != null ?
        !getVdcUuid().equals(that.getVdcUuid()) :
        that.getVdcUuid() != null)
      return false;
    if (getDescription() != null ?
        !getDescription().equals(that.getDescription()) :
        that.getDescription() != null)
      return false;
    if (getVcloudHref() != null ?
        !getVcloudHref().equals(that.getVcloudHref()) :
        that.getVcloudHref() != null)
      return false;
    if (getCreatedDate() != null ?
        !getCreatedDate().equals(that.getCreatedDate()) :
        that.getCreatedDate() != null)
      return false;
    return true;
  }

  @Override
  public int hashCode() {
    int result = super.hashCode();
    long temp;
    result = 31 * result + getStatus();
    temp = Double.doubleToLongBits(getSize());
    result = 31 * result + (int) (temp ^ (temp >>> 32));
    result = 31 * result + (isPublic() ? 1 : 0);
    result = 31 * result + (getLocationId() != null ?
        getLocationId().hashCode() :
        0);
    result = 31 * result + (getOrgUuid() != null ? getOrgUuid().hashCode() : 0);
    result = 31 * result + (getCatalogUuid() != null ?
        getCatalogUuid().hashCode() :
        0);
    result = 31 * result + (getStorageProfileUuid() != null ?
        getStorageProfileUuid().hashCode() :
        0);
    result = 31 * result + (getVdcUuid() != null ? getVdcUuid().hashCode() : 0);
    result = 31 * result + (getDescription() != null ?
        getDescription().hashCode() :
        0);
    result = 31 * result + (getVcloudHref() != null ?
        getVcloudHref().hashCode() :
        0);
    result = 31 * result + (getCreatedDate() != null ?
        getCreatedDate().hashCode() :
        0);
    return result;
  }

  @Override
  public String toString() {
    return "MediaResponse{" + "status=" + status + ", size=" + size
        + ", isPublic=" + isPublic + ", locationId='" + locationId + '\''
        + ", orgUuid='" + orgUuid + '\'' + ", catalogUuid='" + catalogUuid
        + '\'' + ", storageProfileUuid='" + storageProfileUuid + '\''
        + ", vdcUuid='" + vdcUuid + '\'' + ", description='" + description
        + '\'' + ", vcloudHref='" + vcloudHref + '\'' + ", createdDate="
        + createdDate + '}';
  }

}
