/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.notification;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Abstract Resource Alert Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public abstract class AbstractResourceAlertResponse implements Serializable {

  @Serial
  private static final long serialVersionUID = 3176101543610945486L;

  private static final String EQUALITY_CONDITION = "equality";

  private static final String BREACH = "breach";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String group;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String name;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String type;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String username;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String action;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(EQUALITY_CONDITION)
  protected String equalityRelation;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected boolean enabled;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(BREACH)
  protected int breachPeriod;

  public AbstractResourceAlertResponse(final String group, final String name,
      final String type, final String username, final String action,
      final String equalityRelation, final boolean enabled,
      final int breachPeriod) {
    this.group = group;
    this.name = name;
    this.type = type;
    this.username = username;
    this.action = action;
    this.equalityRelation = equalityRelation;
    this.enabled = enabled;
    this.breachPeriod = breachPeriod;
  }

  /**
   * Get the performance counter group attached to this alert.
   *
   * @return {@link String} performance counter group
   */
  public String getGroup() {
    return group;
  }

  /**
   * Get the performance counter name attached to this alert.
   *
   * @return {@link String} performance counter name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the performance counter type attached to this alert.
   *
   * @return {@link String} performance counter type
   */
  public String getType() {
    return type;
  }

  /**
   * Get the username associated with the alert.
   *
   * @return {@link String} username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Get equality relation.
   * <p>
   * e.g. '<=' or '>='
   *
   * @return {@link String} equality relation
   */
  public String getRelation() {
    return equalityRelation;
  }

  /**
   * Get action to perform when alert is triggered.
   *
   * @return {@link String} action
   */
  public String getAction() {
    return action;
  }

  /**
   * Get the breach period that is required in order for the alert to be
   * triggered.
   * <p>
   * i.e. the number of consecutive periods in which the threshold must be met
   * before alert is sent.
   *
   * @return breach period
   */
  public int getBreachPeriod() {
    return breachPeriod;
  }

  /**
   * Set whether the alert is enabled.
   *
   * @return enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  @Override
  public boolean equals(final Object o) {
    return o instanceof final AbstractResourceAlertResponse that
        && enabled == that.enabled && breachPeriod == that.breachPeriod
        && Objects.equals(group, that.group) && Objects.equals(name, that.name)
        && Objects.equals(type, that.type) && Objects.equals(username,
        that.username) && Objects.equals(action, that.action) && Objects.equals(
        equalityRelation, that.equalityRelation);
  }

  @Override
  public int hashCode() {
    return Objects.hash(group, name, type, username, action,
        equalityRelation, enabled, breachPeriod);
  }

  @Override
  public String toString() {
    return toStringHelper().toString();
  }

  protected MoreObjects.ToStringHelper toStringHelper() {
    return MoreObjects.toStringHelper(this)
        .add("group", group)
        .add("name", name)
        .add("type", type)
        .add("username", username)
        .add("action", action)
        .add("equalityRelation", equalityRelation)
        .add("enabled", enabled)
        .add("breachPeriod", breachPeriod);
  }

}
