/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Objects;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VdcBackupSummaryStatsResponse.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public final class VdcBackupSummaryStatsResponse {

  @Expose
  @JsonRequired("The vDC UUID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vdcUuid;

  @Expose
  @JsonRequired("The vDC summary stats.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupSummaryStats stats;

  @Expose
  @JsonRequired("The stats for backup groups within the vDC.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<BackupGroupSummaryStatsResponse> backupGroupStats;

  public VdcBackupSummaryStatsResponse(final String vdcUuid,
      final BackupSummaryStats stats,
      final Set<BackupGroupSummaryStatsResponse> backupGroupStats) {
    this.vdcUuid = vdcUuid;
    this.stats = stats;
    this.backupGroupStats = backupGroupStats;
  }

  /**
   * Gets the vDC UUID.
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Gets the vDC summary stats.
   */
  public BackupSummaryStats getStats() {
    return stats;
  }

  /**
   * Gets child backup group stats.
   */
  public Set<BackupGroupSummaryStatsResponse> getBackupGroupStats() {
    return backupGroupStats;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final VdcBackupSummaryStatsResponse that =
        (VdcBackupSummaryStatsResponse) o;
    return Objects.equals(vdcUuid, that.vdcUuid) && Objects
        .equals(stats, that.stats) && Objects
        .equals(backupGroupStats, that.backupGroupStats);
  }

  @Override
  public int hashCode() {
    return Objects.hash(vdcUuid, stats, backupGroupStats);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("vdcUuid", vdcUuid)
        .add("stats", stats).add("backupGroupStats", backupGroupStats)
        .toString();
  }
}
