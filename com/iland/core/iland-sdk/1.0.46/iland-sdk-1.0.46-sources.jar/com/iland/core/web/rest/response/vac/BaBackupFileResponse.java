/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vac;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VAC Backup File Response.
 *
 * @author <a href="mailto:nkasprza@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public final class BaBackupFileResponse implements Serializable {

  private static final long serialVersionUID = -8993331891694546864L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final float sizeMb;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant modifiedAt;

  /**
   * Instantiates a new Ba backup file.
   *
   * @param uuid       the uuid
   * @param name       the name
   * @param type       the type
   * @param sizeMb     the size mb
   * @param modifiedAt the modified at
   */
  public BaBackupFileResponse(final String uuid, final String name, final String type,
      final float sizeMb, final Instant modifiedAt) {
    this.uuid = uuid;
    this.name = name;
    this.type = type;
    this.sizeMb = sizeMb;
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Gets size mb.
   *
   * @return the size mb
   */
  public float getSizeMb() {
    return sizeMb;
  }

  /**
   * Gets modified at.
   *
   * @return the modified at
   */
  public Instant getModifiedAt() {
    return modifiedAt;
  }
}
