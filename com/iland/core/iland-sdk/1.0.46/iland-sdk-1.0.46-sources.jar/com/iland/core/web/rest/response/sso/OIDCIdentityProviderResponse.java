/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.sso;

import java.util.Optional;

import org.immutables.value.Value;

import com.iland.core.api.sso.IdentityProviderType;
import com.iland.core.web.rest.annotation.APIModel;
import com.iland.core.web.rest.request.sso.OIDCClientAuth;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * OIDC Identity Provider Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIModel
@APIDoc
public abstract class OIDCIdentityProviderResponse extends IdentityProviderResponse {

  /**
   * Authorization URL endpoint required by the OIDC protocol.
   */
  public abstract String authorizationUrl();

  /**
   * Token URL endpoint required by the OIDC protocol.
   */
  public abstract String tokenUrl();

  /**
   * Switch to define the Client Authentication method to be used with the
   * Authorization Code Flow. In the case of JWT signed with private key,
   * the realm private key is used. In the other cases, a client secret has to
   * be defined. For more details, see https://openid.net/specs/openid-connect-core-1_0.html#ClientAuthentication.
   */
  public abstract OIDCClientAuth clientAuth();

  /**
   * This realm will act as an OIDC client to the external IDP. Your realm will
   * need an OIDC client ID when using the Authorization Code Flow to interact with the external IDP.
   */
  public abstract String clientId();

  /**
   * This realm will need a client secret to use when using the Authorization Code
   * Flow. The value of this field can refer a value from an external vault.
   */
  public abstract String clientSecret();

  /**
   * Whether to pass login_hint to identity provider
   */
  public abstract Optional<Boolean> loginHint();

  /**
   * Whether to pass the current locale to the identity provider as a ui_locales parameter.
   */
  public abstract Optional<Boolean> uiLocales();

  /**
   * User Info URL endpoint defined by the OIDC protocol. This is an endpoint
   * from which user profile information can be downloaded.
   */
  public abstract Optional<String> userInfoUrl();


  /**
   * Backchannel logout is a background, out-of-band, REST invocation to the IDP
   * to logout the user. Some IDPs can only perform logout through browser
   * redirects as they may only be able to identity sessions via a browser cookie.
   */
  public abstract Optional<Boolean> backchannelSupported();

  /**
   * Disable usage of User Info service to obtain additional user information?
   * Default is to use this OIDC service.
   */
  public abstract Optional<Boolean> disableUserInfo();

  /**
   * Responses from the IDP may contain an issuer claim. This config value is
   * optional. If specified, this claim will be validated against the value you provide.
   */
  public abstract Optional<String> issuer();

  /**
   * Space-separated list of OIDC scopes to send with the authentication request.
   * The default is openid.
   */
  public abstract Optional<String> defaultScope();

  /**
   * Another optional switch. This is the prompt parameter defined by the OIDC
   * specification. Through it you can force re-authentication and other options.
   * See the specification for more details.
   */
  public abstract Optional<String> prompt();

  /**
   * Specifies whether the IDP accepts forwarded authentication requests that
   * contain the prompt=none query parameter or not. When a realm receives an
   * auth request with prompt=none it checks if the user is currently
   * authenticated and normally returns a login_required error if the user is
   * not logged in. However, when a default IDP can be determined for the auth
   * request (either via kc_idp_hint query param or by setting up a default IDP
   * for the realm) we should be able to forward the auth request with
   * prompt=none to the default IDP so that it checks if the user is currently
   * authenticated there. Because not all IDPs support requests with
   * prompt=none this switch is used to indicate if the default IDP supports the
   * param before redirecting the auth request.
   * <p>
   * It is important to note that if the user is not authenticated in the IDP,
   * the client will still get a login_required error. Even if the user is
   * currently authenticated in the IDP, the client might still get an
   * interaction_required error if authentication or consent pages requiring
   * user interaction would be otherwise displayed. This includes required
   * actions (e.g. change password), consent screens and any screens set to be
   * displayed by the first broker login flow or post broker login flow.
   */
  public abstract Optional<Boolean> acceptsPromptNoneForwardFromClient();

  /**
   * Another optional switch. This is to specify if Keycloak will verify the
   * signatures on the external ID Token signed by this identity provider. If
   * this is on, the Keycloak will need to know the public key of the external
   * OIDC identity provider. See below for how to set it up. WARNING: For the
   * performance purposes, Keycloak caches the public key of the external
   * OIDC identity provider. If you think that private key of your identity
   * provider was compromised, it is obviously good to update your keys, but
   * it’s also good to clear the keys cache.
   */
  public abstract Optional<Boolean> validateSignature();

  /**
   * Applicable if Validate Signatures is on. If the switch is on, then
   * identity provider public keys will be downloaded from given JWKS URL.
   * This allows great flexibility because new keys will be always
   * re-downloaded when the identity provider generates new keypair. If the
   * switch is off, then public key (or certificate) from the Keycloak DB is
   * used, so whenever the identity provider keypair changes, you will always
   * need to import the new key to the Keycloak DB as well.
   */
  public abstract Optional<Boolean> useJwksUrl();

  /**
   * URL where the identity provider JWK keys are stored. See the JWK
   * specification for more details. If you use an external Keycloak as an
   * identity provider, then you can use URL like
   * http://broker-keycloak:8180/auth/realms/test/protocol/openid-connect/certs
   * assuming your brokered Keycloak is running on http://broker-keycloak:8180
   * and it’s realm is test.
   */
  public abstract Optional<String> jwksUrl();

  /**
   * Applicable if Use JWKS URL is off. Here is the public key in PEM format
   * that must be used to verify external IDP signatures.
   */
  public abstract Optional<String> publicKeySignatureVerifierKey();

  /**
   * Applicable if Use JWKS URL is off. This field specifies ID of the public key
   * in PEM format. This config value is optional. As there is no standard way for
   * computing key ID from key, various external identity providers might use
   * different algorithm from Keycloak. If the value of this field is not
   * specified, the validating public key specified above is used for all
   * requests regardless of key ID sent by external IDP. When set, value of this
   * field serves as key ID used by Keycloak for validating signatures from
   * such providers and must match the key ID specified by the IDP.
   */
  public abstract Optional<String> publicKeySignatureVerifierKeyId();

  /**
   * Clock skew in seconds that is tolerated when validating identity
   * "provider tokens. Default value is zero.
   */
  public abstract Optional<Integer> allowedClockSkew();

  /**
   * Non OpenID Connect/OAuth standard query parameters to be forwarded to
   * external IDP from the initial application request to Authorization Endpoint.
   * Multiple parameters can be entered, separated by comma (,).
   */
  public abstract Optional<String> forwardParameters();

  /**
   * Logout URL endpoint defined in the OIDC protocol. This value is optional.
   *
   * @return {@link String} logout url
   */
  public abstract Optional<String> logoutUrl();

  @Override
  @Value.Derived
  public IdentityProviderType type() {
    return IdentityProviderType.OIDC;
  }
}
