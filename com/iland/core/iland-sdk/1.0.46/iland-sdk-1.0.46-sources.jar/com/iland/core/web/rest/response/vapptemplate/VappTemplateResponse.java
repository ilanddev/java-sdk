/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vapptemplate;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VappTemplateResponse.
 *
 * @author <a href="mailto:aquinones@iland.com">Ari Quinones</a>
 */
@APIDoc
public class VappTemplateResponse extends EntityResponse
    implements Serializable {

  private static final long serialVersionUID = 8497134996639691136L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vcloudHref;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int status;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double size;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String storageProfileUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean isPublic;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vdcUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String orgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String catalogUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant createdDate;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean expired;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<VappTemplateVmResponse> vmTemplates;

  public VappTemplateResponse(final String uuid, final String companyId,
      final String name, final boolean deleted, final Instant deletedDate,
      final Instant updatedDate, final String description,
      final String vcloudHref, final int status, final double size,
       final String storageProfileUuid,
      final boolean isPublic, final String vdcUuid, final String locationId,
      final String orgUuid, final String catalogUuid, final Instant createdDate,
      final boolean expired, final List<VappTemplateVmResponse> vmTemplates) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.description = description;
    this.vcloudHref = vcloudHref;
    this.status = status;
    this.size = size;
    this.storageProfileUuid = storageProfileUuid;
    this.isPublic = isPublic;
    this.vdcUuid = vdcUuid;
    this.locationId = locationId;
    this.orgUuid = orgUuid;
    this.catalogUuid = catalogUuid;
    this.createdDate = createdDate;
    this.expired = expired;
    this.vmTemplates = vmTemplates;
  }

  /**
   * Get the vapp template response description
   *
   * @return {@link String} description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get the vcloud href of vapp template response
   *
   * @return {@link String} vcloud href
   */
  public String getVcloudHref() {
    return vcloudHref;
  }

  /**
   * Get the status of vapp template response
   *
   * @return {@link int} status
   */
  public int getStatus() {
    return status;
  }

  /**
   * Get the size of vapp template resource
   *
   * @return {@link double} size
   */
  public double getSize() {
    return size;
  }

  /**
   * Get storage profile uuid of vapp template resource
   *
   * @return {@link String} storage profile uuid
   */
  public String getStorageProfileUuid() {
    return storageProfileUuid;
  }

  /**
   * Get is public of vapp template resource
   *
   * @return {@link boolean} is public
   */
  public boolean isPublic() {
    return isPublic;
  }

  /**
   * Get the vdc uuid of vapp template resource
   *
   * @return {@link String} vdc uuid
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Get the location id of vapp template resource
   *
   * @return {@link String} location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Get the org uuid of vapp template resource
   *
   * @return {@link String} org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Get the catalog uuid of vapp template resource
   *
   * @return {@link String} catalog uuid
   */
  public String getCatalogUuid() {
    return catalogUuid;
  }

  /**
   * Get the created date of vapp template resource
   *
   * @return {@link Instant} created date
   */
  public Instant getCreatedDate() {
    return createdDate;
  }

  /**
   * Get is expired of vapp template resource
   *
   * @return {@link boolean} is expired
   */
  public boolean isExpired() {
    return expired;
  }

  /**
   * Get the vApp template VMs for the vApp template.
   *
   * @return {@link List} of {@link VappTemplateVmResponse} vm templates
   */
  public List<VappTemplateVmResponse> getVmTemplates() {
    return vmTemplates;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    if (!super.equals(o))
      return false;
    final VappTemplateResponse that = (VappTemplateResponse) o;
    return getStatus() == that.getStatus()
        && Double.compare(that.getSize(), getSize()) == 0
        && isPublic() == that
        .isPublic() && isExpired() == that.isExpired() && Objects
        .equals(getDescription(), that.getDescription()) && Objects
        .equals(getVcloudHref(), that.getVcloudHref()) && Objects
        .equals(getStorageProfileUuid(), that.getStorageProfileUuid())
        && Objects.equals(getVdcUuid(), that.getVdcUuid()) && Objects
        .equals(getLocationId(), that.getLocationId()) && Objects
        .equals(getOrgUuid(), that.getOrgUuid()) && Objects
        .equals(getCatalogUuid(), that.getCatalogUuid()) && Objects
        .equals(getCreatedDate(), that.getCreatedDate()) && Objects
        .equals(getVmTemplates(), that.getVmTemplates());
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(super.hashCode(), getDescription(), getVcloudHref(), getStatus(),
            getSize(), getStorageProfileUuid(), isPublic(), getVdcUuid(),
            getLocationId(), getOrgUuid(), getCatalogUuid(), getCreatedDate(),
            isExpired(), getVmTemplates());
  }

  @Override
  public String toString() {
    return "VappTemplateResponse{" + "description='" + description + '\''
        + ", vcloudHref='" + vcloudHref + '\'' + ", status=" + status
        + ", size=" + size + ", storageProfileUuid='" + storageProfileUuid + '\''
        + ", isPublic=" + isPublic + ", vdcUuid='" + vdcUuid + '\''
        + ", locationId='" + locationId + '\'' + ", orgUuid='" + orgUuid + '\''
        + ", catalogUuid='" + catalogUuid + '\'' + ", createdDate="
        + createdDate + ", expired=" + expired + '}';
  }

}
