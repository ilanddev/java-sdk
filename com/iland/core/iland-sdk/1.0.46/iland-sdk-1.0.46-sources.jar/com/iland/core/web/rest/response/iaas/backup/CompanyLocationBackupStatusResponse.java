/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Objects;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * CompanyLocationBackupStatusResponse.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public final class CompanyLocationBackupStatusResponse {

  @Expose
  @JsonRequired("The location ID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String locationId;

  @Expose
  @JsonRequired("The company ID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String companyId;

  @Expose
  @JsonRequired("The backup status configuration for all child orgs of the company-location.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<OrgBackupStatusResponse> childOrgStatuses;

  public CompanyLocationBackupStatusResponse(final String locationId,
      final String companyId,
      final Set<OrgBackupStatusResponse> childOrgStatuses) {
    this.locationId = locationId;
    this.companyId = companyId;
    this.childOrgStatuses = childOrgStatuses;
  }

  /**
   * Gets the location ID.
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Gets the company ID.
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * Gets child org status info.
   */
  public Set<OrgBackupStatusResponse> getChildOrgStatuses() {
    return childOrgStatuses;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final CompanyLocationBackupStatusResponse that =
        (CompanyLocationBackupStatusResponse) o;
    return Objects.equals(locationId, that.locationId) && Objects
        .equals(companyId, that.companyId) && Objects
        .equals(childOrgStatuses, that.childOrgStatuses);
  }

  @Override
  public int hashCode() {
    return Objects.hash(locationId, companyId, childOrgStatuses);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("locationId", locationId)
        .add("companyId", companyId).add("childOrgStatuses", childOrgStatuses)
        .toString();
  }
}
