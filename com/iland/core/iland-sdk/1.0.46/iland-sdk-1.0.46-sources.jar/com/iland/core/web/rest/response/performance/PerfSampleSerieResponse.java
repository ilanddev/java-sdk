/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.performance;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Perf Sample Serie Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class PerfSampleSerieResponse implements Serializable {

  private static final long serialVersionUID = -801973071786092681L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String summary;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int interval;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String group;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String unit;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<PerfSampleResponse> samples;

  public PerfSampleSerieResponse(final String uuid, final String summary,
      final int interval, final String group, final String name,
      final String type, final String unit,
      final List<PerfSampleResponse> samples) {
    this.uuid = uuid;
    this.summary = summary;
    this.interval = interval;
    this.group = group;
    this.name = name;
    this.type = type;
    this.unit = unit;
    this.samples = samples;
  }

  /**
   * Returns the series uuid.
   *
   * @return {@link String} serie uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Returns the interval in seconds for which performance statistics were
   * collected.
   *
   * @return an {@link Integer} value.
   */
  public int getInterval() {
    return interval;
  }

  /**
   * Returns the list of samples within the interval.
   *
   * @return a {@link List} of {@link PerfSampleResponse} object.
   */
  public List<PerfSampleResponse> getSamples() {
    return samples;
  }

  /**
   * Returns serie summary.
   *
   * @return a {@link String}
   */
  public String getSummary() {
    return summary;
  }


  /**
   * Returns the performance counter group.
   *
   * @return one of {@link String}
   */
  public String getGroup() {
    return group;
  }

  /**
   * Returns the name of the counter.
   *
   * @return a {@link String} instance.
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the performance counter rollup type.
   *
   * @return one of {@link String}
   */
  public String getType() {
    return type;
  }

  /**
   * Returns the unit for the values of the performance counter.
   *
   * @return a {@link String}
   */
  public String getUnit() {
    return unit;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final PerfSampleSerieResponse that = (PerfSampleSerieResponse) o;

    if (interval != that.interval)
      return false;
    if (!uuid.equals(that.uuid))
      return false;
    if (!summary.equals(that.summary))
      return false;
    if (!group.equals(that.group))
      return false;
    if (!name.equals(that.name))
      return false;
    if (!type.equals(that.type))
      return false;
    if (!unit.equals(that.unit))
      return false;
    return samples.equals(that.samples);
  }

  @Override
  public int hashCode() {
    int result = uuid.hashCode();
    result = 31 * result + summary.hashCode();
    result = 31 * result + interval;
    result = 31 * result + group.hashCode();
    result = 31 * result + name.hashCode();
    result = 31 * result + type.hashCode();
    result = 31 * result + unit.hashCode();
    result = 31 * result + samples.hashCode();
    return result;
  }

  @Override
  public String toString() {
    return "PerfSampleSerieResponse{" + "uuid='" + uuid + '\'' + ", summary='"
        + summary + '\'' + ", interval=" + interval + ", group='" + group + '\''
        + ", name='" + name + '\'' + ", type='" + type + '\'' + ", unit='"
        + unit + '\'' + ", samples=" + samples + '}';
  }

}
