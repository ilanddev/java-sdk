/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.user;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.iam.IamEntityType;
import com.iland.core.web.rest.response.iam.UserInventoryEntityResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Company Inventory Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserCompanyInventoryResponse implements Serializable {

  private static final long serialVersionUID = -4795650175905747069L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String companyId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String companyName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Map<IamEntityType, List<UserInventoryEntityResponse>> entities;

  public UserCompanyInventoryResponse(final String companyId,
      final String companyName,
      final Map<IamEntityType, List<UserInventoryEntityResponse>> entities) {
    this.companyId = companyId;
    this.companyName = companyName;
    this.entities = entities;
  }

  /**
   * Gets entities.
   *
   * @return the entities
   */
  public Map<IamEntityType, List<UserInventoryEntityResponse>> getEntities() {
    return entities;
  }


  /**
   * Gets company id.
   *
   * @return the company id
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * Gets company name.
   *
   * @return the company name
   */
  public String getCompanyName() {
    return companyName;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserCompanyInventoryResponse that = (UserCompanyInventoryResponse) o;

    if (companyId != null ?
        !companyId.equals(that.companyId) :
        that.companyId != null)
      return false;
    if (companyName != null ?
        !companyName.equals(that.companyName) :
        that.companyName != null)
      return false;
    return entities != null ?
        entities.equals(that.entities) :
        that.entities == null;
  }

  @Override
  public int hashCode() {
    int result = companyId != null ? companyId.hashCode() : 0;
    result = 31 * result + (companyName != null ? companyName.hashCode() : 0);
    result = 31 * result + (entities != null ? entities.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "UserCompanyInventoryResponse{" + "companyId='" + companyId + '\''
        + ", companyName='" + companyName + '\'' + ", entities=" + entities
        + '}';
  }

}
