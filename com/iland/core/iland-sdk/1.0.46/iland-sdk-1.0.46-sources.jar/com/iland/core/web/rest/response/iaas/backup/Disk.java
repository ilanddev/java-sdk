/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the "LICENSE.txt" file that accompanied this software. Any inquiries
 *  concerning the scope or enforceability of the license should be addressed
 *  to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.List;
import java.util.Optional;

import com.iland.cohesity.iaas.backups.common.enums.DiskFormat;
import com.iland.cohesity.iaas.backups.common.enums.PartitionTableFormat;
import com.iland.core.web.rest.annotation.APIModel;


/**
 * Disk.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface Disk {

  /**
   * Array of Disk Blocks.
   * <p>
   * Specifies a set of disk blocks by defining the location and offset of disk
   * blocks in a disk.
   */
  List<DiskBlock> diskBlocks();

  /**
   * Specifies the format of the virtual disk.
   */
  DiskFormat diskFormat();

  /**
   * Array of Partitions.
   * <p>
   * Specifies information about all the partitions in this disk.
   */
  List<DiskPartition> diskPartitions();

  /**
   * Specifies partition table format on a disk.
   */
  PartitionTableFormat partitionTableFormat();

  /**
   * Specifies the sector size of hard disk. It is used for mapping the disk
   * blocks of the disk file into a linear list of sectors.
   */
  long sectorSizeBytes();

  /**
   * Specifies the disk uuid.
   */
  Optional<String> uuid();

  /**
   * Specifies the disk file name. This is the VMDK name and not the flat file
   * name.
   */
  String vmdkFileName();

  /**
   * Specifies the disk size in bytes.
   */
  long vmdkSizeBytes();

}
