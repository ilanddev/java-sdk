/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Product Section Property Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class ProductSectionPropertyResponse implements Serializable {

  private static final long serialVersionUID = 1089853293256840886L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String key;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String value;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String qualifiers;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean userConfigurable;

  public ProductSectionPropertyResponse(final String key, final String value,
      final String qualifiers, final String type,
      final boolean userConfigurable) {
    this.key = key;
    this.value = value;
    this.qualifiers = qualifiers;
    this.type = type;
    this.userConfigurable = userConfigurable;
  }

  /**
   * Get the key.
   *
   * @return {@link String} key
   */
  public String getKey() {
    return key;
  }

  /**
   * Get the value.
   *
   * @return {@link String} value
   */
  public String getValue() {
    return value;
  }

  /**
   * Get the qualifiers.
   *
   * @return {@link String} qualifiers
   */
  public String getQualifiers() {
    return qualifiers;
  }

  /**
   * Get the type.
   *
   * @return {@link String} type
   */
  public String getType() {
    return type;
  }

  /**
   * Is user configurable.
   *
   * @return is user configurable
   */
  public boolean isUserConfigurable() {
    return userConfigurable;
  }

}
