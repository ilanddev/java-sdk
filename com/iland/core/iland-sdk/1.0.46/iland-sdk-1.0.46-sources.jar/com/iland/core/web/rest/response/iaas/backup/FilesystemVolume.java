/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.List;
import java.util.Optional;

import com.iland.cohesity.iaas.backups.common.enums.LogicalVolumeType;
import com.iland.core.web.rest.annotation.APIModel;

/**
 * FilesystemVolume.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface FilesystemVolume {

  /**
   * Array of Disks and Partitions.
   * <p>
   * Specifies information about all the disks and partitions needed to mount
   * this logical volume.
   */
  List<Disk> disks();

  /**
   * Specifies a description about the filesystem.
   */
  String displayName();

  /**
   * Specifies type of the filesystem on this volume.
   */
  String filesystemType();

  /**
   * Specifies the uuid of the filesystem.
   */
  String filesystemUuid();

  /**
   * If true, this is a supported filesystem volume type.
   */
  boolean isSupported();

  /**
   * Specify attributes for a kLMV (Linux) or kLDM (Windows) filesystem. This
   * field is set only for kLVM and kLDM volume types.
   */
  Optional<LogicalVolume> logicalVolume();

  /**
   * Specifies the type of logical volume such as kSimpleVolume, kLVM or kLDM.
   */
  LogicalVolumeType logicalVolumeType();

  /**
   * Specifies the name of the volume such as /C.
   */
  String name();

}
