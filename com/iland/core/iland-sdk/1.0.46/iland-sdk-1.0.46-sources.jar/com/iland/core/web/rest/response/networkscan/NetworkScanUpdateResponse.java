/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscan;

import java.time.Instant;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Network Scan Update Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public final class NetworkScanUpdateResponse {

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private Instant creationDate;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String customTargets;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String defaultPermissions;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String description;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String emails;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int id;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int lastModificationDate;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String name;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String notificationFilterType;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String notificationFilters;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String owner;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int ownerId;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int policyId;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String rrules;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int scannerId;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int shared;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String startTime;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int tagId;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String timezone;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String type;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int userPermissions;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String uuid;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean useDashboard;

	public NetworkScanUpdateResponse(final Instant creationDate,
		final String customTargets, final String defaultPermissions,
		final String description, final String emails, final int id,
		final int lastModificationDate, final String name,
		final String notificationFilterType, final String notificationFilters,
		final String owner, final int ownerId, final int policyId,
		final String rrules, final int scannerId, final int shared,
		final String startTime, final int tagId, final String timezone,
		final String type, final int userPermissions, final String uuid,
		final boolean useDashboard) {
		this.creationDate = creationDate;
		this.customTargets = customTargets;
		this.defaultPermissions = defaultPermissions;
		this.description = description;
		this.emails = emails;
		this.id = id;
		this.lastModificationDate = lastModificationDate;
		this.name = name;
		this.notificationFilterType = notificationFilterType;
		this.notificationFilters = notificationFilters;
		this.owner = owner;
		this.ownerId = ownerId;
		this.policyId = policyId;
		this.rrules = rrules;
		this.scannerId = scannerId;
		this.shared = shared;
		this.startTime = startTime;
		this.tagId = tagId;
		this.timezone = timezone;
		this.type = type;
		this.userPermissions = userPermissions;
		this.uuid = uuid;
		this.useDashboard = useDashboard;
	}

	/**
	 * Whether to use the dashboard.
	 *
	 * @return use dashboard
	 */
	public boolean isUseDashboard() {
		return useDashboard;
	}

	/**
	 * Get the scan uuid.
	 *
	 * @return {@link String} uuid
	 */
	public String getUuid() {
		return uuid;
	}

	/**
	 * Get the user permissions.
	 *
	 * @return user permissionsj
	 */
	public int getUserPermissions() {
		return userPermissions;
	}

	/**
	 * Get the scan type.
	 *
	 * @return {@link String} type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Get the timezone.
	 *
	 * @return timezone
	 */
	public String getTimezone() {
		return timezone;
	}

	/**
	 * Get the tag id.
	 *
	 * @return tag id
	 */
	public int getTagId() {
		return tagId;
	}

	/**
	 * Get the scan start time.
	 *
	 * @return {@link String} start time
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * Get whether the scan is shared.
	 *
	 * @return shared
	 */
	public int getShared() {
		return shared;
	}

	/**
	 * Get the scanner id.
	 *
	 * @return scanner id
	 */
	public int getScannerId() {
		return scannerId;
	}

	/**
	 * Get the scan schedule.
	 *
	 * @return {@link String} schedule
	 */
	public String getRrules() {
		return rrules;
	}

	/**
	 * Get the scan policy id.
	 *
	 * @return policy id
	 */
	public int getPolicyId() {
		return policyId;
	}

	/**
	 * Get the owner id.
	 *
	 * @return owner id
	 */
	public int getOwnerId() {
		return ownerId;
	}

	/**
	 * Get the owner.
	 *
	 * @return {@link String} owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * Get the notification filters.
	 *
	 * @return {@link String} notification filters
	 */
	public String getNotificationFilters() {
		return notificationFilters;
	}

	/**
	 * Get the notification filter type.
	 *
	 * @return {@link String} notification filter type
	 */
	public String getNotificationFilterType() {
		return notificationFilterType;
	}

	/**
	 * Get the scan name.
	 *
	 * @return {@link String} name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Get the last modification date.
	 *
	 * @return last modification date
	 */
	public int getLastModificationDate() {
		return lastModificationDate;
	}

	/**
	 * Get the scan id.
	 *
	 * @return scan id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Get the scan emails.
	 *
	 * @return {@link String} emails
	 */
	public String getEmails() {
		return emails;
	}

	/**
	 * Get the scan description.
	 *
	 * @return {@link String} description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Get the default scan permissions.
	 *
	 * @return {@link String} default scan permissions
	 */
	public String getDefaultPermissions() {
		return defaultPermissions;
	}

	/**
	 * Get the custom targets.
	 *
	 * @return {@link String} custom targets
	 */
	public String getCustomTargets() {
		return customTargets;
	}

	/**
	 * Get the scan creation date.
	 *
	 * @return {@link Date} creation
	 */
	public Instant getCreationDate() {
		return creationDate;
	}

}
