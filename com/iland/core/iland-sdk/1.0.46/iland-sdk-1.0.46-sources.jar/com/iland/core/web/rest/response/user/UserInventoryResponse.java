/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.user;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Inventory Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserInventoryResponse implements Serializable {

  private static long serialVersionUID = 4600306421888861536L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String username;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<UserCompanyInventoryResponse> inventory;

  public UserInventoryResponse(final String username,
      final List<UserCompanyInventoryResponse> inventory) {
    this.username = username;
    this.inventory = inventory;
  }

  /**
   * Gets the username.
   *
   * @return {@link String} username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Get a list of user company inventory.
   *
   * @return {@link List} of {@link UserCompanyInventoryResponse} company
   * inventory
   */
  public List<UserCompanyInventoryResponse> getInventory() {
    return inventory;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserInventoryResponse that = (UserInventoryResponse) o;

    if (username != null ?
        !username.equals(that.username) :
        that.username != null)
      return false;
    return inventory != null ?
        inventory.equals(that.inventory) :
        that.inventory == null;
  }

  @Override
  public int hashCode() {
    int result = username != null ? username.hashCode() : 0;
    result = 31 * result + (inventory != null ? inventory.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "UserInventoryResponse{" + "username='" + username + '\''
        + ", inventory=" + inventory + '}';
  }

}
