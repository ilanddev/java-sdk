/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.util.Set;

import com.iland.core.web.rest.response.common.SetResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * O365 Exchange Mailbox Set response.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365ExchangeMailboxSetResponse
    extends SetResponse<O365ExchangeMailboxResponse> {

  public O365ExchangeMailboxSetResponse(
      final Set<O365ExchangeMailboxResponse> data) {
    super(data);
  }

}
