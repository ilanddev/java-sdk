/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.media;

import com.iland.core.api.util.PublicUuidUtil;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Public Media Response.
 *
 * @author <a href="mailto:bsnydert@iland.com">Brett Snyder</a>
 */
@APIDoc
public class PublicMediaResponse extends MediaResponse {

  private static final long serialVersionUID = 2027539555625120841L;

  /**
   * Instantiates a new Public Media with a public uuid from a previous Media
   *
   * @param media {@link MediaResponse} media
   */
  public PublicMediaResponse(final MediaResponse media) {
    super(PublicUuidUtil.addPublicToUuid(media.getUuid()), media.getCompanyId(),
        media.getName(), media.isDeleted(), media.getDeletedDate(),
        media.getUpdatedDate(), media.getStatus(), media.getSize(),
        media.isPublic(), media.getLocationId(), media.getOrgUuid(),
        PublicUuidUtil.addPublicToUuid(media.getCatalogUuid()),
        media.getStorageProfileUuid(), media.getVdcUuid(),
        media.getDescription(), media.getVcloudHref(), media.getCreatedDate());
  }

}
