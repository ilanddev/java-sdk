/*
 * Copyright (c) 2013,2020 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 205 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.sso.GoogleIdentityProviderConfigRequest;
import com.iland.core.web.rest.request.sso.OIDCIdentityProviderConfigRequest;
import com.iland.core.web.rest.request.sso.OIDCIdentityProviderURLCreationRequest;
import com.iland.core.web.rest.request.sso.OktaIdentityProviderCreateRequest;
import com.iland.core.web.rest.request.sso.SAMLIdentityProviderConfigRequest;
import com.iland.core.web.rest.request.sso.SAMLIdentityProviderUrlCreationRequest;
import com.iland.core.web.rest.response.sso.IdentityProviderRedirectUriResponse;
import com.iland.core.web.rest.response.sso.IdentityProviderResponse;
import com.iland.core.web.rest.response.sso.IdpAccountLinkErrorResponseSet;
import com.iland.core.web.rest.response.sso.OIDCIdentityProviderResponse;
import com.iland.core.web.rest.response.sso.SAMLIdentityProviderResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Single Sign On Resource.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIProperties(name = "Single sign on Resource")
@Path("/companies")
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface CompanySSOResource {

  /**
   * Create a SAML identity provider from a URL.
   *
   * @param companyId company id
   * @param request   url to import identity provider configuration from
   * @return SAML identity provider response
   */
  @POST
  @Path("/{companyId}/actions/create-saml-idp-url")
  @Consumes(MediaType.APPLICATION_JSON)
  SAMLIdentityProviderResponse createSAMLIdentityProviderFromUrl(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId,
      SAMLIdentityProviderUrlCreationRequest request);

  /**
   * Create a OIDC identity provider from a URL.
   *
   * @param companyId company id
   * @param request   url to import identity provider configuration from
   * @return OIDC identity provider response
   */
  @POST
  @Path("/{companyId}/actions/create-oidc-idp-url")
  @Consumes(MediaType.APPLICATION_JSON)
  OIDCIdentityProviderResponse createOIDCIdentityProviderFromURL(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId,
      OIDCIdentityProviderURLCreationRequest request);

  /**
   * Create SAML identity provider from file.
   *
   * @param companyId company id
   * @param config    file of identity provider config
   * @return SAML identity provider response
   */
  @POST
  @Path("/{companyId}/actions/create-saml-idp-from-file")
  @Consumes(MediaType.APPLICATION_XML)
  SAMLIdentityProviderResponse createSAMLIdentityProviderFromFile(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId, byte[] config);

  /**
   * Create SAML identity provider from config.
   *
   * @param companyId           company id
   * @param configCreateRequest saml config
   * @return SAML identity provider response
   */
  @POST
  @Path("/{companyId}/actions/create-saml-idp")
  @Consumes(MediaType.APPLICATION_JSON)
  SAMLIdentityProviderResponse createSamlIdentityProvider(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId,
      SAMLIdentityProviderConfigRequest configCreateRequest);

  /**
   * Create OIDC identity provider from config.
   *
   * @param companyId           company id
   * @param configCreateRequest oidc config
   * @return OIDC identity provider response
   */
  @POST
  @Path("/{companyId}/actions/create-oidc-idp")
  @Consumes(MediaType.APPLICATION_JSON)
  OIDCIdentityProviderResponse createOIDCIdentityProvider(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId,
      OIDCIdentityProviderConfigRequest configCreateRequest);

  /**
   * Create Google identity provider from config.
   *
   * @param companyId           company id
   * @param configCreateRequest google config
   * @return Google identity provider response
   */
  @POST
  @Path("/{companyId}/actions/create-google-idp")
  @Consumes(MediaType.APPLICATION_JSON)
  OIDCIdentityProviderResponse createGoogleIdentityProvider(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId,
      GoogleIdentityProviderConfigRequest configCreateRequest);

  /**
   * Create Okta identity provider from config.
   *
   * @param companyId           company id
   * @param configCreateRequest okta config
   * @return Okta identity provider response
   */
  @POST
  @Path("/{companyId}/actions/create-okta-idp")
  @Consumes(MediaType.APPLICATION_JSON)
  SAMLIdentityProviderResponse createOktaIdentityProvider(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId,
      OktaIdentityProviderCreateRequest configCreateRequest);

  /**
   * Update Google identity provider from config.
   *
   * @param companyId           company id
   * @param configCreateRequest google config
   */
  @PUT
  @Path("/{companyId}/actions/update-google-idp")
  @Consumes(MediaType.APPLICATION_JSON)
  OIDCIdentityProviderResponse updateGoogleIdentityProvider(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId,
      GoogleIdentityProviderConfigRequest configCreateRequest);

  /**
   * Update Okta identity provider from config.
   *
   * @param companyId     company id
   * @param configRequest okta config
   */
  @PUT
  @Path("/{companyId}/actions/update-okta-idp")
  @Consumes(MediaType.APPLICATION_JSON)
  SAMLIdentityProviderResponse updateOktaIdentityProvider(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId,
      OktaIdentityProviderCreateRequest configRequest);

  /**
   * Get the IDP redirect URI for the given company.
   *
   * @param companyId            company id
   * @return identity provider redirect uri response
   */
  @GET
  @Path("/{companyId}/idp-redirect-uri")
  @Consumes(MediaType.APPLICATION_JSON)
  IdentityProviderRedirectUriResponse getIdentityProviderRedirectUri(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId,
      @QueryParam("isOkta") boolean isOkta);


  /**
   * Get the identity provider for the given company.
   *
   * @param companyId company id
   * @return the identity provider
   */
  @GET
  @Path("/{companyId}/idp")
  IdentityProviderResponse getIdentityProvider(
      @SecureEntityRef(Permission.VIEW_COMPANY_IAM) @PathParam("companyId")
          String companyId);

  /**
   * Update the SAML identity provider.
   *
   * @param companyId company id
   * @param samlIdentityProviderConfigRequest saml identity provider config request
   */
  @PUT
  @Path("/{companyId}/actions/update-saml-provider")
  @Consumes(MediaType.APPLICATION_JSON)
  SAMLIdentityProviderResponse updateSamlIdentityProvider(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId,
      SAMLIdentityProviderConfigRequest samlIdentityProviderConfigRequest);

  /**
   * Update the OIDC identity provider.
   *
   * @param companyId                         company id
   * @param oidcIdentityProviderConfigRequest oidc identity provider config request
   */
  @PUT
  @Path("/{companyId}/actions/update-oidc-provider")
  @Consumes(MediaType.APPLICATION_JSON)
  OIDCIdentityProviderResponse updateOIDCIdentityProvider(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId,
      OIDCIdentityProviderConfigRequest oidcIdentityProviderConfigRequest);

  /**
   * Delete the specified identity provider.
   *
   * @param companyId company id
   */
  @DELETE
  @Path("/{companyId}/idp")
  void deleteIdentityProvider(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId);

  /**
   * Get account linking errors for a given company's identity provider.
   *
   * @param companyId company id
   * @return a list of identity provider account link errors
   */
  @GET
  @Path("/{companyId}/idp-account-link-errors")
  IdpAccountLinkErrorResponseSet getIdentityProviderAccountLinkErrors(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IDENTITY_PROVIDER)
      @PathParam("companyId") String companyId);

}
