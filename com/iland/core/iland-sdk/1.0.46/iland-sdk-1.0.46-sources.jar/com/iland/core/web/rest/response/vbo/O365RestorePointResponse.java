/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.vbo;

import java.time.Instant;

import com.google.gson.annotations.Expose;

import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Single restore point entry exposed to the FE for the Search Backups
 * date picker. One row corresponds to one Veeam restore point on the
 * chosen date for a job covering the chosen workload type. The pair of
 * {@code creationTime} and {@code jobName} matches the UI label, e.g.
 * {@code "10:23 AM (Entire Organization Backup)"}.
 *
 * @param restorePointUuid the restore point uuid
 * @param creationTime     when the restore point was created
 * @param jobUuid          the uuid of the job that produced it
 * @param jobName          the job name, may be null when the job
 *                         is not synced locally
 */
@APIDoc
public record O365RestorePointResponse(@Expose String restorePointUuid,
                                       @Expose Instant creationTime,
                                       @Expose String jobUuid,
                                       @Expose String jobName) {
}
