/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vappnetwork;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Network Port Forward Nat Rule Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappNetworkPortForwardNATRuleResponse implements Serializable {

  private static final long serialVersionUID = 5738269403952046618L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String externalPort;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String forwardToPort;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String protocol;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmInterface;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmLocalId;

  public VappNetworkPortForwardNATRuleResponse(final String vmLocalId,
      final String externalPort, final String forwardToPort,
      final String protocol, final String vmInterface) {
    this.vmLocalId = vmLocalId;
    this.externalPort = externalPort;
    this.forwardToPort = forwardToPort;
    this.protocol = protocol;
    this.vmInterface = vmInterface;
  }

  /**
   * Get the external port.
   *
   * @return {@link String} external port
   */
  public String getExternalPort() {
    return externalPort;
  }

  /**
   * Get the forward to port.
   *
   * @return {@link String} forward to port
   */
  public String getForwardToPort() {
    return forwardToPort;
  }

  /**
   * Get the protocol.
   *
   * @return {@link String} protocol
   */
  public String getProtocol() {
    return protocol;
  }

  /**
   * Get the VM interface.
   *
   * @return {@link String} vm interface
   */
  public String getVmInterface() {
    return vmInterface;
  }

  /**
   * Get the associated Vm Uuid.
   *
   * @return {@link String} vm uuid
   */
  public String getVmLocalId() {
    return vmLocalId;
  }

}
