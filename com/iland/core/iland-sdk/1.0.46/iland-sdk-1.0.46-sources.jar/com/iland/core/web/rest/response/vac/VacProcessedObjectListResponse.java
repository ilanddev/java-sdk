/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vac;

import java.util.List;

import com.iland.core.web.rest.response.common.ListResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vac Backup Job Processed Objects List Response
 *
 * @author <a href="mailto:Pablo.Buendia@1111systems.com">Pablo Buendia</a>
 */
@APIDoc
public final class VacProcessedObjectListResponse
    extends ListResponse<VacProcessedObjectResponse> {

  public VacProcessedObjectListResponse(
      final List<VacProcessedObjectResponse> data) {
    super(data);
  }

}
