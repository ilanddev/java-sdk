/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vdi;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VDI User Response.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public class VdiUserResponse implements Serializable {

  private static final long serialVersionUID = 5041600277270781534L;

  @Expose
  @JsonRequired("The user's unique UUID identifier.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @JsonRequired("The user's full name.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @JsonRequired("The user's email address.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String email;

  /**
   * Instantiates a new Vdi user response.
   *
   * @param uuid  the uuid
   * @param name  the name
   * @param email the email
   */
  public VdiUserResponse(final String uuid, final String name,
      final String email) {
    this.uuid = uuid;
    this.name = name;
    this.email = email;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets email.
   *
   * @return the email
   */
  public String getEmail() {
    return email;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final VdiUserResponse that = (VdiUserResponse) o;
    return uuid.equals(that.uuid) && name.equals(that.name) && email
        .equals(that.email);
  }

  @Override
  public int hashCode() {
    return Objects.hash(uuid, name, email);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("uuid", uuid).add("name", name)
        .add("email", email).toString();
  }
}
