/*
 * Copyright (c) 2013 - 2017, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.vappnetwork.VappNetworkDHCPServiceUpdateRequest;
import com.iland.core.web.rest.request.vappnetwork.VappNetworkFirewallUpdateRequest;
import com.iland.core.web.rest.request.vappnetwork.VappNetworkNATServiceUpdateRequest;
import com.iland.core.web.rest.request.vappnetwork.VappNetworkStaticRoutingServiceUpdateRequest;
import com.iland.core.web.rest.request.vappnetwork.VappNetworkUpdateRequest;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vappnetwork.VappNetworkDHCPServiceResponse;
import com.iland.core.web.rest.response.vappnetwork.VappNetworkFirewallResponse;
import com.iland.core.web.rest.response.vappnetwork.VappNetworkInterfaceListResponse;
import com.iland.core.web.rest.response.vappnetwork.VappNetworkNATServiceResponse;
import com.iland.core.web.rest.response.vappnetwork.VappNetworkResponse;
import com.iland.core.web.rest.response.vappnetwork.VappNetworkStaticRoutingServiceResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Vapp Network Resource Interface.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "vApp Networks")
@Path("/vapp-networks")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface VappNetworkResource {

  /**
   * Get a vApp network by UUID.
   *
   * @param networkUuid network uuid
   * @return asynchronous task details
   */
  @GET
  @Path("/{networkUuid}")
  VappNetworkResponse getVappNetwork(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP_NETWORK)
      @PathParam("networkUuid") String networkUuid);

  /**
   * Delete a vApp network.
   *
   * @param networkUuid network uuid
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{networkUuid}")
  TaskResponse removeNetworkFromVapp(
      @SecureEntityRef(Permission.DELETE_ILAND_CLOUD_VAPP_NETWORK)
      @PathParam("networkUuid") String networkUuid);

  /**
   * Update a vApp network's properties. Note that vCloud Director changes the
   * UUID of the network when it is updated.
   *
   * @param networkUuid network uuid
   * @return asynchronous task details
   */
  @PUT
  @Path("/{networkUuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateVappNetwork(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_NETWORK_CONFIGURATION)
      @PathParam("networkUuid") String networkUuid,
      VappNetworkUpdateRequest vappNetwork);

  /**
   * Get a firewall for a given vapp network.
   *
   * @param networkUuid network uuid
   * @return vapp newtork firewall
   */
  @GET
  @Path("/{networkUuid}/firewall")
  VappNetworkFirewallResponse getFirewall(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP_NETWORK)
      @PathParam("networkUuid") String networkUuid);

  /**
   * Update a firewall for a particular vApp.
   *
   * @param networkUuid network uuid
   * @param firewall    vapp firewall
   * @return asynchronous task details
   */
  @POST
  @Path("/{networkUuid}/actions/update-firewall")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateFirewall(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_NETWORK_CONFIGURATION)
      @PathParam("networkUuid") String networkUuid,
      VappNetworkFirewallUpdateRequest firewall);

  /**
   * Get DHCP service for a given vapp network.
   *
   * @param networkUuid network uuid
   * @return vapp DHCP service
   */
  @GET
  @Path("/{networkUuid}/dhcp")
  VappNetworkDHCPServiceResponse getDHCPService(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP_NETWORK)
      @PathParam("networkUuid") String networkUuid);

  /**
   * Update the DHCP service for a particular vApp.
   *
   * @param networkUuid network uuid
   * @param dhcpService vapp dhcp service
   * @return asynchronous task details
   */
  @POST
  @Path("/{networkUuid}/actions/update-dhcp")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateDHCP(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_NETWORK_CONFIGURATION)
      @PathParam("networkUuid") String networkUuid,
      VappNetworkDHCPServiceUpdateRequest dhcpService);

  /**
   * Update the static routing service for a particular vApp.
   *
   * @param networkUuid          network uuid
   * @param staticRoutingService vapp network static routing service
   * @return asynchronous task details
   */
  @POST
  @Path("/{networkUuid}/actions/update-static-routing")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateStaticRouting(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_NETWORK_CONFIGURATION)
      @PathParam("networkUuid") String networkUuid,
      VappNetworkStaticRoutingServiceUpdateRequest staticRoutingService);

  /**
   * Get static routing service for a given vapp and network.
   *
   * @param networkUuid network uuid
   * @return vapp network static routing service
   */
  @GET
  @Path("/{networkUuid}/static-routing")
  VappNetworkStaticRoutingServiceResponse getStaticRouting(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP_NETWORK)
      @PathParam("networkUuid") String networkUuid);

  /**
   * Get vApp Network VM interfaces that are tied to this vApp network.
   *
   * @param networkUuid network uuid
   * @return vapp network VM network interfaces tied to this network
   */
  @GET
  @Path("/{networkUuid}/vm-interfaces")
  VappNetworkInterfaceListResponse getVmInterfaces(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP_NETWORK)
      @PathParam("networkUuid") String networkUuid);

  /**
   * Get NAT service for a given vapp and network.
   *
   * @param networkUuid network uuid
   * @return vapp network nat service
   */
  @GET
  @Path("/{networkUuid}/nat")
  VappNetworkNATServiceResponse getNATService(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP_NETWORK)
      @PathParam("networkUuid") String networkUuid);

  /**
   * Update the NAT service for a particular vApp.
   *
   * @param networkUuid network uuid
   * @param natService  vapp network nat service
   * @return asynchronous task details
   */
  @POST
  @Path("/{networkUuid}/actions/update-nat")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateNAT(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_NETWORK_CONFIGURATION)
      @PathParam("networkUuid") String networkUuid,
      VappNetworkNATServiceUpdateRequest natService);

}
