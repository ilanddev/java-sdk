/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * DiskCostAndUsageResponse.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class DiskCostAndUsageResponse implements Serializable {

  private static final long serialVersionUID = -3604771662749229077L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private ResourceCostAndUsageResponse total;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private ResourceCostAndUsageResponse hdd;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private ResourceCostAndUsageResponse ssd;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private ResourceCostAndUsageResponse archive;

  public DiskCostAndUsageResponse(final ResourceCostAndUsageResponse total,
      final ResourceCostAndUsageResponse hdd,
      final ResourceCostAndUsageResponse ssd,
      final ResourceCostAndUsageResponse archive) {
    this.total = total;
    this.hdd = hdd;
    this.ssd = ssd;
    this.archive = archive;
  }

  /**
   * Get the total disk cost and usgae.
   *
   * @return total disk cost and usage
   */
  public ResourceCostAndUsageResponse getTotal() {
    return total;
  }

  /**
   * Get the HDD tier cost and usage.
   *
   * @return HDD tier cost and usage
   */
  public ResourceCostAndUsageResponse getHdd() {
    return hdd;
  }

  /**
   * Get the SSD tier cost and usage.
   *
   * @return SSD tier cost and usage
   */
  public ResourceCostAndUsageResponse getSsd() {
    return ssd;
  }

  /**
   * Get the archive tier cost and usage.
   *
   * @return archive tier cost and usage
   */
  public ResourceCostAndUsageResponse getArchive() {
    return archive;
  }

}
