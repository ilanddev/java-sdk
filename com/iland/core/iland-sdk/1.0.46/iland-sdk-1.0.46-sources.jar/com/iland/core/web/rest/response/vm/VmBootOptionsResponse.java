/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vm Boot Options Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VmBootOptionsResponse implements Serializable {

  private static final long serialVersionUID = -2672203763267238439L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long bootDelay;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName("is_enter_bios")
  private final boolean enterBIOS;

  public VmBootOptionsResponse(final long bootDelay, final boolean enterBIOS) {
    this.bootDelay = bootDelay;
    this.enterBIOS = enterBIOS;
  }

  /**
   * Get the VM boot delay in milliseconds.
   *
   * @return boot delay in milliseconds
   */
  public long getBootDelay() {
    return bootDelay;
  }

  /**
   * Get whether the VM will force enter BIOS on restart.
   *
   * @return force enter bios on next reboot
   */
  public boolean isEnterBIOS() {
    return enterBIOS;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("VmBootOptionsResponse{");
    sb.append("bootDelay=").append(bootDelay);
    sb.append(", enterBIOS=").append(enterBIOS);
    sb.append('}');
    return sb.toString();
  }
}
