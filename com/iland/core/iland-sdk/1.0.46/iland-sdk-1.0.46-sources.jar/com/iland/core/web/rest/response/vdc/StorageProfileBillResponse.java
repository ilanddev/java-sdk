/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vdc;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Storage Profile Bill Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class StorageProfileBillResponse {

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String storageProfileUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double totalUsage;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double totalCost;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double resUsage;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double resCost;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double burstUsage;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double burstCost;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double vmUsage;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double catalogUsage;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double zertoJournalStorageUsage;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double zertoReplicatedStorageUsage;

  /**
   * Instantiates a new Storage profile usage.
   *
   * @param storageProfileUuid          the storage profile uuid
   * @param totalUsage                  the total usage
   * @param totalCost                   the total cost
   * @param resUsage                    the res usage
   * @param resCost                     the res cost
   * @param burstUsage                  the burst usage
   * @param burstCost                   the burst cost
   * @param catalogUsage                the catalog usage
   * @param vmUsage                     the VM usage
   * @param zertoJournalStorageUsage    the Zerto Journal Storage Usage
   * @param zertoReplicatedStorageUsage the Zerto Replicated Storage Usage
   */
  public StorageProfileBillResponse(final String storageProfileUuid,
      final double totalUsage, final double totalCost, final double resUsage,
      final double resCost, final double burstUsage, final double burstCost,
      final double vmUsage, final double catalogUsage,
      final double zertoJournalStorageUsage,
      final double zertoReplicatedStorageUsage) {
    this.storageProfileUuid = storageProfileUuid;
    this.totalUsage = totalUsage;
    this.totalCost = totalCost;
    this.resUsage = resUsage;
    this.resCost = resCost;
    this.burstUsage = burstUsage;
    this.burstCost = burstCost;
    this.vmUsage = vmUsage;
    this.catalogUsage = catalogUsage;
    this.zertoJournalStorageUsage = zertoJournalStorageUsage;
    this.zertoReplicatedStorageUsage = zertoReplicatedStorageUsage;
  }

  /**
   * Gets total usage.
   *
   * @return the total usage
   */
  public double getTotalUsage() {
    return totalUsage;
  }

  /**
   * Gets vm usage.
   *
   * @return the vm usage
   */
  public double getVmUsage() {
    return vmUsage;
  }

  /**
   * Gets catalog usage.
   *
   * @return the catalog usage
   */
  public double getCatalogUsage() {
    return catalogUsage;
  }

  /**
   * Gets res usage.
   *
   * @return the res usage
   */
  public double getResUsage() {
    return resUsage;
  }

  /**
   * Gets burst usage.
   *
   * @return the burst usage
   */
  public double getBurstUsage() {
    return burstUsage;
  }

  /**
   * Gets storage profile uuid.
   *
   * @return the storage profile uuid
   */
  public String getStorageProfileUuid() {
    return storageProfileUuid;
  }

  /**
   * Gets total cost.
   *
   * @return the total cost
   */
  public double getTotalCost() {
    return totalCost;
  }

  /**
   * Gets res cost.
   *
   * @return the res cost
   */
  public double getResCost() {
    return resCost;
  }

  /**
   * Gets burst cost.
   *
   * @return the burst cost
   */
  public double getBurstCost() {
    return burstCost;
  }

  /**
   * Returns the Zerto Journal Storage Usage.
   *
   * @return the Zerto journal storage usage in MB or 0 if not a Zerto environ
   */
  public double getZertoJournalStorageUsage() {
    return zertoJournalStorageUsage;
  }

  /**
   * Returns the Zerto Replicated Storage Usage
   *
   * @return the Zerto journal replicated usage in MB or 0 if not a Zerto
   * environ
   */
  public double getZertoReplicatedStorageUsage() {
    return zertoReplicatedStorageUsage;
  }
}
