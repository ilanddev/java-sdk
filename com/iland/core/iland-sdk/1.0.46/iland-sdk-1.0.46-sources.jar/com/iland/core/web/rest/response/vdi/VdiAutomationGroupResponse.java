/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vdi;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.shared.vdi.NetworkConnectionType;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VDI Automation Group Response.
 */
@APIDoc
public class VdiAutomationGroupResponse implements Serializable {

  private static final long serialVersionUID = -4930976014813143829L;

  @Expose
  @JsonRequired("The unique identifier for the VDI automation group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @JsonRequired("The name of the VDI automation group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @JsonOptional("The description of the VDI automation group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String description;

  @Expose
  @JsonOptional("The UUID of the edge gateway that should expose RDP access.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String edgeUuid;

  @Expose
  @JsonOptional("A public IP address that is assigned to the edge gateway and should be used to expose RDP access.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String publicIp;

  @Expose
  @JsonRequired("The UUID of the VDI vApp template.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vappTemplateUuid;

  @Expose
  @JsonRequired("The UUID of the VDI VM template.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmTemplateUuid;

  @Expose
  @JsonRequired("The UUID of the vDC that the VDI automation group will be deployed to.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String deploymentVdcUuid;

  @Expose
  @JsonRequired("The UUID of the org-vdc network that deployed VMs should be attached to.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String orgVdcNetworkUuid;

  @Expose
  @JsonOptional("The domain that the VDI instances should join.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String domainToJoin;

  @Expose
  @JsonRequired("The UUID of the associated VDI team.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String teamUuid;

  @Expose
  @JsonRequired("The type of the network connections of deployments.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final NetworkConnectionType networkConnectionType;

  @Expose
  @JsonOptional("Whether joining a domain is enabled for deployments")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean joinDomainEnabled;

  @Expose
  @JsonOptional("Whether to require users to reset the guest admin password after logging in.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean guestPasswordResetRequired;

  @Expose
  @JsonOptional(
      "The UUID of the storage profile that VMs should be deployed on. "
          + "Defaults to the deployment vDCs default storage profile.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String storageProfileUuid;

  /**
   * Instantiates a new VDI automation group response.
   *
   * @param uuid                       the uuid
   * @param name                       the name
   * @param description                the description
   * @param edgeUuid                   the edge UUID that should be used to expose RDP access
   * @param publicIp                   the public IP that RDP access should be exposed on
   * @param vappTemplateUuid           the vapp template uuid
   * @param vmTemplateUuid             the vm template uuid
   * @param deploymentVdcUuid          the deployment vdc uuid
   * @param orgVdcNetworkUuid          the org vdc network uuid
   * @param domainToJoin               the domain to join
   * @param teamUuid                   the team uuid
   * @param networkConnectionType      the network connection type
   * @param joinDomainEnabled          the join domain enabled
   * @param guestPasswordResetRequired the guest password reset required
   * @param storageProfileUuid         the storage profile uuid
   */
  public VdiAutomationGroupResponse(final String uuid, final String name,
      final String description, final String edgeUuid, final String publicIp,
      final String vappTemplateUuid, final String vmTemplateUuid,
      final String deploymentVdcUuid, final String orgVdcNetworkUuid,
      final String domainToJoin, final String teamUuid,
      final NetworkConnectionType networkConnectionType,
      final boolean joinDomainEnabled, final boolean guestPasswordResetRequired,
      final String storageProfileUuid) {
    this.uuid = uuid;
    this.name = name;
    this.description = description;
    this.edgeUuid = edgeUuid;
    this.publicIp = publicIp;
    this.vappTemplateUuid = vappTemplateUuid;
    this.vmTemplateUuid = vmTemplateUuid;
    this.deploymentVdcUuid = deploymentVdcUuid;
    this.orgVdcNetworkUuid = orgVdcNetworkUuid;
    this.domainToJoin = domainToJoin;
    this.teamUuid = teamUuid;
    this.networkConnectionType = networkConnectionType;
    this.joinDomainEnabled = joinDomainEnabled;
    this.guestPasswordResetRequired = guestPasswordResetRequired;
    this.storageProfileUuid = storageProfileUuid;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets vapp template uuid.
   *
   * @return the vapp template uuid
   */
  public String getVappTemplateUuid() {
    return vappTemplateUuid;
  }

  /**
   * Gets org vdc network uuid.
   *
   * @return the org vdc network uuid
   */
  public String getOrgVdcNetworkUuid() {
    return orgVdcNetworkUuid;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets deployment vdc uuid.
   *
   * @return the deployment vdc uuid
   */
  public String getDeploymentVdcUuid() {
    return deploymentVdcUuid;
  }

  /**
   * Gets domain to join.
   *
   * @return the domain to join
   */
  public String getDomainToJoin() {
    return domainToJoin;
  }

  /**
   * Gets the team uuid.
   *
   * @return the team uuid
   */
  public String getTeamUuid() {
    return teamUuid;
  }

  /**
   * Gets edge uuid.
   *
   * @return the edge uuid
   */
  public String getEdgeUuid() {
    return edgeUuid;
  }

  /**
   * Gets public ip.
   *
   * @return the public ip
   */
  public String getPublicIp() {
    return publicIp;
  }

  /**
   * Gets network connection type.
   *
   * @return the network connection type
   */
  public NetworkConnectionType getNetworkConnectionType() {
    return networkConnectionType;
  }

  /**
   * Is join domain enabled boolean.
   *
   * @return the boolean
   */
  public boolean isJoinDomainEnabled() {
    return joinDomainEnabled;
  }

  /**
   * Is guest password reset required boolean.
   *
   * @return the boolean
   */
  public boolean isGuestPasswordResetRequired() {
    return guestPasswordResetRequired;
  }

  /**
   * Gets the VM template UUID.
   *
   * @return vm template UUID
   */
  public String getVmTemplateUuid() {
    return vmTemplateUuid;
  }

  /**
   * Gets storage profile uuid.
   *
   * @return the storage profile uuid
   */
  public String getStorageProfileUuid() {
    return storageProfileUuid;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final VdiAutomationGroupResponse that = (VdiAutomationGroupResponse) o;
    return joinDomainEnabled == that.joinDomainEnabled
        && guestPasswordResetRequired == that.guestPasswordResetRequired
        && Objects.equals(uuid, that.uuid) && Objects.equals(name, that.name)
        && Objects.equals(description, that.description) && Objects
        .equals(edgeUuid, that.edgeUuid) && Objects
        .equals(publicIp, that.publicIp) && Objects
        .equals(vappTemplateUuid, that.vappTemplateUuid) && Objects
        .equals(vmTemplateUuid, that.vmTemplateUuid) && Objects
        .equals(deploymentVdcUuid, that.deploymentVdcUuid) && Objects
        .equals(orgVdcNetworkUuid, that.orgVdcNetworkUuid) && Objects
        .equals(domainToJoin, that.domainToJoin) && Objects
        .equals(teamUuid, that.teamUuid)
        && networkConnectionType == that.networkConnectionType && Objects
        .equals(storageProfileUuid, that.storageProfileUuid);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(uuid, name, description, edgeUuid, publicIp, vappTemplateUuid,
            vmTemplateUuid, deploymentVdcUuid, orgVdcNetworkUuid, domainToJoin,
            teamUuid, networkConnectionType, joinDomainEnabled,
            guestPasswordResetRequired, storageProfileUuid);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("uuid", uuid).add("name", name)
        .add("description", description).add("edgeUuid", edgeUuid)
        .add("publicIp", publicIp).add("vappTemplateUuid", vappTemplateUuid)
        .add("vmTemplateUuid", vmTemplateUuid)
        .add("deploymentVdcUuid", deploymentVdcUuid)
        .add("orgVdcNetworkUuid", orgVdcNetworkUuid)
        .add("domainToJoin", domainToJoin).add("teamUuid", teamUuid)
        .add("networkConnectionType", networkConnectionType)
        .add("joinDomainEnabled", joinDomainEnabled)
        .add("guestPasswordResetRequired", guestPasswordResetRequired)
        .add("storageProfileUuid", storageProfileUuid).toString();
  }
}
