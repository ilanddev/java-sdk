/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Office 365 VBO SharePoint Document response.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365SharePointDocumentResponse implements Serializable {

  private static final long serialVersionUID = 8534100721552609137L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The Veeam native ID of the backed up SharePoint document.")
  private final String id;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The name of the backed up SharePoint document.")
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The user, which created the document.")
  private final String createdBy;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The size of the document.")
  private final long sizeBytes;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The version of the document.")
  private final String version;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The date and time when the document was created.")
  private final Instant creationTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The user, which performed the last modifications to the document.")
  private final String modifiedBy;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The date and time when the document was modified.")
  private final Instant modificationTime;

  public O365SharePointDocumentResponse(final String id, final String name,
      final String createdBy, final long sizeBytes, final String version,
      final Instant creationTime, final String modifiedBy,
      final Instant modificationTime) {
    this.id = id;
    this.name = name;
    this.createdBy = createdBy;
    this.sizeBytes = sizeBytes;
    this.version = version;
    this.creationTime = creationTime;
    this.modifiedBy = modifiedBy;
    this.modificationTime = modificationTime;
  }

  /**
   * Returns the ID of the backed up SharePoint document.
   *
   * @return a Veeam native ID
   */
  public String getId() {
    return id;
  }

  /**
   * Returns the name of the document.
   *
   * @return the name of the document
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the user, which created the document.
   *
   * @return the user, which created the document
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * Returns the size of the document.
   *
   * @return the size of the document
   */
  public long getSizeBytes() {
    return sizeBytes;
  }

  /**
   * Returns the version of the document.
   *
   * @return the version of the document
   */
  public String getVersion() {
    return version;
  }

  /**
   * Returns date and time when the document was created.
   *
   * @return UTC {@link Instant}
   */
  public Instant getCreationTime() {
    return creationTime;
  }

  /**
   * Returns date and time when the document was modified.
   *
   * @return UTC {@link Instant}
   */
  public Instant getModificationTime() {
    return modificationTime;
  }

  /**
   * Returns the user, which performed the last modifications to the document.
   *
   * @return the user, which performed the last modifications to the document
   */
  public String getModifiedBy() {
    return modifiedBy;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final O365SharePointDocumentResponse that =
        (O365SharePointDocumentResponse) o;
    return sizeBytes == that.sizeBytes && Objects.equals(id, that.id) && Objects
        .equals(name, that.name) && Objects.equals(createdBy, that.createdBy)
        && Objects.equals(version, that.version) && Objects
        .equals(creationTime, that.creationTime) && Objects
        .equals(modifiedBy, that.modifiedBy) && Objects
        .equals(modificationTime, that.modificationTime);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(id, name, createdBy, sizeBytes, version, creationTime, modifiedBy,
            modificationTime);
  }

}
