/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.dns;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Org DNS Zone Response.
 * <p>
 * Provides link between an Org and a DNS Zone.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class OrgDNSZoneResponse implements Serializable {

  private static final long serialVersionUID = 7735430151282349870L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String orgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int zoneId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean deleted;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String zoneName;

  public OrgDNSZoneResponse(final String orgUuid, final int zoneId,
      final boolean deleted, final String zoneName) {
    this.orgUuid = orgUuid;
    this.zoneId = zoneId;
    this.deleted = deleted;
    this.zoneName = zoneName;
  }

  /**
   * Get the org uuid.
   *
   * @return org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Get the DNS zone ID.
   *
   * @return dns zone ID
   */
  public int getZoneId() {
    return zoneId;
  }

  /**
   * Get whether the DNS zone has been deleted.
   *
   * @return zone is deleted
   */
  public boolean isDeleted() {
    return deleted;
  }

  /**
   * Get the DNS zone name.
   *
   * @return DNS zone name
   */
  public String getZoneName() {
    return zoneName;
  }

}
