/*
 * Copyright (c) 2013 - 2024, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.response.vac.VacProcessedObjectListResponse;
import com.iland.core.web.rest.response.vac.VacProcessedObjectRestorePointListResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * VAC Backup Jobs Processed Objects resource.
 *
 * @author <a href="mailto:Pablo.Buendia@1111systems.com">Pablo Buendia</a>
 */
@APIProperties(name = "VAC Jobs Processed Objects")
@Path("/vac-jobs-processed-objects")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface VacJobProcessedObjectResource {

  /**
   * Gets a list of processed objects for the Backup Server Job
   *
   * @param jobUuid the Backup Server Job UUID
   * @return a list of processed objects for the Backup Server Job
   */
  @GET
  @Path("/{jobUuid}/processed-objects")
  VacProcessedObjectListResponse getProcessedObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_BACKUP_JOB) @PathParam("jobUuid")
      String jobUuid);

  /**
   * Gets a list of restore points for a processed object of a Backup Server Job
   *
   * @param jobUuid             the Backup Server Job UUID
   * @param processedObjectUuid the Backup Server Job UUID
   * @return a list of restore points for a processed object of a Backup Server Job
   */
  @GET
  @Path("/{jobUuid}/processed-objects/{processedObjectUuid}/restore-points")
  VacProcessedObjectRestorePointListResponse getRestorePoints(
      @SecureEntityRef(Permission.VIEW_ILAND_BACKUP_JOB) @PathParam("jobUuid")
      String jobUuid,
      @PathParam("processedObjectUuid") String processedObjectUuid);
}
