/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import java.io.InputStream;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.api.vbo.O365RestoreSessionType;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.vbo.O365JobRequest;
import com.iland.core.web.rest.request.vbo.O365MailboxPurgeRequest;
import com.iland.core.web.rest.request.vbo.O365OrganizationCreateModifyRequest;
import com.iland.core.web.rest.request.vbo.O365RestoreSessionStartRequest;
import com.iland.core.web.rest.request.vbo.O365SearchSessionStartRequest;
import com.iland.core.web.rest.response.vbo.O365BackupRepositorySetResponse;
import com.iland.core.web.rest.response.vbo.O365CopyJobSetResponse;
import com.iland.core.web.rest.response.vbo.O365DeviceCodeResponse;
import com.iland.core.web.rest.response.vbo.O365GroupPaginatedSetResponse;
import com.iland.core.web.rest.response.vbo.O365JobResponse;
import com.iland.core.web.rest.response.vbo.O365JobSetResponse;
import com.iland.core.web.rest.response.vbo.O365RestorePointSetResponse;
import com.iland.core.web.rest.response.vbo.O365OrganizationResponse;
import com.iland.core.web.rest.response.vbo.O365PurgedUserSetResponse;
import com.iland.core.web.rest.response.vbo.O365RestoreSessionPaginatedSetResponse;
import com.iland.core.web.rest.response.vbo.O365RestoreSessionResponse;
import com.iland.core.web.rest.response.vbo.O365RestoreSessionSetResponse;
import com.iland.core.web.rest.response.vbo.O365SearchSessionResponse;
import com.iland.core.web.rest.response.vbo.O365SharePointSiteSetResponse;
import com.iland.core.web.rest.response.vbo.O365TeamSetResponse;
import com.iland.core.web.rest.response.vbo.O365UserPaginatedSetResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Office 365 VBO Organizations Resource.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIProperties(name = "Office 365 Backup")
@Path("/o365-organizations")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface O365OrganizationResource {

  /**
   * Get an Office 365 VBO Organization given its UUID.
   *
   * @param uuid The Office 365 VBO Organization UUID
   * @return a {@link O365OrganizationResponse} instance
   */
  @GET
  @Path("/{uuid}")
  O365OrganizationResponse getOrganization(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid);

  /**
   * Get Office 365 VBO Organization Jobs given an Organization's UUID.
   *
   * @param uuid The Office 365 VBO Organization UUID
   * @return a {@link O365JobSetResponse} instance
   */
  @GET
  @Path("/{uuid}/jobs")
  O365JobSetResponse getOrganizationJobs(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid);

  /**
   * Get the restore points available for an Office 365 VBO Organization
   * on a given calendar date, narrowed to a single workload type.
   *
   * <p>A restore point is one successful or warning Veeam job session.
   * For each job that backs up the requested workload type, the bean
   * looks at every job session and keeps the ones whose creation time
   * falls inside the requested UTC date. Each entry carries the job
   * name so the FE can render labels like "10:23 AM (Entire Org)".
   *
   * @param uuid the Office 365 VBO Organization UUID
   * @param date the calendar date, ISO format yyyy-MM-dd. UTC.
   * @param type the workload type (Vex, Veod, Vesp, Vet).
   * @return a {@link O365RestorePointSetResponse} instance
   */
  @GET
  @Path("/{uuid}/restore-points")
  O365RestorePointSetResponse getOrganizationRestorePoints(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid,
      @QueryParam("date") String date,
      @QueryParam("type") O365RestoreSessionType type);

  /**
   * Open a Search Backups session for the given workload type. Always
   * creates a new session against the requested restore point (or the
   * latest one when {@code restore_point_uuid} is omitted). Only
   * {@link O365RestoreSessionType#Vex} is currently supported.
   *
   * @param uuid        the Office 365 VBO Organization UUID
   * @param sessionType the workload type, currently only {@code Vex}
   * @param request     the open-session request body
   * @return a {@link O365SearchSessionResponse} instance
   */
  @POST
  @Path("/{uuid}/search-backups/{sessionType}/sessions")
  @Consumes(MediaType.APPLICATION_JSON)
  O365SearchSessionResponse openSearchSession(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid,
      @PathParam("sessionType") O365RestoreSessionType sessionType,
      O365SearchSessionStartRequest request);

  /**
   * Get Office 365 VBO Organization Copy Jobs given an Organization's UUID.
   *
   * @param uuid The Office 365 VBO Organization UUID
   * @return a {@link O365CopyJobSetResponse} instance
   */
  @GET
  @Path("/{uuid}/copy-jobs")
  O365CopyJobSetResponse getOrganizationCopyJobs(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid);

  /**
   * Get Office 365 VBO Organization's inactive restore sessions given an
   * Organization's UUID.
   *
   * @param uuid     The Office 365 VBO Organization UUID
   * @param page     the page number
   * @param pageSize the page size
   * @return a {@link O365RestoreSessionPaginatedSetResponse} instance
   */
  @GET
  @Path("/{uuid}/inactive-restore-sessions")
  O365RestoreSessionPaginatedSetResponse getOrganizationRestoreSessionsHistory(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid, @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize);

  /**
   * Get Office 365 VBO organization's active restore sessions given an
   * organization's UUID.
   *
   * @param uuid The Office 365 VBO Organization UUID
   * @return a {@link O365RestoreSessionSetResponse} instance
   */
  @GET
  @Path("/{uuid}/active-restore-sessions")
  O365RestoreSessionSetResponse getOrganizationRestoreSessionsActive(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid);

  /**
   * Starts restore sessions for exploring and performing restore operations
   * with backups.
   *
   * @param uuid    The Office 365 VBO Organization UUID
   * @param request a {@link O365RestoreSessionStartRequest}
   * @return a {@link O365RestoreSessionResponse} instance
   */
  @POST
  @Path("/{uuid}/actions/start-restore-session")
  @Consumes(MediaType.APPLICATION_JSON)
  O365RestoreSessionResponse startRestoreSession(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid, O365RestoreSessionStartRequest request);

  /**
   * Remove a Microsoft Office 365 VBO organization given its uuid.
   *
   * @param uuid The Office 365 VBO Organization UUID.
   */
  @DELETE
  @Path("/{uuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  void removeOrganization(
      @SecureEntityRef(Permission.DELETE_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid);

  /**
   * Get the users for the Office 365 Organization.
   *
   * @param uuid     The Office 365 VBO Organization UUID
   * @param page     the page number
   * @param pageSize the page size
   * @param searchUser the user's name or display name to search on
   * @return a {@link O365UserPaginatedSetResponse} instance
   */
  @GET
  @Path("/{uuid}/users")
  @Consumes(MediaType.APPLICATION_JSON)
  O365UserPaginatedSetResponse getUsers(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid, @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("searchUser") String searchUser);

  /**
   * Download the entire users as CSV for the Office 365 Organization.
   *
   * @param uuid     The Office 365 VBO Organization UUID
   * @return a {@link InputStream} representing the users file.
   */
  @POST
  @Path("/{uuid}/users-export")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream exportUsers(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid);

  /**
   * Get the groups for the Office 365 Organization.
   *
   * @param uuid     The Office 365 VBO Organization UUID
   * @param page     the page number
   * @param pageSize the page size
   * @param groupName the display name of the group.
   * @return a {@link O365GroupPaginatedSetResponse} instance
   */
  @GET
  @Path("/{uuid}/groups")
  @Consumes(MediaType.APPLICATION_JSON)
  O365GroupPaginatedSetResponse getGroups(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid, @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("groupName") String groupName);

  /**
   * Get Office 365 VBO backup repositories based on the company and location of the given organization uuid
   *
   * @param uuid     The Office 365 VBO Organization UUID
   * @return the {@link O365BackupRepositorySetResponse}
   */
  @GET
  @Path("/{uuid}/backup-repositories")
  @Consumes(MediaType.APPLICATION_JSON)
  O365BackupRepositorySetResponse getVboBackupRepositories(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid);

  /**
   * Create a new Office 365 VBO backup job.
   *
   * @param uuid    The Office 365 VBO Organization UUID
   * @param request a {@link O365JobRequest}
   * @return a {@link O365JobResponse} instance
   */
  @POST
  @Path("/{uuid}/actions/create-job")
  @Consumes(MediaType.APPLICATION_JSON)
  O365JobResponse createO365Job(
      @SecureEntityRef(Permission.CREATE_ILAND_O365_JOB) @PathParam("uuid")
          String uuid, O365JobRequest request);

  /**
   * Get Office 365 VBO Sharepoint sites given an organization UUID.
   *
   * @param uuid     The Office 365 VBO organization UUID.
   * @param page     the page number
   * @param pageSize the page size
   * @return a {@link O365SharePointSiteSetResponse} instance
   */
  @GET
  @Path("/{uuid}/sharepoint-sites")
  O365SharePointSiteSetResponse getSharepointSites(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid,
      @QueryParam("isPersonal") Boolean isPersonal,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize);

  /**
   * Get Office 365 VBO Teams given an organization UUID.
   *
   * @param uuid     The Office 365 VBO organization UUID.
   * @param page     the page number
   * @param pageSize the page size
   * @return a {@link O365TeamSetResponse} instance
   */
  @GET
  @Path("/{uuid}/teams")
  O365TeamSetResponse getTeams(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid, @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize);

  /**
   * Modify the credentials and online settings of a Microsoft Office 365 VBO organization
   * given its uuid. Please note that the credentials have to be changed in MS Azure AD
   * account first before updating here.
   *
   * @param uuid    The Office 365 VBO Organization UUID.
   * @param request The Office 365 VBO Organization modify request.
   */
  @POST
  @Path("/{uuid}/actions/modify")
  @Consumes(MediaType.APPLICATION_JSON)
  void modifyOrganizationCredentials(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid,
      O365OrganizationCreateModifyRequest request);

  /**
   * Submits a purge request for the given mailboxes of the given organization.
   * Please note that mailboxes sent in this request will not be actually deleted
   * until the grace period (in days) as defined in the config has elapsed.
   * @param uuid    The Office 365 VBO Organization UUID.
   * @param request the set of purge mailboxes requested
   */
  @POST
  @Path("/{uuid}/actions/purge-mailboxes")
  @Consumes(MediaType.APPLICATION_JSON)
  void markMailboxesForPurge(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid, Set<O365MailboxPurgeRequest> request);

  /**
   * Given an org uuid, get all the mailboxes marked for purge (any status).
   * @param uuid    The Office 365 VBO Organization UUID.
   * @return the set of mailboxes marked for purge (any status).
   */
  @GET
  @Path("/{uuid}/actions/get-purge-mailboxes")
  @Consumes(MediaType.APPLICATION_JSON)
  O365PurgedUserSetResponse getPurgeMailboxes(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid);

  /**
   * Cancels the purge request for the given mailboxes of the given organization.
   * @param uuid    The Office 365 VBO Organization UUID.
   * @param request the set of purge mailboxes to cancel
   */
  @POST
  @Path("/{uuid}/actions/cancel-purge")
  @Consumes(MediaType.APPLICATION_JSON)
  void cancelPurgeMailboxes(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid, Set<O365MailboxPurgeRequest> request);

  /**
   * Get a device code response from Microsoft Azure to validate in the Microsoft
   * authentication portal. This is to be used while modifying an org.
   *
   * @return a {@link O365DeviceCodeResponse} instance
   */
  @GET
  @Path("/{uuid}/actions/get-o365-device-code")
  @Consumes(MediaType.APPLICATION_JSON)
  O365DeviceCodeResponse getO365DeviceCode(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_ORGANIZATION)
      @PathParam("uuid") String uuid);

}
