/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * CloudTenantBillHistoryResponse.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class CloudTenantBillHistoryResponse implements Serializable {

  private static final long serialVersionUID = 5005505120569373830L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Map<String, List<CloudTenantBillResponse>> bills;

  public CloudTenantBillHistoryResponse(
      final Map<String, List<CloudTenantBillResponse>> bills) {
    this.bills = bills;
  }

  /**
   * Get a map of the historical cloud tenant billing.
   *
   * @return {@link Map} of {@link String} to {@link List} of
   * {@link CloudTenantBillResponse} historical billing
   */
  public Map<String, List<CloudTenantBillResponse>> getBills() {
    return bills;
  }

}
