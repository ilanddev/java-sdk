/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vdi;

import java.io.Serializable;
import java.util.Collections;
import java.util.Objects;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VDI Team Response.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public class VdiTeamResponse implements Serializable {

  private static final long serialVersionUID = -4183512465797092261L;

  @Expose
  @JsonRequired("The team's unique UUID identifier.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @JsonRequired("The team's name.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @JsonRequired("The set of VDI users that belong to the team, identified by UUID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<String> members;

  /**
   * Instantiates a new Vdi team response.
   *
   * @param uuid    the uuid
   * @param name    the name
   * @param members the member vdi user uuids
   */
  public VdiTeamResponse(final String uuid, final String name,
      final Set<String> members) {
    this.uuid = uuid;
    this.name = name;
    this.members = members == null ? Collections.emptySet() : members;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets member vdi user uuids.
   *
   * @return the member vdi user uuids
   */
  public Set<String> getMembers() {
    return members;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final VdiTeamResponse that = (VdiTeamResponse) o;
    return uuid.equals(that.uuid) && name.equals(that.name) && members
        .equals(that.members);
  }

  @Override
  public int hashCode() {
    return Objects.hash(uuid, name, members);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("uuid", uuid).add("name", name)
        .add("members", members).toString();
  }

}
