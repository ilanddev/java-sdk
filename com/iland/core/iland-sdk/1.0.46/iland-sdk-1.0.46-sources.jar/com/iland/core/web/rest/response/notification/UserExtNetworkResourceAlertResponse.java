/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.notification;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Ext Network Resource Alert Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserExtNetworkResourceAlertResponse
    extends AbstractResourceAlertResponse {

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String externalNetworkUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private double threshold;

  public UserExtNetworkResourceAlertResponse(final String group,
      final String name, final String type, final String username,
      final String action, final String equalityRelation, final boolean enabled,
      final int breachPeriod, final String externalNetwork,
      final double threshold) {
    super(group, name, type, username, action, equalityRelation, enabled,
        breachPeriod);
    this.externalNetworkUuid = externalNetwork;
    this.threshold = threshold;
  }

  /**
   * Get the external network uuid attached to this alert.
   *
   * @return {@link String} external network uuid
   */
  public String getExternalNetworkUuid() {
    return externalNetworkUuid;
  }

  /**
   * Get the alerting threshold at which the user wants to receive alerts for
   * the counter specified by group, name and type.
   *
   * @return alerting threshold
   */
  public double getThreshold() {
    return threshold;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserExtNetworkResourceAlertResponse that =
        (UserExtNetworkResourceAlertResponse) o;

    if (Double.compare(that.threshold, threshold) != 0)
      return false;
    return externalNetworkUuid != null ?
        externalNetworkUuid.equals(that.externalNetworkUuid) :
        that.externalNetworkUuid == null;
  }

  @Override
  public int hashCode() {
    int result;
    long temp;
    result = externalNetworkUuid != null ? externalNetworkUuid.hashCode() : 0;
    temp = Double.doubleToLongBits(threshold);
    result = 31 * result + (int) (temp ^ (temp >>> 32));
    return result;
  }

  @Override
  public String toString() {
    return "UserExtNetworkResourceAlertResponse{" + "externalNetworkUuid='"
        + externalNetworkUuid + '\'' + ", threshold=" + threshold + ", group='"
        + group + '\'' + ", name='" + name + '\'' + ", type='" + type + '\''
        + ", username='" + username + '\'' + ", action='" + action + '\''
        + ", equalityRelation='" + equalityRelation + '\'' + ", enabled="
        + enabled + ", breachPeriod=" + breachPeriod + '}';
  }

}
