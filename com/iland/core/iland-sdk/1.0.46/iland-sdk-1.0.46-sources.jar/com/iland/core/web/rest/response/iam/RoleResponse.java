/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iam;

import java.io.Serializable;
import java.util.Collection;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.iam.RoleType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Role Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class RoleResponse implements Serializable {

  private static final long serialVersionUID = 7562597365061517830L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String companyId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Collection<PolicyResponse> policies;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private RoleType type;

  public RoleResponse(final String uuid, final String companyId,
      final String name, final String description,
      final Collection<PolicyResponse> policies, final RoleType type) {
    this.uuid = uuid;
    this.companyId = companyId;
    this.name = name;
    this.description = description;
    this.policies = policies;
    this.type = type;
  }

  /**
   * Get the uuid.
   *
   * @return {@link String} uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Get the company id.
   *
   * @return {@link String} company id
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * Get the name.
   *
   * @return {@link String} name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the description.
   *
   * @return {@link String} description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get the policies.
   *
   * @return {@link Collection} of {@link PolicyResponse} policy responses.
   */
  public Collection<PolicyResponse> getPolicies() {
    return policies;
  }

  /**
   * Get the role type.
   *
   * @return {@link RoleType} role type
   */
  public RoleType getType() {
    return type;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final RoleResponse that = (RoleResponse) o;

    if (uuid != null ? !uuid.equals(that.uuid) : that.uuid != null)
      return false;
    if (companyId != null ?
        !companyId.equals(that.companyId) :
        that.companyId != null)
      return false;
    if (name != null ? !name.equals(that.name) : that.name != null)
      return false;
    if (description != null ?
        !description.equals(that.description) :
        that.description != null)
      return false;
    if (policies != null ?
        !policies.equals(that.policies) :
        that.policies != null)
      return false;
    return type == that.type;
  }

  @Override
  public int hashCode() {
    int result = uuid != null ? uuid.hashCode() : 0;
    result = 31 * result + (companyId != null ? companyId.hashCode() : 0);
    result = 31 * result + (name != null ? name.hashCode() : 0);
    result = 31 * result + (description != null ? description.hashCode() : 0);
    result = 31 * result + (policies != null ? policies.hashCode() : 0);
    result = 31 * result + (type != null ? type.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "RoleResponse{" + "uuid='" + uuid + '\'' + ", companyId='"
        + companyId + '\'' + ", name='" + name + '\'' + ", description='"
        + description + '\'' + ", policies=" + policies + ", type=" + type
        + '}';
  }

}
