/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vdi;

import java.util.List;

import com.iland.core.web.rest.response.common.ListResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VDI Deployment List Response.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public class VdiAutomationDeploymentListResponse
    extends ListResponse<VdiAutomationDeploymentResponse> {

  public VdiAutomationDeploymentListResponse(
      final List<VdiAutomationDeploymentResponse> data) {
    super(data);
  }

}
