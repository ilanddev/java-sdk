/*
 * Copyright (c) 2013 - 2023, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */
package com.iland.core.web.rest.response.vbo;

import java.util.List;
import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * O365 Copy Job Schedule Policy Response.
 *
 * @author <a href="mailto:nkasprzak@1111systems.com">Nick Kasprzak</a>
 */
@APIModel
public interface O365CopyJobSchedulePolicyResponse {

  /**
   * Backup copy job schedule type. The following types are available: Immediate.
   * The backup copy job runs right after the latest restore point appears in a
   * source backup repository. DailyAtTime. The backup copy job runs on the
   * specified days at the specified hours. Periodically. The backup copy job
   * runs repeatedly throughout a day with a specific time interval. = ['Immediate',
   * 'Periodically', 'DailyAtTime']
   */
  String type();

  /**
   * Time interval between the backup copy job runs. = ['Minutes5', 'Minutes10',
   * 'Minutes15', 'Minutes30', 'Hours1', 'Hours2', 'Hours4', 'Hours8'].
   */
  Optional<String> periodicallyEvery();

  /**
   * Days when the backup copy job will run. = ['Everyday', 'Workdays', 'Weekends',
   * 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
   */
  Optional<String> dailyType();

  /**
   * Time to start the backup copy job.
   */
  Optional<String> dailyTime();

  /**
   * Defines whether the backup copy window feature is enabled for this backup copy job.
   */
  Boolean backupCopyWindowEnabled();

  /**
   * Defines an hourly scheme for the backup copy window. The scheduling scheme
   * consists of 168 boolean elements. These elements can be logically divided
   * into 7 groups by 24. Each group represents a day of the week starting from
   * Sunday. Each element represents a backup copy hour: true - the allowed backup
   * copy hour false - the prohibited backup copy hour.
   */
  Optional<List<Boolean>> backupWindow();

  /**
   * Current minute offset from the UTC time.
   */
  Optional<Integer> minuteOffset();
}
