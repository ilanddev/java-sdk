/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscan;

import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Network Scan Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public final class NetworkScanResponse {

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int id;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String uuid;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String name;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String owner;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean enabled;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int folderId;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean read;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String status;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean shared;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int userPermissions;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private Instant creationDate;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int lastModificationDate;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean control;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String startTime;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String timezone;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String rrules;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean useDashboard;

	public NetworkScanResponse(final int id, final String uuid,
		final String name, final String owner, final boolean enabled,
		final int folderId, final boolean read, final String status,
		final boolean shared, final int userPermissions,
		final Instant creationDate, final int lastModificationDate,
		final boolean control, final String startTime, final String timezone,
		final String rrules, final boolean useDashboard) {
		this.id = id;
		this.uuid = uuid;
		this.name = name;
		this.owner = owner;
		this.enabled = enabled;
		this.folderId = folderId;
		this.read = read;
		this.status = status;
		this.shared = shared;
		this.userPermissions = userPermissions;
		this.creationDate = creationDate;
		this.lastModificationDate = lastModificationDate;
		this.control = control;
		this.startTime = startTime;
		this.timezone = timezone;
		this.rrules = rrules;
		this.useDashboard = useDashboard;
	}

	/**
	 * Get the scans ID.
	 *
	 * @return scan ID
	 */
	public int getId() {
		return id;
	}

	/**
	 * Get the scans UUID.
	 *
	 * @return {@link String} uuid
	 */
	public String getUuid() {
		return uuid;
	}

	/**
	 * Get the name of the scan.
	 *
	 * @return {@link String} scan name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Get the scan owner.
	 *
	 * @return {@link String} owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * Get whether the scan is enabled.
	 *
	 * @return enabled
	 */
	public boolean isEnabled() {
		return enabled;
	}

	/**
	 * Get the folder ID.
	 *
	 * @return folder id
	 */
	public int getFolderId() {
		return folderId;
	}

	/**
	 * Get whether scan has been read.
	 *
	 * @return read
	 */
	public boolean isRead() {
		return read;
	}

	/**
	 * Get the status of a scan.
	 *
	 * @return {@link String} scan status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Get whether the scan is shared.
	 *
	 * @return shared
	 */
	public boolean isShared() {
		return shared;
	}

	/**
	 * Get the user permissions for the scan.
	 *
	 * @return user permissions
	 */
	public int getUserPermissions() {
		return userPermissions;
	}

	/**
	 * Get the scan creation date.
	 *
	 * @return {@link Instant} creation date
	 */
	public Instant getCreationDate() {
		return creationDate;
	}

	/**
	 * Get the last modification date.
	 *
	 * @return last modification date
	 */
	public int getLastModificationDate() {
		return lastModificationDate;
	}

	/**
	 * Get the control.
	 *
	 * @return control
	 */
	public boolean isControl() {
		return control;
	}

	/**
	 * Get the start time of the scan.
	 *
	 * @return {@link String} start time
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * Get the timezone of the scan.
	 *
	 * @return {@link String} timezone
	 */
	public String getTimezone() {
		return timezone;
	}

	/**
	 * Get the schedule rules for the scan.
	 *
	 * @return {@link String} schedule for scan
	 */
	public String getRrules() {
		return rrules;
	}

	/**
	 * Whether to use the dashboard.
	 *
	 * @return use dashboard
	 */
	public boolean isUseDashboard() {
		return useDashboard;
	}

}
