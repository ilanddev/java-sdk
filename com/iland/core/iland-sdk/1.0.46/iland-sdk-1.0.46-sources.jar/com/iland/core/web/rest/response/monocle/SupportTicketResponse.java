/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.monocle;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Support Ticket Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class SupportTicketResponse implements Serializable {

  private static final long serialVersionUID = -7934359887231852308L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String id;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String summary;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String status;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String companyId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String creatorFullname;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String creatorUsername;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant creationDate;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<String> ccEmailAddresses;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean ccEmailsEnabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String regardingId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String serviceId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String categoryId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String severity;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String regardingName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String serviceName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String categoryName;

  /**
   * Instantiates a new support ticket.
   *
   * @param ticketNumber     the ticket number
   * @param summary          the summary
   * @param status           the status
   * @param companyId        the company identifier
   * @param creatorFullname  the creator full name
   * @param creatorUsername  the creator user name
   * @param creationDate     the creation date
   * @param ccEmailAddresses the cc email addresses
   * @param ccEmailsEnabled  the cc emails enabled
   * @param regardingId      the regarding option id
   * @param serviceId        the service option id
   * @param categoryId       the category option id
   * @param severity         the severity
   * @param regardingName    the regarding option name
   * @param serviceName      the service option name
   * @param categoryName     the category option name
   */
  public SupportTicketResponse(final String ticketNumber, final String summary,
      final String status, final String companyId, final String creatorFullname,
      final String creatorUsername, final Instant creationDate,
      final List<String> ccEmailAddresses, final boolean ccEmailsEnabled,
      final String regardingId, final String serviceId, final String categoryId,
      final String severity, final String regardingName,
      final String serviceName, final String categoryName) {
    this.id = ticketNumber;
    this.companyId = companyId;
    this.summary = summary;
    this.status = status;
    this.creatorFullname = creatorFullname;
    this.creatorUsername = creatorUsername;
    this.creationDate = creationDate;
    this.ccEmailAddresses = ccEmailAddresses;
    this.ccEmailsEnabled = ccEmailsEnabled;
    this.regardingId = regardingId;
    this.serviceId = serviceId;
    this.categoryId = categoryId;
    this.severity = severity;
    this.regardingName = regardingName;
    this.serviceName = serviceName;
    this.categoryName = categoryName;
  }

  /**
   * Gets the ticket number.
   *
   * @return the ticket number
   */
  public String getId() {
    return id;
  }

  /**
   * Gets the summary.
   *
   * @return the summary
   */
  public String getSummary() {
    return summary;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Gets the company identifier.
   *
   * @return the company identifier
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * Gets the creator full name.
   *
   * @return the creator full name
   */
  public String getCreatorFullname() {
    return creatorFullname;
  }

  /**
   * Gets the creator user name.
   *
   * @return the creator user name
   */
  public String getCreatorUsername() {
    return creatorUsername;
  }

  /**
   * Gets the creation date.
   *
   * @return the creation date
   */
  public Instant getCreationDate() {
    return creationDate;
  }

  /**
   * Gets the cc email addresses.
   *
   * @return the cc email addresses
   */
  public List<String> getCcEmailAddresses() {
    return ccEmailAddresses;
  }

  /**
   * Checks if is cc emails enabled.
   *
   * @return true, if is cc emails enabled
   */
  public boolean isCcEmailsEnabled() {
    return ccEmailsEnabled;
  }

  /**
   * Gets the regarding option id.
   *
   * @return {@link Integer} regarding option id
   */
  public String getRegardingId() {
    return regardingId;
  }

  /**
   * Gets the service option id.
   *
   * @return {@link Integer} service option id
   */
  public String getServiceId() {
    return serviceId;
  }

  /**
   * Get the support category id.
   *
   * @return {@link Integer} category option id
   */
  public String getCategoryId() {
    return categoryId;
  }

  /**
   * Gets the severity.
   *
   * @return {@link SeverityResponse} severity
   */
  public String getSeverity() {
    return severity;
  }

  /**
   * Gets the regarding option name.
   *
   * @return {@link String} regarding option name
   */
  public String getRegardingName() {
    return regardingName;
  }

  /**
   * Gets the service option name.
   *
   * @return {@link String} service option name
   */
  public String getServiceName() {
    return serviceName;
  }

  /**
   * Gets the category option name.
   *
   * @return {@link String} category option name
   */
  public String getCategoryName() {
    return categoryName;
  }

  @Override
  public String toString() {
    return String.format(
        "SupportTicketResponse [id=%s, summary=%s, status=%s, companyId=%s, creatorFullName=%s, creatorUserName=%s, creationDate=%s, ccEmailAddresses=%s, ccEmailsEnabled=%s]",
        id, summary, status, companyId, creatorFullname, creatorUsername,
        creationDate, ccEmailAddresses, ccEmailsEnabled);
  }

}
