/*
 * Copyright (c) 2013 - 2024, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */
package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.nsxt.ApplicationPortProfileRequest;
import com.iland.core.web.rest.response.nsx.ApplicationListResponse;
import com.iland.core.web.rest.response.nsx.ApplicationResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.shared.nsxt.ApplicationPortProfileScope;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;
import com.iland.vcloud.nsx.common.model.ApplicationPortProfileUuid;
import com.iland.vcloud.nsx.common.model.BaseVdcUuid;
import com.iland.vcloud.nsxt.vdc.VdcApplicationPortProfileApi;

/**
 * Resource Interface for Vdc application port profiles.
 *
 * @author <a href="mailto:smittal@11111systems.com">Cory Snyder</a>
 */
@APIProperties(name = "NSX-T Backed vDC Application Port Profiles")
@Path("/nsx-t/vdcs/portProfiles")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface NsxTApplicationPortProfileResource
    extends VdcApplicationPortProfileApi {

  /**
   * Gets the application port profiles (Services) for this VDC
   *
   * @param vdcUuid        the input vdc uuid
   * @param scope          scope of an Application Port Profile. Defaults to SYSTEM if none specified
   * @param page           the starting page (starts at 1)
   * @param pageSize       the page size of this request (max limit 100)
   * @param nameFilter     the optional fuzzy search name filter for this request
   * @param protocolFilter the optional protocol filter for this request
   * @param portFilter     the optional port number filter for this request
   * @return the list of port profiles for this Vdc
   */
  @GET
  @Path("/{vdcUuid}/applications")
  ApplicationListResponse getApplicationPortProfiles(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
      BaseVdcUuid vdcUuid,
      @QueryParam("scope") ApplicationPortProfileScope scope,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("nameFilter") String nameFilter,
      @QueryParam("protocolFilter") String protocolFilter,
      @QueryParam("portFilter") String portFilter);

  /**
   * Gets the application port profile for the given vcloud uuid
   *
   * @param uuid the input vcloud port profile uuid
   * @return the list of port profiles for this Vdc
   */
  @GET
  @Path("/{vdcUuid}/{uuid}")
  ApplicationResponse getApplicationPortProfile(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
      BaseVdcUuid vdcUuid,
      @PathParam("uuid") ApplicationPortProfileUuid uuid);

  /**
   * Create an application port profiles (Service) for this VDC
   *
   * @param vdcUuid the input vdc platform uuid
   * @param request the create request
   * @return the task response to track the status of create
   */
  @POST
  @Path("/{vdcUuid}/create-port-profile")
  TaskResponse createApplicationPortProfile(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") BaseVdcUuid vdcUuid,
      final ApplicationPortProfileRequest request);

  /**
   * Update an application port profiles (Service) for this VDC
   *
   * @param vdcUuid the input vdc platform uuid
   * @return the task response to track the status of update
   */
  @PUT
  @Path("/{vdcUuid}/modify-port-profile")
  TaskResponse updateApplicationPortProfiles(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") BaseVdcUuid vdcUuid,
      final ApplicationPortProfileRequest request);

  /**
   * Delete an application port profiles (Service) for this VDC
   *
   * @param uuid the input application port profile vdc uuid
   * @return the task response to track the status of update
   */
  @DELETE
  @Path("/{vdcUuid}/{uuid}")
  TaskResponse deleteApplicationPortProfile(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") BaseVdcUuid vdcUuid,
      @PathParam("uuid") ApplicationPortProfileUuid uuid);

  /**
   * Application Port profiles can be owned by a vDC only (currently).
   * Use TaskResponse#other_attributes with this key on a port profile
   * create or update Task to retrieve the owner entity UUID.
   *
   * @return the TaskResponse other_attributes key
   */
  @GET
  @Path("grouping-objects/taskOwnerEntityKey")
  String getTaskOwnerEntityKey();
}