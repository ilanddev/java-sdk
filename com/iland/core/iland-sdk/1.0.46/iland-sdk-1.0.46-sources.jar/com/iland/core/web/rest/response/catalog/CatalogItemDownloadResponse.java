/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.catalog;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.media.MediaResponse;
import com.iland.core.web.rest.response.vapptemplate.VappTemplateResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;


/**
 * CatalogItemDownloadResponse.
 *
 * @author <a href="mailto:aquinones@iland.com">Ari Quinones</a>
 */
@APIDoc
public class CatalogItemDownloadResponse implements Serializable {

  private static final long serialVersionUID = -2953360204558358100L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String catalogUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Date timeStamp;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String itemUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String itemType;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String username;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private MediaResponse media;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private VappTemplateResponse vappTemplate;

  public CatalogItemDownloadResponse(final String catalogUuid,
      final Date timeStamp, final String itemUuid, final String itemType,
      final String username, final MediaResponse media,
      final VappTemplateResponse vappTemplate) {
    this.catalogUuid = catalogUuid;
    this.timeStamp = timeStamp;
    this.itemUuid = itemUuid;
    this.itemType = itemType;
    this.username = username;
    this.media = media;
    this.vappTemplate = vappTemplate;
  }

  /**
   * Gets the Catalog Item's catalog uuid
   *
   * @return {@link String} catalogUuid
   */
  public String getCatalogUuid() {
    return catalogUuid;
  }

  /**
   * Gets the timestamp of the catalog item
   *
   * @return {@link Date} timestamp
   */
  public Date getTimeStamp() {
    return timeStamp;
  }

  /**
   * Get the catalog items uuid
   *
   * @return {@link String} item's uuid
   */
  public String getItemUuid() {
    return itemUuid;
  }

  /**
   * Get the catalog item's type
   *
   * @return {@link String} catalog item's type
   */
  public String getItemType() {
    return itemType;
  }

  /**
   * Get the username of the catalog item
   *
   * @return {@link String} username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Get the media response of the catalog item
   *
   * @return {@link MediaResponse} media response
   */
  public MediaResponse getMedia() {
    return media;
  }

  /**
   * Get the vapp template response of the catalog item
   *
   * @return {@link VappTemplateResponse} vapp template response
   */
  public VappTemplateResponse getVappTemplate() {
    return vappTemplate;
  }

  @Override
  public boolean equals(Object object) {
    if (this == object)
      return true;
    if (object == null || getClass() != object.getClass())
      return false;
    if (!super.equals(object))
      return false;
    CatalogItemDownloadResponse that = (CatalogItemDownloadResponse) object;
    if (getCatalogUuid() != null ?
        !getCatalogUuid().equals(that.getCatalogUuid()) :
        that.getCatalogUuid() != null)
      return false;
    if (getTimeStamp() != null ?
        !getTimeStamp().equals(that.getTimeStamp()) :
        that.getTimeStamp() != null)
      return false;
    if (getItemUuid() != null ?
        !getItemUuid().equals(that.getItemUuid()) :
        that.getItemUuid() != null)
      return false;
    if (getItemType() != null ?
        !getItemType().equals(that.getItemType()) :
        that.getItemType() != null)
      return false;
    if (getUsername() != null ?
        !getUsername().equals(that.getUsername()) :
        that.getUsername() != null)
      return false;
    if (getMedia() != null ?
        !getMedia().equals(that.getMedia()) :
        that.getMedia() != null)
      return false;
    if (getVappTemplate() != null ?
        !getVappTemplate().equals(that.getVappTemplate()) :
        that.getVappTemplate() != null)
      return false;
    return true;
  }

  @Override
  public int hashCode() {
    int result = super.hashCode();
    result = 31 * result + (getCatalogUuid() != null ?
        getCatalogUuid().hashCode() :
        0);
    result =
        31 * result + (getTimeStamp() != null ? getTimeStamp().hashCode() : 0);
    result =
        31 * result + (getItemUuid() != null ? getItemUuid().hashCode() : 0);
    result =
        31 * result + (getItemType() != null ? getItemType().hashCode() : 0);
    result =
        31 * result + (getUsername() != null ? getUsername().hashCode() : 0);
    result = 31 * result + (getMedia() != null ? getMedia().hashCode() : 0);
    result = 31 * result + (getVappTemplate() != null ?
        getVappTemplate().hashCode() :
        0);
    return result;
  }

  @Override
  public String toString() {
    return "CatalogItemDownloadItemResponse{" + "catalogUuid='" + catalogUuid
        + '\'' + ", timeStamp=" + timeStamp + ", itemUuid='" + itemUuid + '\''
        + ", itemType='" + itemType + '\'' + ", username='" + username + '\''
        + ", media=" + media + ", vappTemplate=" + vappTemplate + '}';
  }
}
