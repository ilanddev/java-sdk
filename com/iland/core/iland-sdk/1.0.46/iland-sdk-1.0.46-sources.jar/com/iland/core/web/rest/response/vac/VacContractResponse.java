/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vac;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VAC Contract Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public final class VacContractResponse implements Serializable {

  private static final long serialVersionUID = 3419836003823129998L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String status;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Date start;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Date end;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int term;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Date lastMod;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Date created;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Date activated;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Date cancellationDate;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String statusCode;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String group;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean testDrive;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double discount;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<SalesforceSubscriptionResponse> subscriptions;

  /**
   * Instantiates a new Vac contract response.
   *
   * @param uuid             the uuid
   * @param status           the status
   * @param start            the start
   * @param end              the end
   * @param term             the term
   * @param lastMod          the last mod
   * @param created          the created
   * @param activated        the activated
   * @param cancellationDate the cancellation date
   * @param statusCode       the status code
   * @param group            the group
   * @param testDrive        the test drive
   * @param discount         the discount
   * @param subscriptions    the subscriptions
   */
  public VacContractResponse(final String uuid, final String status,
      final Date start, final Date end, final int term, final Date lastMod,
      final Date created, final Date activated, final Date cancellationDate,
      final String statusCode, final String group, final boolean testDrive,
      final double discount,
      final List<SalesforceSubscriptionResponse> subscriptions) {
    this.uuid = uuid;
    this.status = status;
    this.start = start;
    this.end = end;
    this.term = term;
    this.lastMod = lastMod;
    this.created = created;
    this.activated = activated;
    this.cancellationDate = cancellationDate;
    this.statusCode = statusCode;
    this.group = group;
    this.testDrive = testDrive;
    this.discount = discount;
    this.subscriptions = subscriptions;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Gets start.
   *
   * @return the start
   */
  public Date getStart() {
    return start;
  }

  /**
   * Gets end.
   *
   * @return the end
   */
  public Date getEnd() {
    return end;
  }

  /**
   * Gets term.
   *
   * @return the term
   */
  public int getTerm() {
    return term;
  }

  /**
   * Gets last mod.
   *
   * @return the last mod
   */
  public Date getLastMod() {
    return lastMod;
  }

  /**
   * Gets created.
   *
   * @return the created
   */
  public Date getCreated() {
    return created;
  }

  /**
   * Gets activated.
   *
   * @return the activated
   */
  public Date getActivated() {
    return activated;
  }

  /**
   * Gets cancellation date.
   *
   * @return the cancellation date
   */
  public Date getCancellationDate() {
    return cancellationDate;
  }

  /**
   * Gets status code.
   *
   * @return the status code
   */
  public String getStatusCode() {
    return statusCode;
  }

  /**
   * Gets group.
   *
   * @return the group
   */
  public String getGroup() {
    return group;
  }

  /**
   * Is test drive boolean.
   *
   * @return the boolean
   */
  public boolean isTestDrive() {
    return testDrive;
  }

  /**
   * Gets discount.
   *
   * @return the discount
   */
  public double getDiscount() {
    return discount;
  }

  /**
   * Gets subscriptions.
   *
   * @return the subscriptions
   */
  public List<SalesforceSubscriptionResponse> getSubscriptions() {
    return subscriptions;
  }

  /**
   * The type Salesforce subscription response.
   */
  @APIDoc
public static class SalesforceSubscriptionResponse {

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private String uuid;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private String contract;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private String currencyCode;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private String name;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private String contractNumber;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private double consoleTotalMonthlyCost;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private String productId;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private double consoleCostPerUnit;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private double quantity;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private String accountId;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private String productName;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private Date deploymentDate;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private String product;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private String productCode;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private Date cancellationDate;

    /**
     * Instantiates a new Salesforce subscription response.
     *
     * @param uuid                    the uuid
     * @param contract                the contract
     * @param currencyCode            the currency code
     * @param name                    the name
     * @param contractNumber          the contract number
     * @param consoleTotalMonthlyCost the console total monthly cost
     * @param productId               the product id
     * @param consoleCostPerUnit      the console cost per unit
     * @param quantity                the quantity
     * @param accountId               the account id
     * @param productName             the product name
     * @param deploymentDate          the deployment date
     * @param product                 the product
     * @param productCode             the product code
     * @param cancellationDate        the cancellation date
     */
    public SalesforceSubscriptionResponse(final String uuid,
        final String contract, final String currencyCode, final String name,
        final String contractNumber, final double consoleTotalMonthlyCost,
        final String productId, final double consoleCostPerUnit,
        final double quantity, final String accountId, final String productName,
        final Date deploymentDate, final String product,
        final String productCode, final Date cancellationDate) {
      this.uuid = uuid;
      this.contract = contract;
      this.currencyCode = currencyCode;
      this.name = name;
      this.contractNumber = contractNumber;
      this.consoleTotalMonthlyCost = consoleTotalMonthlyCost;
      this.productId = productId;
      this.consoleCostPerUnit = consoleCostPerUnit;
      this.quantity = quantity;
      this.accountId = accountId;
      this.productName = productName;
      this.deploymentDate = deploymentDate;
      this.product = product;
      this.productCode = productCode;
      this.cancellationDate = cancellationDate;
    }

    /**
     * Gets uuid.
     *
     * @return the uuid
     */
    public String getUuid() {
      return uuid;
    }

    /**
     * Gets contract.
     *
     * @return the contract
     */
    public String getContract() {
      return contract;
    }

    /**
     * Gets currency code.
     *
     * @return the currency code
     */
    public String getCurrencyCode() {
      return currencyCode;
    }

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
      return name;
    }

    /**
     * Gets contract number.
     *
     * @return the contract number
     */
    public String getContractNumber() {
      return contractNumber;
    }

    /**
     * Gets console total monthly cost.
     *
     * @return the console total monthly cost
     */
    public double getConsoleTotalMonthlyCost() {
      return consoleTotalMonthlyCost;
    }

    /**
     * Gets product id.
     *
     * @return the product id
     */
    public String getProductId() {
      return productId;
    }

    /**
     * Gets console cost per unit.
     *
     * @return the console cost per unit
     */
    public double getConsoleCostPerUnit() {
      return consoleCostPerUnit;
    }

    /**
     * Gets quantity.
     *
     * @return the quantity
     */
    public double getQuantity() {
      return quantity;
    }

    /**
     * Gets account id.
     *
     * @return the account id
     */
    public String getAccountId() {
      return accountId;
    }

    /**
     * Gets product name.
     *
     * @return the product name
     */
    public String getProductName() {
      return productName;
    }

    /**
     * Gets deployment date.
     *
     * @return the deployment date
     */
    public Date getDeploymentDate() {
      return deploymentDate;
    }

    /**
     * Gets product.
     *
     * @return the product
     */
    public String getProduct() {
      return product;
    }

    /**
     * Gets product code.
     *
     * @return the product code
     */
    public String getProductCode() {
      return productCode;
    }

    /**
     * Gets cancellation date.
     *
     * @return the cancellation date
     */
    public Date getCancellationDate() {
      return cancellationDate;
    }
  }
}


