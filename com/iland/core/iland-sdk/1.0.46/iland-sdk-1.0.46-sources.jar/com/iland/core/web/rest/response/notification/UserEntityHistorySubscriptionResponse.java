/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.notification;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.model.EntityType;
import com.iland.core.web.rest.response.common.EntityTypeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Entity History Subscription Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserEntityHistorySubscriptionResponse implements Serializable {

  private static final long serialVersionUID = 4343683463286784939L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private EntityTypeResponse entityType;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String entityUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String username;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String email;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private FrequencyResponse frequency;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean enabled;

  public UserEntityHistorySubscriptionResponse(final EntityTypeResponse entityType,
      final String entityUuid, final String username, final String email,
      final FrequencyResponse frequency, final boolean enabled) {
    this.entityType = entityType;
    this.entityUuid = entityUuid;
    this.username = username;
    this.email = email;
    this.frequency = frequency;
    this.enabled = enabled;
  }

  /**
   * Gets entity uuid.
   *
   * @return entity uuid
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Gets username.
   *
   * @return username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Gets email.
   *
   * @return email address
   */
  public String getEmail() {
    return email;
  }

  /**
   * Gets the subscription frequency.
   *
   * @return the subscription frequency (currently only 'weekly' is supported
   */
  public FrequencyResponse getFrequency() {
    return frequency;
  }

  /**
   * Is enabled.
   *
   * @return is enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Gets the entity type.
   *
   * @return {@link EntityType} the entity type
   */
  public EntityTypeResponse getEntityType() {
    return entityType;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserEntityHistorySubscriptionResponse that =
        (UserEntityHistorySubscriptionResponse) o;

    if (enabled != that.enabled)
      return false;
    if (entityType != that.entityType)
      return false;
    if (entityUuid != null ?
        !entityUuid.equals(that.entityUuid) :
        that.entityUuid != null)
      return false;
    if (username != null ?
        !username.equals(that.username) :
        that.username != null)
      return false;
    if (email != null ? !email.equals(that.email) : that.email != null)
      return false;
    return frequency != null ?
        frequency.equals(that.frequency) :
        that.frequency == null;
  }

  @Override
  public int hashCode() {
    int result = entityType != null ? entityType.hashCode() : 0;
    result = 31 * result + (entityUuid != null ? entityUuid.hashCode() : 0);
    result = 31 * result + (username != null ? username.hashCode() : 0);
    result = 31 * result + (email != null ? email.hashCode() : 0);
    result = 31 * result + (frequency != null ? frequency.hashCode() : 0);
    result = 31 * result + (enabled ? 1 : 0);
    return result;
  }

  @Override
  public String toString() {
    return "UserEntityHistorySubscriptionResponse{" + "entityType=" + entityType
        + ", entityUuid='" + entityUuid + '\'' + ", username='" + username
        + '\'' + ", email='" + email + '\'' + ", frequency='" + frequency + '\''
        + ", enabled=" + enabled + '}';
  }

}
