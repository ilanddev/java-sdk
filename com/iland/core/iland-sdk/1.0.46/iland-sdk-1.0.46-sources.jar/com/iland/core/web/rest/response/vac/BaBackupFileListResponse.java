/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vac;

import java.util.List;

import com.iland.core.web.rest.response.common.PagedListResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VAC Backup File List Response.
 *
 * @author <a href="mailto:nkasprza@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class BaBackupFileListResponse
    extends PagedListResponse<BaBackupFileResponse, BaBackupFileFilterParams> {

  private static final long serialVersionUID = 8937264426414880531L;

  /**
   * Instantiates a new Paged list response.
   *
   * @param data                  the data
   * @param currentPageParameters the current query parameters
   * @param nextPageParameters    next page parameters
   * @param totalRecords          the total records
   */
  public BaBackupFileListResponse(final List<BaBackupFileResponse> data,
      final BaBackupFileFilterParams currentPageParameters,
      final BaBackupFileFilterParams nextPageParameters,
      final long totalRecords) {
    super(data, currentPageParameters, nextPageParameters, totalRecords);
  }
}
