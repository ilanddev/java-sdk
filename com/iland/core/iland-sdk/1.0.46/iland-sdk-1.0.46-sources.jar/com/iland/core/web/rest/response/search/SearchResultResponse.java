/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.search;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Search Result Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class SearchResultResponse implements Serializable {

  private static final long serialVersionUID = -6839216299682693390L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String query;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int pageOffset;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int pageSize;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int returnedHits;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int totalHits;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<Map<String, String>> results;

  public SearchResultResponse(final String query, final int pageOffset,
      final int pageSize, final int returnedHits, final int totalHits,
      final List<Map<String, String>> results) {
    this.query = query;
    this.pageOffset = pageOffset;
    this.pageSize = pageSize;
    this.returnedHits = returnedHits;
    this.totalHits = totalHits;
    this.results = results;
  }

  /**
   * Get the query string for the search.
   *
   * @return {@link String} query string
   * @requiredField
   */
  public String getQuery() {
    return query;
  }

  /**
   * Get the number of hits returned.
   *
   * @return number of hits returned
   * @requiredField
   */
  public int getReturnedHits() {
    return returnedHits;
  }

  /**
   * A list of search results as a map of properties in the returned document.
   *
   * @return search results list
   * @requiredField
   */
  public List<Map<String, String>> getResults() {
    return results;
  }

  /**
   * Get the total number of hits from query.
   *
   * @return total hits
   * @requiredField
   */
  public int getTotalHits() {
    return totalHits;
  }

  /**
   * Return the top scoring search result.
   *
   * @return top search result
   * @exclude
   */
  public Map<String, String> getTopResult() {
    if (results.size() > 0) {
      return results.get(0);
    } else {
      return new HashMap<>();
    }
  }

  /**
   * Get the page Offset of search results.
   *
   * @return the page offset
   * @requiredField
   */
  public int getPageOffset() {
    return pageOffset;
  }

  /**
   * Get the page size of search results.
   *
   * @return the page size
   * @requiredField
   */
  public int getPageSize() {
    return pageSize;
  }

}
