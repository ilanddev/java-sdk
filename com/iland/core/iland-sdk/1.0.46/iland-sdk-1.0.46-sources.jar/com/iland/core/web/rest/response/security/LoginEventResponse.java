/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.security;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Login Event Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class LoginEventResponse implements Serializable {

  private static final long serialVersionUID = -8961444678681848883L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String username;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long time;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String ipAddress;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String clientName;

  public LoginEventResponse(final String username, final String type,
      final long time, final String ipAddress, final String clientName) {
    this.username = username;
    this.type = type;
    this.time = time;
    this.ipAddress = ipAddress;
    this.clientName = clientName;
  }

  /**
   * Gets the username.
   *
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Gets the time.
   *
   * @return the time
   */
  public long getTime() {
    return time;
  }

  /**
   * Get the ip address.
   *
   * @return user's ip address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Get the client name.
   *
   * @return {@link String} client name
   */
  public String getClientName() {
    return clientName;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final LoginEventResponse that = (LoginEventResponse) o;

    if (time != that.time)
      return false;
    if (username != null ?
        !username.equals(that.username) :
        that.username != null)
      return false;
    if (type != null ? !type.equals(that.type) : that.type != null)
      return false;
    if (ipAddress != null ?
        !ipAddress.equals(that.ipAddress) :
        that.ipAddress != null)
      return false;
    return clientName != null ?
        clientName.equals(that.clientName) :
        that.clientName == null;
  }

  @Override
  public int hashCode() {
    int result = username != null ? username.hashCode() : 0;
    result = 31 * result + (type != null ? type.hashCode() : 0);
    result = 31 * result + (int) (time ^ (time >>> 32));
    result = 31 * result + (ipAddress != null ? ipAddress.hashCode() : 0);
    result = 31 * result + (clientName != null ? clientName.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "LoginEventResponse{" + "username='" + username + '\'' + ", type='"
        + type + '\'' + ", time=" + time + ", ipAddress='" + ipAddress + '\''
        + ", clientName='" + clientName + '\'' + '}';
  }

}
