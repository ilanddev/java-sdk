/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.util.Set;

import com.iland.core.web.rest.response.common.SetResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Office 365 User Set Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class O365UserSetResponse extends SetResponse<O365UserResponse> {

  private static final long serialVersionUID = 5792998806622931510L;

  public O365UserSetResponse(final Set<O365UserResponse> data) {
    super(data);
  }
}
