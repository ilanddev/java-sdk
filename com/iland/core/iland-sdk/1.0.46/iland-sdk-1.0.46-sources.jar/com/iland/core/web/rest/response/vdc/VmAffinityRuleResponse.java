/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vdc;

import java.io.Serializable;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.org.AffinityRuleType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vdc Vm Affinity Rule Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class VmAffinityRuleResponse implements Serializable {

  private static final long serialVersionUID = 3203559945528761732L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<String> vmUuids;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean enabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final AffinityRuleType type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional(
      """
      You can make an affinity rule mandatory to provide a hint to the system that the deployment should fail
      unless the specified placement objective can be achieved. When a virtual machine is the subject of a
      mandatory affinity rule, placement requirements dictated by the rule override any placement changes that
      might be initiated by vSphere services such as High Availability and Storage DRS.\
      """)
  private final boolean isMandatory;

  public VmAffinityRuleResponse(final Set<String> vmUuids,
      final boolean enabled, final String name, final String uuid,
      final AffinityRuleType type, final boolean isMandatory) {
    this.vmUuids = vmUuids;
    this.enabled = enabled;
    this.name = name;
    this.uuid = uuid;
    this.type = type;
    this.isMandatory = isMandatory;
  }

  /**
   * Get the list of {@link String} vm uuids for the affinity rule.
   *
   * @return {@link Set} of {@link String} vm uuids
   */
  public Set<String> getVmUuids() {
    return vmUuids;
  }

  /**
   * Whether the rule is enabled.
   *
   * @return enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Get the rule name.
   *
   * @return {@link String} name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the rule uuid.
   *
   * @return {@link String} rule uuid
   */
  public String getUUID() {
    return uuid;
  }

  /**
   * Get the rule type.
   * <p>
   * Can be one of 'affinity' or 'anti-affinity'
   *
   * @return {@link AffinityRuleType} rule type
   */
  public AffinityRuleType getType() {
    return type;
  }

  /**
   * Is the rule mandatory.
   * <p>
   * You can make an affinity rule mandatory to provide a hint to the system that the deployment should fail
   * unless the specified placement objective can be achieved. When a virtual machine is the subject of a
   * mandatory affinity rule, placement requirements dictated by the rule override any placement changes that
   * might be initiated by vSphere services such as High Availability and Storage DRS.
   * <p/>
   *
   * @return is mandatory
   */
  public boolean isMandatory() {
    return isMandatory;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final VmAffinityRuleResponse that = (VmAffinityRuleResponse) o;
    return uuid != null ? uuid.equals(that.uuid) : super.equals(o);
  }

  @Override
  public int hashCode() {
    return getUUID() != null ? getUUID().hashCode() : super.hashCode();
  }

}