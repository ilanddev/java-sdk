/*
 * Copyright (c) 2013,2014 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 800 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */
package com.iland.core.web.rest.api;

import java.io.InputStream;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.vpg.FailoverCreateRequest;
import com.iland.core.web.rest.request.vpg.FailoverTestAlertCreateRequest;
import com.iland.core.web.rest.request.vpg.FailoverTestCreateRequest;
import com.iland.core.web.rest.request.vpg.FailoverTestStopCreateRequest;
import com.iland.core.web.rest.request.vpg.VpgSubEntityRequest;
import com.iland.core.web.rest.response.performance.PerfSampleSerieResponse;
import com.iland.core.web.rest.response.performance.PerformanceCounterListResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vpg.ExpandedVpgResponse;
import com.iland.core.web.rest.response.vpg.FailoverReportDetailsResponse;
import com.iland.core.web.rest.response.vpg.FailoverTestAlertResponse;
import com.iland.core.web.rest.response.vpg.ServiceProfileResponse;
import com.iland.core.web.rest.response.vpg.VpgCheckpointListResponse;
import com.iland.core.web.rest.response.vpg.VpgVmListResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Vpg Resource interface.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Disaster Recovery")
@Path("/vpgs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface VpgResource {

  /**
   * Retrieve the VPG Failover Test Alert for the given VPG.
   *
   * @param vpgUuid vpg uuid
   * @return zerto failover test alert
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @GET
  @Path("/{vpgUuid}/failover-test-alerts")
  FailoverTestAlertResponse getVpgFailoverTestAlertFor(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VPG) @PathParam("vpgUuid")
          String vpgUuid);

  /**
   * Add a VPG Failover Test Alert for the given VPG.
   *
   * @param vpgUuid vpg uuid
   * @param alert   zerto failover test alert
   * @return zerto failover test alert
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @POST
  @Path("/{vpgUuid}/actions/add-failover-test-alert")
  @Consumes(MediaType.APPLICATION_JSON)
  FailoverTestAlertResponse addVpgFailoverTestAlert(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VPG_CONFIGURATION)
      @PathParam("vpgUuid") String vpgUuid,
      FailoverTestAlertCreateRequest alert);

  /**
   * Remove the VPG Failover Test Alert for the given VPG.
   *
   * @param vpgUuid vpg uuid
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @DELETE
  @Path("/{vpgUuid}/actions/remove-failover-test-alert")
  void removeVpgFailoverTestAlert(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VPG_CONFIGURATION)
      @PathParam("vpgUuid") String vpgUuid);

  /**
   * Returns VPG performance samples given a performance serie information.
   *
   * @param vpgUuid the VPG unique identifier.
   * @param group   performance counter group name
   * @param name    performance counter name
   * @param type    performance counter type
   * @param start   start date
   * @param end     end date
   * @return a performance serie for the vpg, counter and time range
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @GET
  @Path("/{vpgUuid}/performance/{group}::{name}::{type}")
  PerfSampleSerieResponse getPerformanceForVpg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VPG) @PathParam("vpgUuid")
          String vpgUuid, @PathParam("group") String group,
      @PathParam("name") String name, @PathParam("type") String type,
      @QueryParam("start") Long start, @QueryParam("end") Long end);

  /**
   * Test failover for a VPG.
   *
   * @param vpgUuid the VPG unique identifier
   * @param params  the failover test parameters
   * @return asynchronous task details
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @POST
  @Path("/{vpgUuid}/actions/failover-test")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse failoverTestForVpg(
      @SecureEntityRef(Permission.INITIATE_ILAND_CLOUD_VPG_TEST_FAILOVER)
      @PathParam("vpgUuid") String vpgUuid, FailoverTestCreateRequest params);

  /**
   * Stop a VPG failover test and provide feedback as to whether the test was
   * successful.
   *
   * @param vpgUuid the UUID of the VPG.
   * @param params  the failover test stop parameters
   * @return asynchronous task details
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @POST
  @Path("/{vpgUuid}/actions/failover-test-stop")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse failoverTestStop(
      @SecureEntityRef(Permission.INITIATE_ILAND_CLOUD_VPG_TEST_FAILOVER)
      @PathParam("vpgUuid") String vpgUuid,
      FailoverTestStopCreateRequest params);

  /**
   * Gets a VPG by UUID, with options to expand child entites.
   *
   * @param vpgUuid the UUID of the VPG.
   * @return the VPG
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @GET
  @Path("/{vpgUuid}")
  ExpandedVpgResponse getVpg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VPG) @PathParam("vpgUuid")
          String vpgUuid,
      @QueryParam("expand") List<VpgSubEntityRequest> expand);

  /**
   * Gets the VMs that belong to a VPG.
   *
   * @param vpgUuid the UUID of the VPG
   * @return the list of VPG VMs
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @GET
  @Path("/{vpgUuid}/vms")
  VpgVmListResponse getVmsForVpg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VPG) @PathParam("vpgUuid")
          String vpgUuid);

  /**
   * Gets the service profile for a VPG.
   *
   * @param vpgUuid the UUID of the VPG
   * @return the service profile information for the VPG
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @GET
  @Path("/{vpgUuid}/service-profile")
  ServiceProfileResponse getServiceProfile(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VPG) @PathParam("vpgUuid")
          String vpgUuid);

  /**
   * Initiates a live failover on the VPG.
   *
   * @param vpgUuid the UUID of the VPG
   * @param params  the failover parameters
   * @return asynchronous task details
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @POST
  @Path("/{vpgUuid}/actions/failover")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse failover(
      @SecureEntityRef(Permission.INITIATE_ILAND_CLOUD_VPG_LIVE_FAILOVER)
      @PathParam("vpgUuid") String vpgUuid, FailoverCreateRequest params);

  /**
   * Commits changes after a live failover.
   *
   * @param vpgUuid the UUID of the VPG
   * @return asynchronous task details
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @POST
  @Path("/{vpgUuid}/actions/failover-commit")
  TaskResponse commitFailover(
      @SecureEntityRef(Permission.INITIATE_ILAND_CLOUD_VPG_LIVE_FAILOVER)
      @PathParam("vpgUuid") String vpgUuid);

  /**
   * Rolls back changes after a live failover.
   *
   * @param vpgUuid the UUID of the VPG
   * @return asynchronous task details
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @POST
  @Path("/{vpgUuid}/actions/failover-rollback")
  TaskResponse rollbackFailover(
      @SecureEntityRef(Permission.INITIATE_ILAND_CLOUD_VPG_LIVE_FAILOVER)
      @PathParam("vpgUuid") String vpgUuid);

  /**
   * Get checkpoints for a VPG.
   *
   * @param vpgUuid the UUID of the VPG
   * @return list of checkpoints
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @GET
  @Path("/{vpgUuid}/checkpoints")
  VpgCheckpointListResponse getCheckpoints(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VPG) @PathParam("vpgUuid")
          String vpgUuid);

  /**
   * Gets failover report details for a failover task.
   *
   * @param taskUuid the uuid of the task to retrieve the report for
   * @return failover report details
   */
  @SkipSecurityTest("Security logic in EJB.")
  @GET
  @Path("/{vpgUuid}/failover-task-details/{taskUuid}")
  FailoverReportDetailsResponse getFailoverTaskDetails(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VPG) @PathParam("vpgUuid")
          String vpgUuid, @PathParam("taskUuid") String taskUuid);

  /**
   * Gets a failover report for a task.
   * <p>
   * The UUID of the task for the failover operation is the report UUID.
   *
   * @param reportUuid the UUID of the task to retrieve the report for
   * @return failover report
   */
  @SkipSecurityTest("Security logic in EJB")
  @GET
  @Path("/{vpgUuid}/failover-reports/{reportUuid}")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_PDF)
  InputStream downloadFailoverReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VPG) @PathParam("vpgUuid")
          String vpgUuid, @PathParam("reportUuid") String reportUuid,
      @QueryParam("filename") String filename);

  /**
   * Get the list of performance counters that can be used to query for VPG
   * performance data.
   *
   * @param vpgUuid vpg uuid
   * @return the list of performance counters
   */
  @GET
  @Path("/{vpgUuid}/performance-counters")
  PerformanceCounterListResponse getPerformanceCountersForVpg(
      @PathParam("vpgUuid") String vpgUuid);

}
