/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Billing Summary Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class BillingSummaryResponse implements Serializable {

  private static final long serialVersionUID = -7771786276071622071L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private BillResponse previousMonth;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private BillResponse currentMonth;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private BillResponse previousHour;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private BillResponse currentHour;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean testDrive;

  public BillingSummaryResponse(final BillResponse previousMonth,
      final BillResponse currentMonth, final BillResponse previousHour,
      final BillResponse currentHour, final boolean testDrive) {
    this.previousMonth = previousMonth;
    this.currentMonth = currentMonth;
    this.previousHour = previousHour;
    this.currentHour = currentHour;
    this.testDrive = testDrive;
  }

  /**
   * Get the previous month's bill.
   *
   * @return {@link BillResponse} previous month bill
   */
  public BillResponse getPreviousMonth() {
    return previousMonth;
  }

  /**
   * Get the current month's bill.
   *
   * @return {@link BillResponse} current month bill
   */
  public BillResponse getCurrentMonth() {
    return currentMonth;
  }

  /**
   * Get the previous hour's bill.
   *
   * @return {@link BillResponse} previous month bill
   */
  public BillResponse getPreviousHour() {
    return previousHour;
  }

  /**
   * Get the current hour's bill.
   *
   * @return {@link BillResponse} current hour bill
   */
  public BillResponse getCurrentHour() {
    return currentHour;
  }

  /**
   * Get is test drive.
   *
   * @return is test drive
   */
  public boolean isTestDrive() {
    return testDrive;
  }

}
