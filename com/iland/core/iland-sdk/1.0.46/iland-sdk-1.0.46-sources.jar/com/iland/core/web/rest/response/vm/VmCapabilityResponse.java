/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vm Capability Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VmCapabilityResponse implements Serializable {

  private static final long serialVersionUID = 3326211553927238707L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean cpuHotAddEnabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean memoryHotAddEnabled;

  public VmCapabilityResponse(final boolean cpuHotAddEnabled,
      final boolean memoryHotAddEnabled) {
    this.cpuHotAddEnabled = cpuHotAddEnabled;
    this.memoryHotAddEnabled = memoryHotAddEnabled;
  }

  /**
   * Is cpu hot add enabled.
   *
   * @return cpu hot add enabled
   */
  public boolean isCpuHotAddEnabled() {
    return cpuHotAddEnabled;
  }

  /**
   * Is memory hot add enabled.
   *
   * @return memory hot add enabled
   */
  public boolean isMemoryHotAddEnabled() {
    return memoryHotAddEnabled;
  }

}
