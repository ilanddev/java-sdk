/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Replication Target Settings.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class ReplicationTargetSettings implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Specifies the id of the Remote Cluster.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the id of the Remote Cluster.")
  private final long clusterId;

  /**
   * Instantiates a new ReplicationTargetSettings.
   *
   * @param clusterId Specifies the id of the Remote Cluster.
   */
  public ReplicationTargetSettings(final long clusterId) {
    this.clusterId = clusterId;
  }

  /**
   * Specifies the id of the Remote Cluster.
   *
   * @return clusterId
   */
  public long getClusterId() {
    return this.clusterId;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final ReplicationTargetSettings that = (ReplicationTargetSettings) o;
    return clusterId == that.clusterId;
  }

  @Override
  public int hashCode() {
    return Objects.hash(clusterId);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("clusterId", clusterId)
        .toString();
  }
}
