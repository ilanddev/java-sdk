/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vac;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * BaCompanyBackupHistoryResponse.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public final class BaCompanyBackupHistoryResponse implements Serializable {

  private static final long serialVersionUID = -1816560766380187444L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String lastResult;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant lastActive;

  /**
   * Instantiates a new Ba company backup history response.
   *
   * @param lastResult the last result
   * @param lastActive the last active
   */
  public BaCompanyBackupHistoryResponse(final String lastResult,
      final Instant lastActive) {
    this.lastResult = lastResult;
    this.lastActive = lastActive;
  }

  /**
   * Gets last result.
   *
   * @return the last result
   */
  public String getLastResult() {
    return lastResult;
  }

  /**
   * Gets last active.
   *
   * @return the last active
   */
  public Instant getLastActive() {
    return lastActive;
  }
}
