/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.objectstorage.TenantKeyCreateRequest;
import com.iland.core.web.rest.request.objectstorage.TenantKeyDeleteRequest;
import com.iland.core.web.rest.response.common.ObjectPagingParams;
import com.iland.core.web.rest.response.objectstorage.BucketInfoListResponse;
import com.iland.core.web.rest.response.objectstorage.TenantKeyPairResponse;
import com.iland.core.web.rest.response.objectstorage.TenantKeyPairSetResponse;
import com.iland.core.web.rest.response.objectstorage.TenantResponse;
import com.iland.core.web.rest.response.objectstorage.TenantsResponse;
import com.iland.core.web.rest.response.objectstorage.UserSessionResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Object Storage Public API.
 *
 * @author <a href=“mailto:cjsnyder@iland.com”>Collin Snyder</a>
 */
@APIProperties(name = "Object Storage")
@Path("/object-storage")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface ObjectStorageResource {

  /**
   * Create an object storage user session for.
   *
   * @param tenantUuid {@link String}
   * @return {@link UserSessionResponse}
   */
  @POST
  @Path("/{tenantUuid}/actions/create-user-session")
  UserSessionResponse createObjectStorageUserSession(
      @SecureEntityRef(Permission.CREATE_ILAND_OBJECT_STORAGE_USER_SESSION)
      @PathParam("tenantUuid") String tenantUuid);

  /**
   * Renew an object storage user session.
   *
   * @param tenantUuid     tenant uuid
   * @param sessionToken session token
   * @return user session response
   */
  @POST
  @Path("/{tenantUuid}/actions/renew-user-session/{sessionToken}")
  UserSessionResponse renewUserSession(
      @SecureEntityRef(Permission.CREATE_ILAND_OBJECT_STORAGE_USER_SESSION)
      @PathParam("tenantUuid") String tenantUuid,
      @PathParam("sessionToken") String sessionToken);

  /**
   * Retrieves all Object Storage Tenants for a particular company.
   *
   * @param companyId {@link String}
   * @param filters   {@link ObjectPagingParams} object paging params
   * @return {@link TenantsResponse}
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{companyId}/{regionId}/tenants")
  TenantsResponse getAllObjectStorageTenantsForCompany(
      @PathParam("companyId") String companyId,
      @PathParam("regionId") String regionId,
      @BeanParam ObjectPagingParams filters);

  /**
   * Lists access/secret key pairs for an object storage tenant and user.
   *
   * @param tenantUuid tenant uuid
   * @param username username
   * @return tenant keys for username
   */
  @GET
  @Path("/{tenantUuid}/keys/{username}")
  TenantKeyPairSetResponse getTenantKeysForUser(
      @SecureEntityRef(Permission.VIEW_ILAND_CEPH_OBJECT_STORAGE_TENANT)
      @PathParam("tenantUuid") String tenantUuid,
      @PathParam("username") String username);

  /**
   * Create a new access/secret key pair for a tenant.
   *
   * @param tenantUuid               tenant uuid
   * @param tenantKeyCreateRequest tenant key create request
   * @return tenant key
   */
  @POST
  @Path("/{tenantUuid}/key")
  TenantKeyPairResponse createTenantKey(
      @SecureEntityRef(Permission.CREATE_ILAND_OBJECT_STORAGE_KEY)
      @PathParam("tenantUuid") String tenantUuid,
      TenantKeyCreateRequest tenantKeyCreateRequest);

  /**
   * Delete an access/secret key pair for a tenant
   *
   * @param tenantUuid               tenant uuid
   * @param tenantKeyDeleteRequest tenant key delete request
   */
  @DELETE
  @Path("/{tenantUuid}/key")
  void deleteTenantKey(
      @SecureEntityRef(Permission.DELETE_ILAND_OBJECT_STORAGE_KEY)
      @PathParam("tenantUuid") String tenantUuid,
      TenantKeyDeleteRequest tenantKeyDeleteRequest);

  /**
   * Get the list of bucket info for the given tenant.
   *
   * @param tenantUuid tenant uuid
   * @return list of bucket info
   */
  @GET
  @Path("/{tenantUuid}/bucket-info")
  BucketInfoListResponse getBucketInfoList(
      @SecureEntityRef(Permission.VIEW_ILAND_CEPH_OBJECT_STORAGE_TENANT)
      @PathParam("tenantUuid") String tenantUuid);

  /**
   * Get a tenant given it's id.
   *
   * @param tenantUuid tenant uuid
   * @return a tenant response
   */
  @GET
  @Path("/{tenantUuid}")
  TenantResponse getTenant(
      @SecureEntityRef(Permission.VIEW_ILAND_CEPH_OBJECT_STORAGE_TENANT)
      @PathParam("tenantUuid") String tenantUuid);

  /**
   * Sync the tenant.
   *
   * @param tenantUuid tenant uuid
   */
  @POST
  @Path("/{tenantUuid}/sync")
  void syncTenant(@SecureEntityRef(Permission.MANAGE_ILAND_CEPH_OBJECT_STORAGE)
  @PathParam("tenantUuid") String tenantUuid);

}
