/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.sso;

import java.util.Optional;

import org.immutables.value.Value;

import com.iland.core.api.sso.IdentityProviderType;
import com.iland.core.web.rest.annotation.APIModel;
import com.iland.core.web.rest.request.sso.SAMLNameIDPolicyFormat;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * SAML Identity Provider Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIModel
@APIDoc
public abstract class SAMLIdentityProviderResponse extends IdentityProviderResponse {

  /**
   * This is a required field and specifies the SAML endpoint to start the
   * authentication process. If your SAML IDP publishes an IDP entity descriptor,
   * the value of this field will be specified there.
   */
  public abstract String singleSignOnServiceUrl();

  /**
   * Specifies the URI reference corresponding to a name identifier format.
   * Defaults to urn:oasis:names:tc:SAML:2.0:nameid-format:persistent.
   */
  public abstract Optional<SAMLNameIDPolicyFormat> nameIdPolicyFormat();

  /**
   * Specifies which part of the SAML assertion will be used to identify and track
   * external user identities. Can be either Subject NameID or SAML attribute
   * (either by name or by friendly name).
   */
  public abstract Optional<String> principalType();

  /**
   * Way to identify and track external users from the assertion. Default is
   * using Subject NameID, alternatively you can set up identifying attribute.
   */
  public abstract Optional<String> principalAttribute();

  /**
   * If Want AuthnRequests Signed is on, then you can also pick the signature algorithm to use.
   */
  public abstract Optional<String> signatureAlgorithm();

  /**
   * Signed SAML documents contain identification of signing key in KeyName element.
   * For Keycloak / RH-SSO counterparty, use KEY_ID, for MS AD FS use CERT_SUBJECT,
   * for others check and use NONE if no other option works.
   */
  public abstract Optional<String> samlXmlKeyNameTranformer();

  /**
   * Enable if your SAML IDP supports backchannel logout.
   */
  public abstract Optional<Boolean> backchannelSupported();

  /**
   * When this realm responds to any SAML requests sent by the external IDP,
   * which SAML binding should be used? If set to off, then the Redirect Binding will be used.
   */
  public abstract Optional<Boolean> postBindingResponse();

  /**
   * When this realm requests authentication from the external SAML IDP, which
   * SAML binding should be used? If set to off, then the Redirect Binding will be used.
   */
  public abstract Optional<Boolean> postBindingAuthnRequest();

  /**
   * Indicates whether to respond to requests using HTTP-POST binding. If false,
   * HTTP-REDIRECT binding will be used.
   */
  public abstract Optional<Boolean> postBindingLogout();

  /**
   * If true, it will use the realm’s keypair to sign requests sent to the external SAML IDP.
   */
  public abstract Optional<Boolean> wantAuthnRequestsSigned();

  /**
   * If Want AuthnRequests Signed is on, then you can also pick the signature algorithm to use.
   */
  public abstract Optional<Boolean> wantAssertionsSigned();

  /**
   * Indicates whether this service provider expects an encrypted Assertion.
   */
  public abstract Optional<Boolean> wantAssertionsEncrypted();

  /**
   * Indicates that the user will be forced to enter their credentials at the
   * external IDP even if they are already logged in.
   */
  public abstract Optional<Boolean> forceAuthn();

  /**
   * Whether or not the realm should expect that SAML requests and responses
   * from the external IDP to be digitally signed. It is highly recommended you turn this on!
   */
  public abstract Optional<Boolean> validateSignature();

  /**
   * Gets clock skew in seconds that is tolerated when validating identity provider tokens. Default value is zero.
   */
  public abstract Optional<String> allowedClockSkew();

  /**
   * This is an optional field that specifies the SAML logout endpoint.
   * If your SAML IDP publishes an IDP entity descriptor, the value of this
   * field will be specified there.
   */
  public abstract Optional<String> singleLogoutServiceUrl();

  /**
   * The public certificate that will be used to validate the signatures of
   * SAML requests and responses from the external IDP.
   */
  public abstract Optional<String> signingCertificate();

  @Override
  @Value.Derived
  public IdentityProviderType type() {
    return IdentityProviderType.SAML;
  }

}
