/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.edge;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.network.SubnetParticipationResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vcd Edge Interface Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class EdgeInterfaceResponse implements Serializable {

  private static final long serialVersionUID = -5726950189745226457L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String displayName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Double inRateLimit;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Double outRateLimit;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Boolean applyRateLimit;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Boolean defaultRoute;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String network;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String networkUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Set<SubnetParticipationResponse> subnetParticipation;

  public EdgeInterfaceResponse(final String displayName, final String name,
      final Double inRateLimit, final Double outRateLimit, final String type,
      final Boolean applyRateLimit, final Boolean defaultRoute,
      final String network, final String networkUuid,
      final Set<SubnetParticipationResponse> subnetParticipation) {
    this.displayName = displayName;
    this.name = name;
    this.inRateLimit = inRateLimit;
    this.outRateLimit = outRateLimit;
    this.type = type;
    this.applyRateLimit = applyRateLimit;
    this.defaultRoute = defaultRoute;
    this.network = network;
    this.networkUuid = networkUuid;
    this.subnetParticipation = subnetParticipation;
  }

  /**
   * Get the display name for the interface.
   *
   * @return {@link String} display name
   */
  public String getDisplayName() {
    return displayName;
  }

  /**
   * Get the in rate limit.
   *
   * @return {@link Double} in rate limit
   */
  public Double getInRateLimit() {
    return inRateLimit != null && inRateLimit > 0 ? inRateLimit : null;
  }

  /**
   * Get the interface type.
   *
   * @return {@link String} interface type.
   */
  public String getType() {
    return type;
  }

  /**
   * Get the interface name.
   *
   * @return {@link String} name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the out rate limit.
   *
   * @return {@link Double} get out rate limit
   */
  public Double getOutRateLimit() {
    return outRateLimit != null && outRateLimit > 0 ? outRateLimit : null;
  }

  /**
   * Whether to apply rate limit.
   *
   * @return {@link Boolean} instance
   */
  public Boolean isApplyRateLimit() {
    return applyRateLimit;
  }

  /**
   * Whether interface is used for default route.
   *
   * @return {@link Boolean} instance
   */
  public Boolean isUseForDefaultRoute() {
    return defaultRoute;
  }

  /**
   * Gets the name of the associated network.
   *
   * @return {@link String} network name
   */
  public String getNetwork() {
    return network;
  }

  /**
   * Gets the network UUID.
   *
   * @return {@link String} network UUID
   */
  public String getNetworkUuid() {
    return this.networkUuid;
  }

  /**
   * Gets the subnet participation.
   *
   * @return {@link List} of {@link SubnetParticipationResponse}
   */
  public Set<SubnetParticipationResponse> getSubnetParticipation() {
    return subnetParticipation;
  }

}
