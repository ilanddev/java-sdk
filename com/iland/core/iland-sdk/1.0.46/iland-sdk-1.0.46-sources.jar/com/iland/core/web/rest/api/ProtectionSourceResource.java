/*
 * Copyright (c) 2023, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.api;

import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.cohesity.iaas.backups.common.model.ListResponse;
import com.iland.cohesity.iaas.backups.common.model.LocationId;
import com.iland.cohesity.iaas.backups.common.model.ProtectionSourceUid;
import com.iland.cohesity.iaas.backups.common.model.VdcUuid;
import com.iland.cohesity.iaas.backups.protectionsources.OracleProtectionSourceModel;
import com.iland.cohesity.iaas.backups.protectionsources.ProtectionSourcePlatformApi;
import com.iland.cohesity.iaas.backups.protectionsources.PublicProtectionSource;
import com.iland.cohesity.iaas.backups.protectionsources.PublicRegisterPhysicalHostRequest;
import com.iland.cohesity.iaas.backups.protectionsources.SqlProtectionSourceModel;
import com.iland.cohesity.iaas.backups.protectionsources.api.grpc.AgentType;
import com.iland.cohesity.iaas.backups.protectionsources.api.grpc.HostType;
import com.iland.cohesity.iaas.backups.protectionsources.api.grpc.PackageType;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Agent Resource V1.
 */
@APIProperties(name = "Protection Source")
@Path("/protection-sources")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface ProtectionSourceResource extends ProtectionSourcePlatformApi {

	/**
	 * Download an agent for the supplied {@link HostType}.
	 *
	 * @param hostType    the required {@link HostType}
	 * @param packageType an optional {@link PackageType}
	 * @param agentType   an optional {@link AgentType}
	 * @return the agent to be installed
	 */
	@GET
	@Path("/{locationId}/agent/{hostType}")
	@Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
	InputStream downloadAgent(@PathParam("locationId") LocationId locationId,
		@PathParam("hostType") HostType hostType,
		@QueryParam("packageType") PackageType packageType,
		@QueryParam("agentType") AgentType agentType);

	/**
	 * Get the protection sources for the given VDC.
	 *
	 * @param vdcUuid     VDC UUID
	 * @param hostType    e.g. "linux" or "windows"
	 * @param environment e.g. "*" or "sql"
	 * @return a list of protection sources
	 */
	@GET
	@Path("/{vdcUuid}/vms/{hostType: (\\*|linux|windows)}/{environment: (\\*|sql|oracle)}")
	@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
	ListResponse<PublicProtectionSource> listProtectionSourcesForVdc(
		@SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
		VdcUuid vdcUuid, @PathParam("hostType") String hostType,
		@PathParam("environment") String environment);

	/**
	 * Register a new Linux protection source.
	 *
	 * @param vdcUuid VDC UUID
	 * @param request the required {@link PublicRegisterPhysicalHostRequest request}
	 * @return the new {@link PublicProtectionSource response}
	 */
	@POST
	@Path("/{vdcUuid}/register/linux")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
	PublicProtectionSource registerLinuxProtectionSource(
		@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
		@PathParam("vdcUuid") VdcUuid vdcUuid,
		PublicRegisterPhysicalHostRequest request);

	/**
	 * Register a new Windows protection source.
	 *
	 * @param vdcUuid VDC UUID
	 * @param request the required {@link PublicRegisterPhysicalHostRequest request}
	 * @return the new {@link PublicProtectionSource response}
	 */
	@POST
	@Path("/{vdcUuid}/register/windows")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
	PublicProtectionSource registerWindowsProtectionSource(
		@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
		@PathParam("vdcUuid") VdcUuid vdcUuid,
		PublicRegisterPhysicalHostRequest request);

	/**
	 * Register a new Microsoft SQL protection source.
	 *
	 * @param vdcUuid VDC UUID
	 * @param request the required {@link PublicRegisterPhysicalHostRequest request}
	 * @return the new {@link PublicProtectionSource response}
	 */
	@POST
	@Path("/{vdcUuid}/register/sql")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
	PublicProtectionSource registerSqlProtectionSource(
		@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
		@PathParam("vdcUuid") VdcUuid vdcUuid,
		PublicRegisterPhysicalHostRequest request);

  /**
   * Register a Oracle server with an existing protection source.
   *
   * @param vdcUuid             VDC UUID
   * @param protectionSourceUid the protection source UID
   * @return the updated {@link PublicProtectionSource response}
   */
  @PUT
  @Path("/{vdcUuid}/register/oracle/{protectionSourceUid}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
  PublicProtectionSource registerOracleProtectionSource(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") VdcUuid vdcUuid, @PathParam("protectionSourceUid")
  ProtectionSourceUid protectionSourceUid);

	/**
	 * Register a Microsoft SQL server with an existing protection source.
	 *
	 * @param vdcUuid             VDC UUID
	 * @param protectionSourceUid the protection source UID
	 * @return the updated {@link PublicProtectionSource response}
	 */
	@PUT
	@Path("/{vdcUuid}/register/sql/{protectionSourceUid}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
	PublicProtectionSource registerSqlProtectionSource(
		@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
		@PathParam("vdcUuid") VdcUuid vdcUuid, @PathParam("protectionSourceUid")
	ProtectionSourceUid protectionSourceUid);

	/**
	 * Get a protection source.
	 *
	 * @param protectionSourceUid the protection source UID to retrieve
	 * @return a {@link PublicProtectionSource protection source}
	 */
	@GET
	@Path("/{protectionSourceUid}")
	@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
	PublicProtectionSource getProtectionSource(
		@SecureEntityRef(Permission.VIEW_ILAND_CLOUD_PROTECTION_SOURCE)
		@PathParam("protectionSourceUid")
		ProtectionSourceUid protectionSourceUid);

	/**
	 * Delete a protection source.
	 *
	 * @param protectionSourceUid the protection source UID to delete
	 */
	@DELETE
	@Path("/{protectionSourceUid}")
	@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
	void deleteProtectionSource(
		@SecureEntityRef(Permission.DELETE_ILAND_CLOUD_PROTECTION_SOURCE)
		@PathParam("protectionSourceUid")
		ProtectionSourceUid protectionSourceUid);

	/**
	 * Get the SQL protection sources for the given VDC.
	 *
	 * @param vdcUuid VDC UUID
	 * @return a list of SQL protection sources
	 */
	@GET
	@Path("/{vdcUuid}/sql-protection-sources")
	@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
	ListResponse<SqlProtectionSourceModel> listSqlProtectionSourcesForVdc(
		@SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
		VdcUuid vdcUuid);

	/**
	 * Get the Oracle protection sources for the given VDC.
	 *
	 * @param vdcUuid VDC UUID
	 * @return a list of Oracle protection sources
	 */
	@GET
	@Path("/{vdcUuid}/oracle-protection-sources")
	@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
	ListResponse<OracleProtectionSourceModel> listOracleProtectionSourcesForVdc(
		@SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
		VdcUuid vdcUuid);

}
