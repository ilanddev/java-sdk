/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.time;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Specifies a time in day with hours and minutes.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class TimeOfDay implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Specifies an (0-23) hour in a day.
   */
  @Expose
  @JsonRequired("Specifies an (0-23) hour in a day.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Integer hour;

  /**
   * Specifies a (0-59) minute in an hour.
   */
  @Expose
  @JsonRequired("Specifies a (0-59) minute in an hour.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Integer minute;

  /**
   * Instantiates a new TimeOfDay.
   *
   * @param hour   see {@link TimeOfDay#getHour}
   * @param minute see {@link TimeOfDay#getMinute}
   */

  public TimeOfDay(final Integer hour, final Integer minute) {
    this.hour = hour;
    this.minute = minute;
  }

  /**
   * Specifies an (0-23) hour in a day.
   *
   * @return the hour
   */
  public Integer getHour() {
    return this.hour;
  }

  /**
   * Specifies a (0-59) minute in an hour.
   *
   * @return the minute
   */
  public Integer getMinute() {
    return this.minute;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final TimeOfDay that = (TimeOfDay) o;
    return Objects.equals(hour, that.hour) && Objects
        .equals(minute, that.minute);
  }

  @Override
  public int hashCode() {
    return Objects.hash(hour, minute);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("hour", hour)
        .add("minute", minute).toString();
  }
}
