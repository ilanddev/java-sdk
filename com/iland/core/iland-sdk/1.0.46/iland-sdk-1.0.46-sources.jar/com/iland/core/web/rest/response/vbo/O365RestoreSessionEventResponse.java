/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.vbo.O365RestoreSessionEventStatus;
import com.iland.core.api.vbo.O365RestoreSessionEventType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Office 365 VBO Restore Session Event.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365RestoreSessionEventResponse
    implements Serializable, Comparable<O365RestoreSessionEventResponse> {

  private static final long serialVersionUID = -2659433011065565800L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The size of the restored item.")
  private final long itemSizeBytes;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The Veeam native ID of the restore session event.")
  private final String id;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The type of the restore session event.")
  private final O365RestoreSessionEventType type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The status of the restore session.")
  private final O365RestoreSessionEventStatus status;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The date and time when the restore session started.")
  private final Instant startTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The date and time when the restore session ended.")
  private final Instant endTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The duration of the restore session.")
  private final long duration;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired(
      "The title of the restore session event available for exploring "
          + "and restoring during the restore session.")
  private final String title;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired(
      "The order of the restore session event available for exploring "
          + "and restoring during the restore session")
  private final int order;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The user who initiated the restore session.")
  private final String initiatedBy;

  public O365RestoreSessionEventResponse(final long itemSizeBytes,
      final String id, final O365RestoreSessionEventType type,
      final O365RestoreSessionEventStatus status, final Instant startTime,
      final Instant endTime, final long duration, final String title,
      final int order, final String initiatedBy) {
    this.itemSizeBytes = itemSizeBytes;
    this.id = id;
    this.type = type;
    this.status = status;
    this.startTime = startTime;
    this.endTime = endTime;
    this.duration = duration;
    this.title = title;
    this.order = order;
    this.initiatedBy = initiatedBy;
  }

  /**
   * Returns the size of the restored item.
   *
   * @return the size of the restored item.
   */
  public long getItemSizeBytes() {
    return itemSizeBytes;
  }

  /**
   * Returns the ID of the restore session event available for
   * exploring and restoring during the restore session.
   *
   * @return a Veeam native ID
   */
  public String getId() {
    return id;
  }

  /**
   * Returns the type of the restore session event.
   *
   * @return one of {@link O365RestoreSessionEventType}
   */
  public O365RestoreSessionEventType getType() {
    return type;
  }

  /**
   * Returns the status of the restore session.
   *
   * @return one of {@link O365RestoreSessionEventStatus}
   */
  public O365RestoreSessionEventStatus getStatus() {
    return status;
  }

  /**
   * Returns the date and time when the restore session started.
   *
   * @return UTC {@link Instant}
   */
  public Instant getStartTime() {
    return startTime;
  }

  /**
   * Returns the date and time when the restore session ended.
   *
   * @return UTC {@link Instant}
   */
  public Instant getEndTime() {
    return endTime;
  }

  /**
   * Returns the duration of the event in milliseconds.
   *
   * @return duration of the event in milliseconds.
   */
  public long getDuration() {
    return duration;
  }

  /**
   * Returns the title of the restore session event available for exploring
   * and restoring during the restore session.
   *
   * @return the title of the restore session event
   */
  public String getTitle() {
    return title;
  }

  /**
   * Returns the order of the restore session event available for exploring
   * and restoring during the restore session.
   *
   * @return the order of the restore session event
   */
  public int getOrder() {
    return order;
  }

  /**
   * Returns the user, that initiated the restore session.
   *
   * @return the user, that initiated the restore session
   */
  public String getInitiatedBy() {
    return initiatedBy;
  }

  @Override
  public int compareTo(
      final O365RestoreSessionEventResponse o365RestoreSessionEventResponse) {
    if (o365RestoreSessionEventResponse == null
        || o365RestoreSessionEventResponse.getStartTime() == null) {
      return 1;
    }
    return this.getStartTime()
        .compareTo(o365RestoreSessionEventResponse.getStartTime());
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final O365RestoreSessionEventResponse that =
        (O365RestoreSessionEventResponse) o;
    return itemSizeBytes == that.itemSizeBytes && order == that.order && Objects
        .equals(id, that.id) && type == that.type && status == that.status
        && Objects.equals(startTime, that.startTime) && Objects
        .equals(endTime, that.endTime) && Objects
        .equals(duration, that.duration) && Objects.equals(title, that.title)
        && Objects.equals(initiatedBy, that.initiatedBy);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(itemSizeBytes, id, type, status, startTime, endTime, duration,
            title, order, initiatedBy);
  }

}
