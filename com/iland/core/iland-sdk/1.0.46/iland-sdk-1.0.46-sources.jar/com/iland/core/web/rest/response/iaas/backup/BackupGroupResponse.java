/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.backupgroups.enums.BackupGroupPriority;
import com.iland.cohesity.iaas.backups.backupgroups.enums.BackupGroupQosType;
import com.iland.cohesity.iaas.backups.backupgroups.enums.StatusBackupRun;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.shared.iaas.backup.BackupGroupDiskUnit;
import com.iland.core.web.rest.shared.iaas.backup.BackupGroupIndexingPolicy;
import com.iland.core.web.rest.shared.iaas.backup.ProtectionSource;
import com.iland.core.web.rest.shared.time.TimeOfDay;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Backup Group.
 */
@APIDoc
public final class BackupGroupResponse implements Serializable {

  private static final long serialVersionUID = 6985212867482254556L;

  /**
   * Specifies the id of the associated company.
   */
  @Expose
  @JsonRequired("Specifies a company ID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String companyId;

  /**
   * Specifies an id for the backup group.
   */
  @Expose
  @JsonRequired("Specifies a UID for the backup group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uid;

  /**
   * Specifies the iland datacenter location ID.
   */
  @Expose
  @JsonRequired("Specifies the iland datacenter location ID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String locationId;

  /**
   * Specifies the name of the backup group.
   */
  @Expose
  @JsonRequired("Specifies the name of the backup group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  /**
   * Specifies the time when the backup group was created.
   */
  @Expose
  @JsonRequired("Specifies the time when the backup group was created.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant creationTime;

  /**
   * Specifies the last time this Job was updated.
   */
  @Expose
  @JsonRequired("Specifies the last time this Job was updated.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant modifiedTime;

  /**
   * Specifies a text description about the backup group.
   */
  @Expose
  @JsonOptional("Specifies a text description about the backup group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String description;

  /**
   * Specifies the time after which the backup group becomes dormant.
   */
  @Expose
  @JsonOptional("Specifies the time after which the backup group becomes dormant.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant endTime;

  /**
   * Indicates if the current state of the backup group is Active
   * or Inactive.
   * When you create a backup group on a Primary Cluster
   * with a replication schedule, the Cluster creates an
   * Inactive copy of the Job on the Remote Cluster.
   * In addition, when an Active and running Job is deactivated,
   * the Job becomes Inactive.
   */
  @Expose
  @JsonRequired("Indicates if the current state of the backup group is Active "
      + "or Inactive. When you create a backup group on a Primary Cluster "
      + "with a replication schedule, the Cluster creates an "
      + "Inactive copy of the Job on the Remote Cluster. "
      + "In addition, when an Active and running Job is deactivated, "
      + " the Job becomes Inactive.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean active;

  /**
   * Equals 'true' if the backup group was deleted but some Snapshots
   * are still associated with this Job. If 'true', no new Job Runs are started
   * by this backup group.
   */
  @Expose
  @JsonRequired(
      "Equals 'true' if the backup group was deleted but some Snapshots "
          + "are still associated with this Job. If 'true', no new Job Runs are started "
          + "by this backup group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean deleted;

  /**
   * Indicates if the backup group is paused, which means that no new
   * Job Runs are started but any existing Job Runs continue to
   * execute.
   */
  @Expose
  @JsonRequired(
      "Indicates if the backup group is paused, which means that no new "
          + "Job Runs are started but any existing Job Runs continue to "
          + "execute.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean paused;

  /**
   * Specifies the list of Disks to be excluded from backing up. These disks
   * are excluded from all Protection Sources in the backup group.
   */
  @Expose
  @JsonRequired("Specifies the list of Disks to be excluded from backing up. "
      + "These disks are excluded from all Protection Sources in the backup group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<BackupGroupDiskUnit> excludedDisks;

  /**
   * If true, takes a crash-consistent snapshot when app-consistent snapshot
   * fails. Otherwise, the snapshot attempt is marked failed.
   */
  @Expose
  @JsonRequired(
      "If true, takes a crash-consistent snapshot when app-consistent snapshot "
          + "fails. Otherwise, the snapshot attempt is marked failed.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean fallbackToCrashConsistent;

  /**
   * If true, skip physical RDM disks when backing up VMs. Otherwise, backup
   * of VMs having physical RDM will fail.
   */
  @Expose
  @JsonRequired(
      "If true, skip physical RDM disks when backing up VMs. Otherwise, backup "
          + "of VMs having physical RDM will fail.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean skipPhysicalRdmDisks;

  /**
   * If specified, this setting is number of minutes that a Job Run
   * of a Full (no CBT) backup schedule is expected to complete, which is
   * known as a Service-Level Agreement (SLA).
   * A SLA violation is reported when the run time of a Job Run exceeds
   * the SLA time period specified for this backup schedule.
   */
  @Expose
  @JsonRequired(
      "If specified, this setting is number of minutes that a Job Run "
          + "of a Full (no CBT) backup schedule is expected to complete, which is "
          + "known as a Service-Level Agreement (SLA). "
          + "A SLA violation is reported when the run time of a Job Run exceeds "
          + "the SLA time period specified for this backup schedule.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long fullProtectionSlaTimeMins;

  /**
   * If specified, this setting is number of minutes that a Job Run
   * of a CBT-based backup schedule is expected to complete, which
   * is known as a Service-Level Agreement (SLA).
   * A SLA violation is reported when the run time of a Job Run exceeds
   * the SLA time period specified for this backup schedule.
   */
  @Expose
  @JsonRequired(
      "If specified, this setting is number of minutes that a Job Run "
          + "of a CBT-based backup schedule is expected to complete, which "
          + "is known as a Service-Level Agreement (SLA). "
          + "A SLA violation is reported when the run time of a Job Run exceeds "
          + "the SLA time period specified for this backup schedule.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long incrementalProtectionSlaTimeMins;

  /**
   * Specifies settings for indexing files found in an Object
   * (such as a VM) so these files can be searched and recovered.
   * This also specifies inclusion and exclusion rules that determine
   * the directories to index.
   */
  @Expose
  @JsonRequired("Specifies settings for indexing files found in an Object "
      + "(such as a VM) so these files can be searched and recovered. "
      + "This also specifies inclusion and exclusion rules that determine "
      + "the directories to index.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupGroupIndexingPolicy indexingPolicy;

  /**
   * Specifies the unique id of the Protection Policy associated with
   * the backup group. The Policy provides retry settings,
   * Protection Schedules, Priority, SLA, etc.
   * The Job defines the Storage Domain, the Objects to Protect
   * (if applicable), Start Time, Indexing settings, etc.
   */
  @Expose
  @JsonRequired(
      "Specifies the unique id of the Protection Policy associated with "
          + "the backup group. The Policy provides retry settings, "
          + "Protection Schedules, Priority, SLA, etc. "
          + "The Job defines the Storage Domain, the Objects to Protect "
          + "(if applicable), Start Time, Indexing settings, etc.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String policyId;

  /**
   * Specifies the time when the associated Policy was last applied to this Job.
   * This is used to determine if the Policy has changed since it was last
   * applied to this Job.
   */
  @Expose
  @JsonRequired(
      "Specifies the time when the associated Policy was last applied to this Job. "
          + "This is used to determine if the Policy has changed since it was last "
          + "applied to this Job.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant policyAppliedTime;

  /**
   * Specifies the priority of execution for a backup group.
   * iland Supports concurrent backups but if the number of Jobs exceeds
   * the ability to process Jobs, the specified priority determines the
   * execution Job priority.
   * This field also specifies the replication priority.
   * 'LOW' indicates lowest execution priority for a backup group.
   * 'MEDIUM' indicates medium execution priority for a backup group.
   * 'HIGH' indicates highest execution priority for a backup group.
   */
  @Expose
  @JsonRequired("Specifies the priority of execution for a backup group. "
      + "iland Supports concurrent backups but if the number of Jobs exceeds "
      + "the ability to process Jobs, the specified priority determines the "
      + "execution Job priority. "
      + "This field also specifies the replication priority. "
      + "'LOW' indicates lowest execution priority for a backup group. "
      + "'MEDIUM' indicates medium execution priority for a backup group. "
      + "'HIGH' indicates highest execution priority for a backup group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupGroupPriority priority;

  /**
   * Specifies the QoS policy type to use for this backup group.
   * 'HDD' indicates that data is written directly to
   * the HDD tier for this backup group. This is the recommended setting.
   * 'SSD' indicates that data is written directly to
   * the SSD tier for this backup group. Only specify this policy if
   * you need fast ingest speed for a small number of backup groups.
   */
  @Expose
  @JsonRequired("Specifies the QoS policy type to use for this backup group. "
      + "'HDD' indicates that data is written directly to "
      + "the HDD tier for this backup group. This is the recommended setting. "
      + "'SSD' indicates that data is written directly to "
      + "the SSD tier for this backup group. Only specify this policy if "
      + "you need fast ingest speed for a small number of backup groups.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupGroupQosType qosType;

  /**
   * Array of Excluded Source Objects.
   * <p>
   * List of sources from a Protection Source that should not be
   * protected and are excluded from being backed up by the backup group.
   * Leaf and non-leaf Objects may be in this list and an Object in this list
   * must have an ancestor in the {@link BackupGroupResponse#protectedSources} list.
   */
  @Expose
  @JsonRequired("Array of Excluded Source Objects. "
      + "List of sources from a Protection Source that should not be "
      + "protected and are excluded from being backed up by the backup group. "
      + "Leaf and non-leaf Objects may be in this list and an Object in this list "
      + "must have an ancestor in the protected_sources list.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<ProtectionSource> excludedSources;

  /**
   * Array of Protected Source Objects.
   * <p>
   * Specifies the list of Objects to protect (or back up) by the backup group.
   * An Object in this list may be descendant of another Object in this list.
   */
  @Expose
  @JsonRequired("Array of Protected Source Objects. "
      + "Specifies the list of Objects to protect (or back up) by the backup group. "
      + "An Object in this list may be descendant of another Object in this list.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<ProtectionSource> protectedSources;

  /**
   * Specifies the time of day to start the Protection Schedule.
   * This is optional and only applicable if the Protection Policy defines
   * a monthly or a daily Protection Schedule.
   */
  @Expose
  @JsonRequired("Specifies the time of day to start the Protection Schedule. "
      + "This is optional and only applicable if the Protection Policy defines "
      + "a monthly or a daily Protection Schedule.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final TimeOfDay startTime;

  /**
   * Specifies the timezone to use when calculating time for this
   * backup group such as the Job start time.
   * Specify the timezone in the following format: "Area/Location",
   * for example: "America/New_York".
   */
  @Expose
  @JsonRequired("Specifies the timezone to use when calculating time for this "
      + "backup group such as the Job start time. "
      + "Specify the timezone in the following format: 'Area/Location', "
      + "for example: 'America/New_York'.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String timezone;

  /**
   * Specifies information about the parent iland IaaS organization.
   */
  @Expose
  @JsonRequired("Specifies the UUID of the parent iland IaaS organization.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String orgUuid;

  /**
   * Specifies the associated virtual datacenter UUID.
   */
  @Expose
  @JsonRequired("Specifies the associated virtual datacenter UUID")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vdcUuid;

  /**
   * If true, aborts any currently executing backup group Runs of this backup
   * group when a blackout period specified for this backup group starts, even
   * if the backup group Run started before the blackout period began. If false,
   * a backup group Run continues to execute, if the backup group Run started
   * before the blackout period starts.
   */
  @Expose
  @JsonRequired(
      "If true, aborts any currently executing backup group Runs of this backup "
          + "group when a blackout period specified for this backup group starts, even "
          + "if the backup group Run started before the blackout period began. If false, "
          + "a backup group Run continues to execute, if the backup group Run started "
          + "before the blackout period starts.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean abortInBlackoutPeriod;

  /**
   * Whether to continue backing up on quiesce failure.
   */
  @Expose
  @JsonRequired("Whether to continue backing up on quiesce failure.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean continueOnQuiesceFailure;

  /**
   * Indicates if the App-Consistent option is enabled for this backup group. If
   * the option is enabled, quiesces the file system and applications before
   * taking Application-Consistent Snapshots. VMware Tools must be installed on
   * the guest Operating System.
   */
  @Expose
  @JsonRequired(
      "Indicates if the App-Consistent option is enabled for this backup group. If "
          + "the option is enabled, quiesces the file system and applications before "
          + "taking Application-Consistent Snapshots. VMware Tools must be installed on "
          + "the guest Operating System.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean quiesce;

  /**
   * Summary statistics that relate to runs of this backup group.
   */
  @Expose
  @JsonOptional("Summary statistics that relate to runs of this backup group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupSummaryStats summaryStats;

  /**
   * Summary statistics that relate to runs of this backup group.
   */
  @Expose
  @JsonOptional("Information about the last run of this backup group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupGroupRunResponse lastRun;

  /**
   * Summary statistics that relate to runs of this backup group.
   */
  @Expose
  @JsonOptional("Information about the associated backup policy.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupPolicyResponse backupPolicy;

  /**
   * Summary statistics that relate to runs of this backup group.
   */
  @Expose
  @JsonOptional("The run status.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final StatusBackupRun status;

  /**
   * Instantiates a new IaaS backup backup group.
   *
   * @param uid                              the uid
   * @param companyId                        the company id
   * @param locationId                       the location id
   * @param name                             the name
   * @param creationTime                     the creation time
   * @param modifiedTime                     the modified time
   * @param description                      the description
   * @param endTime                          the end time
   * @param active                           the active
   * @param deleted                          the deleted
   * @param paused                           the paused
   * @param excludedDisks                    the excluded disks
   * @param fallbackToCrashConsistent        the fallback to crash consistent
   * @param skipPhysicalRdmDisks             the skip physical rdm disks
   * @param fullProtectionSlaTimeMins        the full protection sla time mins
   * @param incrementalProtectionSlaTimeMins the incremental protection sla time mins
   * @param indexingPolicy                   the indexing policy
   * @param policyId                         the policy id
   * @param policyAppliedTime                the policy applied time
   * @param priority                         the priority
   * @param qosType                          the qos type
   * @param excludedSources                  the excluded sources
   * @param protectedSources                 the protected sources
   * @param startTime                        the start time
   * @param timezone                         the timezone
   * @param orgUuid                          the org UUID
   * @param vdcUuid                          the vdc UUID
   * @param abortInBlackoutPeriod            whether to abort in a blackout period
   * @param continueOnQuiesceFailure         whether to continue on quiesce failure
   * @param quiesce                          whether to quiesce before backup
   * @param summaryStats                     summary stats
   * @param lastRun                          last run info
   * @param backupPolicy                     associated backup policy info
   * @param status                        the status of the run
   */
  public BackupGroupResponse(final String uid, final String companyId,
      final String locationId, final String name, final Instant creationTime,
      final Instant modifiedTime, final String description,
      final Instant endTime, final Boolean active, final Boolean deleted,
      final Boolean paused, final List<BackupGroupDiskUnit> excludedDisks,
      final boolean fallbackToCrashConsistent,
      final boolean skipPhysicalRdmDisks, final long fullProtectionSlaTimeMins,
      final long incrementalProtectionSlaTimeMins,
      final BackupGroupIndexingPolicy indexingPolicy, final String policyId,
      final Instant policyAppliedTime, final BackupGroupPriority priority,
      final BackupGroupQosType qosType,
      final Set<ProtectionSource> excludedSources,
      final Set<ProtectionSource> protectedSources, final TimeOfDay startTime,
      final String timezone, final String orgUuid, final String vdcUuid,
      final boolean abortInBlackoutPeriod,
      final boolean continueOnQuiesceFailure, final boolean quiesce,
      final StatusBackupRun status,
      final BackupSummaryStats summaryStats,
      final BackupGroupRunResponse lastRun,
      final BackupPolicyResponse backupPolicy) {
    this.uid = uid;
    this.companyId = companyId;
    this.locationId = locationId;
    this.name = name;
    this.creationTime = creationTime;
    this.modifiedTime = modifiedTime;
    this.description = description;
    this.endTime = endTime;
    this.active = active != null ? active : true;
    this.deleted = deleted != null ? deleted : false;
    this.paused = paused != null ? paused : false;
    this.excludedDisks = excludedDisks;
    this.fallbackToCrashConsistent = fallbackToCrashConsistent;
    this.skipPhysicalRdmDisks = skipPhysicalRdmDisks;
    this.fullProtectionSlaTimeMins = fullProtectionSlaTimeMins;
    this.incrementalProtectionSlaTimeMins = incrementalProtectionSlaTimeMins;
    this.indexingPolicy = indexingPolicy;
    this.policyId = policyId;
    this.policyAppliedTime = policyAppliedTime;
    this.priority = priority;
    this.qosType = qosType;
    this.excludedSources = excludedSources;
    this.protectedSources = protectedSources;
    this.startTime = startTime;
    this.timezone = timezone;
    this.orgUuid = orgUuid;
    this.vdcUuid = vdcUuid;
    this.abortInBlackoutPeriod = abortInBlackoutPeriod;
    this.continueOnQuiesceFailure = continueOnQuiesceFailure;
    this.quiesce = quiesce;
    this.status = status;
    this.summaryStats = summaryStats;
    this.lastRun = lastRun;
    this.backupPolicy = backupPolicy;
  }

  /**
   * Specifies the UID for the backup group.
   *
   * @return the uid
   */
  public String getUid() {
    return uid;
  }

  /**
   * Specifies the ID of the associated company.
   *
   * @return companyId
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * Specifies the iland datacenter location ID.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Specifies the name of the backup group.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Specifies the time when the backup group was created.
   *
   * @return the creation time
   */
  public Instant getCreationTime() {
    return creationTime;
  }

  /**
   * Specifies the last time this Job was updated.
   *
   * @return the modified time
   */
  public Instant getModifiedTime() {
    return modifiedTime;
  }

  /**
   * Specifies a text description about the backup group.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Specifies the time after which the backup group becomes dormant.
   *
   * @return the end time
   */
  public Instant getEndTime() {
    return endTime;
  }

  /**
   * Indicates if the current state of the backup group is Active
   * or Inactive.
   * When you create a backup group on a Primary Cluster
   * with a replication schedule, the Cluster creates an
   * Inactive copy of the Job on the Remote Cluster.
   * In addition, when an Active and running Job is deactivated,
   * the Job becomes Inactive.
   *
   * @return boolean
   */
  public boolean isActive() {
    return active;
  }

  /**
   * Equals 'true' if the backup group was deleted but some Snapshots
   * are still associated with this Job. If 'true', no new Job Runs are started
   * by this backup group.
   *
   * @return the boolean
   */
  public boolean isDeleted() {
    return deleted;
  }

  /**
   * Indicates if the backup group is paused, which means that no new
   * Job Runs are started but any existing Job Runs continue to
   * execute.
   *
   * @return the boolean
   */
  public boolean isPaused() {
    return paused;
  }

  /**
   * Specifies the list of Disks to be excluded from backing up. These disks
   * are excluded from all Protection Sources in the backup group.
   *
   * @return the excluded disks
   */
  public List<BackupGroupDiskUnit> getExcludedDisks() {
    return excludedDisks;
  }

  /**
   * If true, takes a crash-consistent snapshot when app-consistent snapshot
   * fails. Otherwise, the snapshot attempt is marked failed.
   *
   * @return the boolean
   */
  public boolean isFallbackToCrashConsistent() {
    return fallbackToCrashConsistent;
  }

  /**
   * If true, skip physical RDM disks when backing up VMs. Otherwise, backup
   * of VMs having physical RDM will fail.
   *
   * @return the boolean
   */
  public boolean isSkipPhysicalRdmDisks() {
    return skipPhysicalRdmDisks;
  }

  /**
   * If specified, this setting is number of minutes that a Job Run
   * of a Full (no CBT) backup schedule is expected to complete, which is
   * known as a Service-Level Agreement (SLA).
   * A SLA violation is reported when the run time of a Job Run exceeds
   * the SLA time period specified for this backup schedule.
   *
   * @return the full protection sla time mins
   */
  public long getFullProtectionSlaTimeMins() {
    return fullProtectionSlaTimeMins;
  }

  /**
   * If specified, this setting is number of minutes that a Job Run
   * of a CBT-based backup schedule is expected to complete, which
   * is known as a Service-Level Agreement (SLA).
   * A SLA violation is reported when the run time of a Job Run exceeds
   * the SLA time period specified for this backup schedule.
   *
   * @return the incremental protection sla time mins
   */
  public long getIncrementalProtectionSlaTimeMins() {
    return incrementalProtectionSlaTimeMins;
  }

  /**
   * Specifies settings for indexing files found in an Object
   * (such as a VM) so these files can be searched and recovered.
   * This also specifies inclusion and exclusion rules that determine
   * the directories to index.
   *
   * @return the indexing policy
   */
  public BackupGroupIndexingPolicy getIndexingPolicy() {
    return indexingPolicy;
  }

  /**
   * Specifies the unique id of the Protection Policy associated with
   * the backup group. The Policy provides retry settings,
   * Protection Schedules, Priority, SLA, etc.
   * The Job defines the Storage Domain, the Objects to Protect
   * (if applicable), Start Time, Indexing settings, etc.
   *
   * @return the policy id
   */
  public String getPolicyId() {
    return policyId;
  }

  /**
   * Specifies the time when the associated Policy was last applied to this Job.
   * This is used to determine if the Policy has changed since it was last
   * applied to this Job.
   *
   * @return the policy applied time
   */
  public Instant getPolicyAppliedTime() {
    return policyAppliedTime;
  }

  /**
   * Specifies the priority of execution for a backup group.
   * iland Supports concurrent backups but if the number of Jobs exceeds
   * the ability to process Jobs, the specified priority determines the
   * execution Job priority.
   * This field also specifies the replication priority.
   * 'LOW' indicates lowest execution priority for a backup group.
   * 'MEDIUM' indicates medium execution priority for a backup group.
   * 'HIGH' indicates highest execution priority for a backup group.
   *
   * @return the priority
   */
  public BackupGroupPriority getPriority() {
    return priority;
  }

  /**
   * Specifies the QoS policy type to use for this backup group.
   * 'HDD' indicates that data is written directly to
   * the HDD tier for this backup group. This is the recommended setting.
   * 'SSD' indicates that data is written directly to
   * the SSD tier for this backup group. Only specify this policy if
   * you need fast ingest speed for a small number of backup groups.
   *
   * @return the qos type
   */
  public BackupGroupQosType getQosType() {
    return qosType;
  }

  /**
   * Array of Excluded Source Objects.
   * <p>
   * List of sources from a Protection Source that should not be
   * protected and are excluded from being backed up by the backup group.
   * Leaf and non-leaf Objects may be in this list and an Object in this list
   * must have an ancestor in the {@link BackupGroupResponse#protectedSources} list.
   *
   * @return the excluded sources
   */
  public Set<ProtectionSource> getExcludedSources() {
    return excludedSources;
  }

  /**
   * Array of Protected Source Objects.
   * <p>
   * Specifies the list of Objects to protect (or back up) by the backup group.
   * An Object in this list may be descendant of another Object in this list.
   *
   * @return the protected sources
   */
  public Set<ProtectionSource> getProtectedSources() {
    return protectedSources;
  }

  /**
   * Specifies the time of day to start the Protection Schedule.
   * This is optional and only applicable if the Protection Policy defines
   * a monthly or a daily Protection Schedule.
   * Default value is 02:00 AM.
   *
   * @return the start time
   */
  public TimeOfDay getStartTime() {
    return startTime;
  }

  /**
   * Specifies the timezone to use when calculating time for this
   * backup group such as the Job start time.
   * Specify the timezone in the following format: "Area/Location",
   * for example: "America/New_York".
   *
   * @return the timezone
   */
  public String getTimezone() {
    return timezone;
  }

  /**
   * Specifies the UUID of the parent iland IaaS organization.
   *
   * @return the org UUID
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Specifies the associated virtual datacenter UUID.
   *
   * @return the vdc UUID
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * If true, aborts any currently executing backup group Runs of this backup
   * group when a blackout period specified for this backup group starts, even
   * if the backup group Run started before the blackout period began. If false,
   * a backup group Run continues to execute, if the backup group Run started
   * before the blackout period starts.
   *
   * @return boolean value
   */
  public boolean isAbortInBlackoutPeriod() {
    return abortInBlackoutPeriod;
  }

  /**
   * Whether to continue backing up on quiesce failure.
   *
   * @return boolean value
   */
  public boolean isContinueOnQuiesceFailure() {
    return continueOnQuiesceFailure;
  }

  /**
   * Indicates if the App-Consistent option is enabled for this backup group. If
   * the option is enabled, quiesces the file system and applications before
   * taking Application-Consistent Snapshots. VMware Tools must be installed on
   * the guest Operating System.
   *
   * @return boolean value
   */
  public boolean isQuiesce() {
    return quiesce;
  }

  /**
   * Indicates the status of the latest run, if available.
   *
   * @return {@link StatusBackupRun run status}
   */
  public Optional<StatusBackupRun> getStatus() {
    return Optional.ofNullable(status);
  }

  /**
   * Gets summary stats.
   *
   * @return {@link Optional} of {@link BackupSummaryStats}
   */
  public Optional<BackupSummaryStats> getSummaryStats() {
    return Optional.ofNullable(summaryStats);
  }

  /**
   * Gets last run info (if applicable).
   *
   * @return {@link Optional} of {@link BackupGroupRunResponse}
   */
  public Optional<BackupGroupRunResponse> getLastRun() {
    return Optional.ofNullable(lastRun);
  }

  /**
   * Gets the associated backup policy.
   *
   * @return {@link Optional} of {@link BackupPolicyResponse}
   */
  public Optional<BackupPolicyResponse> getBackupPolicy() {
    return Optional.ofNullable(backupPolicy);
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BackupGroupResponse that = (BackupGroupResponse) o;
    return active == that.active && deleted == that.deleted
        && paused == that.paused
        && fallbackToCrashConsistent == that.fallbackToCrashConsistent
        && skipPhysicalRdmDisks == that.skipPhysicalRdmDisks
        && fullProtectionSlaTimeMins == that.fullProtectionSlaTimeMins
        && incrementalProtectionSlaTimeMins
        == that.incrementalProtectionSlaTimeMins
        && abortInBlackoutPeriod == that.abortInBlackoutPeriod
        && continueOnQuiesceFailure == that.continueOnQuiesceFailure
        && quiesce == that.quiesce && Objects.equals(companyId, that.companyId)
        && Objects.equals(uid, that.uid) && Objects
        .equals(locationId, that.locationId) && Objects.equals(name, that.name)
        && Objects.equals(creationTime, that.creationTime) && Objects
        .equals(modifiedTime, that.modifiedTime) && Objects
        .equals(description, that.description) && Objects
        .equals(endTime, that.endTime) && Objects
        .equals(excludedDisks, that.excludedDisks) && Objects
        .equals(indexingPolicy, that.indexingPolicy) && Objects
        .equals(policyId, that.policyId) && Objects
        .equals(policyAppliedTime, that.policyAppliedTime)
        && priority == that.priority && qosType == that.qosType && Objects
        .equals(excludedSources, that.excludedSources) && Objects
        .equals(protectedSources, that.protectedSources) && Objects
        .equals(startTime, that.startTime) && Objects
        .equals(timezone, that.timezone) && Objects
        .equals(orgUuid, that.orgUuid) && Objects.equals(vdcUuid, that.vdcUuid)
        && Objects.equals(summaryStats, that.summaryStats) && Objects
        .equals(lastRun, that.lastRun) && Objects
        .equals(backupPolicy, that.backupPolicy);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(companyId, uid, locationId, name, creationTime, modifiedTime,
            description, endTime, active, deleted, paused, excludedDisks,
            fallbackToCrashConsistent, skipPhysicalRdmDisks,
            fullProtectionSlaTimeMins, incrementalProtectionSlaTimeMins,
            indexingPolicy, policyId, policyAppliedTime, priority, qosType,
            excludedSources, protectedSources, startTime, timezone, orgUuid,
            vdcUuid, abortInBlackoutPeriod, continueOnQuiesceFailure, quiesce,
            summaryStats, lastRun, backupPolicy);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("companyId", companyId)
        .add("uid", uid).add("locationId", locationId).add("name", name)
        .add("creationTime", creationTime).add("modifiedTime", modifiedTime)
        .add("description", description).add("endTime", endTime)
        .add("active", active).add("deleted", deleted).add("paused", paused)
        .add("excludedDisks", excludedDisks)
        .add("fallbackToCrashConsistent", fallbackToCrashConsistent)
        .add("skipPhysicalRdmDisks", skipPhysicalRdmDisks)
        .add("fullProtectionSlaTimeMins", fullProtectionSlaTimeMins)
        .add("incrementalProtectionSlaTimeMins",
            incrementalProtectionSlaTimeMins)
        .add("indexingPolicy", indexingPolicy).add("policyId", policyId)
        .add("policyAppliedTime", policyAppliedTime).add("priority", priority)
        .add("qosType", qosType).add("excludedSources", excludedSources)
        .add("protectedSources", protectedSources).add("startTime", startTime)
        .add("timezone", timezone).add("orgUuid", orgUuid)
        .add("vdcUuid", vdcUuid)
        .add("abortInBlackoutPeriod", abortInBlackoutPeriod)
        .add("continueOnQuiesceFailure", continueOnQuiesceFailure)
        .add("quiesce", quiesce).add("summaryStats", summaryStats)
        .add("lastRun", lastRun).add("backupPolicy", backupPolicy).toString();
  }
}
