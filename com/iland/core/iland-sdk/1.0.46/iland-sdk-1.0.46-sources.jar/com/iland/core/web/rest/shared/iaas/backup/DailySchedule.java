/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Objects;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.policies.api.enums.Day;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Daily Schedule.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class DailySchedule implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Array of Days.
   * <p>
   * Specifies a list of days of the week when to start Group Runs. If no days are
   * specified, the Groups Runs will run every day of the week. Specifies a day in
   * a week such as 'SUNDAY', 'MONDAY', etc.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Array of Days. Specifies a list of days of the week when"
      + " to start Group Runs. If no days are specified, the Groups Runs will"
      + " run every day of the week. Specifies a day in a week such as "
      + "'SUNDAY', 'MONDAY', etc.")
  private final Set<Day> days;

  /**
   * Instantiates a new DailySchedule.
   *
   * @param days Array of Days. <p> Specifies a list of days of the week when to
   *             start Group Runs. If no days are specified, the Groups Runs will
   *             run every day of the week. Specifies a day in a week such as
   *             'SUNDAY', 'MONDAY', etc.
   */
  public DailySchedule(final Set<Day> days) {
    this.days = days;
  }

  /**
   * Array of Days.
   * <p>
   * Specifies a list of days of the week when to start Group Runs. If no days are
   * specified, the Groups Runs will run every day of the week. Specifies a day in
   * a week such as 'SUNDAY', 'MONDAY', etc.
   *
   * @return days
   */
  public Set<Day> getDays() {
    return this.days;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final DailySchedule that = (DailySchedule) o;
    return Objects.equals(days, that.days);
  }

  @Override
  public int hashCode() {
    return Objects.hash(days);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("days", days).toString();
  }
}
