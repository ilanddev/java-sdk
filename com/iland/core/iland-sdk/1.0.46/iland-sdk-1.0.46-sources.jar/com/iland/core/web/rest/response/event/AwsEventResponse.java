/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.event;

import java.time.Instant;
import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;
import com.iland.core.web.rest.response.common.EntityTypeResponse;

/**
 * AWS Event Response.
 */
@APIModel
public interface AwsEventResponse {

  /**
   * The event uuid
   */
  String uuid();

  /**
   * The owner type
   */
  EventOwnerType ownerType();

  /**
   * The owner id
   */
  String ownerId();

  /**
   * The event entity uuid
   */
  String entityUuid();

  /**
   * The event entity name
   */
  String entityName();

  /**
   * The event entity type
   */
  EntityTypeResponse entityType();

  /**
   * The event type
   */
  EventTypeResponse type();

  /**
   * The creation type
   */
  Instant timestamp();

  /**
   * The core task uuid
   */
  Optional<String> taskUuid();

  /**
   * The username of who triggered the event
   */
  String initiatedByUsername();

  /**
   * The fullname of who triggered the event
   */
  String initiatedByFullName();

  /**
   * The event details message
   */
  String details();

  /**
   * AWS EVENT REQUIRED FIELD. This field will always be populated in the response.
   * <br><br>
   * The event's related contract uuid.
   */
  String contractUuid();

  /**
   * AWS EVENT REQUIRED FIELD. This field will always be populated in the response.
   * <br><br>
   * The event's related contract number.
   */
  String contractNumber();

  /**
   * AWS EVENT REQUIRED FIELD. This field will always be populated in the response.
   * <br><br>
   * The IP address of the user who triggered the event.
   */
  String ipAddress();

  /**
   * AWS EVENT REQUIRED FIELD. It's a sublist of the <b>type</b> field. Each one of these types will have
   * a different subset of AWS EVENT OPTIONAL fields that will be populated.
   * The ones not mentioned will show null in the response.
   *
   * <p>||
   * <u><b>AWS Account Key Event types</b></u>:
   *
   * <p>|
   * S3_STORAGE_ACCOUNT_KEY_CREATE Key Creation: account_id, new_access_key, new_key_description,
   *
   * <p>|
   * S3_STORAGE_ACCOUNT_KEY_DESCRIPTION_UPDATE Key Description Update:  account_id, accessKey, new_key_description,
   *
   * <p>|
   * S3_STORAGE_ACCOUNT_KEY_ENABLE Key Enable: account_id, accessKey
   *
   * <p>|
   * S3_STORAGE_ACCOUNT_KEY_DISABLE Key Disable: account_id, accessKey
   *
   * <p>|
   * S3_STORAGE_ACCOUNT_KEY_ROTATE Key Rotate: account_id, accessKey, new_access_key, new_key_description,
   *
   * <p>|
   * S3_STORAGE_ACCOUNT_KEY_DELETE Key Delete: account_id, accessKey
   *
   * <p>||
   * <u><b>AWS Account Bucket Event types</b></u>:
   *
   * <p>|
   * S3_STORAGE_ACCOUNT_BUCKET_CREATE Bucket creation: account_id, new_bucket_name, new_bucket_object_lock_enabled
   *
   * <p>|
   * S3_INCREASE_STORAGE : additional_storage, new_storage_reservation, current_monthly_storage_cost, currency, additional_monthly_cost, new_monthly_storage_cost
   *
   * <p>|
   * S3_STORAGE_ACCOUNT_CREATE : account_name
   *
   * <p>|
   * S3_STORAGE_ACCOUNT_UPDATE : original_account_name, new_account_name
   *
   **/
  AwsEventTypeResponse awsEventType();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The event's related AWS account id
   */
  Optional<String> accountId();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The event's related AWS Account Key id
   */
  Optional<String> accessKey();

  /**
   * AWS EVENT OPTIONAL FIELD See <b>awsEventType</b> field description for more info.
   * The event's related AWS Account newly generated Key id
   */
  Optional<String> newAccessKey();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The event's related AWS Account key newly generated description.
   */
  Optional<String> newKeyDescription();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The new S3 bucket name.
   */
  Optional<String> newBucketName();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * Whether object lock is enabled in the new S3 bucket
   */
  Optional<Boolean> newBucketObjectLockEnabled();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The current storage quota in TiB before the increase.
   */
  Optional<Integer> existingStorageReservation();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The additional storage in TiB being added.
   */
  Optional<Integer> additionalStorage();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The new storage reservation in TiB after the increase.
   */
  Optional<Integer> newStorageReservation();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The current monthly storage cost before the increase.
   */
  Optional<Double> currentMonthlyStorageCost();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The currency of the storage cost.
   */
  Optional<String> currency();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The additional monthly cost incurred by the storage increase.
   */
  Optional<Double> additionalMonthlyStorageCost();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The new monthly cost after the storage increase.
   */
  Optional<Double> newMonthlyStorageCost();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The new account's name.
   */
  Optional<String> accountName();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The original name of the account before an update.
   */
  Optional<String> originalAccountName();

  /**
   * AWS EVENT OPTIONAL FIELD. See <b>awsEventType</b> field description for more info.
   * The new name of the account after an update.
   */
  Optional<String> newAccountName();

}
