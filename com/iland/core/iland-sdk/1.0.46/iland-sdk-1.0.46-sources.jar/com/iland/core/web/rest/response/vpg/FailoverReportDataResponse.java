/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vpg;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Failover Report Data Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class FailoverReportDataResponse implements Serializable {

  private static final long serialVersionUID = -3885969496497574818L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vpgName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String reportGenerationDate;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String operationName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String pointInTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String startTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String endTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String rto;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String operationResult;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String userNotes;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String protectedSite;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String recoverySite;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String defaultRecoveryHost;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String defaultRecoveryDatastore;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String defaultFailoverMoveNetwork;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String recoveryOrganization;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String recoveryVdc;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String guestCustomization;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String defaultTestRecoveryNetwork;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String defaultRecoveryFolder;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String postRecoveryScript;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String bootOrderSettingsMessage;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<NetworkMapping> networkMappings;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<BootOrderSetting> bootOrderSettings;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<VmRecoverySettings> vmRecoverySettings;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<DetailedRecoveryStep> detailedRecoveryStepList;

  /**
   * Instantiates a new Failover report data.
   *
   * @param vpgName                    the vpg name
   * @param reportGenerationDate       the report generation date
   * @param operationName              the operation name
   * @param pointInTime                the point in time
   * @param startTime                  the start time
   * @param endTime                    the end time
   * @param rto                        the rto
   * @param operationResult            the operation result
   * @param userNotes                  the user notes
   * @param protectedSite              the protected site
   * @param recoverySite               the recovery site
   * @param defaultRecoveryHost        the default recovery host
   * @param defaultRecoveryDatastore   the default recovery datastore
   * @param defaultFailoverMoveNetwork the default failover move network
   * @param recoveryOrganization       the recovery organization
   * @param recoveryVdc                the recovery vdc
   * @param guestCustomization         the guest customization
   * @param defaultTestRecoveryNetwork the default test recovery network
   * @param defaultRecoveryFolder      the default recovery folder
   * @param postRecoveryScript         the post recovery script
   * @param networkMappings            the network mappings
   * @param bootOrderSettingsMessage   the boot order settings
   * @param bootOrderSettings          the boot order settings
   * @param vmRecoverySettings         the vm recovery settings
   * @param detailedRecoveryStepList   the detailed recovery step list
   */
  public FailoverReportDataResponse(final String vpgName,
      final String reportGenerationDate, final String operationName,
      final String pointInTime, final String startTime, final String endTime,
      final String rto, final String operationResult, final String userNotes,
      final String protectedSite, final String recoverySite,
      final String defaultRecoveryHost, final String defaultRecoveryDatastore,
      final String defaultFailoverMoveNetwork,
      final String recoveryOrganization, final String recoveryVdc,
      final String guestCustomization, final String defaultTestRecoveryNetwork,
      final String defaultRecoveryFolder, final String postRecoveryScript,
      final List<NetworkMapping> networkMappings,
      final String bootOrderSettingsMessage,
      final List<BootOrderSetting> bootOrderSettings,
      final List<VmRecoverySettings> vmRecoverySettings,
      final List<DetailedRecoveryStep> detailedRecoveryStepList) {
    this.vpgName = vpgName;
    this.reportGenerationDate = reportGenerationDate;
    this.operationName = operationName;
    this.pointInTime = pointInTime;
    this.startTime = startTime;
    this.endTime = endTime;
    this.rto = rto;
    this.operationResult = operationResult;
    this.protectedSite = protectedSite;
    this.recoverySite = recoverySite;
    this.defaultRecoveryHost = defaultRecoveryHost;
    this.defaultRecoveryDatastore = defaultRecoveryDatastore;
    this.defaultFailoverMoveNetwork = defaultFailoverMoveNetwork;
    this.recoveryOrganization = recoveryOrganization;
    this.recoveryVdc = recoveryVdc;
    this.guestCustomization = guestCustomization;
    this.defaultTestRecoveryNetwork = defaultTestRecoveryNetwork;
    this.defaultRecoveryFolder = defaultRecoveryFolder;
    this.postRecoveryScript = postRecoveryScript;
    this.networkMappings = networkMappings;
    this.bootOrderSettingsMessage = bootOrderSettingsMessage;
    this.bootOrderSettings = bootOrderSettings;
    this.vmRecoverySettings = vmRecoverySettings;
    this.detailedRecoveryStepList = detailedRecoveryStepList;
    this.userNotes = userNotes;
  }

  /**
   * Gets vpg name.
   *
   * @return the vpg name
   */
  public String getVpgName() {
    return vpgName;
  }

  /**
   * Gets report generation date.
   *
   * @return the report generation date
   */
  public String getReportGenerationDate() {
    return reportGenerationDate;
  }

  /**
   * Gets operation name.
   *
   * @return the operation name
   */
  public String getOperationName() {
    return operationName;
  }

  /**
   * Gets point in time.
   *
   * @return the point in time
   */
  public String getPointInTime() {
    return pointInTime;
  }

  /**
   * Gets start time.
   *
   * @return the start time
   */
  public String getStartTime() {
    return startTime;
  }

  /**
   * Gets end time.
   *
   * @return the end time
   */
  public String getEndTime() {
    return endTime;
  }

  /**
   * Gets rto.
   *
   * @return the rto
   */
  public String getRto() {
    return rto;
  }

  /**
   * Gets operation result.
   *
   * @return the operation result
   */
  public String getOperationResult() {
    return operationResult;
  }

  /**
   * Gets user notes.
   *
   * @return the user notes
   */
  public String getUserNotes() {
    return userNotes;
  }

  /**
   * Gets protected site.
   *
   * @return the protected site
   */
  public String getProtectedSite() {
    return protectedSite;
  }

  /**
   * Gets recovery site.
   *
   * @return the recovery site
   */
  public String getRecoverySite() {
    return recoverySite;
  }

  /**
   * Gets default recovery host.
   *
   * @return the default recovery host
   */
  public String getDefaultRecoveryHost() {
    return defaultRecoveryHost;
  }

  /**
   * Gets default recovery datastore.
   *
   * @return the default recovery datastore
   */
  public String getDefaultRecoveryDatastore() {
    return defaultRecoveryDatastore;
  }

  /**
   * Gets default failover move network.
   *
   * @return the default failover move network
   */
  public String getDefaultFailoverMoveNetwork() {
    return defaultFailoverMoveNetwork;
  }

  /**
   * Gets recovery organization.
   *
   * @return the recovery organization
   */
  public String getRecoveryOrganization() {
    return recoveryOrganization;
  }

  /**
   * Gets recovery vdc.
   *
   * @return the recovery vdc
   */
  public String getRecoveryVdc() {
    return recoveryVdc;
  }

  /**
   * Gets guest customization.
   *
   * @return the guest customization
   */
  public String getGuestCustomization() {
    return guestCustomization;
  }

  /**
   * Gets default recovery folder.
   *
   * @return the default recovery folder
   */
  public String getDefaultRecoveryFolder() {
    return defaultRecoveryFolder;
  }

  /**
   * Gets post recovery script.
   *
   * @return the post recovery script
   */
  public String getPostRecoveryScript() {
    return postRecoveryScript;
  }

  /**
   * Gets network mappings.
   *
   * @return the network mappings
   */
  public List<NetworkMapping> getNetworkMappings() {
    return networkMappings;
  }

  /**
   * Gets boot order settings.
   *
   * @return the boot order settings
   */
  public String getBootOrderSettingsMessage() {
    return bootOrderSettingsMessage;
  }

  /**
   * Gets vm recovery settings.
   *
   * @return the vm recovery settings
   */
  public List<VmRecoverySettings> getVmRecoverySettings() {
    return vmRecoverySettings;
  }

  /**
   * Gets boot order settings.
   *
   * @return the boot order settings
   */
  public List<BootOrderSetting> getBootOrderSettings() {
    return bootOrderSettings;
  }

  /**
   * Gets detailed recovery step list.
   *
   * @return the detailed recovery step list
   */
  public List<DetailedRecoveryStep> getDetailedRecoveryStepList() {
    return detailedRecoveryStepList;
  }

  /**
   * The type Vm recovery settings.
   */
  @APIDoc
public static class VmRecoverySettings implements Serializable {

    private static final long serialVersionUID = -6453734454910821409L;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String name;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String recoveryHost;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final Map<String, String> recoveryNetworks;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final Map<String, String> recoveryDatastores;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String recoveryFolder;

    /**
     * Instantiates a new Vm recovery settings.
     *
     * @param name               the vm name
     * @param recoveryHost       the recovery host
     * @param recoveryNetworks   the recovery networks
     * @param recoveryDatastores the recovery datastores
     * @param recoveryFolder     the recovery folder
     */
    public VmRecoverySettings(final String name, final String recoveryHost,
        final Map<String, String> recoveryNetworks,
        final Map<String, String> recoveryDatastores,
        final String recoveryFolder) {
      this.name = name;
      this.recoveryHost = recoveryHost;
      this.recoveryNetworks = recoveryNetworks;
      this.recoveryDatastores = recoveryDatastores;
      this.recoveryFolder = recoveryFolder;
    }

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
      return name;
    }

    /**
     * Gets recovery host.
     *
     * @return the recovery host
     */
    public String getRecoveryHost() {
      return recoveryHost;
    }

    /**
     * Gets recovery networks.
     *
     * @return the recovery networks
     */
    public Map<String, String> getRecoveryNetworks() {
      return recoveryNetworks;
    }

    /**
     * Gets recovery folder.
     *
     * @return the recovery folder
     */
    public String getRecoveryFolder() {
      return recoveryFolder;
    }

    /**
     * Gets recovery datastores.
     *
     * @return the recovery datastores
     */
    public Map<String, String> getRecoveryDatastores() {
      return recoveryDatastores;
    }

  }


  /**
   * The type Detailed recovery step.
   */
  @APIDoc
public static class DetailedRecoveryStep implements Serializable {

    private static final long serialVersionUID = 907290230974376861L;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String number;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String description;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String result;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String startTime;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String endTime;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String executionTime;

    /**
     * Instantiates a new Detailed recovery step.
     *
     * @param number        the number
     * @param description   the description
     * @param result        the result
     * @param startTime     the start time
     * @param endTime       the end time
     * @param executionTime the execution time
     */
    public DetailedRecoveryStep(final String number, final String description,
        final String result, final String startTime, final String endTime,
        final String executionTime) {
      this.number = number;
      this.description = description;
      this.result = result;
      this.startTime = startTime;
      this.endTime = endTime;
      this.executionTime = executionTime;
    }

    /**
     * Gets number.
     *
     * @return the number
     */
    public String getNumber() {
      return number;
    }

    /**
     * Gets description.
     *
     * @return the description
     */
    public String getDescription() {
      return description;
    }

    /**
     * Gets result.
     *
     * @return the result
     */
    public String getResult() {
      return result;
    }

    /**
     * Gets start time.
     *
     * @return the start time
     */
    public String getStartTime() {
      return startTime;
    }

    /**
     * Gets end time.
     *
     * @return the end time
     */
    public String getEndTime() {
      return endTime;
    }

    /**
     * Gets execution time.
     *
     * @return the execution time
     */
    public String getExecutionTime() {
      return executionTime;
    }

  }


  /**
   * The type Network mapping.
   */
  @APIDoc
public static class NetworkMapping implements Serializable {

    private static final long serialVersionUID = 2311453526611263992L;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String sourceNetwork;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String failoverMoveTargetNetwork;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String failoverTestTargetNetwork;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String reverseConfigurationFailoverTestNetwork;

    /**
     * Instantiates a new Network mapping.
     *
     * @param sourceNetwork                           the source network
     * @param failoverMoveTargetNetwork               the failover move test network
     * @param failoverTestTargetNetwork               the failover test target network
     * @param reverseConfigurationFailoverTestNetwork the reverse configuration
     *                                                failover test network
     */
    public NetworkMapping(final String sourceNetwork,
        final String failoverMoveTargetNetwork,
        final String failoverTestTargetNetwork,
        final String reverseConfigurationFailoverTestNetwork) {
      this.sourceNetwork = sourceNetwork;
      this.failoverMoveTargetNetwork = failoverMoveTargetNetwork;
      this.failoverTestTargetNetwork = failoverTestTargetNetwork;
      this.reverseConfigurationFailoverTestNetwork =
          reverseConfigurationFailoverTestNetwork;
    }

    /**
     * Gets source network.
     *
     * @return the source network
     */
    public String getSourceNetwork() {
      return sourceNetwork;
    }

    /**
     * Gets failover move test network.
     *
     * @return the failover move test network
     */
    public String getFailoverMoveTargetNetwork() {
      return failoverMoveTargetNetwork;
    }

    /**
     * Gets failover test target network.
     *
     * @return the failover test target network
     */
    public String getFailoverTestTargetNetwork() {
      return failoverTestTargetNetwork;
    }

    /**
     * Gets reverse configuration failover test network.
     *
     * @return the reverse configuration failover test network
     */
    public String getReverseConfigurationFailoverTestNetwork() {
      return reverseConfigurationFailoverTestNetwork;
    }

  }

  /**
   * Gets default test recovery network.
   *
   * @return the default test recovery network
   */
  public String getDefaultTestRecoveryNetwork() {
    return defaultTestRecoveryNetwork;
  }

  /**
   * The type Boot order setting.
   */
  @APIDoc
public static class BootOrderSetting implements Serializable {

    private static final long serialVersionUID = -1932694005070328868L;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String name;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String vmsInGroup;

    @Expose
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String startupDelay;

    /**
     * Instantiates a new Boot order setting.
     *
     * @param name         the name
     * @param vmsInGroup   the vms in group
     * @param startupDelay the startup delay
     */
    public BootOrderSetting(final String name, final String vmsInGroup,
        final String startupDelay) {
      this.name = name;
      this.vmsInGroup = vmsInGroup;
      this.startupDelay = startupDelay;
    }

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
      return name;
    }

    /**
     * Gets vms in group.
     *
     * @return the vms in group
     */
    public String getVmsInGroup() {
      return vmsInGroup;
    }

    /**
     * Gets startup delay.
     *
     * @return the startup delay
     */
    public String getStartupDelay() {
      return startupDelay;
    }

  }

}
