/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

/**
 * BackupConfigStatus.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public enum BackupConfigStatus {

  /**
   * Indicates that backups are configured on an entity. If the entity is a
   * folder-type (vApp or vDC), this indicates that backups are configured
   * on all existing children of the entity.
   */
  FULL,

  /**
   * Indicates that backups are partially configured on a folder-type entity.
   * This indicates that backups are configured on some but not all VMs within
   * the entity.
   */
  PARTIAL,

  /**
   * Indicates that backups are configured on all VMs within a folder-type
   * entity and that backups will be automatically configured on all
   * new entities within the parent.
   */
  FULL_AUTO,

  /**
   * Indicates that backups are configured on some VMs within a folder-type
   * entity and that backups will be automatically configured on all
   * new entities within the parent.
   */
  PARTIAL_AUTO

}
