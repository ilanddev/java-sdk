/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.io.Serializable;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Office 365 VBO SharePoint Attachment response.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365SharePointAttachmentResponse implements Serializable {

  private static final long serialVersionUID = -3093364710114733375L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The Veeam native ID of the backed up SharePoint Attachment.")
  private final String id;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The name of the backed up SharePoint Attachment.")
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The size of the backed up SharePoint Attachment in bytes.")
  private final long sizeBytes;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The URL of the backed up SharePoint Attachment.")
  private final String url;

  public O365SharePointAttachmentResponse(final String id, final String name,
      final long sizeBytes, final String url) {
    this.id = id;
    this.name = name;
    this.sizeBytes = sizeBytes;
    this.url = url;
  }

  /**
   * Returns the ID of the backed up SharePoint item attachment.
   *
   * @return a Veeam native ID
   */
  public String getId() {
    return id;
  }

  /**
   * Returns the name of the backed up SharePoint item attachment.
   *
   * @return the name of the backed up SharePoint item attachment
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the size of the item attachment.
   *
   * @return the size of the item attachment
   */
  public long getSizeBytes() {
    return sizeBytes;
  }

  /**
   * Returns the URL of th SharePoint item attachment.
   *
   * @return the URL of th SharePoint item attachment
   */
  public String getUrl() {
    return url;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final O365SharePointAttachmentResponse that =
        (O365SharePointAttachmentResponse) o;
    return sizeBytes == that.sizeBytes && Objects.equals(id, that.id) && Objects
        .equals(name, that.name) && Objects.equals(url, that.url);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, sizeBytes, url);
  }

}
