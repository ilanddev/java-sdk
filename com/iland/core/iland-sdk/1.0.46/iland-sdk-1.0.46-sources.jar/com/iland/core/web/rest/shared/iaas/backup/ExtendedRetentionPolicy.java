/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.common.enums.RunType;
import com.iland.cohesity.iaas.backups.policies.api.enums.ReplicationPeriodicity;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Extended Retention Policy.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class ExtendedRetentionPolicy implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Specifies the type of the backup run.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies the type of the backup run.")
  private final RunType backupRunType;

  /**
   * Specifies WORM retention type for the snapshots. When a WORM retention type
   * is specified, the snapshots of the Protection Groups using this policy will
   * be kept for the last N days as specified in the duration of the datalock.
   * During that time, the snapshots cannot be deleted.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies WORM retention type for the snapshots. When a WORM"
      + " retention type is specified, the snapshots of the Protection Groups"
      + " using this policy will be kept for the last N days as specified in"
      + " the duration of the datalock. During that time, the snapshots cannot"
      + " be deleted.")
  private final DatalockConfig datalockConfig;

  /**
   * Specifies the number of days to retain copied Snapshots on the target.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the number of days to retain copied Snapshots on "
      + "the target.")
  private final long daysToKeep;

  /**
   * Specifies a factor to multiply the periodicity by, to determine the copy
   * schedule. For example if set to 2 and the periodicity is hourly, then
   * Snapshots from the first eligible Job Run for every 2 hour period is
   * copied.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies a factor to multiply the periodicity by, to "
      + "determine the copy schedule. For example if set to 2 and the "
      + "periodicity is hourly, then Snapshots from the first eligible "
      + "Job Run for every 2 hour period is copied.")
  private final int multiplier;

  /**
   * Specifies the frequency that Snapshots should be copied to the specified
   * target. Used in combination with multiplier.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the frequency that Snapshots should be copied "
      + "to the specified target. Used in combination with multiplier.")
  private final ReplicationPeriodicity periodicity;

  /**
   * Instantiates a new Extended retention policy.
   *
   * @param backupRunType  the backup run type
   * @param datalockConfig the datalock configuration
   * @param daysToKeep     the days to keep
   * @param multiplier     the multiplier
   * @param periodicity    the periodicity
   */
  public ExtendedRetentionPolicy(final RunType backupRunType,
      final DatalockConfig datalockConfig, final long daysToKeep,
      final int multiplier, final ReplicationPeriodicity periodicity) {
    this.backupRunType = backupRunType;
    this.datalockConfig = datalockConfig;
    this.daysToKeep = daysToKeep;
    this.multiplier = multiplier;
    this.periodicity = periodicity;
  }

  /**
   * Gets backup run type.
   *
   * @return the backup run type
   */
  public Optional<RunType> getBackupRunType() {
    return Optional.ofNullable(backupRunType);
  }

  /**
   * Gets datalock configuration.
   *
   * @return the datalock configuration
   */
  public DatalockConfig getDatalockConfig() {
    return datalockConfig;
  }

  /**
   * Gets days to keep.
   *
   * @return the days to keep
   */
  public long getDaysToKeep() {
    return daysToKeep;
  }

  /**
   * Gets multiplier.
   *
   * @return the multiplier
   */
  public int getMultiplier() {
    return multiplier;
  }

  /**
   * Gets periodicity.
   *
   * @return the periodicity
   */
  public ReplicationPeriodicity getPeriodicity() {
    return periodicity;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final ExtendedRetentionPolicy that = (ExtendedRetentionPolicy) o;
    return daysToKeep == that.daysToKeep && multiplier == that.multiplier
        && backupRunType == that.backupRunType && Objects.equals(that.datalockConfig,
        datalockConfig) && periodicity == that.periodicity;
  }

  @Override
  public int hashCode() {
    return Objects.hash(backupRunType, datalockConfig, daysToKeep, multiplier,
        periodicity);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("backupRunType", backupRunType)
        .add("datalockConfig", datalockConfig).add("daysToKeep", daysToKeep)
        .add("multiplier", multiplier).add("periodicity", periodicity)
        .toString();
  }

}
