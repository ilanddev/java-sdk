/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.sso;

import java.time.Instant;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * A identity provider account link error.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIModel
public interface IdpAccountLinkErrorResponse {

  /**
   * The invalid username that was passed from the identity provider when
   * attempting to log in via SSO.
   */
  String invalidUsername();

  /**
   * The time the error occurred.
   */
  Instant date();
}
