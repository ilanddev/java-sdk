/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.company;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.user.DomainResponse;
import com.iland.core.web.rest.response.user.InvitationStatusResponse;
import com.iland.core.web.rest.response.user.LoginTypeResponse;
import com.iland.core.web.rest.response.user.UserTypeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Company User Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class CompanyUserResponse implements Serializable {

  private static final long serialVersionUID = -7248382243470607873L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected UserTypeResponse userType;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean locked;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String email;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String phone;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String company;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String address;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String city;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String state;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String zip;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String country;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String name;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String fullname;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected boolean deleted;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Instant createdDate;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Instant deletedDate;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected DomainResponse domain;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String firstName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String lastName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String role;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private LoginTypeResponse loginType;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private InvitationStatusResponse invitationStatus;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected boolean twoFactorEnabled;

  public CompanyUserResponse(final UserTypeResponse userType,
      final boolean locked, final String email, final String phone,
      final String company, final String address, final String city,
      final String state, final String zip, final String country,
      final String name, final String fullname, final boolean deleted,
      final Instant createdDate, final Instant deletedDate,
      final DomainResponse domain, final String firstName,
      final String lastName, final String role,
      final LoginTypeResponse loginType,
      final InvitationStatusResponse invitationStatus,
      final boolean twoFactorEnabled) {
    this.userType = userType;
    this.locked = locked;
    this.email = email;
    this.phone = phone;
    this.company = company;
    this.address = address;
    this.city = city;
    this.state = state;
    this.zip = zip;
    this.country = country;
    this.name = name;
    this.fullname = fullname;
    this.deleted = deleted;
    this.createdDate = createdDate;
    this.deletedDate = deletedDate;
    this.domain = domain;
    this.firstName = firstName;
    this.lastName = lastName;
    this.role = role;
    this.loginType = loginType;
    this.invitationStatus = invitationStatus;
    this.twoFactorEnabled = twoFactorEnabled;
  }

  /**
   * Gets user type.
   *
   * @return the user type
   */
  public UserTypeResponse getUserType() {
    return userType;
  }

  /**
   * Gets first name.
   *
   * @return the first name
   */
  public String getFirstName() {
    return firstName;
  }

  /**
   * Gets last name.
   *
   * @return the last name
   */
  public String getLastName() {
    return lastName;
  }

  /**
   * Gets email.
   *
   * @return the email
   */
  public String getEmail() {
    return email;
  }

  /**
   * Gets phone.
   *
   * @return the phone
   */
  public String getPhone() {
    if (phone == null) {
      return "";
    }
    return phone;
  }

  /**
   * Is locked boolean.
   *
   * @return the boolean
   */
  public boolean isLocked() {
    return locked;
  }

  /**
   * Gets address.
   *
   * @return the address
   */
  public String getAddress() {
    return address;
  }

  /**
   * Gets company.
   *
   * @return the company
   */
  public String getCompany() {
    return company;
  }

  /**
   * Gets city.
   *
   * @return the city
   */
  public String getCity() {
    return city;
  }

  /**
   * Gets state.
   *
   * @return the state
   */
  public String getState() {
    return state;
  }

  /**
   * Gets zip code.
   *
   * @return the zip code
   */
  public String getZipCode() {
    return zip;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets fullname.
   *
   * @return the fullname
   */
  public String getFullname() {
    return fullname;
  }

  /**
   * Is deleted boolean.
   *
   * @return the boolean
   */
  public boolean isDeleted() {
    return deleted;
  }


  /**
   * Gets created date.
   *
   * @return the created date
   */
  public Instant getCreatedDate() {
    return createdDate;
  }

  /**
   * Gets deleted date.
   *
   * @return the deleted date
   */
  public Instant getDeletedDate() {
    return deletedDate;
  }

  /**
   * Gets the domain.
   *
   * @return the domain
   */
  public DomainResponse getDomain() {
    return domain;
  }

  /**
   * Gets the country.
   *
   * @return the country
   */
  public String getCountry() {
    return country;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final CompanyUserResponse that = (CompanyUserResponse) o;
    return isLocked() == that.isLocked() && isDeleted() == that.isDeleted()
        && getUserType() == that.getUserType() && Objects
        .equals(getEmail(), that.getEmail()) && Objects
        .equals(getPhone(), that.getPhone()) && Objects
        .equals(getCompany(), that.getCompany()) && Objects
        .equals(getAddress(), that.getAddress()) && Objects
        .equals(getCity(), that.getCity()) && Objects
        .equals(getState(), that.getState()) && Objects.equals(zip, that.zip)
        && getCountry() == that.getCountry() && Objects
        .equals(getName(), that.getName()) && Objects
        .equals(getFullname(), that.getFullname()) && Objects
        .equals(getCreatedDate(), that.getCreatedDate()) && Objects
        .equals(getDeletedDate(), that.getDeletedDate()) && Objects
        .equals(getDomain(), that.getDomain()) && Objects
        .equals(getFirstName(), that.getFirstName()) && Objects
        .equals(getLastName(), that.getLastName()) && Objects
        .equals(role, that.role);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(getUserType(), isLocked(), getEmail(), getPhone(), getCompany(),
            getAddress(), getCity(), getState(), zip, getCountry(), getName(),
            getFullname(), isDeleted(), getCreatedDate(), getDeletedDate(),
            getDomain(), getFirstName(), getLastName(), role);
  }

  @Override
  public String toString() {
    return "CompanyUserResponse{" + "userType=" + userType + ", locked="
        + locked + ", email='" + email + '\'' + ", phone='" + phone + '\''
        + ", company='" + company + '\'' + ", address='" + address + '\''
        + ", city='" + city + '\'' + ", state='" + state + '\'' + ", zip='"
        + zip + '\'' + ", country=" + country + ", name='" + name + '\''
        + ", fullname='" + fullname + '\'' + ", deleted=" + deleted
        + ", createdDate=" + createdDate + ", deletedDate=" + deletedDate
        + ", domain=" + domain + ", firstName='" + firstName + '\''
        + ", lastName='" + lastName + '\'' + ", role='" + role + '\'' + '}';
  }

}
