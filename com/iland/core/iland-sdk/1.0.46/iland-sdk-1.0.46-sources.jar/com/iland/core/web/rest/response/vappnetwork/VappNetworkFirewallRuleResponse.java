/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vappnetwork;

import java.io.Serializable;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Network Firewall Rule Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappNetworkFirewallRuleResponse implements Serializable {

  private static final long serialVersionUID = 417740632982765773L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String destinationIp;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String destinationPortRange;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String direction;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String icmpSubType;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String id;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String policy;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int port;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Set<String> protocols;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String sourceIp;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int sourcePort;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String sourcePortRange;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean loggingEnabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean enabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean matchOnTranslate;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int ruleIndex;

  public VappNetworkFirewallRuleResponse(final String description,
      final String destinationIp, final String destinationPortRange,
      final String direction, final String icmpSubType, final String id,
      final String policy, final int port, final Set<String> protocols,
      final String sourceIp, final int sourcePort, final String sourcePortRange,
      final boolean loggingEnabled, final boolean enabled,
      final boolean matchOnTranslate, final int ruleIndex) {
    this.description = description;
    this.destinationIp = destinationIp;
    this.destinationPortRange = destinationPortRange;
    this.direction = direction;
    this.icmpSubType = icmpSubType;
    this.id = id;
    this.policy = policy;
    this.port = port;
    this.protocols = protocols;
    this.sourceIp = sourceIp;
    this.sourcePort = sourcePort;
    this.sourcePortRange = sourcePortRange;
    this.loggingEnabled = loggingEnabled;
    this.enabled = enabled;
    this.matchOnTranslate = matchOnTranslate;
    this.ruleIndex = ruleIndex;
  }

  /**
   * Get the description.
   *
   * @return {@link String}
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get the destination ip.
   *
   * @return {@link String}
   */
  public String getDestinationIp() {
    return destinationIp;
  }

  /**
   * Get the destinatino port range.
   *
   * @return {@link String}
   */
  public String getDestinationPortRange() {
    return destinationPortRange;
  }

  /**
   * Get the direction.
   *
   * @return {@link String}
   */
  public String getDirection() {
    return direction;
  }

  /**
   * Get the Icmp sub type.
   *
   * @return {@link String}
   */
  public String getIcmpSubType() {
    return icmpSubType;
  }

  /**
   * Get the rule id.
   *
   * @return {@link String}
   */
  public String getId() {
    return id;
  }

  /**
   * Get the policy.
   *
   * @return {@link String}
   */
  public String getPolicy() {
    return policy;
  }

  /**
   * Get the port.
   *
   * @return port
   */
  public int getPort() {
    return port;
  }

  /**
   * Get the set of protocols.
   *
   * @return {@link Set} of {@link String}
   */
  public Set<String> getProtocols() {
    return protocols;
  }

  /**
   * Get the source ip.
   *
   * @return {@link String}
   */
  public String getSourceIp() {
    return sourceIp;
  }

  /**
   * Get the source port.
   *
   * @return source port
   */
  public int getSourcePort() {
    return sourcePort;
  }

  /**
   * Get the source port range.
   *
   * @return {@link String}
   */
  public String getSourcePortRange() {
    return sourcePortRange;
  }

  /**
   * Get whether logging is enabled.
   *
   * @return logging enabled
   */
  public boolean isLoggingEnabled() {
    return loggingEnabled;
  }

  /**
   * Get whehter the rule is enabled.
   *
   * @return is enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Get whether it matches on translate.
   *
   * @return match on translate
   */
  public boolean isMatchOnTranslate() {
    return matchOnTranslate;
  }

  /**
   * Get the application index of this firewall rule (in relation to other
   * firewall rules for a particular edge gateway).
   * <p>
   * We track this because vCloud rule ids do not specify firewall rule order.
   *
   * @return rule index
   */
  public int getRuleIndex() {
    return ruleIndex;
  }

}
