/*
 * Copyright (c) 2022, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscanfree;

import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * {@link ScanTarget Scan Target}.
 *
 * @author <a href="mailto:tspilman@iland.com">Tag Spilman</a>
 */
@APIModel
public interface ScanTarget {

	/**
	 * The target.
	 *
	 * @return the target
	 */
	String target();

	/**
	 * Is scannable?.
	 *
	 * @return scannable
	 */
	boolean isScannable();

	/**
	 * Get message.
	 *
	 * @return the message
	 */
	Optional<String> message();

}
