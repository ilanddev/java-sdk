/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * BackupGroupSummaryStats.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public final class BackupGroupSummaryStatsResponse {

  @Expose
  @JsonRequired("The backup group UID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String backupGroupUid;

  @Expose
  @JsonRequired("The backup summary stats.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupSummaryStats stats;

  public BackupGroupSummaryStatsResponse(final String backupGroupUid,
      final BackupSummaryStats stats) {
    this.backupGroupUid = backupGroupUid;
    this.stats = stats;
  }

  /**
   * The backup group UID.
   */
  public String getBackupGroupUid() {
    return backupGroupUid;
  }

  /**
   * Summary stats for the backup group.
   */
  public BackupSummaryStats getStats() {
    return stats;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BackupGroupSummaryStatsResponse that =
        (BackupGroupSummaryStatsResponse) o;
    return Objects.equals(backupGroupUid, that.backupGroupUid) && Objects
        .equals(stats, that.stats);
  }

  @Override
  public int hashCode() {
    return Objects.hash(backupGroupUid, stats);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("backupGroupUid", backupGroupUid).add("stats", stats).toString();
  }
}
