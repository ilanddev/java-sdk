/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the "LICENSE.txt" file that accompanied this software. Any inquiries
 *  concerning the scope or enforceability of the license should be addressed
 *  to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 */

package com.iland.core.web.rest.response.iaas.backup;

import com.iland.cohesity.iaas.backups.common.enums.FileSearchResultType;
import com.iland.core.web.rest.annotation.APIModel;

/**
 * RecoverableFilesSearchResult.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface RecoverableFileSearchResult {

  /**
   * The ID of the location that the result is associated with.
   */
  String locationId();

  /**
   * The ID of the company that the result is associated with.
   */
  String companyId();

  /**
   * The UUID of the Org that the result is associated with.
   */
  String orgUuid();

  /**
   * The UUID of the vDC that the result is associated with.
   */
  String vdcUuid();

  /**
   * The UUID of the vApp that the result is associated with.
   */
  String vappUuid();

  /**
   * The UUID of the VM that the result is associated with.
   */
  String vmUuid();

  /**
   * Specifies the name of the found file or folder.
   */
  String filename();

  /**
   * Specifies if the found item is a folder. If true, the found item is a
   * folder.
   */
  boolean isFolder();

  /**
   * Specifies the UID of the backup group that is currently associated with the
   * object that contains the backed up file or folder.
   */
  String backupGroupUid();

  /**
   * Specifies the type of the file document such as DIRECTORY, FILE, etc.
   */
  FileSearchResultType type();

  /**
   * The name of the associated VM.
   */
  String vmName();

}
