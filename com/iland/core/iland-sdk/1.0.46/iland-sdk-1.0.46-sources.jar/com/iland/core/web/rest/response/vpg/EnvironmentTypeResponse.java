/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vpg;

/**
 * Environment Type Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public enum EnvironmentTypeResponse {

  VC_VPG,

  VC_VAPP,

  VCD_VAPP,

  PUBLIC_CLOUD,

  HYPERV

}
