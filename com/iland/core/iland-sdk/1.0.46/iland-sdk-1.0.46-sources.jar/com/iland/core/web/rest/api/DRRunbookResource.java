/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.api;

import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.web.rest.request.recovery.DisasterRecoveryRunbookAbortRequest;
import com.iland.core.web.rest.request.recovery.DisasterRecoveryRunbookExecuteRequest;
import com.iland.core.web.rest.request.recovery.DisasterRecoveryRunbookFinalizeExecutionRequest;
import com.iland.core.web.rest.request.recovery.DisasterRecoveryRunbookTestRequest;
import com.iland.core.web.rest.request.recovery.DisasterRecoveryRunbookUpdateRequest;
import com.iland.core.web.rest.response.recovery.DisasterRecoveryRunbookReportDetailsResponse;
import com.iland.core.web.rest.response.recovery.DisasterRecoveryRunbookResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Recovery Runbook Resource Interface.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIProperties(name = "Disaster Recovery")
@Path("/disaster-recovery-runbooks")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface DRRunbookResource {

  /**
   * Test a runbook.
   *
   * @param runbookUuid the UUID of the runbook.
   * @param params      the runbook test parameters
   * @return asynchronous task details
   */
  @POST
  @Path("/{runbookUuid}/actions/test")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse testRunbook(@PathParam("runbookUuid") String runbookUuid,
      DisasterRecoveryRunbookTestRequest params);

  /**
   * Execute a runbook.
   *
   * @param runbookUuid the UUID of the runbook.
   * @param params      the runbook execution parameters
   * @return asynchronous task details
   */
  @POST
  @Path("/{runbookUuid}/actions/execute")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse executeRunbook(@PathParam("runbookUuid") String runbookUuid,
      DisasterRecoveryRunbookExecuteRequest params);

  /**
   * Gets a runbook by UUID.
   *
   * @param runbookUuid the UUID of the runbook.
   * @return the runbook
   */
  @GET
  @Path("/{runbookUuid}")
  DisasterRecoveryRunbookResponse getDisasterRecoveryRunbook(
      @PathParam("runbookUuid") String runbookUuid);

  /**
   * Update a runbook by its UUID.
   *
   * @param runbookUuid the UUID of the runbook
   * @param spec        the specification for updating the runbook
   * @return the updated runbook
   */
  @PUT
  @Path("/{runbookUuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  DisasterRecoveryRunbookResponse updateRunbook(
      @PathParam("runbookUuid") String runbookUuid,
      DisasterRecoveryRunbookUpdateRequest spec);

  /**
   * Delete a runbook by its UUID.
   *
   * @param runbookUuid the UUID of the runbook
   */
  @DELETE
  @Path("/{runbookUuid}")
  void deleteRunbook(@PathParam("runbookUuid") String runbookUuid);

  /**
   * Finalize changes for the active runbook execution. The passed params
   * specify whether each recovery group should be rolled back or commited on a
   * per recovery group basis.
   *
   * @param runbookUuid the UUID of the runbook
   * @param request     the params for finalizing the runbook execution
   * @return asynchronous task details
   */
  @POST
  @Path("/{runbookUuid}/actions/finalize")
  TaskResponse finalizeExecution(@PathParam("runbookUuid") String runbookUuid,
      DisasterRecoveryRunbookFinalizeExecutionRequest request);

  /**
   * Get report summary data for a runbook task.
   *
   * @param taskUuid the uuid of the task to retrieve the report for
   * @return runbook report details
   */
  @GET
  @Path("/{runbookUuid}/runbook-task-details/{taskUuid}")
  DisasterRecoveryRunbookReportDetailsResponse getRecoveryRunbookReportDetails(
      @PathParam("runbookUuid") String runbookUuid,
      @PathParam("taskUuid") String taskUuid);

  /**
   * Download a PDF summary report for a runbook task.
   * <p>
   * The UUID of the task for the runbook operation is the report UUID.
   *
   * @param reportUuid the uuid of the task to retrieve the report for
   * @return failover report
   */
  @GET
  @Path("/{runbookUuid}/reports/{reportUuid}")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_PDF)
  InputStream downloadRunbookReport(
      @PathParam("runbookUuid") String runbookUuid,
      @PathParam("reportUuid") String reportUuid,
      @QueryParam("filename") String filename);

  /**
   * Abort a running disaster recovery runbook so that no new operations are
   * initiated upon recovery groups.
   *
   * @param runbookUuid the disaster recovery runbook UUID
   * @param request     a request for aborting a running recovery runbook operation
   * @return the aborted task
   */
  @POST
  @Path("/{runbookUuid}/actions/abort")
  TaskResponse abortRunbook(@PathParam("runbookUuid") String runbookUuid,
      DisasterRecoveryRunbookAbortRequest request);

}
