/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vm;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Guest Tools Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class GuestToolsResponse implements Serializable {

  private static final long serialVersionUID = 766404496419718391L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String status;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String runningStatus;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String version;

  public GuestToolsResponse(final String status, final String runningStatus,
      final String version) {
    this.status = status;
    this.runningStatus = runningStatus;
    this.version = version;
  }

  /**
   * Get the guest tools status.
   *
   * @return {@link String} status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Get the running status.
   *
   * @return {@link String} running status
   */
  public String getRunningStatus() {
    return runningStatus;
  }

  /**
   * Get the guest tools version.
   *
   * @return {@link String} version
   */
  public String getVersion() {
    return version;
  }

}
