/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscan;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Remediation Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public final class RemediationResponse {

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String value;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String remediation;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int hosts;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int vulns;

	public RemediationResponse(final String value, final String remediation,
		final int hosts, final int vulns) {
		this.value = value;
		this.remediation = remediation;
		this.hosts = hosts;
		this.vulns = vulns;
	}

	/**
	 * Get the value.
	 *
	 * @return {@link String} remediation value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Get the remediation.
	 *
	 * @return {@link String} remediation
	 */
	public String getRemediation() {
		return remediation;
	}

	/**
	 * Get the hosts.
	 *
	 * @return hosts
	 */
	public int getHosts() {
		return hosts;
	}

	/**
	 * Get the vulnerabilities.
	 *
	 * @return vulnerabilities
	 */
	public int getVulns() {
		return vulns;
	}

}
