/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;
import com.iland.offsite.replication.api.OffsiteReplicationPlatformApi;
import com.iland.offsite.replication.api.model.ReplicationInformationResponse;
import com.iland.offsite.replication.api.model.StorageHistoryResponse;

/**
 * Offset Replication resource.
 */
@APIProperties(name = "Offsite Replication")
@Path("/companies")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
@PlatformApi
public interface OffsetReplicationResource extends OffsiteReplicationPlatformApi {

	/**
	 * Get org-level replication information.
	 *
	 * @param orgUuid an org UUID
	 * @param start   optional timestamp parameter (inclusive, epoch milli)
	 * @param end     optional timestamp parameter (exclusive, epoch milli)
	 * @return {@link ReplicationInformationResponse replication information}
	 */
	@GET
	@Path("/{companyId}/orgs/{orgUuid}/replication-information")
	ReplicationInformationResponse getReplicationInformation(
		@SecureEntityRef(Permission.VIEW_COMPANY) @PathParam("companyId")
		String companyId,
		@SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
		String orgUuid, @QueryParam("start") Long start,
		@QueryParam("end") Long end);

	/**
	 * Get org-level storage history.
	 *
	 * @param orgUuid an org UUID
	 * @param start   optional timestamp parameter (inclusive, epoch milli)
	 * @param end     optional timestamp parameter (exclusive, epoch milli)
	 * @return {@link StorageHistoryResponse storage history}
	 */
	@GET
	@Path("/{companyId}/orgs/{orgUuid}/storage-history")
	StorageHistoryResponse getStorageHistory(
		@SecureEntityRef(Permission.VIEW_COMPANY) @PathParam("companyId")
		String companyId,
		@SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
		String orgUuid, @QueryParam("start") Long start,
		@QueryParam("end") Long end);

	/**
	 * Get org-level storage history report.
	 *
	 * @param orgUuid an org UUID
	 * @param start   optional timestamp parameter (inclusive, epoch milli)
	 * @param end     optional timestamp parameter (exclusive, epoch milli)
	 * @return virtual data center
	 */
	@GET
	@Path("/{companyId}/orgs/{orgUuid}/storage-history-report")
	@Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
	InputStream getStorageHistoryReport(
		@SecureEntityRef(Permission.VIEW_COMPANY) @PathParam("companyId")
		String companyId,
		@SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
		String orgUuid, @QueryParam("start") Long start,
		@QueryParam("end") Long end);

}
