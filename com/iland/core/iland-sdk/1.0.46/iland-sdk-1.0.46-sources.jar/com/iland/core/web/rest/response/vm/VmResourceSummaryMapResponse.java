/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.io.Serializable;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vm Resource Summary Map Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class VmResourceSummaryMapResponse implements Serializable {

  private static final long serialVersionUID = 6721777587523998935L;

  private static final String SUMMARIES = "summaries";

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(SUMMARIES)
  private Map<String, VmResourceSummaryResponse> summaryResponseMap;

  public VmResourceSummaryMapResponse(
      final Map<String, VmResourceSummaryResponse> summaryResponseMap) {
    this.summaryResponseMap = summaryResponseMap;
  }

  /**
   * Get the map of resource summaries.
   *
   * @return {@link Map} of {@link String} to {@link VmResourceSummaryResponse}
   */
  public Map<String, VmResourceSummaryResponse> getSummaryMap() {
    return summaryResponseMap;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final VmResourceSummaryMapResponse that = (VmResourceSummaryMapResponse) o;

    return summaryResponseMap.equals(that.summaryResponseMap);
  }

  @Override
  public int hashCode() {
    return summaryResponseMap.hashCode();
  }

  @Override
  public String toString() {
    return "VmResourceSummaryMapResponse{" + "summaryResponseMap="
        + summaryResponseMap + '}';
  }

}
