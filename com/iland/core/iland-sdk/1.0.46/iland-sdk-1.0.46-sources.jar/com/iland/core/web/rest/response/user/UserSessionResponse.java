/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.user;

import java.io.Serializable;
import java.time.Instant;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Session Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserSessionResponse implements Serializable {

  private static final long serialVersionUID = -4459851403645242808L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String sessionId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String ipAddress;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String username;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant start;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant lastAccess;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Map<String, String> clients;

  public UserSessionResponse(final String sessionId, final String ipAddress,
      final String username, final Instant start, final Instant lastAccess,
      final Map<String, String> clients) {
    this.sessionId = sessionId;
    this.ipAddress = ipAddress;
    this.username = username;
    this.start = start;
    this.lastAccess = lastAccess;
    this.clients = clients;
  }

  /**
   * Gets session id.
   *
   * @return the session id
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * Gets ip address.
   *
   * @return the ip address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Gets username.
   *
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Gets start.
   *
   * @return the start
   */
  public Instant getStart() {
    return start;
  }

  /**
   * Gets last access.
   *
   * @return the last access
   */
  public Instant getLastAccess() {
    return lastAccess;
  }

  /**
   * Gets clients.
   *
   * @return the clients
   */
  public Map<String, String> getClients() {
    return clients;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserSessionResponse that = (UserSessionResponse) o;

    if (sessionId != null ?
        !sessionId.equals(that.sessionId) :
        that.sessionId != null)
      return false;
    if (ipAddress != null ?
        !ipAddress.equals(that.ipAddress) :
        that.ipAddress != null)
      return false;
    if (username != null ?
        !username.equals(that.username) :
        that.username != null)
      return false;
    if (start != null ? !start.equals(that.start) : that.start != null)
      return false;
    if (lastAccess != null ?
        !lastAccess.equals(that.lastAccess) :
        that.lastAccess != null)
      return false;
    return clients != null ?
        clients.equals(that.clients) :
        that.clients == null;
  }

  @Override
  public int hashCode() {
    int result = sessionId != null ? sessionId.hashCode() : 0;
    result = 31 * result + (ipAddress != null ? ipAddress.hashCode() : 0);
    result = 31 * result + (username != null ? username.hashCode() : 0);
    result = 31 * result + (start != null ? start.hashCode() : 0);
    result = 31 * result + (lastAccess != null ? lastAccess.hashCode() : 0);
    result = 31 * result + (clients != null ? clients.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "UserSessionResponse{" + "sessionId='" + sessionId + '\''
        + ", ipAddress='" + ipAddress + '\'' + ", username='" + username + '\''
        + ", start=" + start + ", lastAccess=" + lastAccess + ", clients="
        + clients + '}';
  }

}
