/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vac;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VAC Wan Accelerator.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprza</a>
 */
@APIDoc
public final class BaWanAcceleratorResponse implements Serializable {

  private static final long serialVersionUID = 949926755415217576L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("System ID assigned to WAN accelerator in Veeam Availability Console RESTful API.")
  private final String id;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Name or IP-address of a machine which performs the role of WAN Accelerator.")
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("System ID assigned to a management agent that is installed on the backup server that runs WAN accelerator")
  private final String cloudConnectAgentUid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Indicates whether a WAN accelerator is on the client side")
  private final boolean isClientsAccelerator;

  public BaWanAcceleratorResponse(final String id, final String name,
      final String cloudConnectAgentUid, final boolean isClientsAccelerator) {
    this.id = id;
    this.name = name;
    this.cloudConnectAgentUid = cloudConnectAgentUid;
    this.isClientsAccelerator = isClientsAccelerator;
  }

  /**
   * Gets id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Gets name or IP-address of a machine which performs the role of WAN Accelerator.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets cloud connect agent uid.
   *
   * @return the cloud connect agent uid
   */
  public String getCloudConnectAgentUid() {
    return cloudConnectAgentUid;
  }

  /**
   * Is clients accelerator boolean.
   *
   * @return the boolean
   */
  public boolean isClientsAccelerator() {
    return isClientsAccelerator;
  }

}
