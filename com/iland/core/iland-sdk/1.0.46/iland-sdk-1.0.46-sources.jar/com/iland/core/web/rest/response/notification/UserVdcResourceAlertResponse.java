/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.notification;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Vdc Resource Alert Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserVdcResourceAlertResponse
    extends AbstractResourceAlertResponse {

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String vdcUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private long threshold;

  public UserVdcResourceAlertResponse(final String group, final String name,
      final String type, final String username, final String action,
      final String equalityRelation, final boolean enabled,
      final int breachPeriod, final String vdcUuid, final long threshold) {
    super(group, name, type, username, action, equalityRelation, enabled,
        breachPeriod);
    this.vdcUuid = vdcUuid;
    this.threshold = threshold;
  }

  /**
   * Get the Vdc uuid attached to this alert.
   *
   * @return {@link String} vdc uuid
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Get the alerting threshold at which the user wants to receive alerts for
   * the counter specified by group, name and type.
   *
   * @return alerting threshold
   */
  public long getThreshold() {
    return threshold;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserVdcResourceAlertResponse that = (UserVdcResourceAlertResponse) o;

    if (threshold != that.threshold)
      return false;
    return vdcUuid != null ?
        vdcUuid.equals(that.vdcUuid) :
        that.vdcUuid == null;
  }

  @Override
  public int hashCode() {
    int result = vdcUuid != null ? vdcUuid.hashCode() : 0;
    result = 31 * result + (int) (threshold ^ (threshold >>> 32));
    return result;
  }

  @Override
  public String toString() {
    return "UserVdcResourceAlertResponse{" + "vdcUuid='" + vdcUuid + '\''
        + ", threshold=" + threshold + ", group='" + group + '\'' + ", name='"
        + name + '\'' + ", type='" + type + '\'' + ", username='" + username
        + '\'' + ", action='" + action + '\'' + ", equalityRelation='"
        + equalityRelation + '\'' + ", enabled=" + enabled + ", breachPeriod="
        + breachPeriod + '}';
  }

}
