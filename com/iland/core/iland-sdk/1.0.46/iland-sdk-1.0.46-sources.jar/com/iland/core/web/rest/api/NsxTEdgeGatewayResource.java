/*
 * Copyright (c) 2013 - 2023, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.common.location.LocationPrefixedUuid;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.nsx.EdgeGatewayFirewallUpdateRequest;
import com.iland.core.web.rest.request.nsx.EdgeGatewayNATUpdateRequest;
import com.iland.core.web.rest.request.nsx.IpSetCreateRequest;
import com.iland.core.web.rest.request.nsx.IpSetUpdateRequest;
import com.iland.core.web.rest.request.nsxt.IpSecVpnTunnelRequest;
import com.iland.core.web.rest.request.nsxt.L2VpnTunnelRequest;
import com.iland.core.web.rest.request.nsxt.StaticGroupCreateRequest;
import com.iland.core.web.rest.request.nsxt.StaticRouteRequest;
import com.iland.core.web.rest.response.nsx.IPsecStatisticsResponse;
import com.iland.core.web.rest.response.nsx.IpSetListResponse;
import com.iland.core.web.rest.response.nsx.IpSetResponse;
import com.iland.core.web.rest.response.nsx.L2VPNStatisticsResponse;
import com.iland.core.web.rest.response.nsxt.IpSecVpnTunnel;
import com.iland.core.web.rest.response.nsxt.IpSecVpnTunnelList;
import com.iland.core.web.rest.response.nsxt.L2VpnTunnel;
import com.iland.core.web.rest.response.nsxt.L2VpnTunnelList;
import com.iland.core.web.rest.response.nsxt.NsxTIpsecVpnStatisticsResponse;
import com.iland.core.web.rest.response.nsxt.StaticGroup;
import com.iland.core.web.rest.response.nsxt.StaticGroupAssociatedVMs;
import com.iland.core.web.rest.response.nsxt.StaticGroupsList;
import com.iland.core.web.rest.response.nsxt.StaticRouteResponse;
import com.iland.core.web.rest.response.nsxt.StaticRoutes;
import com.iland.core.web.rest.response.task.TaskListResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.shared.nsxt.ApplicationPortProfileReferenceList;
import com.iland.core.web.rest.shared.nsxt.EdgeDhcpForwardConfig;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;
import com.iland.vcloud.common.edge.FirewallPersistenceApi;
import com.iland.vcloud.common.edge.NatPersistenceApi;
import com.iland.vcloud.common.edge.NatPortProfileApi;
import com.iland.vcloud.nsx.common.model.EdgeUuid;
import com.iland.vcloud.nsx.common.model.FirewallGroupUuid;
import com.iland.vcloud.nsxt.edge.EdgeDhcpForwarderApi;
import com.iland.vcloud.nsxt.edge.IpSetApi;
import com.iland.vcloud.nsxt.edge.IpsecVpnApi;
import com.iland.vcloud.nsxt.edge.L2VpnApi;
import com.iland.vcloud.nsxt.edge.StaticGroupsApi;
import com.iland.vcloud.nsxt.edge.StaticRoutesApi;

/**
 * NSX-T Edge Gateway REST resource V1.
 */
@APIProperties(name = "NSX-T Edge Gateways")
@Path("nsx-t/edge-gateways")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface NsxTEdgeGatewayResource
    extends L2VpnApi, NatPersistenceApi, FirewallPersistenceApi,
    NatPortProfileApi, IpSetApi, IpsecVpnApi, StaticGroupsApi,
    EdgeDhcpForwarderApi, StaticRoutesApi {

  /**
   * Create a new L2 VPN tunnel on a NSX-T Edge Gateway.
   * NSX-T L2VPN "Tunnels" are roughly analogous to NSX-V L2VPN "Sites."
   *
   * @param edgeUuid      the uuid of the edge gateway
   * @param createRequest request containing VPN tunnel parameters
   * @return {@link TaskResponse} the task associated with the create operation
   */
  @POST
  @Path("{edgeUuid}/l2vpn")
  TaskResponse createEdgeL2VpnTunnel(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_L2_VPN_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      L2VpnTunnelRequest createRequest);

  /**
   * Modify an existing L2 VPN tunnel on a NSX-T Edge Gateway.
   * NSX-T L2VPN "Tunnels" are roughly analogous to NSX-V L2VPN "Sites."
   *
   * @param edgeUuid      the uuid of the edge gateway
   * @param updateRequest request containing VPN tunnel parameters (tunnel id must be present)
   * @return {@link TaskResponse} the task associated with the modify operation
   */
  @PUT
  @Path("{edgeUuid}/l2vpn")
  TaskResponse modifyEdgeL2VpnTunnel(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_L2_VPN_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      L2VpnTunnelRequest updateRequest);

  /**
   * Delete an existing L2 VPN tunnel on a NSX-T Edge Gateway.
   * NSX-T L2VPN "Tunnels" are roughly analogous to NSX-V L2VPN "Sites."
   *
   * @param edgeUuid     the uuid of the edge gateway
   * @param l2TunnelUuid the uuid of the L2 VPN tunnel to delete
   * @return {@link TaskResponse} the task associated with the delete operation
   */
  @DELETE
  @Path("{edgeUuid}/l2vpn/{l2TunnelUuid}")
  TaskResponse deleteEdgeL2VpnTunnel(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_L2_VPN_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      @PathParam("l2TunnelUuid") LocationPrefixedUuid l2TunnelUuid);

  /**
   * Gets all L2 VPN tunnels for a NSX-T Edge Gateway.
   * NSX-T L2VPN "Tunnels" are roughly analogous to NSX-V L2VPN "Sites."
   *
   * @param edgeUuid the uuid of the edge gateway
   * @return {@link L2VpnTunnelList}
   */
  @GET
  @Path("{edgeUuid}/l2vpn")
  L2VpnTunnelList getEdgeL2VpnTunnels(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid);

  /**
   * Gets a specific L2 VPN tunnel on a NSX-T Edge Gateway.
   * NSX-T L2VPN "Tunnels" are roughly analogous to NSX-V L2VPN "Sites."
   *
   * @param edgeUuid     the uuid of the edge gateway
   * @param l2TunnelUuid the uuid of the L2 VPN tunnel to retrieve
   * @return {@link L2VpnTunnel}
   */
  @GET
  @Path("{edgeUuid}/l2vpn/{l2TunnelUuid}")
  L2VpnTunnel getEdgeL2VpnTunnel(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid, @PathParam("l2TunnelUuid") LocationPrefixedUuid l2TunnelUuid);

  /**
   * Gets statistics for all current L2 VPN tunnels on a NSX-T Edge Gateway.
   *
   * @param edgeUuid the uuid of the edge gateway
   * @return {@link L2VPNStatisticsResponse}
   */
  @GET
  @Path("{edgeUuid}/l2vpn/statistics")
  L2VPNStatisticsResponse getEdgeL2VpnStatistics(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid);

  /**
   * Updates the NAT configuration for an NSX-T Edge Gateway. The change(s) as
   * a result of the update are applied via asynchronous tasks.
   *
   * @param edgeUuid                    the uuid of the edge gateway
   * @param edgeGatewayNATUpdateRequest the payload containing the NAT update(s)
   * @return {@link TaskListResponse} a {@link TaskResponse} for each change to the NAT
   * configuration (create, update, delete) made as part of the update
   */
  @POST
  @Path("{edgeUuid}/nat")
  TaskListResponse updateEdgeGatewayNat(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid,
      EdgeGatewayNATUpdateRequest edgeGatewayNATUpdateRequest);

  /**
   * Gets the list of ICMP types available for use in the NAT rule configuration of
   * an NSX-T Edge Gateway.
   *
   * @param edgeUuid the edge uuid
   * @return {@link ApplicationPortProfileReferenceList}
   */
  @GET
  @Path("{edgeUuid}/nat/icmp-types")
  ApplicationPortProfileReferenceList getNatIcmpApplications(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid);

  /**
   * Updates the Firewall configuration for an NSX-T Edge Gateway. The change(s) as
   * a result of the update are applied via asynchronous tasks.
   *
   * @param edgeUuid                         the uuid of the edge gateway
   * @param edgeGatewayFirewallUpdateRequest the payload containing the Firewall update(s)
   * @return {@link TaskResponse} a {@link TaskResponse} for each change to the NAT
   * configuration (create, update, delete) made as part of the update
   */
  @PUT
  @Path("{edgeUuid}/firewall")
  TaskResponse updateEdgeGatewayFirewall(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid,
      EdgeGatewayFirewallUpdateRequest edgeGatewayFirewallUpdateRequest);

  /**
   * Get all IpSets for a given edge
   *
   * @param edgeUuid the given edge uuid
   * @param page     paging params. Default value 1
   * @param pageSize paging params. Default value 25
   * @return list response of ip sets
   */
  @GET
  @Path("{edgeUuid}/ip-sets")
  IpSetListResponse getIpSets(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid, @DefaultValue("1") @QueryParam("page") Integer page,
      @DefaultValue("25") @QueryParam("pageSize") Integer pageSize);

  /**
   * Get a single IpSet for a given ip set Uuid
   *
   * @param ipSetUuid the given IpSet uuid (also known as firewallGroupUid)
   * @return the ip set response
   */
  @GET
  @Path("/{edgeUuid}/ip-set/{ipSetUuid}")
  IpSetResponse getIpSet(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid,
      @PathParam("ipSetUuid") FirewallGroupUuid ipSetUuid);

  /**
   * Creates an IpSet asynchronously
   *
   * @param edgeUuid the edge uuid associated with this request
   * @param request  the create payload
   * @return a task response for tracking the progress
   */
  @POST
  @Path("/{edgeUuid}/ip-set")
  TaskResponse createIpSet(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid, IpSetCreateRequest request);

  /**
   * Updates an IpSet asynchronously
   *
   * @param edgeUuid the edge uuid associated with this request
   * @param request  the update payload
   * @return a task response for tracking the progress
   */
  @PUT
  @Path("/{edgeUuid}/ip-set")
  TaskResponse updateIpSet(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid, IpSetUpdateRequest request);


  /**
   * Deletes an IpSet asynchronously
   *
   * @param edgeUuid  the edge uuid associated with this request
   * @param ipSetUuid the ipSet uuid associated with this request
   * @return a task response for tracking the progress
   */
  @DELETE
  @Path("/{edgeUuid}/ip-set/{ipSetUuid}")
  TaskResponse deleteIpSet(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      @PathParam("ipSetUuid") FirewallGroupUuid ipSetUuid);

  /**
   * IP Sets and Static Groups can be owned by either an Edge Gateway or vDC Group.
   * Use TaskResponse#other_attributes with this key on an IP set/Static Group
   * Task to retrieve the owner entity UUID.
   *
   * @return the TaskResponse other_attributes key
   */
  @GET
  @Path("grouping-objects/taskOwnerEntityKey")
  String getTaskOwnerEntityKey();

  /**
   * Create a new Ipsec VPN tunnel on a NSX-T Edge Gateway.
   * NSX-T Ipsec "Tunnels" are roughly analogous to NSX-V Ipsec "Sites."
   *
   * @param edgeUuid      the uuid of the edge gateway
   * @param createRequest request containing VPN tunnel parameters
   * @return {@link TaskResponse} the task associated with the create operation
   */
  @POST
  @Path("{edgeUuid}/ipsec")
  TaskResponse createEdgeIpSecVpnTunnel(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_IPSEC_VPN_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      IpSecVpnTunnelRequest createRequest);

  /**
   * Modify an existing Ipsec VPN tunnel on a NSX-T Edge Gateway.
   * NSX-T IpsecVPN "Tunnels" are roughly analogous to NSX-V Ipsec "Sites."
   *
   * @param edgeUuid      the uuid of the edge gateway
   * @param updateRequest request containing VPN tunnel parameters (tunnel id must be present)
   * @return {@link TaskResponse} the task associated with the modify operation
   */
  @PUT
  @Path("{edgeUuid}/ipsec")
  TaskResponse modifyEdgeIpSecVpnTunnel(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_IPSEC_VPN_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      IpSecVpnTunnelRequest updateRequest);

  /**
   * Delete an existing Ipsec VPN tunnel on a NSX-T Edge Gateway.
   * NSX-T Ipsec "Tunnels" are roughly analogous to NSX-V IpsecVPN "Sites."
   *
   * @param edgeUuid        the uuid of the edge gateway
   * @param ipsecTunnelUuid the uuid of the ipsec VPN tunnel to delete
   * @return {@link TaskResponse} the task associated with the delete operation
   */
  @DELETE
  @Path("{edgeUuid}/ipsec/{ipsecTunnelUuid}")
  TaskResponse deleteEdgeIpSecVpnTunnel(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_IPSEC_VPN_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      @PathParam("ipsecTunnelUuid") LocationPrefixedUuid ipsecTunnelUuid);

  /**
   * Gets all Ipsec VPN tunnels for a NSX-T Edge Gateway.
   * NSX-T Ipsec "Tunnels" are roughly analogous to NSX-V Ipsec "Sites."
   *
   * @param edgeUuid the uuid of the edge gateway
   * @return {@link IpSecVpnTunnelList}
   */
  @GET
  @Path("{edgeUuid}/ipsec")
  IpSecVpnTunnelList getEdgeIpSecVpnTunnels(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid);

  /**
   * Gets a specific Ipsec VPN tunnel on a NSX-T Edge Gateway.
   * NSX-T Ipsec "Tunnels" are roughly analogous to NSX-V Ipsec "Sites."
   *
   * @param edgeUuid        the uuid of the edge gateway
   * @param ipsecTunnelUuid the uuid of the Ipsec VPN tunnel to retrieve
   * @return {@link IpSecVpnTunnel}
   */
  @GET
  @Path("{edgeUuid}/ipsec/{ipsecTunnelUuid}")
  IpSecVpnTunnel getEdgeIpSecVpnTunnel(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid,
      @PathParam("ipsecTunnelUuid") LocationPrefixedUuid ipsecTunnelUuid);

  /**
   * Gets statistics for all current Ipsec VPN tunnels on a NSX-T Edge Gateway.
   *
   * @param edgeUuid the uuid of the edge gateway
   * @return {@link IPsecStatisticsResponse}
   */
  @GET
  @Path("{edgeUuid}/ipsec/statistics")
  NsxTIpsecVpnStatisticsResponse getEdgeIpSecVpnStatistics(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid);

  /**
   * Create a new firewall static group on a NSX-T Edge Gateway.
   *
   * @param edgeUuid      the uuid of the edge gateway
   * @param createRequest request containing static group parameters
   * @return {@link TaskResponse} the task associated with the create operation
   */
  @POST
  @Path("{edgeUuid}/static-groups")
  TaskResponse createStaticGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      StaticGroupCreateRequest createRequest);

  /**
   * Update an existing firewall static group on a NSX-T Edge Gateway.
   *
   * @param edgeUuid      the uuid of the edge gateway
   * @param updateRequest request containing static group parameters(static group id must be present)
   * @return {@link TaskResponse} the task associated with the modify operation
   */
  @PUT
  @Path("{edgeUuid}/static-group")
  TaskResponse updateStaticGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      StaticGroupCreateRequest updateRequest);

  /**
   * Delete an existing firewall static group on a NSX-T Edge Gateway.
   *
   * @param edgeUuid        the uuid of the edge gateway
   * @param staticGroupUuid the uuid of the static group to delete
   * @return {@link TaskResponse} the task associated with the delete operation
   */
  @DELETE
  @Path("{edgeUuid}/static-group/{staticGroupUuid}")
  TaskResponse deleteStaticGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      @PathParam("staticGroupUuid") FirewallGroupUuid staticGroupUuid);

  /**
   * Gets all firewall static groups for a NSX-T Edge Gateway.
   *
   * @param edgeUuid the uuid of the edge gateway
   * @param page     paging params. Default value 1
   * @param pageSize paging params. Default value 25
   * @return {@link StaticGroupsList}
   */
  @GET
  @Path("{edgeUuid}/static-groups")
  StaticGroupsList getStaticGroups(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid, @DefaultValue("1") @QueryParam("page") Integer page,
      @DefaultValue("25") @QueryParam("pageSize") Integer pageSize);

  /**
   * Gets a specific static group on a NSX-T Edge Gateway.
   *
   * @param staticGroupUuid the uuid of the static group to retrieve
   * @return {@link StaticGroup}
   */
  @GET
  @Path("{edgeUuid}/static-group/{staticGroupUuid}")
  StaticGroup getStaticGroup(@SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE)
  @PathParam(("edgeUuid")) EdgeUuid edgeUuid,
      @PathParam("staticGroupUuid") FirewallGroupUuid staticGroupUuid);

  /**
   * Gets static groups associated vms list(that are linked to member networks).
   *
   * @param firewallGroupUuid the uuid of the static group to retrieve
   * @param page     paging params. Default value 1
   * @param pageSize paging params. Default value 25
   * @return {@link StaticGroupAssociatedVMs}
   */
  @GET
  @Path("staticGroup/{staticGroupUuid}/associated-vms")
  StaticGroupAssociatedVMs getStaticGroupAssociatedVMs(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE)
      @PathParam("staticGroupUuid") FirewallGroupUuid firewallGroupUuid,
      @DefaultValue("1") @QueryParam("page") Long page,
      @DefaultValue("25") @QueryParam("pageSize") Long pageSize);

  /**
   * Retrieves the DHCP Forwarder configuration on an Edge Gateway. A routed Org vDC network
   * connected to this edge can choose to configure its DHCP configuration in RELAY mode which
   * will use this DHCP forwarder.
   *
   * @param edgeUuid the full edge UUID
   * @return {@link EdgeDhcpForwardConfig}
   */
  @GET
  @Path("dhcp-forwarder/{edgeUuid}")
  EdgeDhcpForwardConfig getDhcpForwarderConfiguration(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid);

  /**
   * Updates the DHCP forwarder configuration for an Edge Gateway.
   *
   * @param edgeUuid the full edge UUID
   * @param dhcpForwardConfig the updated DHCP forwarder config
   * @return {@link TaskResponse}
   */
  @PUT
  @Path("dhcp-forwarder/{edgeUuid}")
  TaskResponse updateDhcpForwarderConfiguration(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid, EdgeDhcpForwardConfig dhcpForwardConfig);

  /**
   * Create a new static route on a NSX-T Edge Gateway.
   *
   * @param edgeUuid      the uuid of the edge gateway
   * @param createRequest request containing static route parameters
   * @return {@link TaskResponse} the task associated with the create operation
   */
  @POST
  @Path("{edgeUuid}/static-route")
  TaskResponse createStaticRoute(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      StaticRouteRequest createRequest);

  /**
   * Update an existing firewall static route on a NSX-T Edge Gateway.
   *
   * @param edgeUuid      the uuid of the edge gateway
   * @param updateRequest request containing static route parameters(static route id must be present)
   * @return {@link TaskResponse} the task associated with the modify operation
   */
  @PUT
  @Path("{edgeUuid}/static-route")
  TaskResponse updateStaticRoute(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      StaticRouteRequest updateRequest);

  /**
   * Delete an existing static route on a NSX-T Edge Gateway.
   *
   * @param edgeUuid        the uuid of the edge gateway
   * @param staticRouteUuid the uuid of the static route to delete
   * @return {@link TaskResponse} the task associated with the delete operation
   */
  @DELETE
  @Path("{edgeUuid}/static-route/{staticRouteUuid}")
  TaskResponse deleteStaticRoute(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      @PathParam("staticRouteUuid") LocationPrefixedUuid staticRouteUuid);

  /**
   * Gets all static routes for a NSX-T Edge Gateway.
   *
   * @param edgeUuid the uuid of the edge gateway
   * @return {@link StaticRoutes}
   */
  @GET
  @Path("{edgeUuid}/static-routes")
  StaticRoutes getStaticRoutes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid);

  /**
   * Gets a specific static route on a NSX-T Edge Gateway.
   *
   * @param staticRouteUuid the uuid of the static route to retrieve
   * @return {@link StaticRouteResponse}
   */
  @GET
  @Path("{edgeUuid}/static-route/{staticRouteUuid}")
  StaticRouteResponse getStaticRoute(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE)
      @PathParam(("edgeUuid")) EdgeUuid edgeUuid,
      @PathParam("staticRouteUuid") LocationPrefixedUuid staticRouteUuid);
}
