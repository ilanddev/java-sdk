/*
 * Copyright (c) 2025, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Instant;
import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

@APIModel
public interface BackupGroupSummaryInfo {

	/**
	 * The backup group UID.
	 */
	String backupGroupUid();

	/**
	 * The backup group name.
	 */
	Optional<String> backupGroupName();

	/**
	 * The start time inclusive.
	 */
	Instant start();

	/**
	 * The end time inclusive.
	 */
	Instant end();

	/**
	 * The total number of bytes ingested.
	 */
	Long ingressBytes();

}
