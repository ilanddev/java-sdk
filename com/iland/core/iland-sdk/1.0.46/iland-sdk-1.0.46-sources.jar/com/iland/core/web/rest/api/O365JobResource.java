/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.api;

import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.vbo.O365CopyJobCreateRequest;
import com.iland.core.web.rest.request.vbo.O365CopyJobRestoreSessionRequest;
import com.iland.core.web.rest.request.vbo.O365CopyJobSchedulePolicyRequest;
import com.iland.core.web.rest.request.vbo.O365JobRequest;
import com.iland.core.web.rest.request.vbo.O365JobSchedulePolicyRequest;
import com.iland.core.web.rest.request.vbo.O365RestoreSessionStartRequest;
import com.iland.core.web.rest.response.vbo.O365CopyJobResponse;
import com.iland.core.web.rest.response.vbo.O365JobResponse;
import com.iland.core.web.rest.response.vbo.O365JobSessionSetResponse;
import com.iland.core.web.rest.response.vbo.O365RestoreSessionResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Office 365 VBO Job Resource.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIProperties(name = "Office 365 Backup")
@Path("/o365-jobs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface O365JobResource {

  /**
   * Get an Office 365 VBO Job.
   *
   * @param uuid The Office 365 VBO Job UUID
   * @return a {@link O365JobResponse} instance
   */
  @GET
  @Path("/{uuid}")
  O365JobResponse getJobByUuid(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_JOB) @PathParam("uuid")
          String uuid);

  /**
   * Get Office 365 VBO Job Sessions given a Job UUID.
   *
   * @param uuid     The Office 365 VBO Job UUID
   * @param page     the page
   * @param pageSize the page size
   * @return a {@link O365JobSessionSetResponse} instance
   */
  @GET
  @Path("/{uuid}/job-sessions")
  @SkipSecurityTest("We get both job uuid and copy job uuid here so we need to override this. Custom security logic in EJB.")
  O365JobSessionSetResponse getJobSessions(@PathParam("uuid")
          String uuid, @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize);

  /**
   * Starts a restore session for exploring and performing restore operations
   * with backups.
   *
   * @param uuid    The Office 365 VBO Job UUID
   * @param request a {@link O365RestoreSessionStartRequest}
   * @return a {@link O365RestoreSessionResponse} instance
   */
  @POST
  @Path("/{uuid}/actions/start-restore-session")
  @Consumes(MediaType.APPLICATION_JSON)
  O365RestoreSessionResponse startRestoreSession(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_JOB) @PathParam("uuid")
          String uuid,
      O365RestoreSessionStartRequest request);

  /**
   * Start a backup job given its UUID.
   *
   * @param uuid The Office 365 VBO Job UUID
   * @return a {@link O365JobResponse} instance
   */
  @POST
  @Path("/{uuid}/actions/start-backup-job")
  @Consumes(MediaType.APPLICATION_JSON)
  O365JobResponse startJob(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_JOB) @PathParam("uuid")
          String uuid);

  /**
   * Stop a backup job given its UUID.
   *
   * @param uuid The Office 365 VBO Job UUID
   * @return a {@link O365JobResponse} instance
   */
  @POST
  @Path("/{uuid}/actions/stop-backup-job")
  @Consumes(MediaType.APPLICATION_JSON)
  O365JobResponse stopJob(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_JOB) @PathParam("uuid")
          String uuid);

  /**
   * Enable a backup job given its UUID.
   *
   * @param uuid The Office 365 VBO Job UUID
   * @return a {@link O365JobResponse} instance
   */
  @POST
  @Path("/{uuid}/actions/enable")
  @Consumes(MediaType.APPLICATION_JSON)
  O365JobResponse enableJob(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_JOB) @PathParam("uuid")
          String uuid);

  /**
   * Disable a backup job given its UUID.
   *
   * @param uuid The Office 365 VBO Job UUID
   * @return a {@link O365JobResponse} instance
   */
  @POST
  @Path("/{uuid}/actions/disable")
  @Consumes(MediaType.APPLICATION_JSON)
  O365JobResponse disableJob(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_JOB) @PathParam("uuid")
          String uuid);

  /**
   * Modify a backup job given its UUID.
   *
   * @param uuid          The Office 365 VBO Job UUID
   * @param modifyRequest the {@link O365JobRequest} instance
   * @return a {@link O365JobResponse} instance
   */
  @PUT
  @Path("/{uuid}/actions/modifyJob")
  @Consumes(MediaType.APPLICATION_JSON)
  O365JobResponse modifyJob(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_JOB) @PathParam("uuid")
          String uuid, O365JobRequest modifyRequest);

  /**
   * Modify a backup job given its UUID. Currently only
   * modification of schedule policy is supported.
   *
   * @param uuid                  The Office 365 VBO Job UUID
   * @param schedulePolicyRequest the {@link O365JobSchedulePolicyRequest} instance
   * @return a {@link O365JobResponse} instance
   */
  @PUT
  @Path("/{uuid}/actions/modify")
  @Consumes(MediaType.APPLICATION_JSON)
  // TODO IC-5148 Remove this api after console starts using modifyJob api
  O365JobResponse modifyJobSchedulePolicy(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_JOB) @PathParam("uuid")
          String uuid, O365JobSchedulePolicyRequest schedulePolicyRequest);

  /**
   * Remove a backup job given its UUID.
   *
   * @param uuid The Office 365 VBO Job UUID
   */
  @DELETE
  @Path("/{uuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  void removeJob(
      @SecureEntityRef(Permission.DELETE_ILAND_O365_JOB) @PathParam("uuid")
          String uuid);

  /**
   * Create a backup copy job.
   *
   * @param uuid                     The Office 365 VBO copy Job UUID
   * @param o365CopyJobCreateRequest {@link O365CopyJobCreateRequest} copy job create request
   * @return {@link O365CopyJobResponse}  copy job response
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Path("/{uuid}/actions/create-copy-job")
  O365CopyJobResponse createCopyJob(
      @SecureEntityRef(Permission.CREATE_ILAND_O365_JOB) @PathParam("uuid")
      String uuid, O365CopyJobCreateRequest o365CopyJobCreateRequest);

  /**
   * Delete a backup copy job.
   *
   * @param uuid The Office 365 VBO Job UUID
   */
  @DELETE
  @Path("/copy-job/{uuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  void removeCopyJob(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_COPY_JOB) @PathParam("uuid")
      String uuid);

  /**
   * Get a backup copy job.
   *
   * @param uuid The Office 365 VBO Job UUID
   */
  @GET
  @Path("/copy-job/{uuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  O365CopyJobResponse getCopyJob(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_COPY_JOB) @PathParam("uuid")
      String uuid);

  /**
   * Start a restore session for a copy job.
   *
   * @param uuid                             The Office 365 VBO Copy Job UUID
   * @param o365CopyJobRestoreSessionRequest copy job restore session request
   * @return restore session response
   */
  @POST
  @Path("/copy-job/{uuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  O365RestoreSessionResponse startCopyJobRestoreSession(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_COPY_JOB) @PathParam("uuid")
      String uuid,
      O365CopyJobRestoreSessionRequest o365CopyJobRestoreSessionRequest);

  /**
   * Modify a copy job's schedule policy.
   *
   * @param uuid                  The Office 365 VBO Copy Job UUID
   * @param schedulePolicyRequest copy job schedule policy request
   * @return modified copy job
   */
  @PUT
  @Path("/copy-job/{uuid}/actions/modify")
  @Consumes(MediaType.APPLICATION_JSON)
  O365CopyJobResponse modifyCopyJobSchedulePolicy(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_COPY_JOB) @PathParam("uuid")
      String uuid, O365CopyJobSchedulePolicyRequest schedulePolicyRequest);

  /**
   * Download all the given job sessions as CSV file.
   *
   * @param uuid     The Office 365 VBO job UUID
   * @return a {@link InputStream} representing the job sessions file.
   */
  @POST
  @Path("/{uuid}/sessions-export")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream exportJobSessions(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_JOB)
      @PathParam("uuid") String uuid);

}
