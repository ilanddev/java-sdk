/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscan;

import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Network Scan Info Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public final class NetworkScanInfoResponse {

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String uuid;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean editAllowed;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String status;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String policy;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean pciCanUpload;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean hasAuditTrail;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private Instant scanStart;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int folderId;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String targets;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private Instant timestamp;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int objectId;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String scannerName;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean haskb;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int hostCount;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private Instant scanEnd;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String name;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int userPermissions;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean control;

	public NetworkScanInfoResponse(final String uuid, final boolean editAllowed,
		final String status, final String policy, final boolean pciCanUpload,
		final boolean hasAuditTrail, final Instant scanStart,
		final int folderId, final String targets, final Instant timestamp,
		final int objectId, final String scannerName, final boolean haskb,
		final int hostCount, final Instant scanEnd, final String name,
		final int userPermissions, final boolean control) {
		this.uuid = uuid;
		this.editAllowed = editAllowed;
		this.status = status;
		this.policy = policy;
		this.pciCanUpload = pciCanUpload;
		this.hasAuditTrail = hasAuditTrail;
		this.scanStart = scanStart;
		this.folderId = folderId;
		this.targets = targets;
		this.timestamp = timestamp;
		this.objectId = objectId;
		this.scannerName = scannerName;
		this.haskb = haskb;
		this.hostCount = hostCount;
		this.scanEnd = scanEnd;
		this.name = name;
		this.userPermissions = userPermissions;
		this.control = control;
	}

	/**
	 * Get the scan uuid.
	 *
	 * @return {@link String} uuid
	 */
	public String getUuid() {
		return uuid;
	}

	/**
	 * Get whether the scan is editable.
	 *
	 * @return is edit allowed
	 */
	public boolean isEditAllowed() {
		return editAllowed;
	}

	/**
	 * Get the scan status.
	 *
	 * @return {@link String} status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Get the scan policy.
	 *
	 * @return {@link String} policy
	 */
	public String getPolicy() {
		return policy;
	}

	/**
	 * Get whether PCI can upload.
	 *
	 * @return pci can upload
	 */
	public boolean isPciCanUpload() {
		return pciCanUpload;
	}

	/**
	 * Whether the scan has an audit trail.
	 *
	 * @return has audit trail
	 */
	public boolean isHasAuditTrail() {
		return hasAuditTrail;
	}

	/**
	 * Get the scan start.
	 *
	 * @return {@link String} scan start
	 */
	public Instant getScanStart() {
		return scanStart;
	}

	/**
	 * Get the folder ID.
	 *
	 * @return folder id
	 */
	public int getFolderId() {
		return folderId;
	}

	/**
	 * Get the scan targets.
	 *
	 * @return {@link String} scan targets
	 */
	public String getTargets() {
		return targets;
	}

	/**
	 * Get the scan timestamp.
	 *
	 * @return timestamp
	 */
	public Instant getTimestamp() {
		return timestamp;
	}

	/**
	 * Get the scan object ID.
	 *
	 * @return object ID
	 */
	public int getObjectId() {
		return objectId;
	}

	/**
	 * Get the scanner name.
	 *
	 * @return {@link String} scanner name
	 */
	public String getScannerName() {
		return scannerName;
	}

	/**
	 * Whether scan is Haskb.
	 *
	 * @return whether scan is haskb
	 */
	public boolean isHaskb() {
		return haskb;
	}

	/**
	 * Get the host count.
	 *
	 * @return host count
	 */
	public int getHostCount() {
		return hostCount;
	}

	/**
	 * Get the scan end.
	 *
	 * @return {@link String} scan end
	 */
	public Instant getScanEnd() {
		return scanEnd;
	}

	/**
	 * Get the scan name.
	 *
	 * @return {@link String} scan name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Set the scan name.
	 *
	 * @param name {@link String} scan name
	 */
	public void setName(final String name) {
		this.name = name;
	}

	/**
	 * Get the user permissions.
	 *
	 * @return user permissions
	 */
	public int getUserPermissions() {
		return userPermissions;
	}

	/**
	 * Get whether is control.
	 *
	 * @return control
	 */
	public boolean isControl() {
		return control;
	}

}
