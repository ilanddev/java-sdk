/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.network;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.IpRangeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Subnet Participation Update Request.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class SubnetParticipationResponse implements Serializable {

  private static final long serialVersionUID = 8040543580753135299L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String gateway;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String netmask;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String ipAddress;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Set<IpRangeResponse> ipRanges;

  public SubnetParticipationResponse(final String gateway, final String netmask,
      final String ipAddress, final Set<IpRangeResponse> ipRanges) {
    this.gateway = gateway;
    this.netmask = netmask;
    this.ipAddress = ipAddress;
    this.ipRanges = ipRanges;
  }

  /**
   * Gets the gateway property.
   *
   * @return {@link String} gateway name
   */
  public String getGateway() {
    return gateway;
  }

  /**
   * Gets the netmask property.
   *
   * @return {@link String} netmask
   */
  public String getNetmask() {
    return netmask;
  }

  /**
   * Gets the ip address property.
   *
   * @return {@link String} ip addresss
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Gets a copy of the list of ip ranges.
   *
   * @return {@link List} of {@link IpRangeResponse}
   */
  public Set<IpRangeResponse> getIpRanges() {
    return ipRanges;
  }

}
