/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vac;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.iland.core.web.rest.annotation.APIModel;

@APIModel
public interface BaCompanyResponse {

  /**
   * Gets company name configured in Veeam Cloud Connect or Veeam Availability Console.
   */
  String name();

  /**
   * Gets location id.
   */
  String locationId();

  /**
   * Gets last active.
   */
  Optional<Instant> lastActive();

  /**
   * Get the uuid for a VAC tenant.
   */
  String uuid();

  /**
   * Whether the VAC tenant is enabled or not.
   */
  @JsonProperty("is_enabled")
  boolean isEnabled();

  /**
   * Get the company id associated with the VAC tenant.
   */
  String companyId();

  /**
   * Indicates whether deleted backup file protection is enabled.
   */
  boolean backupProtectionEnabled();

  /**
   * Number of days during which deleted backup files must be kept in the
   * recycle bin on the Veeam Cloud Connect server.
   */
  int backupProtectionPeriod();

  /**
   * Gets number of virtual machines protected with backup jobs.
   */
  int vmsBackedUp();

  /**
   * Gets number of virtual machines backed up to a cloud repository.
   */
  int vmsBackedUpToCloud();

  /**
   * Total storage of the VAC tenant in MB.
   */
  long totalStorageQuota();

  /**
   * Used storage of the VAC tenant in MB.
   */
  long usedStorageQuota();

  /**
   * URL endpoint of the VAC tenant.
   */
  String endpoint();

  /**
   * Get the agent and sub tenant count.
   * This count composed of the licenses CC_Server_Backup and CC_Workstation_Backup.
   */
  int agentAndSubTenantCount();

  /**
   * Returns whether the tenant is managed by service provider
   */
  @JsonProperty("is_managed_by_service_provider")
  boolean isManagedByServiceProvider();

  /**
   * Indicates whether the tenant's repository is stored in AWS Object Storage
   */
  @JsonProperty("is_repository_stored_in_aws")
  boolean isRepositoryStoredInAws();

  /**
   * Indicates whether the tenant's repository immutability is enabled. This is valid only if the repository is stored using AWS Object Storage, indicated by the attribute isRepositoryStoredInAWS.
   */
  Optional<Boolean> isImmutabilityEnabled();

  /**
   * Duration of a tenant's repository immutability period, in seconds. This is valid only if the repository is stored using AWS Object Storage, indicated by the attribute isRepositoryStoredInAWS.
   */
  Optional<Integer> immutabilityInterval();

  /**
   * Is the VAC tenant a test drive tenant?
   */
  boolean testDrive();

  // TODO: Remove after v3 upgrade on prod
  List<BaBackupResourceResponse> backupResources();

  /**
   * The contract uuid of the company that the VAC tenant belongs to.
   *
   * @return {@link String} contract uuid
   */
  String contractUuid();

  /**
   * The description of the VAC tenant.
   *
   * @return {@link String} description
   */
  String description();

  /**
   * The instance uid of the VAC tenant.
   *
   * @return {@link String} instance uid
   */
  String instanceUid();

}
