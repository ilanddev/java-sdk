/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Specifies information about a disk unit in a controller.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class BackupGroupDiskUnit implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Specifies the ID of the controller bus that controls the disk.
   */
  @Expose
  @JsonRequired(
      "Specifies the ID of the controller bus that controls the " + "disk.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Long busNumber;

  /**
   * Specifies the controller type like SCSI, or IDE etc.
   */
  @Expose
  @JsonRequired("Specifies the controller type like SCSI, or IDE etc.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String controllerType;

  /**
   * Specifies the disk file name. This is the VMDK name and not the flat file
   * name.
   */
  @Expose
  @JsonRequired("Specifies the disk file name. This is the VMDK name and not "
      + "the flat file name.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Long unitNumber;

  /**
   * Instantiates a new DiskUnit.
   *
   * @param busNumber      see {@link BackupGroupDiskUnit#getBusNumber}
   * @param controllerType see {@link BackupGroupDiskUnit#getControllerType}
   * @param unitNumber     see {@link BackupGroupDiskUnit#getUnitNumber}
   */

  public BackupGroupDiskUnit(final Long busNumber,
      final String controllerType, final Long unitNumber) {
    this.busNumber = busNumber;
    this.controllerType = controllerType;
    this.unitNumber = unitNumber;
  }

  /**
   * Specifies the Id of the controller bus that controls the disk.
   *
   * @return the bus Number
   */
  public Long getBusNumber() {
    return this.busNumber;
  }

  /**
   * Specifies the controller type like SCSI, or IDE etc.
   *
   * @return the controller Type
   */
  public String getControllerType() {
    return this.controllerType;
  }

  /**
   * Specifies the disk file name. This is the VMDK name and not the flat file
   * name.
   *
   * @return the unit Number
   */
  public Long getUnitNumber() {
    return this.unitNumber;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BackupGroupDiskUnit that = (BackupGroupDiskUnit) o;
    return Objects.equals(busNumber, that.busNumber) && Objects
        .equals(controllerType, that.controllerType) && Objects
        .equals(unitNumber, that.unitNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(busNumber, controllerType, unitNumber);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("busNumber", busNumber)
        .add("controllerType", controllerType).add("unitNumber", unitNumber)
        .toString();
  }
}
