/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Specifies settings for indexing files found in an Object (such as a VM) so
 * these files can be searched and recovered. This also specifies inclusion and
 * exclusion rules that determine the directories to index.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class BackupGroupIndexingPolicy implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Array of Indexed Directories.
   * <p>
   * Specifies a list of directories to index.
   */
  @Expose
  @JsonRequired("Array of Indexed Directories. Specifies a list of "
      + "directories to index.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<String> allowPrefixes;

  /**
   * Array of Excluded Directories.
   * <p>
   * Specifies a list of directories to exclude from indexing.
   */
  @Expose
  @JsonRequired("Array of Excluded Directories. Specifies a list of "
      + "directories to exclude from indexing.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<String> denyPrefixes;

  /**
   * Specifies if the files found in an Object (such as a VM) should be indexed.
   * If false (the default), files are indexed.
   */
  @Expose
  @JsonRequired(
      "Specifies if the files found in an Object (such as a VM) should be "
          + "indexed. If false (the default), files are indexed.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean disableIndexing;

  /**
   * Instantiates a new IndexingPolicy.
   *
   * @param allowPrefixes   see
   * {@link BackupGroupIndexingPolicy#getAllowPrefixes}
   * @param denyPrefixes    see
   * {@link BackupGroupIndexingPolicy#getDenyPrefixes}
   * @param disableIndexing see
   * {@link BackupGroupIndexingPolicy#isDisableIndexing}
   */

  public BackupGroupIndexingPolicy(final List<String> allowPrefixes,
      final List<String> denyPrefixes, final boolean disableIndexing) {
    this.allowPrefixes =
        allowPrefixes != null ? allowPrefixes : Collections.emptyList();
    this.denyPrefixes =
        denyPrefixes != null ? denyPrefixes : Collections.emptyList();
    this.disableIndexing = disableIndexing;
  }

  /**
   * Array of Indexed Directories.
   * <p>
   * Specifies a list of directories to index.
   *
   * @return the allow Prefixes
   */
  public List<String> getAllowPrefixes() {
    return this.allowPrefixes;
  }

  /**
   * Array of Excluded Directories.
   * <p>
   * Specifies a list of directories to exclude from indexing.
   *
   * @return the deny Prefixes
   */
  public List<String> getDenyPrefixes() {
    return this.denyPrefixes;
  }

  /**
   * Specifies if the files found in an Object (such as a VM) should be indexed.
   * If false (the default), files are indexed.
   *
   * @return disable Indexing
   */
  public boolean isDisableIndexing() {
    return this.disableIndexing;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BackupGroupIndexingPolicy that = (BackupGroupIndexingPolicy) o;
    return Objects.equals(allowPrefixes, that.allowPrefixes) && Objects
        .equals(denyPrefixes, that.denyPrefixes) && Objects
        .equals(disableIndexing, that.disableIndexing);
  }

  @Override
  public int hashCode() {
    return Objects.hash(allowPrefixes, denyPrefixes, disableIndexing);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("allowPrefixes", allowPrefixes)
        .add("denyPrefixes", denyPrefixes)
        .add("disableIndexing", disableIndexing).toString();
  }
}
