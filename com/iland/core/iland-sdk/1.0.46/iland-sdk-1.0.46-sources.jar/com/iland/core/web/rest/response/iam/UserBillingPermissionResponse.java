/*
 * Copyright (c) 2013 - 2025, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.iam;

import java.util.List;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * A billing relevant permission and the inventory entities a user can use the
 * permission with.
 */
@APIModel
public interface UserBillingPermissionResponse {

    /**
     * The name of the billing permission.
     */
    String permission();

    /**
     * The list of inventory entities the user can use with the billing
     * permission.
     */
    List<UserInventoryEntityResponse> entitiesForPermission();

}
