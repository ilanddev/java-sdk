/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.YearMonth;
import java.util.Optional;

import org.immutables.value.Value;

import com.iland.core.web.rest.annotation.APIModel;
import com.iland.core.web.rest.shared.billing.CurrencyCode;

/**
 * IaaS Backup Bill.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface IaasBackupBill {

  /**
   * The ID of the company that is associated with the bill.
   */
  String companyId();

  /**
   * The ID of the location that is associated with the bill.
   */
  String locationId();

  /**
   * The UUID of the org that is associated with the bill.
   */
  String orgUuid();

  /**
   * The UUID of the vDC that is associated with the bill.
   */
  String vdcUuid();

  /**
   * The billing year.
   */
  int year();

  /**
   * The billing month, in range 1-12.
   */
  int month();

  /**
   * The billing year and month.
   */
  @Value.Derived
  default YearMonth yearMonth() {
    return YearMonth.of(year(), month());
  }

  /**
   * The number of byte-hours that have been consumed as burst.
   */
  long burstUsageByteHours();

  /**
   * The total number of byte-hours that have been consumed.
   */
  long totalUsageByteHours();

  /**
   * The total number of byte-hours that have been consumed by local backups.
   */
  long localUsageByteHours();

  /**
   * The total number of byte-hours that have been consumed by remote backups.
   */
  long remoteUsageByteHours();

  /**
   * The total cost of burst usage.
   */
  double burstCost();

  /**
   * The total cost of reserved usage.
   */
  double reservedCost();

  /**
   * The relevant currency.
   */
  CurrencyCode currencyCode();

  /**
   * The contracted reserve storage measured in bytes.
   */
  Optional<Long> reservedStorageBytes();

  /**
   * The total number of bytes ingested.
   */
  Optional<Long> ingressBytes();

}
