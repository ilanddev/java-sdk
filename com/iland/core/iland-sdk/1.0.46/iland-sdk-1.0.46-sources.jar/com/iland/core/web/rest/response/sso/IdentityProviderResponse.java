/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.sso;

import com.iland.core.api.sso.IdentityProviderType;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Identity Provider Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public abstract class IdentityProviderResponse {

  /**
   * Whether or not to force all users to sign in using SSO. If enabled
   * all users, even local AD users are forced to sign in through SSO.
   */
  public abstract boolean enforceSso();

  /**
   * Turn the provider on/off.
   */
  public abstract boolean enabled();

  /**
   * The identity provider type.
   */
  public abstract IdentityProviderType type();
}
