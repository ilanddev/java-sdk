/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Continuous Schedule.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class ContinuousSchedule implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * If specified, this field defines the time interval in minutes when new Group
   * Runs are started.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("If specified, this field defines the time interval in "
      + "minutes when new Group Runs are started.")
  private final long backupIntervalMins;

  /**
   * Instantiates a new ContinuousSchedule.
   *
   * @param backupIntervalMins If specified, this field defines the time
   *                           interval in minutes when new Group Runs are
   *                           started.
   */
  public ContinuousSchedule(final long backupIntervalMins) {
    this.backupIntervalMins = backupIntervalMins;
  }

  /**
   * If specified, this field defines the time interval in minutes when new Group
   * Runs are started.
   *
   * @return backupIntervalMins
   */
  public long getBackupIntervalMins() {
    return this.backupIntervalMins;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final ContinuousSchedule that = (ContinuousSchedule) o;
    return Objects.equals(backupIntervalMins, that.backupIntervalMins);
  }

  @Override
  public int hashCode() {
    return Objects.hash(backupIntervalMins);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("backupIntervalMins", backupIntervalMins).toString();
  }
}
