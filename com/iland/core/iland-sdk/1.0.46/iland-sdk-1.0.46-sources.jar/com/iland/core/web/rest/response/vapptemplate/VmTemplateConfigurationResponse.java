/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vapptemplate;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VM Template Configuration Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VmTemplateConfigurationResponse implements Serializable {

  private static final long serialVersionUID = 4302514888955162487L;

  @Expose
  @SerializedName("uuid")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @SerializedName("name")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @SerializedName("description")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String description;

  @Expose
  @SerializedName("memory_in_bytes")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long memoryInBytes;

  @Expose
  @SerializedName("number_of_cpus")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int numberOfCpus;

  @Expose
  @SerializedName("number_of_cores_per_socket")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int numberOfCpuCoresPerSocket;

  @Expose
  @SerializedName("storage_profile_uuid")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String storageProfileUuid;

  @Expose
  @SerializedName("hardware_version")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String hardwareVersion;

  @Expose
  @SerializedName("operating_system_version")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String operatingSystemVersion;

  @Expose
  @SerializedName("expose_cpu_virtualization")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean exposeCpuVirtualization;

  @Expose
  @SerializedName("computer_name")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String computerName;

  @Expose
  @SerializedName("disks")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<TemplateDiskConfigurationResponse> disks;

  @Expose
  @SerializedName("vnics")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<TemplateVnicConfigurationResponse> vnics;

  @Expose
  @SerializedName("eula_sections")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<EulaSection> eulaSections;

  /**
   * Instantiates a new Vm template configuration.
   *  @param uuid                      the uuid
   * @param name                      the name
   * @param description               the description
   * @param memoryInBytes             the memory in bytes
   * @param numberOfCpus              the number of cpus
   * @param numberOfCpuCoresPerSocket the number of cpu cores per socket
   * @param storageProfileUuid        the storage profile uuid
   * @param hardwareVersion           the hardware version
   * @param operatingSystemVersion    the operating system version
   * @param exposeCpuVirtualization   the expose cpu virtualization
   * @param computerName              the computer name
   * @param disks                     the disks
   * @param vnics                     the vnics
   * @param eulaSections              the eula sections
   */
  public VmTemplateConfigurationResponse(final String uuid, final String name,
      final String description, final long memoryInBytes,
      final int numberOfCpus, final int numberOfCpuCoresPerSocket,
      final String storageProfileUuid, final String hardwareVersion,
      final String operatingSystemVersion,
      final boolean exposeCpuVirtualization, final String computerName,
      final List<TemplateDiskConfigurationResponse> disks,
      final List<TemplateVnicConfigurationResponse> vnics,
      final List<EulaSection> eulaSections) {
    this.uuid = uuid;
    this.name = name;
    this.description = description;
    this.memoryInBytes = memoryInBytes;
    this.numberOfCpus = numberOfCpus;
    this.numberOfCpuCoresPerSocket = numberOfCpuCoresPerSocket;
    this.storageProfileUuid = storageProfileUuid;
    this.hardwareVersion = hardwareVersion;
    this.operatingSystemVersion = operatingSystemVersion;
    this.exposeCpuVirtualization = exposeCpuVirtualization;
    this.computerName = computerName;
    this.disks = disks;
    this.vnics = vnics;
    this.eulaSections = eulaSections;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets memory in bytes.
   *
   * @return the memory in bytes
   */
  public long getMemoryInBytes() {
    return memoryInBytes;
  }

  /**
   * Gets number of cpus.
   *
   * @return the number of cpus
   */
  public int getNumberOfCpus() {
    return numberOfCpus;
  }

  /**
   * Gets number of cpu cores per socket.
   *
   * @return the number of cpu cores per socket
   */
  public int getNumberOfCpuCoresPerSocket() {
    return numberOfCpuCoresPerSocket;
  }

  /**
   * Gets storage profile uuid.
   *
   * @return the storage profile uuid
   */
  public String getStorageProfileUuid() {
    return storageProfileUuid;
  }

  /**
   * Gets hardware version.
   *
   * @return the hardware version
   */
  public String getHardwareVersion() {
    return hardwareVersion;
  }

  /**
   * Gets operating system version.
   *
   * @return the operating system version
   */
  public String getOperatingSystemVersion() {
    return operatingSystemVersion;
  }

  /**
   * Is expose cpu virtualization boolean.
   *
   * @return the boolean
   */
  public boolean isExposeCpuVirtualization() {
    return exposeCpuVirtualization;
  }

  /**
   * Gets computer name.
   *
   * @return the computer name
   */
  public String getComputerName() {
    return computerName;
  }

  /**
   * Gets disks.
   *
   * @return the disks
   */
  public List<TemplateDiskConfigurationResponse> getDisks() {
    return disks;
  }

  /**
   * Gets vnics.
   *
   * @return the vnics
   */
  public List<TemplateVnicConfigurationResponse> getVnics() {
    return vnics;
  }

  /**
   * Gets the EULA sections.
   *
   * @return the EULA sections
   */
  public List<EulaSection> getEulaSections() {
    return eulaSections;
  }
}
