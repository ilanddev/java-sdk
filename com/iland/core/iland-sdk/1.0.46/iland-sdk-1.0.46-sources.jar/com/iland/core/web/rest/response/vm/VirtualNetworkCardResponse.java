/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vm;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.shared.IPAddressingMode;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Virtual Network Card Implementation.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VirtualNetworkCardResponse implements Serializable {

  private static final long serialVersionUID = 3605612196239158774L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String ipAddress;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private IPAddressingMode ipAddressingMode;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String macAddress;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String networkName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean isConnected;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean isPrimary;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int vnicId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean deleted;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String adapterType;

  /**
   * Instantiates a new Virtual network card.
   *
   * @param ipAddress        the ip address
   * @param ipAddressingMode the ip addressing mode
   * @param macAddress       the mac address
   * @param networkName      the network name
   * @param isConnected      the is connected
   * @param isPrimary        is primary network connection
   * @param vnicId           the vnic id
   * @param deleted          the deleted
   * @param adapterType      the adapter type
   */
  public VirtualNetworkCardResponse(final String ipAddress,
      final IPAddressingMode ipAddressingMode, final String macAddress,
      final String networkName, final boolean isConnected,
      final boolean isPrimary, final int vnicId, final boolean deleted,
      final String adapterType) {
    this.ipAddress = ipAddress;
    this.ipAddressingMode = ipAddressingMode;
    this.macAddress = macAddress;
    this.networkName = networkName;
    this.isConnected = isConnected;
    this.isPrimary = isPrimary;
    this.vnicId = vnicId;
    this.deleted = deleted;
    this.adapterType = adapterType;
  }

  /**
   * Get the IP address.
   *
   * @return {@link String} ip address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Get the IP addresssing mode.
   *
   * @return {@link IPAddressingMode} ip addressing mode
   */
  public IPAddressingMode getIpAddressingMode() {
    return ipAddressingMode;
  }

  /**
   * Get the mac address
   *
   * @return {@link String} mac address
   */
  public String getMacAddress() {
    return macAddress;
  }

  /**
   * Get the network name.
   *
   * @return {@link String} network name
   */
  public String getNetworkName() {
    return networkName;
  }

  /**
   * Check whether this network adapter is connected.
   *
   * @return whether network is connected
   */
  public boolean isConnected() {
    return isConnected;
  }

  /**
   * Check if this is the primary network connection.
   *
   * @return whether this is a primary network connection
   */
  public boolean isPrimaryNetworkConnection() {
    return isPrimary;
  }

  /**
   * Return the vnic id (address on parent).
   *
   * @return vnic id
   */
  public int getId() {
    return vnicId;
  }

  /**
   * Return whether the vnic spot is deleted / unused for this Vm.
   *
   * @return boolean representing deleted / unused vnic spot
   */
  public boolean isDeleted() {
    return deleted;
  }

  /**
   * Get the adapter type.
   *
   * @return {@link String} adapter type
   */
  public String getAdapterType() {
    return adapterType;
  }

}

