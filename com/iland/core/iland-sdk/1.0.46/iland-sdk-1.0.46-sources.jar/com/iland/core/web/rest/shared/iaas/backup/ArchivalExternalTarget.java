/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.common.enums.VaultType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Archival External Target.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class ArchivalExternalTarget implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Specifies the id of Archival Vault.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the id of Archival Vault.")
  private final long vaultId;

  /**
   * Name of the Archival Vault.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Name of the Archival Vault.")
  private final String vaultName;

  /**
   * Specifies the type of the Archival External Target such as 'CLOUD',
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the type of the Archival External Target such as "
      + "'CLOUD'.")
  private final VaultType vaultType;

  /**
   * Instantiates a new Archival external target.
   *
   * @param vaultId   the vault id
   * @param vaultName the vault name
   * @param vaultType the vault type
   */
  public ArchivalExternalTarget(final long vaultId, final String vaultName,
      final VaultType vaultType) {
    this.vaultId = vaultId;
    this.vaultName = vaultName;
    this.vaultType = vaultType;
  }

  /**
   * Gets vault id.
   *
   * @return the vault id
   */
  public long getVaultId() {
    return vaultId;
  }

  /**
   * Gets vault name.
   *
   * @return the vault name
   */
  public String getVaultName() {
    return vaultName;
  }

  /**
   * Gets vault type.
   *
   * @return the vault type
   */
  public VaultType getVaultType() {
    return vaultType;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final ArchivalExternalTarget that = (ArchivalExternalTarget) o;
    return vaultId == that.vaultId && Objects.equals(vaultName, that.vaultName)
        && vaultType == that.vaultType;
  }

  @Override
  public int hashCode() {
    return Objects.hash(vaultId, vaultName, vaultType);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("vaultId", vaultId)
        .add("vaultName", vaultName).add("vaultType", vaultType).toString();
  }
}
