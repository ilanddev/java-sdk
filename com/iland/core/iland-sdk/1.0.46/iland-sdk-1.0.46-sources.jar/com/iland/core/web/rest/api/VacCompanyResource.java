/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.vac.BaBackupResourceUpdateRequest;
import com.iland.core.web.rest.request.vac.BaCompanyContractUpgradeRequest;
import com.iland.core.web.rest.request.vac.BaCompanyPasswordResetRequest;
import com.iland.core.web.rest.request.vac.BaCompanyUpdateRequest;
import com.iland.core.web.rest.request.vac.PerfIntervalRequest;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vac.BaBackupDirectoryFilterParams;
import com.iland.core.web.rest.response.vac.BaBackupDirectoryListResponse;
import com.iland.core.web.rest.response.vac.BaBackupFileFilterParams;
import com.iland.core.web.rest.response.vac.BaBackupFileListResponse;
import com.iland.core.web.rest.response.vac.BaCompanyCreationRequirementsResponse;
import com.iland.core.web.rest.response.vac.BaCompanyResponse;
import com.iland.core.web.rest.response.vac.BaJobListResponse;
import com.iland.core.web.rest.response.vac.VacPerfSampleListResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * VAC Company resource.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIProperties(name = "Cloud Backup")
@Path("/vac-companies")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface VacCompanyResource {

  /**
   * Gets a VAC company by its uuid.
   *
   * @param uuid vac company uuid
   * @return vac company
   */
  @GET
  @Path("/{uuid}")
  BaCompanyResponse getVacCompany(
      @SecureEntityRef(Permission.VIEW_ILAND_BACKUP_TENANT) @PathParam("uuid")
          String uuid);

  /**
   * Delete a VAC company given its uuid.
   *
   * @param uuid vac company uuid
   * @return delete vac company task
   */
  @DELETE
  @Path("/{uuid}")
  TaskResponse deleteVacCompany(
      @SecureEntityRef(Permission.DELETE_ILAND_BACKUP_TENANT) @PathParam("uuid")
          String uuid);

  /**
   * Get the storage usage performance samples for a given company, timeframe and
   * performance sampling interval.
   * <p>
   * If no interval is explicitly specified, an 'HOUR' interval is assumed.
   *
   * @param uuid     the company uuid
   * @param start    The start timestamp, in epoch milliseconds. Defaults to
   *                 the past day when the interval=HOUR and to the past 90
   *                 days when interval=DAY.
   * @param end      The end timestamp, in epoch milliseconds. Defaults to
   *                 the current time.
   * @param limit    sample limit
   * @param interval perf interval
   * @return list of storage usage performance samples
   */
  @GET
  @Path("/{uuid}/storage-usage")
  VacPerfSampleListResponse getStorageUsage(
      @SecureEntityRef(Permission.VIEW_ILAND_BACKUP_TENANT) @PathParam("uuid")
          String uuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("limit") Integer limit,
      @QueryParam("interval") PerfIntervalRequest interval);

  /**
   * Update the password for the VAC company.
   *
   * @param uuid                 vac company uuid
   * @param passwordResetRequest password reset request
   */
  @POST
  @Path("/{uuid}/actions/update-password")
  @Consumes(MediaType.APPLICATION_JSON)
  void resetVacCompanyPassword(
      @SecureEntityRef(Permission.MANAGE_ILAND_BACKUP_TENANT_PASSWORD)
      @PathParam("uuid") String uuid,
      BaCompanyPasswordResetRequest passwordResetRequest);

  /**
   * Upgrade the contract associated with a particular VAC company.
   *
   * @param companyUuid           the vac company uuid
   * @param updateContractRequest of changes to be made
   */
  @POST
  @Path("/{uuid}/actions/request-upgrade-contract")
  @Consumes(MediaType.APPLICATION_JSON)
  void requestContractUpgrade(
      @SecureEntityRef(Permission.MANAGE_ILAND_BACKUP_TENANT_STORAGE)
      @PathParam("uuid") String companyUuid,
      BaCompanyContractUpgradeRequest updateContractRequest);

  /**
   * Update the VAC company.
   *
   * @param uuid                   the UUID of the vac company
   * @param baCompanyUpdateRequest VAC company update request
   */
  @PUT
  @Path("/{uuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateVacCompany(
      @SecureEntityRef(Permission.MANAGE_ILAND_BACKUP_TENANT) @PathParam("uuid")
          String uuid, BaCompanyUpdateRequest baCompanyUpdateRequest);

  /**
   * Update the VAC company's storage quota.
   * <p>
   *
   * Backup resource storage quota cannot exceed contracted value nor can be
   * updated in a VAC company with multiple backup resources. Contact iland support
   * to update storage quota in those cases.
   * </p>
   *
   * @param uuid                          the UUID of the vac company
   * @param baBackupResourceUpdateRequest backup resource update request
   */
  @PUT
  @Path("/{uuid}/actions/update-storage-quota")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateVacCompanyStorageQuota(
      @SecureEntityRef(Permission.MANAGE_ILAND_BACKUP_TENANT) @PathParam("uuid")
          String uuid,
      BaBackupResourceUpdateRequest baBackupResourceUpdateRequest);

  /**
   * Get a list of backup directories given a VAC company uuid.
   *
   * @param uuid the UUID of the vac company
   * @return list of vac backup directories
   */
  @GET
  @Path("/{uuid}/vac-backup-directories")
  @Consumes(MediaType.APPLICATION_JSON)
  BaBackupDirectoryListResponse getVacBackupDirectories(
      @SecureEntityRef(Permission.VIEW_ILAND_BACKUP_TENANT) @PathParam("uuid")
          String uuid, @BeanParam BaBackupDirectoryFilterParams filterParams);

  /**
   * Get a list of backup files given a VAC company uuid and backup directory uuid.
   *
   * @param uuid                the UUID of the vac company
   * @param backupDirectoryUuid the UUID of the backup directory
   * @return list of vac backup files
   */
  @GET
  @Path("/{uuid}/{backupDirectoryUuid}/vac-backup-files")
  @Consumes(MediaType.APPLICATION_JSON)
  BaBackupFileListResponse getVacBackupFiles(
      @SecureEntityRef(Permission.VIEW_ILAND_BACKUP_TENANT) @PathParam("uuid")
          String uuid,
      @PathParam("backupDirectoryUuid") String backupDirectoryUuid,
      @BeanParam BaBackupFileFilterParams filterParams);

  /**
   * Get a list of VAC jobs for a given VAC company.
   *
   * @param uuid the UUID of a vac company
   * @return a list of vac jobs for the given company
   */
  @GET
  @Path("/{uuid}/jobs")
  BaJobListResponse getVacCompanyJobs(
      @SecureEntityRef(Permission.VIEW_ILAND_BACKUP_TENANT) @PathParam("uuid")
          String uuid);

  /**
   * Get the minimum size for VAC company creation in GB.
   *
   * @return the minimum size of a VAC company creation in GB
   */
  @GET
  @Path("/vac-company-creation-requirements")
  BaCompanyCreationRequirementsResponse getVacCompanyCreationRequirements();

}
