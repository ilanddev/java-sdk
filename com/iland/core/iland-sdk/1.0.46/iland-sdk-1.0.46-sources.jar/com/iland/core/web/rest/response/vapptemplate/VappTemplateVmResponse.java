/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vapptemplate;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Template Vm Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappTemplateVmResponse implements Serializable {

  private static final long serialVersionUID = 5256291134462649778L;

  private static final String VCLOUD_HREF = "vcloud_href";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int status;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private double size;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String uuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String name;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String fullname;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String description;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCLOUD_HREF)
  protected String vCloudHref;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected boolean deleted = false;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Date createdDate;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Date deletedDate;

  public VappTemplateVmResponse(final String uuid, final String name,
      final String description, final int status, final String vCloudHref,
      final double size, final Date createdDate, final Date deletedDate) {
    this.uuid = uuid;
    this.name = fullname = name;
    this.description = description;
    this.status = status;
    this.vCloudHref = vCloudHref;
    this.size = size;
    this.createdDate = createdDate;
    this.deletedDate = deletedDate;
  }

  /**
   * Returns the medaa status.
   *
   * @return 1 or 0
   */
  public int getStatus() {
    return status;
  }

  /**
   * Returns the media size on disk in GB.
   *
   * @return double greater than 0
   */
  public double getSize() {
    return size;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets fullname.
   *
   * @return the fullname
   */
  public String getFullname() {
    return fullname;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets cloud href.
   *
   * @return the cloud href
   */
  public String getvCloudHref() {
    return vCloudHref;
  }

  /**
   * Is deleted boolean.
   *
   * @return the boolean
   */
  public boolean isDeleted() {
    return deleted;
  }

  /**
   * Gets created date.
   *
   * @return the created date
   */
  public Date getCreatedDate() {
    return createdDate;
  }

  /**
   * Gets deleted date.
   *
   * @return the deleted date
   */
  public Date getDeletedDate() {
    return deletedDate;
  }

}
