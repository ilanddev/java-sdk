/*
 * Copyright (c) 2013,2014 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 205 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.cohesity.iaas.backups.common.model.BaseVdcUuid;
import com.iland.cohesity.iaas.backups.common.model.RecoverableSqlSearchInformation;
import com.iland.cohesity.iaas.backups.recovery.SqlRecoveryApi;
import com.iland.cohesity.iaas.backups.recovery.model.SearchRecoverableSqlSnapshotsFilters;
import com.iland.cohesity.iaas.backups.recovery.model.SqlOverwriteOriginalTaskParams;
import com.iland.cohesity.iaas.backups.recovery.model.SqlRestoreAsNewDatabaseNewInstanceTaskParams;
import com.iland.cohesity.iaas.backups.recovery.model.SqlRestoreAsNewDatabaseOriginalInstanceTaskParams;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * SQL Recovery Resource Interface v1.
 */
@APIProperties(name = "SQL Recovery")
@Path("/vdcs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
@PlatformApi
public interface SqlRecoveryResource extends SqlRecoveryApi {

  /**
   * Searches for recoverable SQL snapshots within the vDC.
   *
   * @param vdcUuid the UUID of the vDC
   * @param filters optional query filters
   * @return a list of recoverable VM snapshots
   */
  @POST
  @Path("/{vdcUuid}/recoverable-sql-snapshots")
  RecoverableSqlSearchInformation searchRecoverableSqlSnapshots(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
      BaseVdcUuid vdcUuid, SearchRecoverableSqlSnapshotsFilters filters);

  /**
   * Create a new SQL recovery task that will overwrite the original database.
   *
   * @param vdcUuid the UUID of the vDC
   * @param params  restoration parameters
   * @return the restore task, used to track the asynchronous operation
   */
  @POST
  @Path("/{vdcUuid}/actions/restore-sql-snapshot-overwrite-original")
  TaskResponse createSqlRestoreOverwriteOriginalTask(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") BaseVdcUuid vdcUuid,
      SqlOverwriteOriginalTaskParams params);

  /**
   * Create a new SQL recovery task that will create a new database on a
   * different server instance from the original.
   *
   * @param vdcUuid the UUID of the vDC
   * @param params  restoration parameters
   * @return the restore task, used to track the asynchronous operation
   */
  @POST
  @Path("/{vdcUuid}/actions/restore-sql-snapshot-as-new-database")
  TaskResponse createSqlRestoreAsNewDatabaseTask(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") BaseVdcUuid vdcUuid,
      SqlRestoreAsNewDatabaseNewInstanceTaskParams params);

  /**
   * Create a new SQL recovery task that will create a new database on the
   * original server instance. This endpoint requires that the database is
   * renamed.
   *
   * @param vdcUuid the UUID of the vDC
   * @param params  restoration parameters
   * @return the restore task, used to track the asynchronous operation
   */
  @POST
  @Path("/{vdcUuid}/actions/restore-sql-snapshot-as-new-database-original-instance")
  TaskResponse createSqlRestoreAsNewDatabaseOriginalInstanceTask(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") BaseVdcUuid vdcUuid,
      SqlRestoreAsNewDatabaseOriginalInstanceTaskParams params);

}
