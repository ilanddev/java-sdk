/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.time.Instant;
import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * O365 Purge User response (purge status at the user level).
 *
 * @author <a href="mailto:smittal@iland.com">Sachin Mittal</a>
 */
@APIModel
public interface O365PurgeUserResponse {

  /**
   * The user native uuid for the mailbox that was marked for purging.
   */
  String userNativeUuid();

  /**
   * The mailbox (email) that is marked for purging.
   */
  String mailbox();

  /**
   * Get the org platform uuid associated with this mailbox.
   */
  String organizationUuid();

  /**
   * Get the purge initiated date associated with this mailbox.
   */
  Instant initiatedDate();

  /**
   * Get the purge date associated with this mailbox.
   */
  Instant purgeDate();

  /**
   * Whether this user / mailbox will be purged at all (cancel use case).
   */
  boolean active();

  /**
   * The status of this purge user request - Completed, Running, Cancelled or Failed
   */
  String purgeStatus();

  /**
   * The error message if any on this purge request (would come from monocle)
   */
  Optional<String> errorMsg();

  /**
   * The admin user who requested purging of this user.
   */
  Optional<String> requestedBy();

  /**
   * Specifies the purge completed date time.
   */
  Optional<Instant> completedDate();
}