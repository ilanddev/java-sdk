/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.vbo.O365RestoreSessionResult;
import com.iland.core.api.vbo.O365RestoreSessionState;
import com.iland.core.api.vbo.O365RestoreSessionType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Office 365 VBO Restore Session.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365RestoreSessionResponse
    implements Serializable, Comparable<O365RestoreSessionResponse> {

  private static final long serialVersionUID = -2465817423074152915L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The O365 Restore Session iland platform UUID.")
  private final String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The iland location id.")
  private final String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The iland company id. (aka CRM # id)")
  private final String companyId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The parent VBO Organization iland platform UUID.")
  private final String o365OrganizationUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The name of this O365 restore session.")
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The type of this O365 restore session.")
  private final O365RestoreSessionType type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The result of this O365 restore session.")
  private final O365RestoreSessionResult result;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The state of this O365 restore session.")
  private final O365RestoreSessionState state;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The date and time when the restore session was started.")
  private final Instant creationTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The date and time when the restore session ended.")
  private final Instant endTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The user, that initiated the restore session.")
  private final String initiatedBy;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Unstructured basic info about the restore session.")
  private final String details;

  public O365RestoreSessionResponse(final String uuid, final String locationId,
      final String companyId, final String o365OrganizationUuid,
      final String name, final O365RestoreSessionType type,
      final O365RestoreSessionResult result,
      final O365RestoreSessionState state, final Instant creationTime,
      final Instant endTime, final String initiatedBy, final String details) {
    this.uuid = uuid;
    this.locationId = locationId;
    this.companyId = companyId;
    this.o365OrganizationUuid = o365OrganizationUuid;
    this.name = name;
    this.type = type;
    this.result = result;
    this.state = state;
    this.creationTime = creationTime;
    this.endTime = endTime;
    this.initiatedBy = initiatedBy;
    this.details = details;
  }

  /**
   * Returns the O365 Restore Session UUID.
   *
   * @return an iland platform UUID
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Returns an iland location id.
   *
   * @return the iland location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Returns the iland company id.
   *
   * @return an CRM # id
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * Returns the parent's VBO Organization UUID.
   *
   * @return an iland platform UUID
   */
  public String getO365OrganizationUuid() {
    return o365OrganizationUuid;
  }

  /**
   * Returns the name of this O365 restore session.
   *
   * @return the name of this O365 restore session.
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the type of the restore session.
   *
   * @return one of {@link O365RestoreSessionType}
   */
  public O365RestoreSessionType getType() {
    return type;
  }

  /**
   * Returns the result of the restore session actions.
   *
   * @return one of {@link O365RestoreSessionResult}
   */
  public O365RestoreSessionResult getResult() {
    return result;
  }

  /**
   * Returns the state of the restore session.
   *
   * @return one of {@link O365RestoreSessionState}
   */
  public O365RestoreSessionState getState() {
    return state;
  }

  /**
   * Returns the date and time when the restore session was started.
   *
   * @return UTC {@link Instant}
   */
  public Instant getCreationTime() {
    return creationTime;
  }

  /**
   * Returns the date and time when the restore session ended.
   *
   * @return UTC {@link Instant}
   */
  public Instant getEndTime() {
    return endTime;
  }

  /**
   * Returns the user, that initiated the restore session.
   *
   * @return the user, that initiated the restore session
   */
  public String getInitiatedBy() {
    return initiatedBy;
  }

  /**
   * Returns the restore session details.
   *
   * @return unstructured basic info about the restore session.
   */
  public String getDetails() {
    return details;
  }

  /**
   * Is the Restore session active?
   *
   * @return true or false
   */
  public boolean isActive() {
    return getState() == O365RestoreSessionState.Starting
        || getState() == O365RestoreSessionState.Working
        || getState() == O365RestoreSessionState.Stopping;
  }

  @Override
  public int compareTo(
      final O365RestoreSessionResponse o365RestoreSessionResponse) {
    if (o365RestoreSessionResponse == null
        || o365RestoreSessionResponse.getCreationTime() == null) {
      return 1;
    }
    return this.getCreationTime()
        .compareTo(o365RestoreSessionResponse.getCreationTime());
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final O365RestoreSessionResponse that = (O365RestoreSessionResponse) o;
    return Objects.equals(uuid, that.uuid) && Objects
        .equals(locationId, that.locationId) && Objects
        .equals(companyId, that.companyId) && Objects
        .equals(o365OrganizationUuid, that.o365OrganizationUuid) && Objects
        .equals(name, that.name) && type == that.type && result == that.result
        && state == that.state && Objects
        .equals(creationTime, that.creationTime) && Objects
        .equals(endTime, that.endTime) && Objects
        .equals(initiatedBy, that.initiatedBy) && Objects
        .equals(details, that.details);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(uuid, locationId, companyId, o365OrganizationUuid, name, type,
            result, state, creationTime, endTime, initiatedBy, details);
  }

}
