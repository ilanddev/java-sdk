/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.vapp;

import java.io.Serializable;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Resource Summary Map Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappResourceSummaryMapResponse implements Serializable {

  private static final long serialVersionUID = 6721777587523998935L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Map<String, VappResourceSummaryResponse> summaries;

  public VappResourceSummaryMapResponse(
      final Map<String, VappResourceSummaryResponse> summaries) {
    this.summaries = summaries;
  }

  /**
   * Get the map of resource summaries.
   *
   * @return {@link Map} of {@link String} to
   * {@link VappResourceSummaryResponse}
   */
  public Map<String, VappResourceSummaryResponse> getSummaryMap() {
    return summaries;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final VappResourceSummaryMapResponse that =
        (VappResourceSummaryMapResponse) o;

    return summaries.equals(that.summaries);
  }

  @Override
  public int hashCode() {
    return summaries.hashCode();
  }

  @Override
  public String toString() {
    return "VappResourceSummaryMapResponse{" + "summaryResponseMap=" + summaries
        + '}';
  }

}
