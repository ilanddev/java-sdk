/*
 * Copyright (c) 2013 - 2025, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.BackupGroupV2;
import com.iland.cohesity.iaas.backups.common.model.CompanyId;
import com.iland.cohesity.iaas.backups.common.model.ListResponse;
import com.iland.cohesity.iaas.backups.common.model.LocationId;
import com.iland.core.api.iam.AccessType;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SecureUserRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.notification.UserAlertEmailsCreateRequest;
import com.iland.core.web.rest.request.notification.UserEntityHistorySubscriptionCreateRequest;
import com.iland.core.web.rest.request.notification.UserEntityHistorySubscriptionDeleteRequest;
import com.iland.core.web.rest.request.notification.UserPreferencesCreateRequest;
import com.iland.core.web.rest.request.user.UserRoleUpdateRequest;
import com.iland.core.web.rest.request.user.UserUpdateRequest;
import com.iland.core.web.rest.request.vpg.VpgSubEntityRequest;
import com.iland.core.web.rest.response.catalog.CatalogListResponse;
import com.iland.core.web.rest.response.company.CompanyListResponse;
import com.iland.core.web.rest.response.edge.EdgeListResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupListResponse;
import com.iland.core.web.rest.response.iam.RoleResponse;
import com.iland.core.web.rest.response.iam.UserBillingPermissionListResponse;
import com.iland.core.web.rest.response.media.MediaListResponse;
import com.iland.core.web.rest.response.notification.UserAlertEmailsResponse;
import com.iland.core.web.rest.response.notification.UserEntityHistorySubscriptionListResponse;
import com.iland.core.web.rest.response.notification.UserEntityHistorySubscriptionResponse;
import com.iland.core.web.rest.response.notification.UserPreferencesResponse;
import com.iland.core.web.rest.response.org.OrgListResponse;
import com.iland.core.web.rest.response.org.OrgVdcNetworkListResponse;
import com.iland.core.web.rest.response.security.LoginEventListResponse;
import com.iland.core.web.rest.response.user.AccountEventListResponse;
import com.iland.core.web.rest.response.user.UserIdentityProviderLinkResponse;
import com.iland.core.web.rest.response.user.UserInventoryResponse;
import com.iland.core.web.rest.response.user.UserResponse;
import com.iland.core.web.rest.response.user.UserSessionListResponse;
import com.iland.core.web.rest.response.vac.BaCompanySetResponse;
import com.iland.core.web.rest.response.vac.BaJobListResponse;
import com.iland.core.web.rest.response.vapp.VappListResponse;
import com.iland.core.web.rest.response.vappnetwork.VappNetworkListResponse;
import com.iland.core.web.rest.response.vapptemplate.VappTemplateListResponse;
import com.iland.core.web.rest.response.vbo.O365CopyJobSetResponse;
import com.iland.core.web.rest.response.vbo.O365JobSetResponse;
import com.iland.core.web.rest.response.vbo.O365OrganizationSetResponse;
import com.iland.core.web.rest.response.vbo.O365RestoreSessionSetResponse;
import com.iland.core.web.rest.response.vcctenant.VccFailoverPlanListResponse;
import com.iland.core.web.rest.response.vdc.VdcListResponse;
import com.iland.core.web.rest.response.vm.VmListResponse;
import com.iland.core.web.rest.response.vpg.ExpandedVpgListResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * User Resource Interface v1.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Users")
@Path("/users")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface UserResource {

  /**
   * Returns the user specified by their username.
   *
   * @param username the user's username
   * @return user
   */
  @GET
  @Path("/{username}")
  UserResponse getUser(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username);

  /**
   * Updates a user's information.
   *
   * @param username the user's username
   * @return updated user
   */
  @PUT
  @SkipSecurityTest("We don't want the security test to update our user props.")
  @Path("/{username}")
  @Consumes(MediaType.APPLICATION_JSON)
  UserResponse updateUser(
      @SecureUserRef(AccessType.WRITE) @PathParam("username") String username,
      UserUpdateRequest request);

  /**
   * Gets a user's current sessions.
   *
   * @param username unique username as seen by iland AD
   * @return user
   */
  @GET
  @Path("/{username}/sessions")
  UserSessionListResponse getActiveSessions(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username);

  /**
   * Ends all active sessions for the user.
   *
   * @param username the username to get sessions for
   */
  @DELETE
  @Path("/{username}/sessions")
  void endAllActiveSessions(
      @SecureUserRef(AccessType.WRITE) @PathParam("username") String username);

  /**
   * Ends a session for a user.
   *
   * @param username  the username of the user
   * @param sessionId the session ID to end
   */
  @DELETE
  @Path("/{username}/sessions/{sessionId}")
  void endSession(
      @SecureUserRef(AccessType.WRITE) @PathParam("username") String username,
      @PathParam("sessionId") String sessionId);

  /**
   * Gets account event logs.
   *
   * @param username the username of the user
   */
  @GET
  @Path("/{username}/account-events")
  AccountEventListResponse getAccountEvents(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username,
      @QueryParam("offset") Integer offset, @QueryParam("limit") Integer limit,
      @QueryParam("dateFrom") Long dateFrom, @QueryParam("dateTo") Long dateTo);

  /**
   * Add an entity history subscription.
   *
   * @param username username
   * @param sub      subscription details
   * @return new subscription
   */
  @POST
  @Path("/{username}/actions/subscribe-to-entity-history")
  @Consumes(MediaType.APPLICATION_JSON)
  UserEntityHistorySubscriptionResponse subscribeToEntityHistory(
      @SecureUserRef(AccessType.WRITE) @PathParam("username") String username,
      UserEntityHistorySubscriptionCreateRequest sub);

  /**
   * Remove an entity history subscription.
   *
   * @param username username
   * @param sub      subscription details
   */
  @POST
  @Path("/{username}/actions/unsubscribe-from-entity-history")
  @Consumes(MediaType.APPLICATION_JSON)
  void removeEntityHistorySubscription(
      @SecureUserRef(AccessType.WRITE) @PathParam("username") String username,
      UserEntityHistorySubscriptionDeleteRequest sub);

  /**
   * Get entity history subscriptions for a given user.
   *
   * @param username username
   * @return list of entity history subscriptions
   */
  @GET
  @Path("/{username}/entity-history-subscriptions")
  UserEntityHistorySubscriptionListResponse getEntityHistorySubscriptions(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username);

  /**
   * Retrieve user preferences section.
   *
   * @param username username to retrieve preferences for
   * @return user preferences
   */
  @GET
  @Path("/{username}/preferences")
  UserPreferencesResponse getPreferences(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username);

  /**
   * Store / update user preferences section.
   *
   * @param username username to store preferences for
   * @return user preferences
   */
  @PUT
  @Path("/{username}/preferences")
  @Consumes(MediaType.APPLICATION_JSON)
  UserPreferencesResponse updatePreferences(
      @SecureUserRef(AccessType.WRITE) @PathParam("username") String username,
      UserPreferencesCreateRequest request);

  /**
   * Deletes a user.
   *
   * @param username username of the user to delete
   */
  @SkipSecurityTest("custom logic in EJB method")
  @DELETE
  @Path("/{username}")
  void delete(@PathParam("username") String username);

  /**
   * Get login events for a user. Login events include both successfull and
   * unsuccessful login attempts. The type field of the returned login events
   * will either be 'LOGIN' (meaning success) or 'LOGIN_ERROR' (meaning login
   * failure. You may request at most 100 events at a time.
   *
   * @param username the user's username
   * @param offset   the offset of the first event to retrieve
   * @param limit    the limit of the number of login events to retrieve
   * @return list of login events
   */
  @GET
  @Path("/{username}/login-events")
  LoginEventListResponse getLoginEvents(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username,
      @QueryParam("offset") Integer offset, @QueryParam("limit") Integer limit);

  /**
   * Get the set of user alerting emails for a given username.
   * <p>
   * This set of emails is used for all alerts (resource and billing, etc)
   * whenever an alert is triggered.
   *
   * @param username the user's username
   * @return set of alerting emails
   */
  @GET
  @Path("/{username}/alert-emails")
  UserAlertEmailsResponse getUserAlertEmails(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username);

  /**
   * Store the set of user alerting emails for a given username.
   *
   * @param username        the user's username
   * @param userAlertEmails set of alerting emails for the user
   * @return set of alerting emails
   */
  @POST
  @Path("/{username}/actions/update-alert-emails")
  @Consumes(MediaType.APPLICATION_JSON)
  UserAlertEmailsResponse updateAlertEmails(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username,
      UserAlertEmailsCreateRequest userAlertEmails);

  /**
   * Gets the inventory hierarchy for a user.
   *
   * @param username  the username of the user
   * @param companyId optional company ID parameter that may be used to restrict
   *                  the results to just those within a specific company
   * @return list of org hierarchies for the specified user
   */
  @GET
  @Path("/{username}/inventory")
  UserInventoryResponse getInventory(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username,
      @QueryParam("company") String companyId);

  /**
   * Get the company role for a specified user.
   *
   * @param username  the username of the user
   * @param companyId the company ID
   * @return the user's role within the specified company.
   */
  @GET
  @Path("/{username}/roles/{companyId}")
  RoleResponse getCompanyRole(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username,
      @PathParam("companyId") String companyId);

  /**
   * Update the company role for a specified user.
   *
   * @param username              the username of the user
   * @param companyId             the company ID
   * @param userRoleUpdateRequest the data object specifying role update
   *                              parameters
   */
  @PUT
  @Path("/{username}/roles/{companyId}")
  @Consumes(MediaType.APPLICATION_JSON)
  void updateCompanyRole(@PathParam("username") String username,
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId, UserRoleUpdateRequest userRoleUpdateRequest);

  /**
   * Gets user billing permissions for a company and the current user.
   * With each permission, a list of user inventory entities usable with the
   * permission is included as well.
   *
   * @param companyId the company id
   * @return list of billing permissions
   */
  @GET
  @Path("/{companyId}/permissions/billing")
  UserBillingPermissionListResponse getAvailableBillingPermissions(
      @PathParam("companyId") String companyId);

  /**
   * Deletes a user's role within a specified company.
   *
   * @param username  the username of the user
   * @param companyId the company ID
   */
  @DELETE
  @Path("/{username}/roles/{companyId}")
  void deleteCompanyRole(@PathParam("username") String username,
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId);

  /**
   * Gets the list of companies that the user has access to.
   *
   * @param username the username of the user
   */
  @GET
  @Path("/{username}/companies")
  CompanyListResponse getCompanies(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username);

  /**
   * Gets the list of orgs that the user has access to.
   *
   * @param username the username of the user
   */
  @GET
  @Path("/{username}/orgs")
  OrgListResponse getAllUserOrgs(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username);

  /**
   * Get the orgs for a company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return list of orgs
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/orgs")
  OrgListResponse getOrgsForUser(@PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the vDCs for a company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return list of vDCs
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/vdcs")
  VdcListResponse getVdcsForUser(@PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the vApps for a company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return list of vApps
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/vapps")
  VappListResponse getVappsForUser(@PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the VMs for a company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return list of VMs
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/vms")
  VmListResponse getVmsForUser(@PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the media for a company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return list of media
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/media")
  MediaListResponse getMediaForUser(@PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the vApp templates for a company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return list of vApp templates
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/vapp-templates")
  VappTemplateListResponse getVappTemplatesForUser(
      @PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the edges for a company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return list of edges
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/edges")
  EdgeListResponse getEdgesForUser(@PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the VPGs for company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return list of VPGs
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/vpgs")
  ExpandedVpgListResponse getVpgsForUser(@PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId,
      @QueryParam("expand") List<VpgSubEntityRequest> expand);

  /**
   * Get all VCC-R failover plans for a company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return list of VCC-R failover plan
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/vcc-failover-plans")
  VccFailoverPlanListResponse getVccFailoverPlansForUser(
      @PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the vac companies for company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return set of vac companies
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/vac-companies")
  BaCompanySetResponse getBaCompaniesForUser(
      @PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the vac jobs for company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return list of vac jobs
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/vac-jobs")
  BaJobListResponse getBaJobsForUser(
      @PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the org vdc networks for the company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return a list of org vdc networks
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/org-vdc-networks")
  OrgVdcNetworkListResponse getOrgVdcNetworksForUser(
      @PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the vapp networks for the company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return a list of org vdc networks
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/vapp-networks")
  VappNetworkListResponse getVappNetworksForUser(
      @PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the catalogs for the given company and user.
   *
   * @param username   the username of the user
   * @param companyId  the company ID
   * @param locationId the location ID
   * @return a list of catalogs
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/catalogs")
  CatalogListResponse getCatalogsForUser(@PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the Office 365 VBO companies for a company and user.
   *
   * @param username   the user name
   * @param companyId  the company identifier (aka CRM # id)
   * @param locationId the location identifier
   * @return a {@link O365OrganizationSetResponse} instance.
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/o365-organizations")
  O365OrganizationSetResponse getO365OrganizationsForUser(
      @PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the Office 365 VBO jobs for a company and user.
   *
   * @param username   the user name
   * @param companyId  the company identifier (aka CRM # id)
   * @param locationId the location identifier
   * @return a {@link O365JobSetResponse} instance.
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/o365-jobs")
  O365JobSetResponse getO365JobsForUser(@PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);


  /**
   * Get the Office 365 VBO copy jobs for a company and user.
   *
   * @param username   the user name
   * @param companyId  the company identifier (aka CRM # id)
   * @param locationId the location identifier
   * @return a {@link O365CopyJobSetResponse } instance.
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/o365-copy-jobs")
  O365CopyJobSetResponse getO365CopyJobsForUser(
      @PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the Office 365 VBO active restore sessions for a company and user.
   *
   * @param username   the user name
   * @param companyId  the company identifier (aka CRM # id)
   * @param locationId the location identifier
   * @return a {@link O365RestoreSessionSetResponse} instance.
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/o365-restore-sessions")
  O365RestoreSessionSetResponse getO365ActiveRestoreSessionsForUser(
      @PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId);

  /**
   * Get the backup groups for a company and user.
   *
   * @param username            the username of the user
   * @param companyId           the company ID
   * @param locationId          the location ID
   * @param includeLastRun      whether to include last run info
   * @param includeSummaryStats whether to include summary stats in the response
   * @param includeBackupPolicy whether to include backup policy details
   * @return list of backup groups
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/backup-groups")
  BackupGroupListResponse getBackupGroupsForUser(
      @PathParam("username") String username,
      @PathParam("companyId") String companyId,
      @QueryParam("location") String locationId,
      @QueryParam("includeSummaryStats") boolean includeSummaryStats,
      @QueryParam("includeLastRun") boolean includeLastRun,
      @QueryParam("includeBackupPolicy") boolean includeBackupPolicy);

  /**
   * Get the backup groups for a company and user.
   *
   * @param username            the username of the user
   * @param companyId           the company ID
   * @param locationId          the location ID
   * @param includeLastRun      whether to include last run info
   * @param includeSummaryStats whether to include summary stats in the response
   * @param includeBackupPolicy whether to include backup policy details
   * @param includeLegacyVMware weather to include legacy VMware backup groups
   * @return {@link ListResponse list of backup groups}
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{username}/companies/{companyId}/backup-groups-x")
  ListResponse<BackupGroupV2> getV2BackupGroups(
      @PathParam("username") String username,
      @PathParam("companyId") CompanyId companyId,
      @QueryParam("location") LocationId locationId,
      @QueryParam("includeSummaryStats") boolean includeSummaryStats,
      @QueryParam("includeLastRun") boolean includeLastRun,
      @QueryParam("includeBackupPolicy") boolean includeBackupPolicy,
      @QueryParam("includeLegacyVMware") boolean includeLegacyVMware);

  /**
   * Get the identity provider link for a user if they have any.
   *
   * @param username name of user to get identity provider link for
   * @return user identity provider link
   */
  @GET
  @Path("/{username}/identity-provider-link")
  UserIdentityProviderLinkResponse getIdentityProviderLink(
      @SecureUserRef(AccessType.READ) @PathParam("username") String username);

}
