/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.util.Optional;

import org.immutables.value.Value;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * Product section property qualifier that requires a string value to be a valid
 * IP address. If the network name is provided, requires that the IP address
 * is on the network with the given name.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public abstract class IpQualifier extends Qualifier {

  /**
   * Optional network name.
   */
  @Value.Parameter
  public abstract Optional<String> networkName();

  @Override
  @Value.Derived
  public QualifierType type() {
    return QualifierType.IP;
  }
}
