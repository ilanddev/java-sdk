/*
 * Copyright (c) 2013,2014 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 205 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */
package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.response.edge.EdgeResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Edge Gateway REST resource V1.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Edges")
@Path("/edges")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface EdgeResource {

  /**
   * Gets information for a VCD edge gateway.
   *
   * @param edgeUuid edge UUID
   * @return edge
   */
  @GET
  @Path("/{edgeUuid}")
  EdgeResponse getEdge(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

}
