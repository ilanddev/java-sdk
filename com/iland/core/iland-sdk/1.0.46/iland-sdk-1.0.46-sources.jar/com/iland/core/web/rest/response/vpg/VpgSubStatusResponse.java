/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vpg;

/**
 * VPG Sub Status Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public enum VpgSubStatusResponse {

  NONE,

  INITIAL_SYNC,

  CREATING,

  VOLUME_INITIAL_SYNC,

  SYNC,

  RECOVERY_POSSIBLE,

  DELTA_SYNC,

  NEEDS_CONFIGURATION,

  ERROR,

  EMPTY_PROTECTION_GROUP,

  DISCONNECTED_FROM_PEER_NO_RECOVERY_POINTS,

  FULL_SYNC,

  VOLUME_DELTA_SYNC,

  VOLUME_FULL_SYNC,

  FAILING_OVER_COMMITTING,

  FAILING_OVER_BEFORE_COMMIT,

  FAILING_OVER_ROLLING_BACK,

  PROMOTING,

  MOVING_COMMITTING,

  MOVING_BEFORE_COMMIT,

  MOVING_ROLLING_BACK,

  DELETING,

  PENDING_REMOVE,

  BITMAP_SYNC,

  DISCONNECTED_FROM_PEER,

  REPLICATION_PAUSED_USER_INITIATED,

  REPLICATION_PAUSED_SYSTEM_INITIATED,

  RECOVERY_STORAGE_PROFILE_ERROR,

  BACKUP,

  ROLLING_BACK,

  RECOVERY_STORAGE_ERROR,

  JOURNAL_STORAGE_ERROR,

  VM_NOT_PROTECTED_ERROR,

  JOURNAL_OR_RECOVERY_MISSING_ERROR,

  ADDED_VMS_IN_INITIAL_SYNC,

  REPLICATION_PAUSED_FOR_MISSING_VOLUME,

  STOPPING_FOT_FAILURE,

  ROLLING_BACK_FAILOVER_LIVE_FAILURE,

  ROLLING_BACK_MOVE_FAILURE,

  SPLITTING_COMMITTING,

  PREPARE_PRESEED,

  JOURNAL_VM_RESTORE,

  RANSOMWARE,

  UNKNOWN

}
