/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.user;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserResponse implements Serializable {

  private static final long serialVersionUID = -7248382243470607873L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected UserTypeResponse userType;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean locked = false;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String email;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String phone;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String company = "";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String address = "";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String city = "";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String state = "";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String zip = "";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String country;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String name;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String fullname;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected boolean deleted = false;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Instant createdDate;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Instant deletedDate;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected DomainResponse domain;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String firstName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String lastName;

  public UserResponse(final UserTypeResponse userType, final boolean locked,
      final String email, final String phone, final String company,
      final String address, final String city, final String state,
      final String zip, final String country, final String name,
      final String fullname, final boolean deleted, final Instant createdDate,
      final Instant deletedDate, final DomainResponse domain,
      final String firstName, final String lastName
      ) {
    this.userType = userType;
    this.locked = locked;
    this.email = email;
    this.phone = phone;
    this.company = company;
    this.address = address;
    this.city = city;
    this.state = state;
    this.zip = zip;
    this.country = country;
    this.name = name;
    this.fullname = fullname;
    this.deleted = deleted;
    this.createdDate = createdDate;
    this.deletedDate = deletedDate;
    this.domain = domain;
    this.firstName = firstName;
    this.lastName = lastName;
  }

  /**
   * Gets user type.
   *
   * @return the user type
   */
  public UserTypeResponse getUserType() {
    return userType;
  }

  /**
   * Gets first name.
   *
   * @return the first name
   */
  public String getFirstName() {
    return firstName;
  }

  /**
   * Gets last name.
   *
   * @return the last name
   */
  public String getLastName() {
    return lastName;
  }

  /**
   * Gets email.
   *
   * @return the email
   */
  public String getEmail() {
    return email;
  }

  /**
   * Gets phone.
   *
   * @return the phone
   */
  public String getPhone() {
    if (phone == null) {
      return "";
    }
    return phone;
  }

  /**
   * Is locked boolean.
   *
   * @return the boolean
   */
  public boolean isLocked() {
    return locked;
  }

  /**
   * Gets address.
   *
   * @return the address
   */
  public String getAddress() {
    return address;
  }

  /**
   * Gets company.
   *
   * @return the company
   */
  public String getCompany() {
    return company;
  }

  /**
   * Gets city.
   *
   * @return the city
   */
  public String getCity() {
    return city;
  }

  /**
   * Gets state.
   *
   * @return the state
   */
  public String getState() {
    return state;
  }

  /**
   * Gets zip code.
   *
   * @return the zip code
   */
  public String getZipCode() {
    return zip;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets fullname.
   *
   * @return the fullname
   */
  public String getFullname() {
    return fullname;
  }

  /**
   * Is deleted boolean.
   *
   * @return the boolean
   */
  public boolean isDeleted() {
    return deleted;
  }


  /**
   * Gets created date.
   *
   * @return the created date
   */
  public Instant getCreatedDate() {
    return createdDate;
  }

  /**
   * Gets deleted date.
   *
   * @return the deleted date
   */
  public Instant getDeletedDate() {
    return deletedDate;
  }

  /**
   * Gets the domain.
   *
   * @return the domain
   */
  public DomainResponse getDomain() {
    return domain;
  }

  /**
   * Gets the country.
   *
   * @return the country
   */
  public String getCountry() {
    return country;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserResponse that = (UserResponse) o;

    if (locked != that.locked)
      return false;
    if (deleted != that.deleted)
      return false;
    if (userType != that.userType)
      return false;
    if (email != null ? !email.equals(that.email) : that.email != null)
      return false;
    if (phone != null ? !phone.equals(that.phone) : that.phone != null)
      return false;
    if (company != null ? !company.equals(that.company) : that.company != null)
      return false;
    if (address != null ? !address.equals(that.address) : that.address != null)
      return false;
    if (city != null ? !city.equals(that.city) : that.city != null)
      return false;
    if (state != null ? !state.equals(that.state) : that.state != null)
      return false;
    if (zip != null ? !zip.equals(that.zip) : that.zip != null)
      return false;
    if (country != null ? !country.equals(that.country) : that.country != null)
      return false;
    if (name != null ? !name.equals(that.name) : that.name != null)
      return false;
    if (fullname != null ?
        !fullname.equals(that.fullname) :
        that.fullname != null)
      return false;
    if (createdDate != null ?
        !createdDate.equals(that.createdDate) :
        that.createdDate != null)
      return false;
    if (deletedDate != null ?
        !deletedDate.equals(that.deletedDate) :
        that.deletedDate != null)
      return false;
    return domain != null ? domain.equals(that.domain) : that.domain == null;
  }

  @Override
  public int hashCode() {
    int result = userType != null ? userType.hashCode() : 0;
    result = 31 * result + (locked ? 1 : 0);
    result = 31 * result + (email != null ? email.hashCode() : 0);
    result = 31 * result + (phone != null ? phone.hashCode() : 0);
    result = 31 * result + (company != null ? company.hashCode() : 0);
    result = 31 * result + (address != null ? address.hashCode() : 0);
    result = 31 * result + (city != null ? city.hashCode() : 0);
    result = 31 * result + (state != null ? state.hashCode() : 0);
    result = 31 * result + (zip != null ? zip.hashCode() : 0);
    result = 31 * result + (country != null ? country.hashCode() : 0);
    result = 31 * result + (name != null ? name.hashCode() : 0);
    result = 31 * result + (fullname != null ? fullname.hashCode() : 0);
    result = 31 * result + (deleted ? 1 : 0);
    result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
    result = 31 * result + (deletedDate != null ? deletedDate.hashCode() : 0);
    result = 31 * result + (domain != null ? domain.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "UserResponse{" + "userType=" + userType + ", locked=" + locked
        + ", email='" + email + '\'' + ", phone='" + phone + '\''
        + ", company='" + company + '\'' + ", address='" + address + '\''
        + ", city='" + city + '\'' + ", state='" + state + '\'' + ", zip='"
        + zip + '\'' + ", country='" + country + '\'' + ", name='" + name + '\''
        + ", fullname='" + fullname + '\'' + ", deleted=" + deleted
        + ", createdDate=" + createdDate + ", deletedDate=" + deletedDate
        + ", domain='" + domain + '\'' + '}';
  }

}
