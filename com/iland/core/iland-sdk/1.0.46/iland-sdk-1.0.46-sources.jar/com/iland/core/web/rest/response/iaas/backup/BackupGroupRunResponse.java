/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * BackupGroupRun.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public final class BackupGroupRunResponse {

  @Expose
  @JsonRequired("The UID of the backup run.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uid;

  @Expose
  @JsonRequired(
      "Specifies details about the backup task for a backup group run. A backup "
          + "task captures the original backup snapshots for each source in the backup "
          + "group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupRun backupRun;

  @Expose
  @JsonRequired("Array of Copy Run Tasks. "
      + "Specifies details about the Copy tasks of this backup group run. A Copy "
      + "task copies the captured snapshots to an external target or a remote "
      + "cluster.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<CopyRun> copyRuns;

  @Expose
  @JsonRequired("Specifies the UID of the backup group that was run.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String backupGroupUid;

  @Expose
  @JsonRequired("Specifies the name of the backup group name that was run.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String backupGroupName;

  @Expose
  @JsonRequired("Specifies the associated vCloud organization UUID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String orgUuid;

  @Expose
  @JsonRequired("Specifies the associated vCloud vDC UUID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vdcUuid;

  @Expose
  @JsonRequired("Specifies the associated company ID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String companyId;

  @Expose
  @JsonRequired("Specifies the associated datacenter location ID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String locationId;

  @Expose
  @JsonRequired("Specifies the duration of the run in milliseconds.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Long duration;

	@Expose
	@JsonRequired("Array of messages.")
	@Since(ApiVersion.ONE_DOT_ZERO)
	private final List<String> messages;

  public BackupGroupRunResponse(final String uid, final BackupRun backupRun,
      final List<CopyRun> copyRuns, final String backupGroupUid,
      final String backupGroupName, final String orgUuid, final String vdcUuid,
      final String companyId, final String locationId,
		  final List<String> messages) {
    this.uid = uid;
    this.backupRun = backupRun;
    this.copyRuns = copyRuns;
    this.backupGroupUid = backupGroupUid;
    this.backupGroupName = backupGroupName;
    this.orgUuid = orgUuid;
    this.vdcUuid = vdcUuid;
    this.companyId = companyId;
    this.locationId = locationId;
    this.duration = duration(backupRun).toMillis();
	  this.messages = messages;
  }

  private static Duration duration(final BackupRun backupRun) {
    if (backupRun == null) {
      return Duration.ZERO;
    }

    final BackupRunStats stats = backupRun.getStats();
    final Instant start = stats.getStartTime();
    final Optional<Instant> endTime = stats.getEndTime();

    return endTime.map(instant -> Duration.between(start, instant))
        .orElse(Duration.ZERO);
  }

  /**
   * The UID of the backup run.
   */
  public String getUid() {
    return uid;
  }

  /**
   * Specifies details about the backup task for a backup group run. A backup
   * task captures the original backup snapshots for each source in the backup
   * group.
   */
  public BackupRun getBackupRun() {
    return backupRun;
  }

  /**
   * Array of Copy Run Tasks.
   * <p>
   * Specifies details about the Copy tasks of this backup group run. A Copy
   * task copies the captured snapshots to an external target or a remote
   * cluster.
   */
  public List<CopyRun> getCopyRuns() {
    return copyRuns;
  }

  /**
   * Specifies the UID of the backup group that was run.
   */
  public String getBackupGroupUid() {
    return backupGroupUid;
  }

  /**
   * Specifies the name of the backup group name that was run.
   */
  public String getBackupGroupName() {
    return backupGroupName;
  }

  /**
   * Specifies the associated vCloud organization UUID.
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Specifies the associated vCloud vDC UUID.
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Specifies the associated company ID.
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * Specifies the associated datacenter location ID.
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Specifies the duration of the run.
   */
  public Optional<Long> getDuration() {
    return Optional.ofNullable(duration);
  }

	/**
	 * Specifies the run messages.
	 */
	public List<String> getMessages() {
		return messages;
	}

	@Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BackupGroupRunResponse that = (BackupGroupRunResponse) o;
    return Objects.equals(uid, that.uid) && Objects
        .equals(backupRun, that.backupRun) && Objects
        .equals(copyRuns, that.copyRuns) && Objects
        .equals(backupGroupUid, that.backupGroupUid) && Objects
        .equals(backupGroupName, that.backupGroupName) && Objects
        .equals(orgUuid, that.orgUuid) && Objects.equals(vdcUuid, that.vdcUuid)
        && Objects.equals(companyId, that.companyId) && Objects
        .equals(locationId, that.locationId) && Objects
		    .equals(messages, that.messages);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(uid, backupRun, copyRuns, backupGroupUid, backupGroupName,
            orgUuid, vdcUuid, companyId, locationId, messages);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("uid", uid)
        .add("backupRun", backupRun).add("copyRuns", copyRuns)
        .add("backupGroupUid", backupGroupUid)
        .add("backupGroupName", backupGroupName).add("orgUuid", orgUuid)
        .add("vdcUuid", vdcUuid).add("companyId", companyId)
        .add("locationId", locationId).add("messages", messages)
		    .toString();
  }
}
