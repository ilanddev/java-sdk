/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Objects;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VmBackupStatusResponse.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public class VmBackupStatusResponse {

  @Expose
  @JsonRequired("The UUID of the VM.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @JsonRequired("The set of advanced backup groups that this VM is protected in.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<BackupGroupStatusDescriptor> backupGroups;

  public VmBackupStatusResponse(final String uuid,
      final Set<BackupGroupStatusDescriptor> backupGroups) {
    this.uuid = uuid;
    this.backupGroups = backupGroups;
  }

  /**
   * Gets the VM UUID.
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets relevant backup group information.
   */
  public Set<BackupGroupStatusDescriptor> getBackupGroups() {
    return backupGroups;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final VmBackupStatusResponse that = (VmBackupStatusResponse) o;
    return Objects.equals(uuid, that.uuid) && Objects
        .equals(backupGroups, that.backupGroups);
  }

  @Override
  public int hashCode() {
    return Objects.hash(uuid, backupGroups);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("uuid", uuid)
        .add("backupGroups", backupGroups).toString();
  }
}
