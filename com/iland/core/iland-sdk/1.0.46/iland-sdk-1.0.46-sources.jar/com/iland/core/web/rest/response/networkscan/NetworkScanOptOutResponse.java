/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscan;

import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Network Scan Opt Out Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public final class NetworkScanOptOutResponse {

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String orgUuid;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private boolean optOut;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private Set<String> exclusions;

	public NetworkScanOptOutResponse(final String orgUuid, final boolean optOut,
		final Set<String> exclusions) {
		this.orgUuid = orgUuid;
		this.optOut = optOut;
		this.exclusions = exclusions;
	}

	/**
	 * Get the org uuid.
	 *
	 * @return {@link String} org uuid
	 */
	public String getOrgUuid() {
		return orgUuid;
	}

	/**
	 * Is the org opted out.
	 *
	 * @return is opt out
	 */
	public boolean isOptOut() {
		return optOut;
	}

	/**
	 * Get the set of ip addresses to skip.
	 *
	 * @return {@link Set} of {@link String} ip addresses
	 */
	public Set<String> getExclusions() {
		return exclusions;
	}

	@Override
	public boolean equals(final Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		final NetworkScanOptOutResponse that = (NetworkScanOptOutResponse) o;

		if (orgUuid != null ?
			!orgUuid.equals(that.orgUuid) :
			that.orgUuid != null)
			return false;
		return exclusions != null ?
			exclusions.equals(that.exclusions) :
			that.exclusions == null;
	}

	@Override
	public int hashCode() {
		int result = orgUuid != null ? orgUuid.hashCode() : 0;
		result = 31 * result + (exclusions != null ? exclusions.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		return "NessusScanOptOutResponse{" + "orgUuid='" + orgUuid + '\''
			+ ", optOut=" + optOut + ", exclusions=" + exclusions + '}';
	}

}
