/*
 * Copyright (c) 2013,2014 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 205 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */
package com.iland.core.web.rest.api;

import java.io.InputStream;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.common.SnapshotCreateRequest;
import com.iland.core.web.rest.request.common.UpdateMetadataRequest;
import com.iland.core.web.rest.request.vapp.RuntimeLeaseUpdateRequest;
import com.iland.core.web.rest.request.vapp.StorageLeaseUpdateRequest;
import com.iland.core.web.rest.request.vapp.VappCopyMoveRequest;
import com.iland.core.web.rest.request.vapp.VappDescriptionUpdateRequest;
import com.iland.core.web.rest.request.vapp.VappNetworkCreateRequest;
import com.iland.core.web.rest.request.vapp.VappRenameRequest;
import com.iland.core.web.rest.request.vapp.VappStartupSectionItemRequest;
import com.iland.core.web.rest.request.vm.BuildVmRequest;
import com.iland.core.web.rest.request.vm.UpdateProductSectionPropertiesRequest;
import com.iland.core.web.rest.request.vm.VmCreateRequest;
import com.iland.core.web.rest.response.billing.BillResponse;
import com.iland.core.web.rest.response.common.HasSnapshotResponse;
import com.iland.core.web.rest.response.common.SnapshotResponse;
import com.iland.core.web.rest.response.iaas.backup.VappBackupStatusDetailResponse;
import com.iland.core.web.rest.response.iaas.intbackup.VappIntegratedBackupStatusDetailResponse;
import com.iland.core.web.rest.response.metadata.MetadataListResponse;
import com.iland.core.web.rest.response.performance.PerfSampleSerieResponse;
import com.iland.core.web.rest.response.performance.PerformanceCounterListResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vapp.DownloadDetailsResponse;
import com.iland.core.web.rest.response.vapp.VappResourceSummaryResponse;
import com.iland.core.web.rest.response.vapp.VappResponse;
import com.iland.core.web.rest.response.vapp.VappStartupSectionItemListResponse;
import com.iland.core.web.rest.response.vappnetwork.VappNetworkListResponse;
import com.iland.core.web.rest.response.vdc.StorageProfileListResponse;
import com.iland.core.web.rest.response.vm.ProductSectionListResponse;
import com.iland.core.web.rest.response.vm.VmListResponse;
import com.iland.core.web.rest.response.vm.VmResourceSummaryMapResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Vapp Resource interface v1.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "vApps")
@Path("/vapps")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface VappResource {

  /**
   * Returns vApp Billing for a given invoice period.
   * <p>
   * If month and year are not explicitly supplied the current invoice period is
   * used.
   *
   * @param vappUuid vapp uuid
   * @param year     the invoice period year (defaults to current year)
   * @param month    the invoice period month (defaults to the current month) must
   *                 be in range 1-12
   * @return billing for the vApp and given invoice period
   */
  @GET
  @Path("/{vappUuid}/billing")
  BillResponse getBillingForVapp(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP_BILLING)
      @PathParam("vappUuid") String vappUuid, @QueryParam("year") Integer year,
      @QueryParam("month") Integer month);

  /**
   * Update the description for a vapp.
   *
   * @param vappUuid vapp uuid
   * @param request  request to update vapp description
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/update-description")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateDescription(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid, VappDescriptionUpdateRequest request);

  /**
   * Get the startup section for a particular Vapp.
   *
   * @param vappUuid vapp uuid
   * @return list of vapp startup section items
   */
  @GET
  @Path("/{vappUuid}/startup-section")
  VappStartupSectionItemListResponse getStartupSection(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid);

  /**
   * Update the startup section of a particular Vapp.
   *
   * @param vappUuid       vapp uuid
   * @param startupSection of instances
   * @return list of vapp startup section items
   */
  @POST
  @Path("/{vappUuid}/actions/update-startup-section")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateStartupSection(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_CONFIGURATION)
      @PathParam("vappUuid") String vappUuid,
      List<VappStartupSectionItemRequest> startupSection);

  /**
   * Retrieve metadata associated with a Vapp.
   *
   * @param vappUuid vm uuid
   * @return list of metadata for the vapp
   */
  @GET
  @Path("/{vappUuid}/metadata")
  MetadataListResponse getMetadataForVapp(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid);

  /**
   * Add / update metadata associated with a Vapp.
   *
   * @param vappUuid vapp uuid
   * @param metadata of instances
   * @return asynchronous task details
   */
  @PUT
  @Path("/{vappUuid}/metadata")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateMetadataForVapp(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_CONFIGURATION)
      @PathParam("vappUuid") String vappUuid,
      List<UpdateMetadataRequest> metadata);

  /**
   * Delete a specific piece of metadata associated with a Vapp by its key.
   *
   * @param vappUuid vapp uuid
   * @param key      metadata key
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{vappUuid}/metadata/{key}")
  TaskResponse deleteMetadataForVapp(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_CONFIGURATION)
      @PathParam("vappUuid") String vappUuid, @PathParam("key") String key);

  /**
   * Creates a new vApp in the Vdc based on an existing vapp.
   *
   * @param vappUuid vapp uuid
   * @param spec     specifications for newly copyied vapp
   * @return asynchronous task details
   */
  @SkipSecurityTest("We've had some issues with the vApp actually copied/moved and messing up other tests.")
  @POST
  @Path("/{vappUuid}/actions/copy")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse copyVapp(
      @SecureEntityRef(Permission.COPY_MOVE_DOWNLOAD_ILAND_CLOUD_VAPP)
      @PathParam("vappUuid") String vappUuid, VappCopyMoveRequest spec);

  /**
   * Creates a new vApp in the Vdc based on an existing vapp.
   *
   * @param vappUuid vapp uuid
   * @param spec     specifications for newly copyied vapp
   * @return asynchronous task details
   */
  @SkipSecurityTest("We've had some issues with the vApp actually copied/moved and messing up other tests.")
  @POST
  @Path("/{vappUuid}/actions/move")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse moveVapp(
      @SecureEntityRef(Permission.COPY_MOVE_DOWNLOAD_ILAND_CLOUD_VAPP)
      @PathParam("vappUuid") String vappUuid, VappCopyMoveRequest spec);

  /**
   * Add a new Org Vdc Network Direct Network to the given vApp.
   *
   * @param vappUuid    vapp uuid
   * @param networkUuid network uuid
   * @return asynchronous task details
   */
  // TODO API-V1 consider refactoring and combining with createVappNetwork
  // endpoint?
  @POST
  @Path("/{vappUuid}/org-vdc-network/{networkUuid}")
  TaskResponse addOrgVdcNetworkToVapp(
      @SecureEntityRef(Permission.CREATE_ILAND_CLOUD_VAPP_NETWORKS)
      @PathParam("vappUuid") String vappUuid,
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_INTERNAL_NETWORK_CONFIGURATION)
      @PathParam("networkUuid") String networkUuid);

  /**
   * Add a new vApp network to the given vApp.
   *
   * @param vappUuid                 vapp uuid
   * @param vappNetworkCreateRequest add vapp network request
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/add-vapp-network")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse addVappNetwork(
      @SecureEntityRef(Permission.CREATE_ILAND_CLOUD_VAPP_NETWORKS)
      @PathParam("vappUuid") String vappUuid,
      VappNetworkCreateRequest vappNetworkCreateRequest);

  /**
   * Rename a vApp.
   *
   * @param vappUuid vapp uuid
   * @param request  request for renaming a vApp
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/update-name")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateName(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_CONFIGURATION)
      @PathParam("vappUuid") String vappUuid, VappRenameRequest request);

  /**
   * Delete a vApp.
   *
   * @param vappUuid vapp uuid
   * @return asynchronous task details
   */
  @SkipSecurityTest("don't want to delete our test vapp")
  @DELETE
  @Path("/{vappUuid}")
  TaskResponse deleteVapp(@SecureEntityRef(Permission.DELETE_ILAND_CLOUD_VAPP)
  @PathParam("vappUuid") String vappUuid);

  /**
   * Get the snapshot for the given vApp.
   *
   * @param vappUuid vapp uuid
   * @return snapshot
   */
  @GET
  @Path("/{vappUuid}/snapshot")
  SnapshotResponse getSnapshot(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid);

  /**
   * Check for the existence of a snapshot for the given vApp.
   *
   * @param vappUuid vapp uuid
   * @return whether snapshot exists
   */
  @GET
  @Path("/{vappUuid}/has-snapshot")
  HasSnapshotResponse hasVappSnapshot(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid);

  /**
   * Create a snapshot for the given vApp.
   *
   * @param vappUuid vapp uuid
   * @param request  request for creating a snapshot of a vApp
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/create-snapshot")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse createSnapshot(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_SNAPSHOTS)
      @PathParam("vappUuid") String vappUuid, SnapshotCreateRequest request);

  /**
   * Restore a vApp from a snapshot.
   *
   * @param vappUuid vapp uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/restore-snapshot")
  TaskResponse restoreSnapshot(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_SNAPSHOTS)
      @PathParam("vappUuid") String vappUuid);

  /**
   * Remove a snapshot from a vApp.
   *
   * @param vappUuid vapp uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/remove-snapshot")
  TaskResponse removeSnapshot(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_SNAPSHOTS)
      @PathParam("vappUuid") String vappUuid);

  /**
   * Update the runtime lease for the given vApp.
   *
   * @param vappUuid vapp uuid
   * @param request  lease expiration from now in (seconds)
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/update-runtime-lease")
  TaskResponse updateRuntimeLease(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_LEASES)
      @PathParam("vappUuid") String vappUuid,
      RuntimeLeaseUpdateRequest request);

  /**
   * Update the storage lease for the given vApp.
   *
   * @param vappUuid vapp uuid
   * @param request  lease expiration from now in (seconds)
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/update-storage-lease")
  TaskResponse updateStorageLease(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_LEASES)
      @PathParam("vappUuid") String vappUuid,
      StorageLeaseUpdateRequest request);

  /**
   * Add virtual machines to the vApp from templates.
   * <p>
   * Invocation of this endpoint implies that the user has reviewed and accepted
   * any and all EULAs associated with referenced templates.
   *
   * @param vappUuid vapp uuid
   * @param requests list of add vm requests
   * @return asynchronous task details
   */
  @SkipSecurityTest("Need a custom test provider to submit appropriate vApp template UUIDs in the json.")
  @POST
  @Path("/{vappUuid}/actions/add-vms-from-templates")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse addVms(@SecureEntityRef(Permission.CREATE_ILAND_CLOUD_VAPP_VMS)
  @PathParam("vappUuid") String vappUuid, List<VmCreateRequest> requests);

  /**
   * Create virtual machines in a vApp
   *
   * @param vappUuid vapp uuid
   * @param vms      list of vapp vms
   * @return asynchronous task details
   */
  @SkipSecurityTest("Need a custom test provider to submit appropriate vApp template UUIDs in the json.")
  @POST
  @Path("/{vappUuid}/actions/build-vms")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse buildVms(@SecureEntityRef(Permission.CREATE_ILAND_CLOUD_VAPP_VMS)
  @PathParam("vappUuid") String vappUuid, List<BuildVmRequest> vms);

  /**
   * Get the networks for a given vApp.
   *
   * @param vappUuid vapp uuid
   * @return list of networks
   */
  @GET
  @Path("/{vappUuid}/networks")
  VappNetworkListResponse getNetworksFor(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid);

  /**
   * Get vApp performance data for the given vApp, counter, and time range.
   *
   * @param vappUuid vapp uuid
   * @param group    the performance counter group
   * @param name     the performance counter name
   * @param type     the performance counter type
   * @param start    start date
   * @param end      end date
   * @param interval interval
   * @param limit    limit
   * @return performance samples serie for the given vApp, counter and date
   * range
   */
  @GET
  @Path("/{vappUuid}/performance/{group}::{name}::{type}")
  PerfSampleSerieResponse getPerformanceForVapp(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid, @PathParam("group") String group,
      @PathParam("name") String name, @PathParam("type") String type,
      @QueryParam("start") Long start, @QueryParam("end") Long end,
      @QueryParam("interval") String interval,
      @QueryParam("limit") String limit);

  /**
   * Get the list of performance counters that can be used to query for vApp
   * performance data.
   *
   * @param vappUuid vApp UUID
   * @return the list of performance counters
   */
  @GET
  @Path("/{vappUuid}/performance-counters")
  PerformanceCounterListResponse getPerformanceCounters(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid);

  /**
   * Power on a vApp.
   *
   * @param vappUuid                vapp uuid
   * @param forceGuestCustomization optional param to force guest
   *                                re-customization on restart defaults to false
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/poweron")
  TaskResponse powerOnVapp(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_POWER_STATE)
      @PathParam("vappUuid") String vappUuid,
      @QueryParam("forceGuestCustomization") boolean forceGuestCustomization);

  /**
   * Power off a vApp.
   *
   * @param vappUuid vapp uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/poweroff")
  TaskResponse powerOffVapp(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_POWER_STATE)
      @PathParam("vappUuid") String vappUuid);

  /**
   * Managed shutdown of a vApp using the vApp's startup section settings.
   *
   * @param vappUuid vapp uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/managed-shutdown")
  TaskResponse managedShutdown(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_POWER_STATE)
      @PathParam("vappUuid") String vappUuid);

  /**
   * Suspend a vApp.
   *
   * @param vappUuid vapp uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/suspend")
  TaskResponse suspendVapp(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_POWER_STATE)
      @PathParam("vappUuid") String vappUuid);

  /**
   * Shutdown a vApp.
   * <p>
   * This action requires VMWare Tools to be installed on each VM in the vApp.
   *
   * @param vappUuid vapp uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/shutdown")
  TaskResponse shutdownVapp(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_POWER_STATE)
      @PathParam("vappUuid") String vappUuid);

  /**
   * Reset a vApp.
   *
   * @param vappUuid vapp uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/reset")
  TaskResponse resetVapp(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_POWER_STATE)
      @PathParam("vappUuid") String vappUuid);

  /**
   * Reboot a vApp.
   *
   * @param vappUuid vapp uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vappUuid}/actions/reboot")
  TaskResponse rebootVapp(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_POWER_STATE)
      @PathParam("vappUuid") String vappUuid);

  /**
   * Get a vApp by UUID.
   *
   * @param vAppUuid vapp uuid
   * @return vapp
   */
  @GET
  @Path("/{vappUuid}")
  VappResponse getVapp(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vAppUuid);

  /**
   * Get the list of VMs for a vApp.
   *
   * @param vappUuid vapp uuid
   * @return list of vms
   */
  @SkipSecurityTest("Custom logic in EJB")
  @GET
  @Path("/{vAppUuid}/vms")
  VmListResponse getVmsForVapp(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vAppUuid")
          String vappUuid);

  /**
   * Get the resource summary for the given vApp.
   *
   * @param vappUuid vapp uuid
   * @return resource summary for the given vapp
   */
  @GET
  @Path("/{vappUuid}/summary")
  VappResourceSummaryResponse getSummary(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid);

  /**
   * Enable the download of the vapp. Returns a TaskResponse which monitors the
   * progress of the download. Use {@link #downloadVapp(String)} endpoint when task
   * progress is synced to download the vapp.
   *
   * @param vappUuid vapp uuid
   * @return {@link TaskResponse} core task
   */
  @POST
  @Path("/{vappUuid}/actions/enable-download")
  TaskResponse enableDownload(
      @SecureEntityRef(Permission.COPY_MOVE_DOWNLOAD_ILAND_CLOUD_VAPP)
      @PathParam("vappUuid") String vappUuid);

  /**
   * Download the vApp as an OVA package. {@link #enableDownload(String)} must
   * be called and synced before attempting to download the vapp.
   *
   * @param vappUuid vapp uuid
   * @return {@link InputStream} ova file
   */
  @GET
  @Path("/{vappUuid}/download")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream downloadVapp(
      @SecureEntityRef(Permission.COPY_MOVE_DOWNLOAD_ILAND_CLOUD_VAPP)
      @PathParam("vappUuid") String vappUuid);

  /**
   * Gets download details for the vApp. Details include whether the vapp is
   * enabled for download, and, if enabled, the size and name of the download.
   *
   * @param vappUuid vapp uuid
   * @return the download details
   */
  @GET
  @Path("/{vappUuid}/download-details")
  DownloadDetailsResponse getDownloadDetailsForVapp(
      @SecureEntityRef(Permission.COPY_MOVE_DOWNLOAD_ILAND_CLOUD_VAPP)
      @PathParam("vappUuid") String vappUuid);

  /**
   * Get the map of resource summaries for all VMs in the given vApp.
   *
   * @param vappUuid vApp uuid
   * @return map of VM uuid to vm resource summary
   */
  @GET
  @Path("{vappUuid}/vm-summary-map")
  VmResourceSummaryMapResponse getVmResourceSummariesForVapp(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid);

  /**
   * Get the storage profiles available to the vApp.
   *
   * @param vappUuid        vApp uuid
   * @param includeDisabled whether to include disabled profiles (defaults to
   *                        false if not explicitly provided)
   * @return list of storage profiles available to the vApp
   */
  @GET
  @Path("/{vappUuid}/available-storage-profiles")
  StorageProfileListResponse getAvailableStorageProfiles(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid,
      @QueryParam("includeDisabled") Boolean includeDisabled);

  /**
   * Gets the vApp's backup status.
   *
   * @param vappUuid the UUID of the vApp
   * @return vApp backup status details
   */
  @GET
  @Path("/{vappUuid}/backup-status")
  VappBackupStatusDetailResponse getBackupStatus(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid);

  /**
   * Gets the vApp's integrated backup status.
   *
   * @param vappUuid the UUID of the vApp
   * @return vApp integrated backup status details
   */
  @GET
  @Path("/{vappUuid}/integrated-backup-status")
  VappIntegratedBackupStatusDetailResponse getIntegratedBackupStatus(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid);

  /**
   * Get the product sections for a vApp.
   *
   * @param vappUuid the UUID of the vApp
   * @return a list of product sections
   */
  @GET
  @Path("/{vappUuid}/product-sections")
  ProductSectionListResponse getProductSections(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP) @PathParam("vappUuid")
          String vappUuid);

  /**
   * Update product section properties of a vApp.
   *
   * @param vappUuid the UUID of the vApp
   * @param params   the map of keys/values to update
   * @return a list of product sections
   */
  @POST
  @Path("/{vappUuid}/actions/update-product-section-properties")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateProductSectionProperties(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_CONFIGURATION)
      @PathParam("vappUuid") String vappUuid,
      UpdateProductSectionPropertiesRequest params);

}
