/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.notification;

import java.io.Serializable;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Preferences Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserPreferencesResponse implements Serializable {

  private static final long serialVersionUID = -1974339160253748559L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Map<String, String> preferences;

  public UserPreferencesResponse(final Map<String, String> preferences) {
    this.preferences = preferences;
  }

  /**
   * Get the user preferences map.
   *
   * @return {@link Map} user preferences
   */
  public Map<String, String> getPreferences() {
    return preferences;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserPreferencesResponse that = (UserPreferencesResponse) o;

    return preferences != null ?
        preferences.equals(that.preferences) :
        that.preferences == null;
  }

  @Override
  public int hashCode() {
    return preferences != null ? preferences.hashCode() : 0;
  }

  @Override
  public String toString() {
    return "UserPreferencesResponse{" + "preferences=" + preferences + '}';
  }

}
