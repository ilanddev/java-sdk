/*
 * Copyright (c) 2013,2014 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 205 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */
package com.iland.core.web.rest.api;

import java.io.InputStream;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.common.UpdateMetadataRequest;
import com.iland.core.web.rest.request.media.MediaCloneRequest;
import com.iland.core.web.rest.request.media.MediaUpdateRequest;
import com.iland.core.web.rest.response.media.MediaResponse;
import com.iland.core.web.rest.response.metadata.MetadataListResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Media Resource Interface v1.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Media")
@Path("/media")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface MediaResource {

  /**
   * Retrieve media.
   *
   * @param mediaUuid media uuid
   * @return media object
   */
  @GET
  @Path("/{mediaUuid}")
  MediaResponse getMedia(@SecureEntityRef(Permission.VIEW_ILAND_CLOUD_MEDIA)
  @PathParam("mediaUuid") String mediaUuid);

  /**
   * Retrieve metadata associated with a media.
   *
   * @param mediaUuid media uuid
   * @return list of metadata for the given media
   */
  @GET
  @Path("/{mediaUuid}/metadata")
  MetadataListResponse getMetadataForMedia(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_MEDIA)
      @PathParam("mediaUuid") String mediaUuid);

  /**
   * Add / update metadata associated with a media.
   *
   * @param mediaUuid media uuid
   * @param metadata  list of metadata
   * @return asynchronous task details
   */
  @PUT
  @Path("/{mediaUuid}/metadata")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateMetadataForMedia(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_MEDIA_CONFIGURATION)
      @PathParam("mediaUuid") String mediaUuid,
      List<UpdateMetadataRequest> metadata);

  /**
   * Delete a specific piece of metadata associated with a media by its key.
   *
   * @param mediaUuid media uuid
   * @param key       metadata key
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{mediaUuid}/metadata/{key}")
  TaskResponse deleteMetadataForMedia(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_MEDIA_CONFIGURATION)
      @PathParam("mediaUuid") String mediaUuid, @PathParam("key") String key);

  /**
   * Update a Media.
   * <p>
   * Capable of updating the media name, description and storage profile.
   *
   * @param mediaUuid media uuid
   * @param spec      specification for updating media
   * @return asynchronous task details
   */
  @PUT
  @Path("/{mediaUuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateMedia(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_MEDIA_CONFIGURATION)
      @PathParam("mediaUuid") String mediaUuid, MediaUpdateRequest spec);

  /**
   * Delete a Media.
   *
   * @param mediaUuid media uuid
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{mediaUuid}")
  TaskResponse deleteMedia(@SecureEntityRef(Permission.DELETE_ILAND_CLOUD_MEDIA)
  @PathParam("mediaUuid") String mediaUuid);

  /**
   * Clone a given media.
   * <p>
   * The name of the media as well as the catalog, vDC, and storage profile
   * placement of the newly created media are determined by the parameters
   * submitted in the specification.
   * <p>
   * If no storage profile is explicitly submitted in the spec, the vDC default
   * storage profile will be used.
   *
   * @param mediaUuid media uuid to clone
   * @param spec      specification for cloning media
   * @return asynchronous task details
   */
  @POST
  @SkipSecurityTest("Custom logic in EJB method, need custom security test.")
  @Path("/{mediaUuid}/actions/clone")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse cloneMedia(
      @SecureEntityRef(Permission.CLONE_DOWNLOAD_ILAND_CLOUD_MEDIA)
      @PathParam("mediaUuid") String mediaUuid, MediaCloneRequest spec);

  /**
   * Download a Media as an ISO file.
   *
   * @param mediaUuid media uuid
   */
  @GET
  @Path("/{mediaUuid}/download")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream downloadMedia(
      @SecureEntityRef(Permission.CLONE_DOWNLOAD_ILAND_CLOUD_MEDIA)
      @PathParam("mediaUuid") String mediaUuid);

  /**
   * Sync a media item belonging to a catalog with its source object
   *
   * @param mediaUuid media uuid to sync
   * @return asynchronous task details
   */
  @POST
  @Path("/{mediaUuid}/actions/sync")
  TaskResponse syncMedia(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_MEDIA_CONFIGURATION)
      @PathParam("mediaUuid") String mediaUuid);

}
