/*
 * Copyright (c) 2013 - 2017, iland Internet Solutions, Corp
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of iland Internet Solutions, Corp nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
package com.iland.core.web.sdk.connection;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.Charset;

import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientResponseContext;
import javax.ws.rs.client.ClientResponseFilter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import org.apache.commons.io.IOUtils;

import com.iland.core.api.error.ApiError;
import com.iland.core.api.error.ApiErrorType;

/**
 * Intercepts API errors to return our custom exception classes.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class ApiClientErrorInterceptor implements ClientResponseFilter {

	private final Gson gson = new GsonBuilder().create();

	@Override
	public void filter(final ClientRequestContext requestContext,
		final ClientResponseContext responseContext) throws IOException {
		final int status = responseContext.getStatus();
		if (status >= 400) {
			final String data = data(responseContext);
			final ApiError error = createError(data, status);

			throw new IlandApiException(error);
		}
	}

	private String data(final ClientResponseContext responseContext)
		throws IOException {
		final StringWriter writer = new StringWriter();
		try (final InputStream in = responseContext.getEntityStream()) {
			IOUtils.copy(in, writer, Charset.defaultCharset().name());
		}

		return writer.toString();
	}

	private ApiError createError(final String data, final int status) {
		ApiError error;
		try {
			error = gson.fromJson(data, ApiError.class);
		} catch (final JsonSyntaxException e) {
			final String errorMessage = String.format(
				"An unexpected error occurred. Server response: %s", data);
			error = new ApiError(ApiErrorType.UNKNOWN_ERROR, 500, errorMessage);
		}
		error.setStatus(status);

		return error;
	}

}
