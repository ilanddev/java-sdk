/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vapptemplate;

import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * vApp Template EULA section.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class EulaSection {

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The info field of the template OVF EULA section.")
  private final String info;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The license field of the template OVF EULA section.")
  private final String license;

  /**
   * Creates a new EULA section.
   *
   * @param info    the info field
   * @param license the license field
   */
  public EulaSection(final String info, final String license) {
    this.info = info;
    this.license = license;
  }

  /**
   * Gets the info field of the EULA section.
   */
  public String getInfo() {
    return info;
  }

  /**
   * Gets the license field of the EULA section.
   */
  public String getLicense() {
    return license;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final EulaSection that = (EulaSection) o;
    return Objects.equals(info, that.info) && Objects
        .equals(license, that.license);
  }

  @Override
  public int hashCode() {
    return Objects.hash(info, license);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("info", info)
        .add("license", license).toString();
  }
}
