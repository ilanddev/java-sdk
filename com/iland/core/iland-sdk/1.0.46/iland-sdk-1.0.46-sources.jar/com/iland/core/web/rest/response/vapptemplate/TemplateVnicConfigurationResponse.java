/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vapptemplate;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Template VNIC Configuration Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class TemplateVnicConfigurationResponse implements Serializable {

  private static final long serialVersionUID = -6648181054896079270L;


  public enum IpAddressingMode {

    DHCP,

    MANUAL,

    POOL,

    NONE,

  }


  public enum AdapterType {

    E1000E,

    E1000,

    VLANCE,

    VMXNET,

    FLEXIBLE,

    VMXNET2,

    VMXNET3,

  }


  @Expose
  @SerializedName("network_name")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String networkName;

  @Expose
  @SerializedName("ip_assignment_mode")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final IpAddressingMode ipAssignmentMode;

  @Expose
  @SerializedName("ip_address")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String ipAddress;

  @Expose
  @SerializedName("primary_vnic")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean primaryVnic;

  @Expose
  @SerializedName("network_adapter_type")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final AdapterType networkAdapterType;

  @Expose
  @SerializedName("needs_customization")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean needsCustomization;

  @Expose
  @SerializedName("connected")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean connected;

  /**
   * Instantiates a new Template vnic configuration.
   *
   * @param networkName        the network uuid
   * @param ipAssignmentMode   the ip assignment mode
   * @param ipAddress          the ip address
   * @param primaryVnic        the primary vnic
   * @param networkAdapterType the network adapter type
   * @param needsCustomization the needs customization
   * @param connected          the connected
   */
  public TemplateVnicConfigurationResponse(final String networkName,
      final IpAddressingMode ipAssignmentMode, final String ipAddress,
      final boolean primaryVnic, final AdapterType networkAdapterType,
      final boolean needsCustomization, final boolean connected) {
    this.networkName = networkName;
    this.ipAssignmentMode = ipAssignmentMode;
    this.ipAddress = ipAddress;
    this.primaryVnic = primaryVnic;
    this.networkAdapterType = networkAdapterType;
    this.needsCustomization = needsCustomization;
    this.connected = connected;
  }

  /**
   * Gets network uuid.
   *
   * @return the network uuid
   */
  public String getNetworkName() {
    return networkName;
  }

  /**
   * Gets ip assignment mode.
   *
   * @return the ip assignment mode
   */
  public IpAddressingMode getIpAssignmentMode() {
    return ipAssignmentMode;
  }

  /**
   * Gets ip address.
   *
   * @return the ip address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Is primary vnic boolean.
   *
   * @return the boolean
   */
  public boolean isPrimaryVnic() {
    return primaryVnic;
  }

  /**
   * Gets network adapter type.
   *
   * @return the network adapter type
   */
  public AdapterType getNetworkAdapterType() {
    return networkAdapterType;
  }

  /**
   * Is needs customization boolean.
   *
   * @return the boolean
   */
  public boolean isNeedsCustomization() {
    return needsCustomization;
  }

  /**
   * Is connected boolean.
   *
   * @return the boolean
   */
  public boolean isConnected() {
    return connected;
  }

}
