/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.recovery;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Recovery Group Descriptor Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class RecoveryGroupDescriptorResponse implements Serializable {

  private static final long serialVersionUID = -3869179964019130300L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private RecoveryGroupTypeResponse type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int orderIndex;

  public RecoveryGroupDescriptorResponse(final String name, final String uuid,
      final RecoveryGroupTypeResponse type, final int orderIndex) {
    this.name = name;
    this.uuid = uuid;
    this.type = type;
    this.orderIndex = orderIndex;
  }

  /**
   * Get the recovery group name.
   *
   * @return recovery group name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the recovery group UUID.
   *
   * @return plan UUID
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Get the recovery group type.
   *
   * @return {@link RecoveryGroupTypeResponse} group type
   */
  public RecoveryGroupTypeResponse getType() {
    return type;
  }

  /**
   * Get the order index for the recovery group.
   *
   * @return recovery group order index
   */
  public int getOrderIndex() {
    return orderIndex;
  }

}
