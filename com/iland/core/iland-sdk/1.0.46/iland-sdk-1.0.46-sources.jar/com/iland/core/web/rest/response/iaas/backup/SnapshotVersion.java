/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Instant;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * SnapshotVersion.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface SnapshotVersion {

  /**
   * The time that the snapshot was captured.
   */
  Instant startTime();

  /**
   * Specifies the number of the attempts made by the VCloudProtectionJob Run to
   * capture a snapshot of the object. For example, if an snapshot is
   * successfully captured after three attempts, this field equals 3.
   */
  long attemptNumber();

  /**
   * Specifies the size of the data captured from the source object. For a full
   * backup (where Change Block Tracking is not utilized) this field is equal to
   * logicalSizeBytes. For an incremental backup (where Change Block Tracking is
   * utilized), this field specifies the size of the data that has changed since
   * the last backup.
   */
  long deltaSizeBytes();

  /**
   * Specifies if an app-consistent snapshot was captured. For example, was the
   * VM was quiesced before the snapshot was captured.
   */
  boolean appConsistent();

  /**
   * Specifies if the snapshot is a full backup. For example, all blocks of the
   * VM is captured and Change Block Tracking is not utilized.
   */
  boolean fullBackup();

  /**
   * Specifies the id of the backup run.
   */
  String backupRunUid();

  /**
   * Specifies the size of the snapshot if the data is fully hydrated or
   * expanded and not reduced by change-block tracking, compression and
   * deduplication. For example if a VMDK of size 100GB is created with thin
   * provisioning and the disk size to store the VMDK is 20GB. The logical size
   * of this object is 100GB and the physical size is 20GB.
   */
  long logicalSizeBytes();

}
