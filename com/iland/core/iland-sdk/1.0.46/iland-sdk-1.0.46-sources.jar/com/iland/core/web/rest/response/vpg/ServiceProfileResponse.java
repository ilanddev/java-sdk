/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vpg;

import java.io.Serializable;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Service Profile Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class ServiceProfileResponse implements Serializable {

  private static final long serialVersionUID = 8710699320381980447L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String location;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String serviceProfileIdentifier;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String serviceProfileName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int history;

  @Since(ApiVersion.ONE_DOT_ZERO)
  private final byte journalWarningThresholdInPercent;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final byte maxJournalSizeInPercent;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int rpo;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int testInterval;

  public ServiceProfileResponse(final String uuid, final String location,
      final String serviceProfileIdentifier, final String serviceProfileName,
      final String description, final int history,
      final byte journalWarningThresholdInPercent,
      final byte maxJournalSizeInPercent, final int rpo,
      final int testInterval) {
    this.uuid = uuid;
    this.location = location;
    this.serviceProfileIdentifier = serviceProfileIdentifier;
    this.serviceProfileName = serviceProfileName;
    this.description = description;
    this.history = history;
    this.journalWarningThresholdInPercent = journalWarningThresholdInPercent;
    this.maxJournalSizeInPercent = maxJournalSizeInPercent;
    this.rpo = rpo;
    this.testInterval = testInterval;
  }

  /**
   * Gets the uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets the location.
   *
   * @return the location
   */
  public String getLocation() {
    return location;
  }

  /**
   * Gets the service profile identifier.
   *
   * @return the service profile identifier
   */
  public String getServiceProfileIdentifier() {
    return serviceProfileIdentifier;
  }

  /**
   * Gets the service profile name.
   *
   * @return the service profile name
   */
  public String getServiceProfileName() {
    return serviceProfileName;
  }

  /**
   * Gets the description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets the history.
   *
   * @return the history
   */
  public int getHistory() {
    return history;
  }

  /**
   * Gets the journal warning threshold in percent.
   *
   * @return the journal warning threshold in percent
   */
  public byte getJournalWarningThresholdInPercent() {
    return journalWarningThresholdInPercent;
  }

  /**
   * Gets the max journal size in percent.
   *
   * @return the max journal size in percent
   */
  public byte getMaxJournalSizeInPercent() {
    return maxJournalSizeInPercent;
  }

  /**
   * Gets the rpo.
   *
   * @return the rpo
   */
  public int getRpo() {
    return rpo;
  }

  /**
   * Gets the test interval.
   *
   * @return the test interval
   */
  public int getTestInterval() {
    return testInterval;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final ServiceProfileResponse that = (ServiceProfileResponse) o;
    return getHistory() == that.getHistory()
        && getJournalWarningThresholdInPercent() == that
        .getJournalWarningThresholdInPercent()
        && getMaxJournalSizeInPercent() == that.getMaxJournalSizeInPercent()
        && getRpo() == that.getRpo() && getTestInterval() == that
        .getTestInterval() && Objects.equals(getUuid(), that.getUuid())
        && Objects.equals(getLocation(), that.getLocation()) && Objects
        .equals(getServiceProfileIdentifier(),
            that.getServiceProfileIdentifier()) && Objects
        .equals(getServiceProfileName(), that.getServiceProfileName())
        && Objects.equals(getDescription(), that.getDescription());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getUuid(), getLocation(), getServiceProfileIdentifier(),
        getServiceProfileName(), getDescription(), getHistory(),
        getJournalWarningThresholdInPercent(), getMaxJournalSizeInPercent(),
        getRpo(), getTestInterval());
  }

}
