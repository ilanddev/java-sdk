/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vpg;

import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Expanded Vpg Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class ExpandedVpgResponse extends EntityResponse
    implements Serializable {

  private static final long serialVersionUID = -5479440662126938856L;


  public enum ActiveProcessStage {

    IN_TEST,

    STARTING,

    STOPPING,

    NONE,

  }


  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private ServiceProfileResponse serviceProfile;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<VpgVmResponse> vms;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String orgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String serviceProfileUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vpgIdentifier;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vpgName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String organizationName;

  @SerializedName("actual_rpo")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int actualRPO;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final VpgEntitiesResponse entities;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final VpgStatusResponse status;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final VpgSubStatusResponse subStatus;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final VpgPriorityResponse priority;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int vmsCount;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private LocalDateTime lastTest;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String sourceSite;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String targetSite;

  @SerializedName("provisioned_storage_in_mb")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long provisionedStorageInMB;

  @SerializedName("used_storage_in_mb")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long usedStorageInMB;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long iops;

  @SerializedName("throughput_in_mb")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double throughputInMB;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String serviceProfileIdentifier;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean backupEnabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String recoverySiteIdentifier;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String protectedSiteIdentifier;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private ActiveProcessStage activeProcessStage;

  @SerializedName("recovery_journal_used_storage_in_mb")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long recoveryJournalUsedStorageInMB;

  @SerializedName("recovery_journal_provisioned_storage_in_mb")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long recoveryJournalProvisionedStorageInMB;

  public ExpandedVpgResponse(final String uuid, final String companyId,
      final String name, final boolean deleted, final Instant deletedDate,
      final Instant updatedDate, final ServiceProfileResponse serviceProfile,
      final List<VpgVmResponse> vms, final String orgUuid,
      final String locationId, final String serviceProfileUuid,
      final String vpgIdentifier, final String vpgName,
      final String organizationName, final int actualRPO,
      final VpgEntitiesResponse entities, final VpgStatusResponse status,
      final VpgSubStatusResponse subStatus, final VpgPriorityResponse priority,
      final int vmsCount, final LocalDateTime lastTest, final String sourceSite,
      final String targetSite, final long provisionedStorageInMB,
      final long usedStorageInMB, final long iops, final double throughputInMB,
      final String serviceProfileIdentifier, final boolean backupEnabled,
      final String recoverySiteIdentifier, final String protectedSiteIdentifier,
      final ActiveProcessStage activeProcessStage,
      final long recoveryJournalUsedStorageInMB,
      final long recoveryJournalProvisionedStorageInMB) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.serviceProfile = serviceProfile;
    this.vms = vms;
    this.orgUuid = orgUuid;
    this.locationId = locationId;
    this.serviceProfileUuid = serviceProfileUuid;
    this.vpgIdentifier = vpgIdentifier;
    this.vpgName = vpgName;
    this.organizationName = organizationName;
    this.actualRPO = actualRPO;
    this.entities = entities;
    this.status = status;
    this.subStatus = subStatus;
    this.priority = priority;
    this.vmsCount = vmsCount;
    this.lastTest = lastTest;
    this.sourceSite = sourceSite;
    this.targetSite = targetSite;
    this.provisionedStorageInMB = provisionedStorageInMB;
    this.usedStorageInMB = usedStorageInMB;
    this.iops = iops;
    this.throughputInMB = throughputInMB;
    this.serviceProfileIdentifier = serviceProfileIdentifier;
    this.backupEnabled = backupEnabled;
    this.recoverySiteIdentifier = recoverySiteIdentifier;
    this.protectedSiteIdentifier = protectedSiteIdentifier;
    this.activeProcessStage = activeProcessStage;
    this.recoveryJournalUsedStorageInMB = recoveryJournalUsedStorageInMB;
    this.recoveryJournalProvisionedStorageInMB =
        recoveryJournalProvisionedStorageInMB;
  }

  /**
   * Gets the service profile.
   *
   * @return the service profile
   */
  public ServiceProfileResponse getServiceProfile() {
    return serviceProfile;
  }

  /**
   * Gets the vms.
   *
   * @return the vms
   */
  public List<VpgVmResponse> getVms() {
    return vms;
  }

  /**
   * Gets the vpg identifier.
   *
   * @return the vpg identifier
   */
  public String getVpgIdentifier() {
    return vpgIdentifier;
  }

  /**
   * Gets the vpg name.
   *
   * @return the vpg name
   */
  public String getVpgName() {
    return vpgName;
  }

  /**
   * Gets the organization name.
   *
   * @return the organization name
   */
  public String getOrganizationName() {
    return organizationName;
  }

  /**
   * Gets the actual rpo.
   *
   * @return the actual rpo
   */
  public int getActualRPO() {
    return actualRPO;
  }

  /**
   * Gets the entities.
   *
   * @return the entities
   */
  public VpgEntitiesResponse getEntities() {
    return entities;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public VpgStatusResponse getStatus() {
    return status;
  }

  /**
   * Gets the sub status.
   *
   * @return the sub status
   */
  public VpgSubStatusResponse getSubStatus() {
    return subStatus;
  }

  /**
   * Gets the priorty.
   *
   * @return the priorty
   */
  public VpgPriorityResponse getPriorty() {
    return priority;
  }

  /**
   * Gets the vms count.
   *
   * @return the vms count
   */
  public int getVmsCount() {
    return vmsCount;
  }

  /**
   * Gets the last test.
   *
   * @return the last test
   */
  public LocalDateTime getLastTest() {
    return lastTest;
  }

  /**
   * Gets the source site.
   *
   * @return the source site
   */
  public String getSourceSite() {
    return sourceSite;
  }

  /**
   * Gets the target site.
   *
   * @return the target site
   */
  public String getTargetSite() {
    return targetSite;
  }

  /**
   * Gets the provisioned storage in mb.
   *
   * @return the provisioned storage in mb
   */
  public long getProvisionedStorageInMB() {
    return provisionedStorageInMB;
  }

  /**
   * Gets the used storage in mb.
   *
   * @return the used storage in mb
   */
  public long getUsedStorageInMB() {
    return usedStorageInMB;
  }

  /**
   * Gets the i ops.
   *
   * @return the i ops
   */
  public long getiOPS() {
    return iops;
  }

  /**
   * Gets the throughput in mb.
   *
   * @return the throughput in mb
   */
  public double getThroughputInMB() {
    return throughputInMB;
  }

  /**
   * Gets the service profile identifier.
   *
   * @return the service profile identifier
   */
  public String getServiceProfileIdentifier() {
    return serviceProfileIdentifier;
  }

  /**
   * Checks if is backup enabled.
   *
   * @return true, if is backup enabled
   */
  public boolean isBackupEnabled() {
    return backupEnabled;
  }

  /**
   * Gets the recovery site identifier.
   *
   * @return the recovery site identifier
   */
  public String getRecoverySiteIdentifier() {
    return recoverySiteIdentifier;
  }

  /**
   * Gets the protected site identifier.
   *
   * @return the protected site identifier
   */
  public String getProtectedSiteIdentifier() {
    return protectedSiteIdentifier;
  }

  /**
   * Gets the priority.
   *
   * @return {@link VpgPriorityResponse} priority response
   */
  public VpgPriorityResponse getPriority() {
    return priority;
  }

  /**
   * Gets the active process stage.
   *
   * @return {@link ActiveProcessStage}
   */
  public ActiveProcessStage getActiveProcessStage() {
    return activeProcessStage;
  }

  /**
   * Gets the recovery journal used storage in MB.
   *
   * @return the recovery journal used storage
   */
  public long getRecoveryJournalUsedStorageInMB() {
    return recoveryJournalUsedStorageInMB;
  }

  /**
   * Gets the org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets the VPG location.
   *
   * @return the location ID
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Gets the UUID of the associated service profile.
   *
   * @return the service profile UUID
   */
  public String getServiceProfileUuid() {
    return serviceProfileUuid;
  }

  /**
   * Gets the recovery journal provisioned storage in MB
   *
   * @return the recovery journal provisioned storage
   */
  public long getRecoveryJournalProvisionedStorageInMB() {
    return recoveryJournalProvisionedStorageInMB;
  }

}
