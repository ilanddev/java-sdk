/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vm;

import java.io.Serializable;
import java.math.BigInteger;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.DiskTypeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Virtual Disk Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VirtualDiskResponse implements Serializable {

  private static final long serialVersionUID = -3535585048373543989L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private BigInteger size;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private DiskTypeResponse type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String storageProfileUuid;

  public VirtualDiskResponse(final String name, final BigInteger size,
      final DiskTypeResponse type, final String storageProfileUuid) {
    this.name = name;
    this.size = size;
    this.type = type;
    this.storageProfileUuid = storageProfileUuid;
  }

  /**
   * Get the name.
   *
   * @return {@link String} disk name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the disk size.
   *
   * @return {@link BigInteger} size
   */
  public BigInteger getSize() {
    return size;
  }

  /**
   * Get the disk bus type.
   *
   * @return {@link DiskTypeResponse} disk bus type
   */
  public DiskTypeResponse getType() {
    return type;
  }

  /**
   * Get the disks storage profile.
   *
   * @return {@link String} storage profile uuid
   */
  public String getStorageProfileUuid() {
    return storageProfileUuid;
  }

}
