/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vac;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VAC Backup Directory Response.
 *
 * @author <a href="mailto:nkasprza@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public final class BaBackupDirectoryResponse implements Serializable {

  private static final long serialVersionUID = 3737913461961847305L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final float sizeMb;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant modifiedAt;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String repositoryName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String backupServerName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean recycled;

  /**
   * Instantiates a new Ba backup directory response.
   *
   * @param uuid             the uuid
   * @param name             the name
   * @param sizeMb           the size mb
   * @param modifiedAt       the modified at
   * @param repositoryName   the repository name
   * @param backupServerName the backup server name
   * @param recycled         the recycled
   */
  public BaBackupDirectoryResponse(final String uuid, final String name,
      final float sizeMb, final Instant modifiedAt,
      final String repositoryName, final String backupServerName,
      final boolean recycled) {
    this.uuid = uuid;
    this.name = name;
    this.sizeMb = sizeMb;
    this.modifiedAt = modifiedAt;
    this.repositoryName = repositoryName;
    this.backupServerName = backupServerName;
    this.recycled = recycled;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets size mb.
   *
   * @return the size mb
   */
  public float getSizeMb() {
    return sizeMb;
  }

  /**
   * Gets modified at.
   *
   * @return the modified at
   */
  public Instant getModifiedAt() {
    return modifiedAt;
  }

  /**
   * Gets repository name.
   *
   * @return the repository name
   */
  public String getRepositoryName() {
    return repositoryName;
  }

  /**
   * Gets backup server name.
   *
   * @return the backup server name
   */
  public String getBackupServerName() {
    return backupServerName;
  }

  /**
   * Is recycled boolean.
   *
   * @return the boolean
   */
  public boolean isRecycled() {
    return recycled;
  }

}
