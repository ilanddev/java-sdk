/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.vbo;

import java.util.Set;

import com.iland.core.web.rest.response.common.SetResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Set wrapper for {@link O365RestorePointResponse}.
 */
@APIDoc
public final class O365RestorePointSetResponse
    extends SetResponse<O365RestorePointResponse> {

  private static final long serialVersionUID = 1L;

  /**
   * Create a restore point set response.
   *
   * @param data the set of restore points
   */
  public O365RestorePointSetResponse(final Set<O365RestorePointResponse> data) {
    super(data);
  }
}
