/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vdi;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.shared.vdi.NetworkConnectionType;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * The type Vdi automation deployment response.
 */
@APIDoc
public class VdiAutomationDeploymentResponse implements Serializable {

  private static final long serialVersionUID = 5010569806355074855L;

  @Expose
  @JsonRequired("The unique identifier for the VDI automation group deployment.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @JsonRequired("The UUID of the parent organization.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String orgUuid;

  @Expose
  @JsonRequired("The unique identifier for the VDI automation group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String automationGroupUuid;

  @Expose
  @JsonRequired("The state of the deployment.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final State state;

  @Expose
  @JsonRequired("The user that the deployment is assigned to.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final DeploymentUser deploymentUser;

  @Expose
  @JsonRequired("Deployment configuration from the associated automation group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final AutomationGroupConfig configuration;

  @Expose
  @JsonRequired("Deployment details that are specific to the virtual desktop.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final DeploymentDetails deploymentDetails;

  @Expose
  @JsonOptional("Deployment failure message. Will be undefined if the deployment state is not FAILED.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String failureMessage;

  /**
   * Instantiates a new Vdi automation deployment response.
   *
   * @param uuid                the uuid
   * @param orgUuid             the organization uuid
   * @param automationGroupUuid the automation group uuid
   * @param state               the state
   * @param deploymentUser      the associated deployment user
   * @param configuration       the configuration
   * @param deploymentDetails   the deployment details
   * @param failureMessage      the failure message
   */
  public VdiAutomationDeploymentResponse(final String uuid,
      final String orgUuid, final String automationGroupUuid, final State state,
      final DeploymentUser deploymentUser,
      final AutomationGroupConfig configuration,
      final DeploymentDetails deploymentDetails, final String failureMessage) {
    this.uuid = uuid;
    this.orgUuid = orgUuid;
    this.automationGroupUuid = automationGroupUuid;
    this.state = state;
    this.deploymentUser = deploymentUser;
    this.configuration = configuration;
    this.deploymentDetails = deploymentDetails;
    this.failureMessage = failureMessage;
  }


  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets automation group uuid.
   *
   * @return the automation group uuid
   */
  public String getAutomationGroupUuid() {
    return automationGroupUuid;
  }

  /**
   * Gets state.
   *
   * @return the state
   */
  public State getState() {
    return state;
  }

  /**
   * Gets configuration.
   *
   * @return the configuration
   */
  public AutomationGroupConfig getConfiguration() {
    return configuration;
  }

  /**
   * Gets deployment details.
   *
   * @return the deployment details
   */
  public DeploymentDetails getDeploymentDetails() {
    return deploymentDetails;
  }

  /**
   * Gets the deployment user.
   *
   * @return the deployment user
   */
  public DeploymentUser getDeploymentUser() {
    return deploymentUser;
  }

  /**
   * Gets failure message.
   *
   * @return the failure message
   */
  public String getFailureMessage() {
    return failureMessage;
  }

  /**
   * The type Deployment details.
   */
  @APIDoc
public static class DeploymentDetails {

    @Expose
    @JsonOptional("The internal IP address that has been assigned on the org vdc network.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String internalIp;

    @Expose
    @JsonOptional("The public port that is exposing RDP.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String publicRdpPort;

    @Expose
    @JsonOptional("The UUID of the VM that backs this deployment.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String vmUuid;

    @Expose
    @JsonOptional("The UUID of the vApp that backs this deployment.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String vappUuid;

    @Expose
    @JsonOptional("The initial guest admin password.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String guestAdminPassword;

    @Expose
    @JsonOptional("The computer name that has been assigned to the desktop VM.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String computerName;

    /**
     * Instantiates a new Deployment details.
     *
     * @param internalIp         the internal ip
     * @param publicRdpPort      the public rdp port
     * @param vmUuid             the vm uuid
     * @param vappUuid           the vapp uuid
     * @param guestAdminPassword the guest admin password
     * @param computerName       the computer name
     */
    public DeploymentDetails(final String internalIp,
        final String publicRdpPort, final String vmUuid, final String vappUuid,
        final String guestAdminPassword, final String computerName) {
      this.internalIp = internalIp;
      this.publicRdpPort = publicRdpPort;
      this.vmUuid = vmUuid;
      this.vappUuid = vappUuid;
      this.guestAdminPassword = guestAdminPassword;
      this.computerName = computerName;
    }

    /**
     * Gets internal ip.
     *
     * @return the internal ip
     */
    public String getInternalIp() {
      return internalIp;
    }

    /**
     * Gets public rdp port.
     *
     * @return the public rdp port
     */
    public String getPublicRdpPort() {
      return publicRdpPort;
    }

    /**
     * Gets vm uuid.
     *
     * @return the vm uuid
     */
    public String getVmUuid() {
      return vmUuid;
    }

    /**
     * Gets vapp uuid.
     *
     * @return the vapp uuid
     */
    public String getVappUuid() {
      return vappUuid;
    }

    /**
     * Gets guest admin password.
     *
     * @return the guest admin password
     */
    public String getGuestAdminPassword() {
      return guestAdminPassword;
    }

    /**
     * Gets computer name.
     *
     * @return the computer name
     */
    public String getComputerName() {
      return computerName;
    }
  }


  /**
   * The type Deployment user.
   */
  @APIDoc
public static class DeploymentUser {

    @Expose
    @JsonRequired("The UUID of the VDI user that the desktop deployment is assigned to.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String userUuid;

    @Expose
    @JsonRequired("The email address of the user that the desktop deployment is assigned to.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String userEmail;

    @Expose
    @JsonRequired("The full name of the user that the desktop deployment is assigned to.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String userFullName;


    /**
     * Instantiates a new Deployment user.
     *
     * @param userUuid     the user uuid
     * @param userEmail    the user email
     * @param userFullName the user full name
     */
    public DeploymentUser(final String userUuid, final String userEmail,
        final String userFullName) {
      this.userUuid = userUuid;
      this.userEmail = userEmail;
      this.userFullName = userFullName;
    }

    /**
     * Gets user uuid.
     *
     * @return the user uuid
     */
    public String getUserUuid() {
      return userUuid;
    }

    /**
     * Gets user email.
     *
     * @return the user email
     */
    public String getUserEmail() {
      return userEmail;
    }

    /**
     * Gets user full name.
     *
     * @return the user full name
     */
    public String getUserFullName() {
      return userFullName;
    }
  }


  /**
   * The type Automation group config.
   */
  @APIDoc
public static class AutomationGroupConfig {

    @Expose
    @JsonRequired("The VM template UUID.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String vmTemplateUuid;

    @Expose
    @JsonRequired("The UUID of the vDC that the desktop VM is deployed to.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String deploymentVdcUuid;

    @Expose
    @JsonRequired("The UUID of the org-vDC network that the VM is attached to.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String orgVdcNetworkUuid;

    @Expose
    @JsonOptional("The name of the domain that the VM will join.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String domainToJoin;

    @Expose
    @JsonOptional("The UUID of the edge that the org-vDC network is attached to and through which RDP NAT will be routed.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String edgeUuid;

    @Expose
    @JsonOptional("The public IP address through which RDP access will be provided.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final String publicRdpIp;

    @Expose
    @JsonRequired("The type of the network connections of deployments.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final NetworkConnectionType networkConnectionType;

    @Expose
    @JsonOptional("Whether joining a domain is enabled for deployments")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final boolean joinDomainEnabled;

    @Expose
    @JsonOptional("Whether to require users to reset the guest admin password after logging in.")
    @Since(ApiVersion.ONE_DOT_ZERO)
    private final boolean guestPasswordResetRequired;

    /**
     * Instantiates a new Automation group config.
     *
     * @param vmTemplateUuid             the vm template uuid
     * @param deploymentVdcUuid          the deployment vdc uuid
     * @param orgVdcNetworkUuid          the org vdc network uuid
     * @param domainToJoin               the domain to join
     * @param edgeUuid                   the edge uuid
     * @param publicRdpIp                the public ip
     * @param networkConnectionType      the network connection type
     * @param joinDomainEnabled          the join domain enabled
     * @param guestPasswordResetRequired the guest password reset required
     */
    public AutomationGroupConfig(final String vmTemplateUuid,
        final String deploymentVdcUuid, final String orgVdcNetworkUuid,
        final String domainToJoin, final String edgeUuid,
        final String publicRdpIp,
        final NetworkConnectionType networkConnectionType,
        final boolean joinDomainEnabled,
        final boolean guestPasswordResetRequired) {
      this.vmTemplateUuid = vmTemplateUuid;
      this.deploymentVdcUuid = deploymentVdcUuid;
      this.orgVdcNetworkUuid = orgVdcNetworkUuid;
      this.domainToJoin = domainToJoin;
      this.edgeUuid = edgeUuid;
      this.publicRdpIp = publicRdpIp;
      this.networkConnectionType = networkConnectionType;
      this.joinDomainEnabled = joinDomainEnabled;
      this.guestPasswordResetRequired = guestPasswordResetRequired;
    }

    /**
     * Gets vm template uuid.
     *
     * @return the vm template uuid
     */
    public String getVmTemplateUuid() {
      return vmTemplateUuid;
    }

    /**
     * Gets deployment vdc uuid.
     *
     * @return the deployment vdc uuid
     */
    public String getDeploymentVdcUuid() {
      return deploymentVdcUuid;
    }

    /**
     * Gets org vdc network uuid.
     *
     * @return the org vdc network uuid
     */
    public String getOrgVdcNetworkUuid() {
      return orgVdcNetworkUuid;
    }

    /**
     * Gets domain to join.
     *
     * @return the domain to join
     */
    public String getDomainToJoin() {
      return domainToJoin;
    }

    /**
     * Gets edge uuid.
     *
     * @return the edge uuid
     */
    public String getEdgeUuid() {
      return edgeUuid;
    }

    /**
     * Gets public ip.
     *
     * @return the public ip
     */
    public String getPublicRdpIp() {
      return publicRdpIp;
    }

    /**
     * Gets network connection type.
     *
     * @return the network connection type
     */
    public NetworkConnectionType getNetworkConnectionType() {
      return networkConnectionType;
    }

    /**
     * Is join domain enabled boolean.
     *
     * @return the boolean
     */
    public boolean isJoinDomainEnabled() {
      return joinDomainEnabled;
    }

    /**
     * Is guest password reset required boolean.
     *
     * @return the boolean
     */
    public boolean isGuestPasswordResetRequired() {
      return guestPasswordResetRequired;
    }
  }


  /**
   * The enum State.
   */
  public enum State {

    /**
     * Queued for deployment state.
     */
    QUEUED_FOR_DEPLOYMENT,

    /**
     * Deploying state.
     */
    DEPLOYING,

    /**
     * Booting state.
     */
    BOOTING,

    /**
     * Configuring rdp access state.
     */
    CONFIGURING_RDP_ACCESS,

    /**
     * Sending user access notification state.
     */
    SENDING_USER_ACCESS_NOTIFICATION,

    /**
     * Ready state.
     */
    READY,

    /**
     * Queued for undeployment state.
     */
    QUEUED_FOR_UNDEPLOYMENT,

    /**
     * Sending user undeploy notification state.
     */
    SENDING_USER_UNDEPLOY_NOTIFICATION,

    /**
     * Removing rdp access state.
     */
    REMOVING_RDP_ACCESS,

    /**
     * Powering down state.
     */
    POWERING_DOWN,

    /**
     * Undeploying state.
     */
    UNDEPLOYING,

    /**
     * Failed state;
     */
    FAILED

  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final VdiAutomationDeploymentResponse that =
        (VdiAutomationDeploymentResponse) o;
    return Objects.equals(uuid, that.uuid) && Objects
        .equals(orgUuid, that.orgUuid) && Objects
        .equals(automationGroupUuid, that.automationGroupUuid)
        && state == that.state && Objects
        .equals(deploymentUser, that.deploymentUser) && Objects
        .equals(configuration, that.configuration) && Objects
        .equals(deploymentDetails, that.deploymentDetails) && Objects
        .equals(failureMessage, that.failureMessage);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(uuid, orgUuid, automationGroupUuid, state, deploymentUser,
            configuration, deploymentDetails, failureMessage);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("uuid", uuid)
        .add("orgUuid", orgUuid).add("automationGroupUuid", automationGroupUuid)
        .add("state", state).add("deploymentUser", deploymentUser)
        .add("configuration", configuration)
        .add("deploymentDetails", deploymentDetails)
        .add("failureMessage", failureMessage).toString();
  }
}
