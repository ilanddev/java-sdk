/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.core.web.rest.response.task.PagedTaskListResponse;
import com.iland.core.web.rest.response.task.TaskFilterParams;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Task Resource.
 *
 * @author <a href="mailto:csnyder@iland.com">Brett Snyder</a>
 */
@APIProperties(name = "Tasks")
@Path("/tasks")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface TaskResource {

  /**
   * Get a task by its UUID.
   *
   * @param uuid task UUID
   * @return the task details
   */
  @GET
  @Path("/{uuid}")
  TaskResponse getTask(@PathParam("uuid") String uuid);

  /**
   * Allows a client to perform dynamic task queries.
   *
   * @return the list of queried tasks
   */
  @GET
  PagedTaskListResponse getTasks(@BeanParam TaskFilterParams filters);

  /**
   * Cancel a task. Supported for catalog upload tasks only.
   *
   * @deprecated Use {@link #cancelTask(String, String)}.
   *
   * @param uuid task UUID
   */
  @POST
  @Path("/{uuid}/actions/cancel")
  @Deprecated(since = "12.31")
  void cancelTask(@PathParam("uuid") String uuid);

  /**
   * Cancel a task. Supported for catalog upload tasks and Copy VM to another
   * vApp tasks. The locationId determines the correct routing for tasks that
   * are bound to a vendor instance location e.g vCloud tasks like copy VM.
   *
   * <p>Returns 400 if the task type is not cancellable or the task is not
   * running, 403 if the caller is not a system admin or the task initiator,
   * and 404 if the task UUID is not found.
   *
   * @param locationId the location Id (e.g. dal22.ilandcloud.com)
   * @param uuid       task UUID
   */
  @POST
  @Path("{locationId}/{uuid}/actions/cancel")
  void cancelTask(@PathParam("locationId") String locationId,
      @PathParam("uuid") String uuid);

}
