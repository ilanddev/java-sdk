/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.shared.billing.CurrencyCode;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Cloud Tenant Bill Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class CloudTenantBillResponse implements Serializable {

  private static final long serialVersionUID = 960941543562455596L;

  private static final String STORAGE_QUOTA_IN_GB = "storage_quota_in_gb";

  private static final String STORAGE_PRICE_PER_GB = "storage_price_per_gb";

  private static final String INSIDER_PROTECTION_PRICE_PER_GB =
      "insider_protection_price_per_gb";

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double total;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int year;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int month;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private CurrencyCode currencyCode;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(STORAGE_QUOTA_IN_GB)
  private long storageQuotaInGB;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(STORAGE_PRICE_PER_GB)
  private double storagePricePerGB;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double fullMonthContractCost;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean hasInsiderProtection;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(INSIDER_PROTECTION_PRICE_PER_GB)
  private double insiderProtectionPricePerGB;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double insiderProtectionTotal;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double wanAcceleratorApplianceTotal;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double dedicatedVeeamGatewayTotal;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double rentalLicensesSubscriptionsTotal;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double crossConnectSubscriptionsTotal;

  public CloudTenantBillResponse(final double total, final int year,
      final int month, final CurrencyCode currencyCode,
      final long storageQuotaInGB, final double storagePricePerGB,
      final double fullMonthContractCost, final boolean hasInsiderProtection,
      final double insiderProtectionPricePerGB,
      final double insiderProtectionTotal,
      final double wanAcceleratorApplianceTotal,
      final double dedicatedVeeamGatewayTotal,
      final double rentalLicensesSubscriptionsTotal,
      final double crossConnectSubscriptionsTotal) {
    this.total = total;
    this.year = year;
    this.month = month;
    this.currencyCode = currencyCode;
    this.storageQuotaInGB = storageQuotaInGB;
    this.storagePricePerGB = storagePricePerGB;
    this.fullMonthContractCost = fullMonthContractCost;
    this.hasInsiderProtection = hasInsiderProtection;
    this.insiderProtectionPricePerGB = insiderProtectionPricePerGB;
    this.insiderProtectionTotal = insiderProtectionTotal;
    this.wanAcceleratorApplianceTotal = wanAcceleratorApplianceTotal;
    this.dedicatedVeeamGatewayTotal = dedicatedVeeamGatewayTotal;
    this.rentalLicensesSubscriptionsTotal = rentalLicensesSubscriptionsTotal;
    this.crossConnectSubscriptionsTotal = crossConnectSubscriptionsTotal;
  }

  /**
   * Get the total.
   *
   * @return total cost
   */
  public double getTotal() {
    return total;
  }

  /**
   * Get the year.
   *
   * @return year
   */
  public int getYear() {
    return year;
  }

  /**
   * Get the month.
   *
   * @return month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Get the currency code for the bill.
   *
   * @return {@link CurrencyCode} currency code
   */
  public CurrencyCode getCurrencyCode() {
    return currencyCode;
  }

  /**
   * Get the storage price per GB.
   *
   * @return per GB storage price
   */
  public double getStoragePricePerGB() {
    return storagePricePerGB;
  }

  /**
   * Get the full month contract cost.
   *
   * @return full month contract cost
   */
  public double getFullMonthContractCost() {
    return fullMonthContractCost;
  }

  /**
   * Get the storage quota in GB.
   *
   * @return storage quota
   */
  public long getStorageQuotaInGB() {
    return storageQuotaInGB;
  }

  /**
   * Does the VCC customer have insider protection.
   *
   * @return has insider protection
   */
  public boolean hasInsiderProtection() {
    return hasInsiderProtection;
  }

  /**
   * Get the insider protection price per GB.
   *
   * @return insider protection price per GB
   */
  public double getInsiderProtectionPricePerGB() {
    return insiderProtectionPricePerGB;
  }

  /**
   * Get the insider protection total.
   *
   * @return insider protection total
   */
  public double getInsiderProtectionTotal() {
    return insiderProtectionTotal;
  }

  /**
   * Get the wan accelerator appliance total.
   *
   * @return wan accelerator total
   */
  public double getWanAcceleratorApplianceTotal() {
    return wanAcceleratorApplianceTotal;
  }

  /**
   * Get the dedicated veeam gateway total.
   *
   * @return dedicated veeam gateway total
   */
  public double getDedicatedVeeamGatewayTotal() {
    return dedicatedVeeamGatewayTotal;
  }

  /**
   * Get the rental licenses subscriptions total.
   *
   * @return rental licenses subscriptions total
   */
  public double getRentalLicensesSubscriptionsTotal() {
    return rentalLicensesSubscriptionsTotal;
  }

  /**
   * Get the cross connect subscriptions total.
   *
   * @return the cross connect subscriptions total
   */
  public double getCrossConnectSubscriptionsTotal() {
    return crossConnectSubscriptionsTotal;
  }
}
