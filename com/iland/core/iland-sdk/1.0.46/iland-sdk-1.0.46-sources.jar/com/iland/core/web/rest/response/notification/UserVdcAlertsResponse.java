/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.notification;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Vdc Alerts Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserVdcAlertsResponse implements Serializable {

  private static final long serialVersionUID = 7360654249691820988L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private UserBroadVdcResourceAlertListResponse userBroadVdcResourceAlerts;

  public UserVdcAlertsResponse(
      final UserBroadVdcResourceAlertListResponse userBroadVdcResourceAlerts) {
    this.userBroadVdcResourceAlerts = userBroadVdcResourceAlerts;
  }

  /**
   * Get user broad vdc resource alerts.
   *
   * @return {@link UserBroadVdcResourceAlertListResponse} response
   */
  public UserBroadVdcResourceAlertListResponse getUserBroadVdcResourceAlerts() {
    return userBroadVdcResourceAlerts;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserVdcAlertsResponse that = (UserVdcAlertsResponse) o;
    return userBroadVdcResourceAlerts != null && userBroadVdcResourceAlerts
        .equals(that.userBroadVdcResourceAlerts)
        || userBroadVdcResourceAlerts == null
        && that.userBroadVdcResourceAlerts == null;
  }

  @Override
  public int hashCode() {
    int result = 0;
    result = 31 * result + (userBroadVdcResourceAlerts != null ?
        userBroadVdcResourceAlerts.hashCode() :
        0);
    return result;
  }

  @Override
  public String toString() {
    return ", userBroadVdcResourceAlerts=" + userBroadVdcResourceAlerts + '}';
  }

}
