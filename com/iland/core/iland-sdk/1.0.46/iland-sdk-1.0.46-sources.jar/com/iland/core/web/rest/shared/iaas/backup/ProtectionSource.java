/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.common.enums.VCloudProtectionSourceType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * IaaS Protection Source.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class ProtectionSource implements Serializable {

  private static final long serialVersionUID = -8402772548869553982L;

  /**
   * The iland IaaS entity UUID.
   */
  @Expose
  @JsonOptional(
      "The iland IaaS entity UUID. May be null if the source has been "
          + "deleted.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String entityUuid;

  /**
   * The type of the associated iland IaaS entity.
   */
  @Expose
  @JsonRequired("The type of the associated iland IaaS entity.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final VCloudProtectionSourceType entityType;

  /**
   * The name of the associated entity.
   */
  @Expose
  @JsonRequired("The name of the associated entity.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String entityName;

  /**
   * The ID of the associated entity in the backend backup system.
   */
  @Expose
  @JsonRequired("The UID of the associated entity in the backend backup system.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String nativeUid;

  /**
   * Instantiates a new IaaS protection source.
   *
   * @param entityUuid the entity uuid
   * @param entityType the entity type
   * @param entityName the name of the entity
   * @param nativeUid  the native UID
   */
  public ProtectionSource(final String entityUuid,
      final VCloudProtectionSourceType entityType, final String entityName,
      final String nativeUid) {
    this.entityUuid = entityUuid;
    this.entityType = entityType;
    this.entityName = entityName;
    this.nativeUid = nativeUid;
  }

  /**
   * Gets the iland entity UUID.
   *
   * @return the iland entity uuid
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Gets the type of the associated iland IaaS entity.
   *
   * @return the entity type
   */
  public VCloudProtectionSourceType getEntityType() {
    return entityType;
  }

  /**
   * Gets native UID of the source in the backing service.
   *
   * @return the native uid
   */
  public String getNativeUid() {
    return nativeUid;
  }

  /**
   * Gets the name of the associated entity.
   *
   * @return the entity name
   */
  public String getEntityName() {
    return entityName;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final ProtectionSource that = (ProtectionSource) o;
    return Objects.equals(entityUuid, that.entityUuid)
        && entityType == that.entityType && Objects
        .equals(entityName, that.entityName) && Objects
        .equals(nativeUid, that.nativeUid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(entityUuid, entityType, entityName, nativeUid);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("entityUuid", entityUuid)
        .add("entityType", entityType).add("entityName", entityName)
        .add("nativeUid", nativeUid).toString();
  }
}
