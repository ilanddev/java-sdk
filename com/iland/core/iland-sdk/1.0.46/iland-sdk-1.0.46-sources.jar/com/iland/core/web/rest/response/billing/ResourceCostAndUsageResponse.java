/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Resource Cost And Usage Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class ResourceCostAndUsageResponse implements Serializable {

  private static final long serialVersionUID = -6360943960646233332L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private CostAndUsageResponse total;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private CostAndUsageResponse reserved;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private CostAndUsageResponse burst;

  public ResourceCostAndUsageResponse(final CostAndUsageResponse total,
      final CostAndUsageResponse reserved, final CostAndUsageResponse burst) {
    this.total = total;
    this.reserved = reserved;
    this.burst = burst;
  }

  /**
   * Get the total cost and usage.
   *
   * @return total cost and usage
   */
  public CostAndUsageResponse getTotal() {
    return total;
  }

  /**
   * Get the reservation cost and usage.
   *
   * @return reserved cost and usage
   */
  public CostAndUsageResponse getReserved() {
    return reserved;
  }

  /**
   * Get the burst cost and usage.
   *
   * @return burst cost and usage
   */
  public CostAndUsageResponse getBurst() {
    return burst;
  }

}
