/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vapp;

import java.io.Serializable;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Download Details Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class DownloadDetailsResponse implements Serializable {

  private static final long serialVersionUID = -8915615221511252146L;

  private static final String ENABLED = "enabled";

  private static final String DOWNLOAD_NAME = "download_name";

  private static final String DOWNLOAD_SIZE_BYTES = "download_size_bytes";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(ENABLED)
  @Expose
  private boolean enabled;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(DOWNLOAD_NAME)
  @Expose
  private String downloadName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(DOWNLOAD_SIZE_BYTES)
  @Expose
  private Long downloadSizeBytes;

  public DownloadDetailsResponse(final boolean enabled,
      final String downloadName, final Long downloadSizeBytes) {
    this.enabled = enabled;
    this.downloadName = downloadName;
    this.downloadSizeBytes = downloadSizeBytes;
  }

  /**
   * Is enabled boolean.
   *
   * @return the boolean
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Gets download name.
   *
   * @return the download name
   */
  public String getDownloadName() {
    return downloadName;
  }

  /**
   * Gets download size bytes.
   *
   * @return the download size bytes
   */
  public Long getDownloadSizeBytes() {
    return downloadSizeBytes;
  }

  @Override
  public boolean equals(Object object) {
    if (object == null || getClass() != object.getClass()) {
      return false;
    }
    DownloadDetailsResponse that = (DownloadDetailsResponse) object;
    return Objects.equals(enabled, that.isEnabled()) && Objects
        .equals(downloadName, that.getDownloadName()) && Objects
        .equals(downloadSizeBytes, that.getDownloadSizeBytes());
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("DownloadDetailsResponse{");
    sb.append("enabled=").append(enabled);
    sb.append(", downloadName='").append(downloadName).append('\'');
    sb.append(", downloadSizeBytes=").append(downloadSizeBytes);
    sb.append("}");
    return sb.toString();
  }

}
