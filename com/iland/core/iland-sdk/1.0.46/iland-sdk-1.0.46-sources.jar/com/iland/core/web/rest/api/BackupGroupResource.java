/*
 * Copyright (c) 2013,2020 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 205 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.iaas.backup.BackupGroupDeleteRequest;
import com.iland.core.web.rest.request.iaas.backup.BackupGroupUpdateRequest;
import com.iland.core.web.rest.request.iaas.backup.GetBackupGroupSummaryStatsFilters;
import com.iland.core.web.rest.request.iaas.backup.GetBackupStorageSamplesFilters;
import com.iland.core.web.rest.request.iaas.backup.ListBackupGroupRunsQueryParams;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupRunListResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupRunResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupStorageMetricListResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupStorageSampleSeriesResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupSummaryStatsResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupPolicyResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.shared.iaas.backup.BackupGroupStorageMetric;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Backup Groups Public API.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Backup Groups")
@Path("/backup-groups")
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface BackupGroupResource {

  /**
   * Get details of an individual backup protection group.
   *
   * @param backupGroupUid      the backup group UID
   * @param includeSummaryStats whether to include summary stats in the response
   * @param includeLastRun      whether to include last run info in the response
   * @param includeBackupPolicy whether to include backup policy info
   * @return {@link BackupGroupResponse}
   * @throws NotFoundException if the backup group is not found
   */
  @GET
  @Path("/{backupGroupUid}")
  BackupGroupResponse getBackupGroup(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_BACKUP_GROUP)
      @PathParam("backupGroupUid") String backupGroupUid,
      @QueryParam("includeSummaryStats") boolean includeSummaryStats,
      @QueryParam("includeLastRun") boolean includeLastRun,
      @QueryParam("includeBackupPolicy") boolean includeBackupPolicy);

  /**
   * Get details for the policy associated with a specified backup group.
   *
   * @param backupGroupUid the backup group UID
   * @return {@link BackupGroupResponse}
   * @throws NotFoundException if the backup group is not found
   */
  @GET
  @Path("/{backupGroupUid}/policy")
  BackupPolicyResponse getBackupGroupPolicy(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_BACKUP_GROUP)
      @PathParam("backupGroupUid") String backupGroupUid);

  /**
   * Get a specific backup group run.
   *
   * @param backupGroupUid the backup group UID
   * @param backupRunUid   the run UID
   * @return {@link BackupGroupRunResponse}
   * @throws NotFoundException if the backup group is not found
   */
  @GET
  @Path("/{backupGroupUid}/runs/{backupRunUid}")
  BackupGroupRunResponse getBackupGroupRun(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_BACKUP_GROUP)
      @PathParam("backupGroupUid") String backupGroupUid,
      @PathParam("backupRunUid") String backupRunUid);

  /**
   * List runs for the specified backup group.
   * <p>
   *
   * Limit defaults to 10 and query time range defaults to last 24 hours.
   *
   * @param backupGroupUid the backup group UID
   * @param params         query filter params
   * @return {@link BackupGroupRunListResponse}
   * @throws NotFoundException if the backup group is not found
   */
  @GET
  @Path("/{backupGroupUid}/backup-runs")
  BackupGroupRunListResponse listBackupGroupRuns(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_BACKUP_GROUP)
      @PathParam("backupGroupUid") String backupGroupUid,
      @BeanParam ListBackupGroupRunsQueryParams params);

  /**
   * Get summary stats for an individual backup protection group.
   * <p>
   *
   * Stat time-range defaults to the past 24 hours.
   *
   * @param backupGroupUid the backup group UID
   * @param filters optional filters that can be used to specify a custom timeframe.
   * @return {@link BackupGroupSummaryStatsResponse}
   * @throws NotFoundException if the backup group is not found
   */
  @GET
  @Path("/{backupGroupUid}/summary-stats")
  BackupGroupSummaryStatsResponse getBackupGroupSummaryStats(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_BACKUP_GROUP)
      @PathParam("backupGroupUid") String backupGroupUid,
      @BeanParam GetBackupGroupSummaryStatsFilters filters);

  /**
   * Update a backup group.
   *
   * @param backupGroupUid the UID of the backup group
   * @param updateRequest  the update request body
   * @return {@link BackupGroupResponse}
   * @throws NotFoundException if the backup group is not found
   */
  @PUT
  @Path("/{backupGroupUid}")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupGroupResponse updateBackupGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_BACKUP_GROUP_CONFIGURATION)
      @PathParam("backupGroupUid") String backupGroupUid,
      BackupGroupUpdateRequest updateRequest);

  /**
   * Delete a backup group.
   *
   * @param backupGroupUid the UID of the backup group
   * @param deleteRequest  the deletion request
   * @throws NotFoundException if the backup group is not found
   */
  @DELETE
  @Path("/{backupGroupUid}")
  @Consumes(MediaType.APPLICATION_JSON)
  void deleteBackupGroup(
      @SecureEntityRef(Permission.DELETE_ILAND_CLOUD_BACKUP_GROUP)
      @PathParam("backupGroupUid") String backupGroupUid,
      BackupGroupDeleteRequest deleteRequest);

  /**
   * Gets the list of storage metrics that are available for the backup group.
   *
   * @param backupGroupUid the UID of the backup group
   * @return the list of storage metrics names
   */
  @GET
  @Path("/{backupGroupUid}/backup-storage-metrics")
  BackupGroupStorageMetricListResponse getBackupStorageMetrics(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_BACKUP_GROUP)
      @PathParam("backupGroupUid") String backupGroupUid);

  /**
   * Gets a series of backup group storage samples for a specified storage
   * metric.
   *
   * @param backupGroupUid the UID of the backup group
   * @param metric         the storage metric name
   * @param filters        optional filters for the start and end of the series
   * @return the sample series
   */
  @GET
  @Path("/{backupGroupUid}/backup-storage-metrics/{metric}/samples")
  BackupGroupStorageSampleSeriesResponse getBackupStorageSamples(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_BACKUP_GROUP)
      @PathParam("backupGroupUid") String backupGroupUid,
      @PathParam("metric") BackupGroupStorageMetric metric,
      @BeanParam GetBackupStorageSamplesFilters filters);

}
