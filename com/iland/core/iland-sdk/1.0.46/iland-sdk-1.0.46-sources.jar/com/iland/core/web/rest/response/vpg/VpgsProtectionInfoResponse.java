/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.vpg;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VPGs Protection Info Response.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public class VpgsProtectionInfoResponse implements Serializable {

  private static final long serialVersionUID = -3087334938616134697L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long totalReplicatedVms;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long totalUnreplicatedVms;

  public VpgsProtectionInfoResponse(final long totalReplicatedVms,
      final long totalUnreplicatedVms) {
    this.totalReplicatedVms = totalReplicatedVms;
    this.totalUnreplicatedVms = totalUnreplicatedVms;
  }

  /**
   * Returns the total number of VMs replicated from the source sites.
   *
   * @return the total number of VMs replicated from the source sites.
   */
  public long getTotalReplicatedVms() {
    return totalReplicatedVms;
  }

  /**
   * Returns the total number of VMs non-replicated from the source sites.
   *
   * @return the total number of VMs non-replicated from the source sites or -1
   * if we cannot determine that number.
   */
  public long getTotalUnreplicatedVms() {
    return totalUnreplicatedVms;
  }

}
