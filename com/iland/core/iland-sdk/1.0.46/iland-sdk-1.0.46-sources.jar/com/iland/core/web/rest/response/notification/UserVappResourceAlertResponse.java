/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.notification;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Vapp Resource Alert Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserVappResourceAlertResponse
    extends AbstractResourceAlertResponse {

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String vappUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected long threshold;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean cloneToChildren;

  public UserVappResourceAlertResponse(final String group, final String name,
      final String type, final String username, final String action,
      final String equalityRelation, final boolean enabled,
      final int breachPeriod, final String vappUuid, final long threshold,
      final boolean cloneToChildren) {
    super(group, name, type, username, action, equalityRelation, enabled,
        breachPeriod);
    this.vappUuid = vappUuid;
    this.threshold = threshold;
    this.cloneToChildren = cloneToChildren;
  }

  /**
   * Get the Vapp uuid attached to this alert.
   *
   * @return {@link String} vapp uuid
   */
  public String getVappUuid() {
    return vappUuid;
  }

  /**
   * Get the alerting threshold at which the user wants to receive alerts for
   * the counter specified by group, name and type.
   *
   * @return alerting threshold
   */
  public long getThreshold() {
    return threshold;
  }

  /**
   * Whether the alert should be cloned to child VMs.
   *
   * @return is clone to children
   */
  public boolean isCloneToChildren() {
    return cloneToChildren;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserVappResourceAlertResponse that =
        (UserVappResourceAlertResponse) o;

    if (threshold != that.threshold)
      return false;
    if (cloneToChildren != that.cloneToChildren)
      return false;
    return vappUuid != null ?
        vappUuid.equals(that.vappUuid) :
        that.vappUuid == null;
  }

  @Override
  public int hashCode() {
    int result = vappUuid != null ? vappUuid.hashCode() : 0;
    result = 31 * result + (int) (threshold ^ (threshold >>> 32));
    result = 31 * result + (cloneToChildren ? 1 : 0);
    return result;
  }

  @Override
  public String toString() {
    return "UserVappResourceAlertResponse{" + "vappUuid='" + vappUuid + '\''
        + ", threshold=" + threshold + ", cloneToChildren=" + cloneToChildren
        + ", group='" + group + '\'' + ", name='" + name + '\'' + ", type='"
        + type + '\'' + ", username='" + username + '\'' + ", action='" + action
        + '\'' + ", equalityRelation='" + equalityRelation + '\'' + ", enabled="
        + enabled + ", breachPeriod=" + breachPeriod + '}';
  }

}
