/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.sdk.util;

import java.util.concurrent.TimeoutException;

import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.sdk.Client;

/**
 * ApiUtils.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public class Utils {

  /**
   * Wait on a task to be synchronized.
   *
   * @param client  {@link Client} api client
   * @param task    {@link TaskResponse} core task
   * @param timeout milliseconds before timing out waiting on task to sync
   * @param sleep   milliseconds to sleep between checking task status
   * @return {@link TaskResponse} synced core task
   */
  public static TaskResponse waitForSyncedTask(final Client client,
      final TaskResponse task, final long timeout, final long sleep)
      throws TimeoutException {
    long endTime = timeout > 0L ? System.nanoTime() + (timeout * 1000) : 0L;
    TaskResponse tUpdated = client.getTaskResource().getTask(task.getUuid());
    while (!tUpdated.isSynced()) {
      tUpdated = client.getTaskResource().getTask(task.getUuid());
      if (timeout > 0 && System.nanoTime() >= endTime) {
        throw new TimeoutException(
            String.format("Timeout while waiting on task=%s", task.getUuid()));
      }
      if (sleep > 0) {
        try {
          Thread.sleep(sleep);
        } catch (final InterruptedException e) {
          throw new RuntimeException(e);
        }
      }
    }
    return tUpdated;
  }

  /**
   * Wait for a synced task.
   * <p>
   * Uses 1 second between queries to API for task status.
   *
   * @param client {@link Client} client
   * @param task   {@link TaskResponse} task
   * @return {@link TaskResponse} synced core task
   * @throws TimeoutException
   */
  public static TaskResponse waitForSyncedTask(final Client client,
      final TaskResponse task) throws TimeoutException {
    return waitForSyncedTask(client, task, -1, 1000);
  }

  /**
   * Wait for a synced test and then run the given callback function.
   *
   * @param client   {@link Client} client
   * @param task     {@link TaskResponse} task
   * @param callback {@link Callback} callback function to run upon task sync
   * @throws Exception
   */
  public static void performAfterSync(final Client client,
      final TaskResponse task, final Callback callback) throws Exception {
    final TaskResponse t = waitForSyncedTask(client, task);
    callback.call(t);
  }

}
