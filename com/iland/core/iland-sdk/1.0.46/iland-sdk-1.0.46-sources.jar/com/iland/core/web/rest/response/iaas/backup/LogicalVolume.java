/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the "LICENSE.txt" file that accompanied this software. Any inquiries
 *  concerning the scope or enforceability of the license should be addressed
 *  to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 */

package com.iland.core.web.rest.response.iaas.backup;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * LogicalVolume.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface LogicalVolume {

  /**
   * Specifies a logical volume stored as a tree where the leaves are the blocks
   * of partitions and intermediate nodes are assembled by combining nodes using
   * one of the following modes: linear layout, striped, mirrored, RAID etc. A
   * deviceTree is a block device formed by combining one or more Devices using
   * a combining strategy.
   */
  DeviceTreeDetails deviceRootNode();

  /**
   * Specifies the group name of the logical volume.
   */
  String groupName();

  /**
   * Specifies the group uuid of the logical volume.
   */
  String groupUuid();

  /**
   * Specifies the name of the logical volume.
   */
  String name();

  /**
   * Specifies the uuid of the logical volume.
   */
  String uuid();

}
