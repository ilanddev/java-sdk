/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Screen Ticket Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class ScreenTicketResponse implements Serializable {

  private static final long serialVersionUID = -795783617681207416L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String screenTicket;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String host;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String sslThumprint;

  public ScreenTicketResponse(final String vmId, final String screenTicket,
      final String host, final String sslThumprint) {
    this.vmId = vmId;
    this.screenTicket = screenTicket;
    this.host = host;
    this.sslThumprint = sslThumprint;
  }

  /**
   * Get the screen ticket.
   *
   * @return {@link String}
   */
  public String getScreenTicket() {
    return screenTicket;
  }

  /**
   * Get the host for connecting to.
   *
   * @return {@link String} host
   */
  public String getHost() {
    return host;
  }

  /**
   * Get the SSL thumbprint of the host connecting to.
   *
   * @return {@link String} SSL thumbprint of host
   */
  public String getSslThumprint() {
    return sslThumprint;
  }

  /**
   * Get the VM id associated with the screen ticket.
   *
   * @return {@link String} vm id
   */
  public String getVmId() {
    return vmId;
  }

}
