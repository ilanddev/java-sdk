/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.objectstorage;

import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * TenantResponse.
 *
 * @author <a href=“mailto:cjsnyder@iland.com”>Collin Snyder</a>
 */
@APIModel
public interface TenantResponse {

  /**
   * The unique ID of the tenant.
   */
  String tenantId();

  /**
   * The unique ID of the company.
   */
  String companyId();

  /**
   * The region the tenant exists in.
   */
  String region();

  /**
   * Whether tenant access is enabled. If not enabled, users will "
   * + "not be able to read or write to their buckets.
   */
  boolean enabled();

  /**
   * The tenant's storage quota in KiB.
   */
  Long quotaKib();

  /**
   * The total storage usage in KiB.
   */
  Long usageKib();

  /**
   * The total number of objects.
   */
  Long numObjects();

  /**
   * The total number of buckets.
   */
  Long numBuckets();

  /**
   * Whether tenant has stats and bucket info.
   */
  boolean hasStatsAndBucketInfo();

  /**
   * Name of the tenant.
   */
  Optional<String> name();

  /**
   * Name of the account.
   */
  Optional<String> accountName();

}
