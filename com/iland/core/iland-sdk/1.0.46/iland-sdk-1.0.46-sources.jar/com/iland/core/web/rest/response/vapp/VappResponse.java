/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.vapp;

import java.time.Instant;
import java.util.Date;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class VappResponse extends EntityResponse {

  private static final String RUNTIME_LEASE = "runtime_lease";

  private static final String STORAGE_LEASE = "storage_lease";

  private static final String RUNTIME_EXPIRATION = "runtime_expire";

  private static final String STORAGE_EXPIRATION = "storage_expire";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean deployed = false;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String status;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Set<String> storageProfiles;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Integer runtimeLeaseInSeconds;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Integer storageLeaseInSeconds;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(RUNTIME_EXPIRATION)
  private Date runtimeLeaseExpiration;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(STORAGE_EXPIRATION)
  private Date storageLeaseExpiration;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String vdcUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String orgUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String locationId;


  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String description;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String vcloudHref;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Instant createdDate;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean isExpired;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String allocationModel;

  public VappResponse(final String uuid, final String companyId,
      final Instant createdDate, final boolean deleted,
      final Instant deletedDate, final String name, final Instant updatedDate,
      final String vdcUuid, final String orgUuid, final String locationId,
      final boolean deployed, final String description,
      final Date runtimeLeaseExpiration, final Integer runtimeLeaseInSeconds,
      final String status, final Date storageLeaseExpiration,
      final Integer storageLeaseInSeconds, final Set<String> storageProfiles,
      final String vcloudHref, final boolean isExpired,
      final String allocationModel) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.vdcUuid = vdcUuid;
    this.orgUuid = orgUuid;
    this.locationId = locationId;
    this.deployed = deployed;
    this.description = description;
    this.runtimeLeaseExpiration = runtimeLeaseExpiration;
    this.runtimeLeaseInSeconds = runtimeLeaseInSeconds;
    this.status = status;
    this.storageLeaseExpiration = storageLeaseExpiration;
    this.storageLeaseInSeconds = storageLeaseInSeconds;
    this.storageProfiles = storageProfiles;
    this.vcloudHref = vcloudHref;
    this.isExpired = isExpired;
    this.createdDate = createdDate;
    this.allocationModel = allocationModel;
  }

  /**
   * Is deployed boolean.
   *
   * @return the boolean
   */
  public boolean isDeployed() {
    return deployed;
  }

  /**
   * Gets status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Gets storage profiles.
   *
   * @return the storage profiles
   */
  public Set<String> getStorageProfiles() {
    return storageProfiles;
  }

  /**
   * Get the runtime lease expiration in seconds.
   *
   * @return {@link Integer} seconds to expiration of lease
   */
  public Integer getRuntimeLeaseInSeconds() {
    return runtimeLeaseInSeconds;
  }

  /**
   * Get the storage lease expiration in seconds.
   *
   * @return {@link Integer} seconds to expiration of lease
   */
  public Integer getStorageLeaseInSeconds() {
    return storageLeaseInSeconds;
  }

  /**
   * Get the storage lease expiration in seconds.
   *
   * @return {@link Date} expiration
   */
  public Date getStorageLeaseExpiration() {
    return storageLeaseExpiration;
  }

  /**
   * Get the runtime lease expiration date.
   *
   * @return {@link Date} expiration
   */
  public Date getRuntimeLeaseExpiration() {
    return runtimeLeaseExpiration;
  }


  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Gets location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Gets org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets vcloud href.
   *
   * @return the vcloud href
   */
  public String getVcloudHref() {
    return vcloudHref;
  }


  /**
   * Gets created date.
   *
   * @return the created date
   */
  public Instant getCreatedDate() {
    return createdDate;
  }

  /**
   * Whether vapp is expired.
   *
   * @return is vapp expired
   */
  public boolean isExpired() {
    return isExpired;
  }

  /**
   * Get the allocation model.
   *
   * @return {@link String} allocation model
   */
  public String getAllocationModel() {
    return allocationModel;
  }

}
