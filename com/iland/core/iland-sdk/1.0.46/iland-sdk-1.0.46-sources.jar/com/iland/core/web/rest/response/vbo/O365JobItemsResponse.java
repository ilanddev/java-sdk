/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Response class to hold either included or excluded backup items.
 *
 * @author <a href="mailto:smittal@iland.com">Sachin Mittal</a>
 */
@APIDoc
public final class O365JobItemsResponse {

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("The backup item type partial organization.")
  private final Set<O365PartialOrgJobItemsResponse> partialOrgResponses;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("The backup item type group.")
  private final Set<O365JobItemGroupResponse> groupResponses;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("The backup item type user.")
  private final Set<O365JobItemUserResponse> userResponses;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("The backup item type sharepoint site.")
  private final Set<O365SharePointSiteResponse> sharePointSiteResponses;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("The backup item type sharepoint personal site.")
  private final Set<O365SharePointPersonalSiteResponse> sharePointPersonalSiteResponses;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("The backup item type team.")
  private final Set<O365TeamResponse> teamResponses;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("The backup item type team including team chats.")
  private final Set<O365JobTeamResponse> teamsChatResponse;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies if exclude all personal sites option is selected.")
  private final Boolean excludeAllPersonalSites;

  public O365JobItemsResponse(
      final Set<O365PartialOrgJobItemsResponse> partialOrgResponses,
      final Set<O365JobItemGroupResponse> groupResponses,
      final Set<O365JobItemUserResponse> userResponses,
      final Set<O365SharePointSiteResponse> sharePointSiteResponses,
      final Set<O365SharePointPersonalSiteResponse> sharePointPersonalSiteResponses,
      final Set<O365TeamResponse> teamResponses,
      final Set<O365JobTeamResponse> teamsChatResponse,
      final Boolean excludeAllPersonalSites) {
    this.partialOrgResponses = partialOrgResponses;
    this.groupResponses = groupResponses;
    this.userResponses = userResponses;
    this.sharePointSiteResponses = sharePointSiteResponses;
    this.sharePointPersonalSiteResponses = sharePointPersonalSiteResponses;
    this.teamResponses = teamResponses;
    this.teamsChatResponse = teamsChatResponse;
    this.excludeAllPersonalSites = excludeAllPersonalSites;
  }

  /**
   * Get the backup item type group.
   *
   * @return backup item type group.
   */
  public Set<O365JobItemGroupResponse> getGroupResponses() {
    return groupResponses;
  }

  /**
   * Get the backup item type user.
   *
   * @return backup item type user.
   */
  public Set<O365JobItemUserResponse> getUserResponses() {
    return userResponses;
  }

  /**
   * Get the backup item type sharepoint site.
   *
   * @return backup item type sharepoint site.
   */
  public Set<O365SharePointSiteResponse> getSharePointSiteResponses() {
    return sharePointSiteResponses;
  }

  /**
   * Get the backup item type partial organization.
   *
   * @return backup item type sharepoint site.
   */
  public Set<O365PartialOrgJobItemsResponse> getPartialOrgResponses() {
    return partialOrgResponses;
  }

  /**
   * Get the backup item type team.
   *
   * @return backup item type team.
   */
  public Set<O365TeamResponse> getTeamResponses() {
    return teamResponses;
  }

  /**
   * Get the backup item type teams including teams chat.
   *
   * @return backup item type teams including teams chat.
   */
  public Set<O365JobTeamResponse> getTeamsChatResponse() {
    return teamsChatResponse;
  }

  /**
   * Get the backup item type personal sharepoint site.
   *
   * @return backup item type personal sharepoint site.
   */
   public Set<O365SharePointPersonalSiteResponse> getSharePointPersonalSiteResponses() {
    return sharePointPersonalSiteResponses;
  }

  /**
   * Specifies if all personal sites are excluded
   *
   * @return {@link Boolean}
   */
  public Boolean getExcludeAllPersonalSites() {
    return excludeAllPersonalSites;
  }
}
