/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Office 365 VBO SharePoint Library response.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365SharePointLibraryResponse implements Serializable {

  private static final long serialVersionUID = -5838680106915363320L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The Veeam native ID of the backed up SharePoint Library.")
  private final String id;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The name of the backed up SharePoint Library.")
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The description of the backed up SharePoint Library.")
  private final String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The URL of the backed up SharePoint Library.")
  private final String url;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The date and time when the document library was created.")
  private final Instant creationTime;

  public O365SharePointLibraryResponse(final String id, final String name,
      final String description, final String url, final Instant creationTime) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.url = url;
    this.creationTime = creationTime;
  }

  /**
   * Returns the ID of the backed up SharePoint document library.
   *
   * @return a Veeam native ID
   */
  public String getId() {
    return id;
  }

  /**
   * Returns the name of the backed up SharePoint document library.
   *
   * @return the name of the backed up SharePoint document library
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the description of the document library.
   *
   * @return the description of the document library
   */
  public String getDescription() {
    return description;
  }

  /**
   * Returns the URL of the SharePoint document library.
   *
   * @return the URL of the SharePoint document library
   */
  public String getUrl() {
    return url;
  }

  /**
   * Returns date and time when the document library was created.
   *
   * @return UTC {@link Instant}
   */
  public Instant getCreationTime() {
    return creationTime;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final O365SharePointLibraryResponse that =
        (O365SharePointLibraryResponse) o;
    return Objects.equals(id, that.id) && Objects.equals(name, that.name)
        && Objects.equals(description, that.description) && Objects
        .equals(url, that.url) && Objects
        .equals(creationTime, that.creationTime);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, description, url, creationTime);
  }

}
