/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.user;

import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * User Creation Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIModel
public interface UserCreationResponse {

  /**
   * The username of the user that was requested to create.
   *
   * @return {@link String} username
   */
  String username();

  /**
   * Whether or not the username was created.
   *
   * @return whether username was created
   */
  boolean created();

  /**
   * Error returned when creating user, if any.
   *
   * @return {@link Optional} of {@link String} error
   */
  Optional<String> error();
}
