/*
 * Copyright (c) 2013 - 2019 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 205 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */
package com.iland.core.web.rest.api;

import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.cohesity.iaas.backups.backupgroups.BackupGroupV2PlatformOrgApi;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.BackupGroupV2;
import com.iland.cohesity.iaas.backups.common.model.ListResponse;
import com.iland.cohesity.iaas.backups.common.model.OrgUuid;
import com.iland.cohesity.iaas.backups.protectionsources.OracleProtectionSourceModel;
import com.iland.cohesity.iaas.backups.protectionsources.ProtectionSourcePlatformOrgApi;
import com.iland.cohesity.iaas.backups.protectionsources.PublicProtectionSource;
import com.iland.cohesity.iaas.backups.protectionsources.SqlProtectionSourceModel;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.catalog.CatalogCreateRequest;
import com.iland.core.web.rest.request.dns.DNSRecordCreateRequest;
import com.iland.core.web.rest.request.dns.DNSRecordUpdateRequest;
import com.iland.core.web.rest.request.dns.DNSZoneCreateRequest;
import com.iland.core.web.rest.request.iaas.backup.BackupPolicyUpdateRequest;
import com.iland.core.web.rest.request.iaas.backup.GetBackupGroupSummaryStatsFilters;
import com.iland.core.web.rest.request.networkscan.NetworkScanOptOutCreateRequest;
import com.iland.core.web.rest.request.networkscan.NetworkScanUpdateRequest;
import com.iland.core.web.rest.request.org.OrgVappLeaseUpdateRequest;
import com.iland.core.web.rest.request.org.OrgVappTemplateLeaseUpdateRequest;
import com.iland.core.web.rest.request.recovery.DisasterRecoveryRunbookCreateRequest;
import com.iland.core.web.rest.request.vpg.BatchFailoverParamsRequest;
import com.iland.core.web.rest.request.vpg.BatchFailoverTestParamsRequest;
import com.iland.core.web.rest.request.vpg.VpgSubEntityRequest;
import com.iland.core.web.rest.response.billing.BandwidthUsageSummaryResponse;
import com.iland.core.web.rest.response.billing.BillListResponse;
import com.iland.core.web.rest.response.billing.BillResponse;
import com.iland.core.web.rest.response.billing.BillingLegacyResponse;
import com.iland.core.web.rest.response.billing.BillingSampleSerieListResponse;
import com.iland.core.web.rest.response.billing.CurrencyCodeResponse;
import com.iland.core.web.rest.response.billing.OrgBillingByVdcResponse;
import com.iland.core.web.rest.response.billing.OrgVdcBillsListResponse;
import com.iland.core.web.rest.response.catalog.CatalogListResponse;
import com.iland.core.web.rest.response.common.IPAddressSetResponse;
import com.iland.core.web.rest.response.common.PublicIpAssignmentListResponse;
import com.iland.core.web.rest.response.dns.CheckDNSZoneResponse;
import com.iland.core.web.rest.response.dns.DNSRecordListResponse;
import com.iland.core.web.rest.response.dns.DNSRecordResponse;
import com.iland.core.web.rest.response.dns.DNSZoneResponse;
import com.iland.core.web.rest.response.dns.OrgDNSZoneListResponse;
import com.iland.core.web.rest.response.edge.EdgeListResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupListResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupPolicyListResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupPolicyResponse;
import com.iland.core.web.rest.response.iaas.backup.OrgBackupStatusResponse;
import com.iland.core.web.rest.response.iaas.backup.OrgBackupSummaryStatsResponse;
import com.iland.core.web.rest.response.iaas.intbackup.OrgIntegratedBackupStatusResponse;
import com.iland.core.web.rest.response.media.MediaListResponse;
import com.iland.core.web.rest.response.network.NetworkPerfSampleSerieListResponse;
import com.iland.core.web.rest.response.networkscan.LaunchResponse;
import com.iland.core.web.rest.response.networkscan.NetworkScanDetailsResponse;
import com.iland.core.web.rest.response.networkscan.NetworkScanListResponse;
import com.iland.core.web.rest.response.networkscan.NetworkScanOptOutResponse;
import com.iland.core.web.rest.response.networkscan.NetworkScanUpdateResponse;
import com.iland.core.web.rest.response.org.IsComplianceOrgResponse;
import com.iland.core.web.rest.response.org.OrgExpiredItemsResponse;
import com.iland.core.web.rest.response.org.OrgResponse;
import com.iland.core.web.rest.response.org.OrgVdcNetworkListResponse;
import com.iland.core.web.rest.response.performance.PerfSampleSerieResponse;
import com.iland.core.web.rest.response.performance.PerformanceCounterListResponse;
import com.iland.core.web.rest.response.recovery.DisasterRecoveryRunbookListResponse;
import com.iland.core.web.rest.response.recovery.DisasterRecoveryRunbookResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vapp.VappListResponse;
import com.iland.core.web.rest.response.vappnetwork.VappNetworkListResponse;
import com.iland.core.web.rest.response.vapptemplate.VappTemplateListResponse;
import com.iland.core.web.rest.response.vcctenant.VccFailoverPlanListResponse;
import com.iland.core.web.rest.response.vcctenant.VccReplicationUsageResponse;
import com.iland.core.web.rest.response.vdc.VdcListResponse;
import com.iland.core.web.rest.response.vm.VmListResponse;
import com.iland.core.web.rest.response.vpg.ExpandedVpgListResponse;
import com.iland.core.web.rest.response.vpg.VpgsProtectionInfoResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Org Resource Interface V1.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Organizations")
@Path("/orgs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface OrgResource
    extends BackupGroupV2PlatformOrgApi, ProtectionSourcePlatformOrgApi {

  /**
   * Get an organization given its uuid.
   *
   * @param orgUuid org uuid
   * @return organization
   */
  @GET
  @Path("/{orgUuid}")
  OrgResponse getOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Get the virtual data centers (VDCs) for the given organization.
   *
   * @param orgUuid org uuid
   * @return a list of virtual data centers
   */
  @GET
  @Path("/{orgUuid}/vdcs")
  VdcListResponse getVdcsForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Get the vApps for the organization.
   *
   * @param orgUuid org uuid
   * @return a list of virtual applications
   */
  @GET
  @Path("/{orgUuid}/vapps")
  VappListResponse getVappsForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Get the VMs for the organization.
   *
   * @param orgUuid org uuid
   * @return a list of virtual machines
   */
  @GET
  @Path("/{orgUuid}/vms")
  VmListResponse getVmsForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Get the org vdc networks for the organization.
   *
   * @param orgUuid org uuid
   * @return a list of org vdc networks
   */
  @GET
  @Path("/{orgUuid}/org-vdc-networks")
  OrgVdcNetworkListResponse getOrgVdcNetworksForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Get the vcd edges for the organization.
   *
   * @param orgUuid org uuid
   * @return a list of vcd edges
   */
  @GET
  @Path("/{orgUuid}/edges")
  EdgeListResponse getEdgesForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Get the vapp networks for the organization.
   *
   * @param orgUuid org uuid
   * @return a list of vapp networks
   */
  @GET
  @Path("/{orgUuid}/vapp-networks")
  VappNetworkListResponse getVappNetworksForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Get the set of IP addresses that are not mapped to PTR DNS records yet.
   *
   * @param orgUuid org uuid
   * @return set of IP addresses that have no PTR record mapping
   */
  @GET
  @Path("/{orgUuid}/unmapped-dns-ptr-ip-addresses")
  IPAddressSetResponse getAvailableIPsForPTRRecords(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Get the DNS records associated with the given organization.
   *
   * @param orgUuid org uuid
   * @return list of DNS records for the organization
   */
  @GET
  @Path("/{orgUuid}/dns-records")
  DNSRecordListResponse getDNSRecords(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Add a new DNS record for the given organization.
   *
   * @param orgUuid org uuid
   * @param record  dns record
   * @return new DNS record
   */
  @POST
  @Path("/{orgUuid}/dns-records")
  @Consumes(MediaType.APPLICATION_JSON)
  DNSRecordResponse addDNSRecord(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_DNS)
      @PathParam("orgUuid") String orgUuid, DNSRecordCreateRequest record);

  /**
   * Get the managed DNS zones associated with the given organization.
   *
   * @param orgUuid org uuid
   * @return list of managed DNS zones for the organization
   */
  @GET
  @Path("/{orgUuid}/dns-zones")
  OrgDNSZoneListResponse getDNSZones(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Add a new managed DNS zone for the given organization.
   *
   * @param orgUuid  org uuid
   * @param zoneSpec dns zone spec
   * @return new DNS zone
   */
  @POST
  @Path("/{orgUuid}/dns-zones")
  @Consumes(MediaType.APPLICATION_JSON)
  DNSZoneResponse addDNSZone(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_DNS)
      @PathParam("orgUuid") String orgUuid, DNSZoneCreateRequest zoneSpec);

  /**
   * Check a managed DNS Zone for Validity and report errors.
   *
   * @param orgUuid org uuid
   * @param zoneId  zoneId
   * @return dns zone check result
   */
  @GET
  @Path("/{orgUuid}/dns-zones/{zoneId}/is-valid")
  CheckDNSZoneResponse checkDNSZone(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @PathParam("zoneId") int zoneId);

  /**
   * Delete a DNS zone for the given organization and zone ID.
   *
   * @param orgUuid org uuid
   * @param zoneId  dns zone id
   */
  @DELETE
  @Path("/{orgUuid}/dns-zones/{zoneId}")
  void deleteDNSZone(@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_DNS)
  @PathParam("orgUuid") String orgUuid, @PathParam("zoneId") int zoneId);

  /**
   * Update a DNS record for the given organization.
   *
   * @param orgUuid  org uuid
   * @param recordId the DNS record ID
   * @param record   dns record
   * @return updated DNS record
   */
  @PUT
  @Path("/{orgUuid}/dns-records/{recordId}")
  @Consumes(MediaType.APPLICATION_JSON)
  DNSRecordResponse updateDNSRecord(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_DNS)
      @PathParam("orgUuid") String orgUuid, @PathParam("recordId") int recordId,
      DNSRecordUpdateRequest record);

  /**
   * Delete a DNS record for the given organization.
   *
   * @param orgUuid  org uuid
   * @param recordId dns record id to delete
   */
  @DELETE
  @Path("/{orgUuid}/dns-records/{recordId}")
  void deleteDNSRecord(@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_DNS)
  @PathParam("orgUuid") String orgUuid, @PathParam("recordId") int recordId);

  /**
   * Get catalogs associated with the given organization.
   *
   * @param orgUuid org uuid
   * @return list of catalogs for the organization
   */
  @GET
  @Path("/{orgUuid}/catalogs")
  CatalogListResponse getCatalogsForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Get vapp templates for a given organization.
   *
   * @param orgUuid org uuid
   * @return list of vapp templates for the given organization
   */
  @GET
  @Path("/{orgUuid}/vapp-templates")
  VappTemplateListResponse getVappTemplatesForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Has the org had any legacy bills ever?
   *
   * @param orgUuid iland platform org uuid
   * @return a {@link BillingLegacyResponse} instance
   */
  @GET
  @Path("/{orgUuid}/legacy-billing-info")
  BillingLegacyResponse hasAnyLegacyBilling(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Returns Org Billing for a given invoice period.
   * <p>
   * If month and year are not explicitly supplied the current invoice period is
   * used.
   *
   * @param orgUuid org uuid
   * @param year    the invoice period year (defaults to current year)
   * @param month   the invoice period month (defaults to the current month) must
   *                be in range 1-12
   * @return billing for the organization and given invoice period
   */
  @GET
  @Path("/{orgUuid}/billing")
  BillResponse getBilling(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_BILLING)
      @PathParam("orgUuid") String orgUuid, @QueryParam("year") Integer year,
      @QueryParam("month") Integer month);

  /**
   * Get current org billing broken down by Vdc.
   *
   * @param orgUuid org uuid
   * @return current billing for the organization broken down by VDC
   */
  @GET
  @Path("/{orgUuid}/billing-by-vdc")
  OrgBillingByVdcResponse getCurrentBillingByVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_BILLING)
      @PathParam("orgUuid") String orgUuid);

  /**
   * Get historical org billing.
   *
   * @param orgUuid org uuid
   * @param start   start
   * @param end     end
   * @return list of historical bills for the organization between the given
   * dates
   */
  @GET
  @Path("/{orgUuid}/historical-billing")
  BillListResponse getHistoricalBilling(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_BILLING)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end);

  /**
   * Update the org / vapp lease settings section for a given org.
   *
   * @param orgUuid org uuid
   * @param spec    specification for updating org vapp lease settings
   * @return organization
   */
  @POST
  @Path("/{orgUuid}/actions/update-vapp-lease-settings")
  @Consumes(MediaType.APPLICATION_JSON)
  OrgResponse updateOrgVappLeaseSettings(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_CONFIGURATION)
      @PathParam("orgUuid") String orgUuid, OrgVappLeaseUpdateRequest spec);

  /**
   * Update the org / vapp template lease settings section for a given org.
   *
   * @param orgUuid org uuid
   * @param spec    specification for updating org vapp template lease settings
   * @return organization
   */
  @POST
  @Path("/{orgUuid}/actions/update-vapp-template-lease-settings")
  @Consumes(MediaType.APPLICATION_JSON)
  OrgResponse updateOrgVappTemplateLeaseSettings(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_CONFIGURATION)
      @PathParam("orgUuid") String orgUuid,
      OrgVappTemplateLeaseUpdateRequest spec);

  /**
   * Get medias for a given Org.
   *
   * @param orgUuid org uuid
   * @return list of medias for the given organization
   */
  @GET
  @Path("/{orgUuid}/medias")
  MediaListResponse getMedias(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Return whether an org is a compliance organization.
   *
   * @param orgUuid organization uuid
   * @return whether the org is a compliance org
   */
  @GET
  @Path("/{orgUuid}/is-compliance-org")
  IsComplianceOrgResponse isComplianceOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid);

  /**
   * Create a catalog in the organization.
   *
   * @param orgUuid organization uuid
   * @param request request for new catalog
   * @return core task
   */
  @POST
  @Path("/{orgUuid}/catalog")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse createCatalog(
      @SecureEntityRef(Permission.CREATE_ILAND_CLOUD_ORG_CATALOGS)
      @PathParam("orgUuid") String orgUuid, CatalogCreateRequest request);

  /**
   * Returns Org Billing Currency Code.
   *
   * @param orgUuid org uuid
   * @return org currency code
   */
  @GET
  @Path("/{orgUuid}/billing-currency-code")
  CurrencyCodeResponse getBillingCurrencyCode(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_BILLING)
      @PathParam("orgUuid") String orgUuid);

  /**
   * Gets the public IP assignments for the organization.
   *
   * @param orgUuid org uuid
   * @return public IP assignments
   */
  @GET
  @Path("/{orgUuid}/public-ip-assignments")
  @Consumes(MediaType.APPLICATION_JSON)
  PublicIpAssignmentListResponse getOrgPublicIpAssignments(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Gets the public IPs for the organization.
   *
   * @param orgUuid org uuid
   * @return public IPs
   */
  @GET
  @Path("/{orgUuid}/public-ips")
  @Consumes(MediaType.APPLICATION_JSON)
  IPAddressSetResponse getOrgPublicIps(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Returns the list of VPGs for a given target vCloud Organization.
   *
   * @param orgUuid org uuid
   * @return list of zerto vpgs
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @GET
  @Path("/{orgUuid}/vpgs")
  ExpandedVpgListResponse getVpgsForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid,
      @QueryParam("expand") final List<VpgSubEntityRequest> expand);

  /**
   * Returns a VPGs protection info.
   *
   * @param orgUuid org uuid
   * @return a {@link VpgsProtectionInfoResponse} the VPGs protection info
   */
  @SkipSecurityTest("We don't have a VPG that coke user should have access to.")
  @GET
  @Path("/{orgUuid}/vpgs-protection-info")
  VpgsProtectionInfoResponse getVpgsProtectionSummary(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Returns the list of VCC-R failover plans for a given target vCloud
   * Organization.
   *
   * @param orgUuid org uuid
   * @return list of VCC-R failover Plans
   */
  @GET
  @Path("/{orgUuid}/vcc-failover-plans")
  VccFailoverPlanListResponse getVccFailoverPlans(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Returns the vcc replication storage used by all the vdcs in the org
   *
   * @param orgUuid org uuid
   * @return {@link VccReplicationUsageResponse}VCC-R storage response
   */
  @GET
  @Path("/{orgUuid}/vcc-replication-storage")
  VccReplicationUsageResponse getVccReplicationStorage(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
      String orgUuid);

  /**
   * Batch test failover for one or more VPGs within an org.
   *
   * @param params  the batch failover test parameters
   * @param orgUuid the uuid of the organization that the vpgs belong to
   * @return asynchronous task details
   */
  @POST
  @Path("/{orgUuid}/actions/vpg-batch-failover-test")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse batchFailoverTest(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
      String orgUuid, BatchFailoverTestParamsRequest params);

  /**
   * Initiates a batch live failover on one or more VPGs withing an org.
   *
   * @param params  the batch failover parameters
   * @param orgUuid the uuid of the organization that the vpgs belong to
   * @return asynchronous task details
   */
  @POST
  @Path("/{orgUuid}/actions/vpg-batch-failover")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse batchFailover(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
      String orgUuid, BatchFailoverParamsRequest params);

  /**
   * Get the expired vapp and vapp templates for the given org.
   *
   * @param orgUuid org uuid
   * @return expired items, vapps and vapp templates
   */
  @GET
  @Path("/{orgUuid}/expired-items")
  OrgExpiredItemsResponse getExpiredItems(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Returns the summary of bandwidth usage, and current reservation for the
   * given month and year. If no month / year values are provided, the current
   * month will be defaulted to. If you provide the month or year query
   * parameters you must provide both of them to receive a valid response.
   * <p>
   * All bandwidth units are GB.
   *
   * @param orgUuid the UUID of the organization for which bandwidth summary is
   *                returned
   * @param month   the month to return bandwidth summary for. The valid values
   *                for the month query parameter are 1-12.
   * @param year    the year to return bandwidth summary for
   * @return the monthly bandwidth summary
   */
  @GET
  @Path("/{orgUuid}/bandwidth-usage-summary")
  BandwidthUsageSummaryResponse getBandwidthUsageSummary(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @QueryParam("month") Integer month,
      @QueryParam("year") Integer year);

  /**
   * Get a list of series detailing the hourly cost over an invoice period for
   * all vDCs in a given Organization.
   *
   * @param orgUuid          the UUID of the organization
   * @param year             the year
   * @param month            the month in range 1-12
   * @param additionalFields additional bill fields that should be included in
   *                         the series
   * @return a list of series of samples detailing hourly vDC total cost by hour
   * for the invoice period
   */
  @GET
  @Path("/{orgUuid}/vdcs-cost-over-invoice-period")
  BillingSampleSerieListResponse getVdcCostOverInvoicePeriodSeries(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_BILLING)
      @PathParam("orgUuid") String orgUuid, @QueryParam("year") Integer year,
      @QueryParam("month") Integer month,
      @QueryParam("additionalFields") List<String> additionalFields);

  /**
   * Get a list of vDC bills for a given org between the given date ranges.
   *
   * @param orgUuid    the UUID of the organization
   * @param startYear  the start year
   * @param startMonth the start month (must be in range of 1-12)
   * @param endYear    the end year
   * @param endMonth   the end month (must be in range of 1-12)
   * @return list of vDC bills per invoice period for the given org
   */
  @GET
  @Path("/{orgUuid}/historical-billing-by-vdc")
  OrgVdcBillsListResponse getHistoricalBillingByVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_BILLING)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("startYear") Integer startYear,
      @QueryParam("startMonth") Integer startMonth,
      @QueryParam("endYear") Integer endYear,
      @QueryParam("endMonth") Integer endMonth);

  /**
   * Get external network usage for the given organization and type.
   *
   * @param orgUuid org uuid
   * @param type    type
   * @param start   start date
   * @param end     end date
   * @return performance samples for external network, given counter, and date
   * range
   */
  @GET
  @Path("/{orgUuid}/external-network-usage")
  NetworkPerfSampleSerieListResponse getExternalNetworkUsageFor(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @QueryParam("type") String type,
      @QueryParam("start") Long start, @QueryParam("end") Long end);

  /**
   * Get external network usage summary for the given organization and type.
   *
   * @param orgUuid org uuid
   * @param type    type
   * @param start   start date
   * @param end     end date
   * @return performance samples for external network, given counter, and date
   * range
   */
  @GET
  @Path("/{orgUuid}/external-network-summation")
  NetworkPerfSampleSerieListResponse getExternalNetworkSummaryFor(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @QueryParam("type") String type,
      @QueryParam("start") Long start, @QueryParam("end") Long end);

  /**
   * Get network usage for the given organization and type.
   *
   * @param orgUuid org uuid
   * @param type    type
   * @param start   start date
   * @param end     end date
   * @return list of network performance samples for the network
   */
  @GET
  @Path("/{orgUuid}/bandwidth-usage")
  NetworkPerfSampleSerieListResponse getNetUsageFor(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @QueryParam("type") String type,
      @QueryParam("start") Long start, @QueryParam("end") Long end);

  /**
   * Get network usage summary for the given organization and type.
   *
   * @param orgUuid org uuid
   * @param type    type
   * @param start   start date
   * @param end     end date
   * @return list of network performane samples for the network
   */
  @GET
  @Path("/{orgUuid}/bandwidth-summation")
  NetworkPerfSampleSerieListResponse getNetSummaryFor(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @QueryParam("type") String type,
      @QueryParam("start") Long start, @QueryParam("end") Long end);

  /**
   * Launch a CODA scan given an organization uuid. This method is only used
   * for testing to bypass the CODA enabled flag.
   *
   * @param orgUuid org uuid
   * @return network scan launch
   */
  @POST
  @Path("/{orgUuid}/coda/actions/launch-scan")
  LaunchResponse launchCodaScan(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid);

  /**
   * Launch a network scan given an organization uuid and a scan id.
   * <p>
   * Will only successfully queue scan launch if that scan is not currently in
   * progress.
   *
   * @param orgUuid        org uuid
   * @param scanTemplateId network scan id
   * @return network launch
   */
  @POST
  @Path("/{orgUuid}/nessus-scan-templates/{scanTemplateId}/actions/launch-scan")
  LaunchResponse launchNetworkScan(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @PathParam("scanTemplateId") int scanTemplateId);

  /**
   * Pause a network scan given an organization uuid and a scan id.
   * <p>
   * Will only successfully pause scan if that scan is currently running.
   *
   * @param orgUuid        org uuid
   * @param scanTemplateId network scan id
   */
  @POST
  @Path("/{orgUuid}/nessus-scan-templates/{scanTemplateId}/actions/pause-scan")
  void pauseNetworkScan(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @PathParam("scanTemplateId") int scanTemplateId);

  /**
   * Stop a network scan given an organization uuid and a scan id.
   * <p>
   * Will only successfully stop scan if that scan is currently running.
   *
   * @param orgUuid        org uuid
   * @param scanTemplateId network scan id
   */
  @POST
  @Path("/{orgUuid}/nessus-scan-templates/{scanTemplateId}/actions/stop-scan")
  void stopNetworkScan(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @PathParam("scanTemplateId") int scanTemplateId);

  /**
   * Resume a network scan given an organization uuid and a scan id.
   * <p>
   * Will only successfully resume scan if that scan is currently paused.
   *
   * @param orgUuid        org uuid
   * @param scanTemplateId network scan id
   */
  @POST
  @Path("/{orgUuid}/nessus-scan-templates/{scanTemplateId}/actions/resume-scan")
  void resumeNetworkScan(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @PathParam("scanTemplateId") int scanTemplateId);

  /**
   * Get a list of all scans for a given organization.
   *
   * @param orgUuid org uuid
   * @param offset  the offset of the first scan to retrieve
   * @param limit   the limit of the number of scans to retrieve
   * @return list of network scans for the organization
   */
  @GET
  @Path("/{orgUuid}/nessus-scan-templates")
  NetworkScanListResponse getNetworkScanTemplates(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("offset") Integer offset, @QueryParam("limit") Integer limit);

  /**
   * Get a list of all scans with given ID that are in a given organization.
   * <p>
   * This will only return all the scans with the given ID.
   *
   * @param orgUuid org uuid
   * @param offset  the offset of the first scan to retrieve
   * @param limit   the limit of the number of scans to retrieve
   * @return list of launched network scans for the organization
   */
  @GET
  @Path("/{orgUuid}/nessus-scan-templates/{scanTemplateId}/nessus-scan-results")
  NetworkScanListResponse getNetworkScanResultsForTemplate(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @PathParam("scanTemplateId") int scanTemplateId,
      @QueryParam("offset") Integer offset, @QueryParam("limit") Integer limit);

  /**
   * Get the scan details for a given organization and a scan UUID.
   * <p>
   * Scan uuid is different than scan id: scan uuid points to a specific scan
   * where scan ID points to the template the scan was run from.
   *
   * @param orgUuid org uuid
   * @return list of launched network scans for the organization
   */
  @GET
  @Path("/{orgUuid}/nessus-scans-results/{scanResultUuid}")
  NetworkScanDetailsResponse getNetworkScanResult(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @PathParam("scanResultUuid") String scanResultUuid);

  /**
   * Update a scan given an organization and the scan ID.
   * <p>
   *
   * @param orgUuid        org uuid
   * @param scanTemplateId scan template id
   * @param spec           specification for updating the scan
   * @return details of the updated scan
   */
  @PUT
  @Path("/{orgUuid}/nessus-scan-templates/{scanTemplateId}")
  @Consumes(MediaType.APPLICATION_JSON)
  NetworkScanUpdateResponse updateNetworkScanTemplate(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @PathParam("scanTemplateId") int scanTemplateId,
      NetworkScanUpdateRequest spec);

  /**
   * Gets a vCD edge gateway usage summary, summarizing the total bandwidth used
   * for both inbound and outbound edge network traffic.
   * <p>
   * If no start/end dates are provided it will default to the latest hour
   * range. If you pass a custom time range both start and end date must be
   * passed together
   *
   * @param orgUuid UUID of the parent organization
   * @param type    type
   * @param start   start date
   * @param end     end date
   */
  @GET
  @Path("/{orgUuid}/edge-network-usage-summary")
  NetworkPerfSampleSerieListResponse getEdgeNetworkUsageSummary(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @QueryParam("type") String type,
      @QueryParam("start") Long start, @QueryParam("end") Long end);

  /**
   * Gets usage data for a VCD edge gateway. Returns a time series showing the
   * average inbound and outbound network thoughput in KBps.
   *
   * @param orgUuid UUID of the parent organization
   * @param type    type
   * @param start   start date
   * @param end     end date
   * @return network performance samples
   */
  @GET
  @Path("/{orgUuid}/edge-network-usage-over-time")
  NetworkPerfSampleSerieListResponse getEdgeNetworkUsageOverTime(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @QueryParam("type") String type,
      @QueryParam("start") Long start, @QueryParam("end") Long end);

  /**
   * Get the list of recovery runbooks for a given organization.
   *
   * @param orgUuid the organization UUID
   * @return the list of runbooks
   */
  @GET
  @Path("/{orgUuid}/disaster-recovery-runbooks")
  DisasterRecoveryRunbookListResponse getRecoveryRunbooks(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_DR_RUNBOOKS)
      @PathParam("orgUuid") String orgUuid);

  /**
   * Add a runbook to the given organizations runbooks.
   *
   * @param orgUuid the organization UUID
   * @param spec    the specification for the new recovery runbook
   * @return the newly craeted recovery runbook
   */
  @POST
  @Path("/{orgUuid}/disaster-recovery-runbooks")
  @Consumes(MediaType.APPLICATION_JSON)
  DisasterRecoveryRunbookResponse createRecoveryRunbook(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_DR_RUNBOOKS)
      @PathParam("orgUuid") String orgUuid,
      DisasterRecoveryRunbookCreateRequest spec);

  /**
   * Update a set of ip addresses or ranges to opt out of weekly network scans
   * for a given org. Or opt out completely of all scans.
   *
   * @param request network scan opt out details
   */
  @POST
  @Path("/{orgUuid}/actions/update-nessus-scan-opt-out-preferences")
  @Consumes(MediaType.APPLICATION_JSON)
  NetworkScanOptOutResponse updateNetworkScanOptOutPreferences(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      NetworkScanOptOutCreateRequest request);

  /**
   * Get the network scan opt out details for the given org.
   *
   * @param orgUuid org uuid
   */
  @GET
  @Path("/{orgUuid}/nessus-scan-opt-out-preferences")
  NetworkScanOptOutResponse getNetworkScanOptOutPreferences(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid);

  /**
   * Get the protection sources for the given org.
   *
   * @param orgUuid     org UUID
   * @param hostType    e.g. "linux" or "windows"
   * @param environment e.g. "*" or "sql"
   * @return a list of protection sources
   */
  @GET
  @Path("/{orgUuid}/vms/{hostType: (\\*|linux|windows)}/{environment: (\\*|sql)}")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
  ListResponse<PublicProtectionSource> listProtectionSourcesForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("orgUuid")
      OrgUuid orgUuid, @PathParam("hostType") String hostType,
      @PathParam("environment") String environment);

  /**
   * Get the SQL protection sources for the given org.
   *
   * @param orgUuid org UUID
   * @return a list of protection sources
   */
  @GET
  @Path("/{orgUuid}/sql-protection-sources")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
  ListResponse<SqlProtectionSourceModel> listSqlProtectionSourcesForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("orgUuid")
      OrgUuid orgUuid);

  /**
   * Get the Oracle protection sources for the given org.
   *
   * @param orgUuid org UUID
   * @return a list of Oracle protection sources
   */
  @GET
  @Path("/{orgUuid}/oracle-protection-sources")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
  ListResponse<OracleProtectionSourceModel> listOracleProtectionSourcesForOrg(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("orgUuid")
      OrgUuid orgUuid);

  /**
   * List the existing backup groups that are configured in a specified
   * organization.
   *
   * @param orgUuid             the UUID of the org
   * @param includeDeleted      whether to include deleted backup groups
   * @param includeSummaryStats whether to include backup summary stats
   * @param includeLastRun      whether to include last run info in the response
   * @param includeBackupPolicy whether to include backup policy info
   * @return {@link BackupGroupListResponse}
   */
  @GET
  @Path("/{orgUuid}/backup-groups")
  BackupGroupListResponse listBackupGroups(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @QueryParam("includeDeleted") boolean includeDeleted,
      @QueryParam("includeSummaryStats") boolean includeSummaryStats,
      @QueryParam("includeLastRun") boolean includeLastRun,
      @QueryParam("includeBackupPolicy") boolean includeBackupPolicy);

  /**
   * List the existing backup groups that are configured in a specified
   * organization.
   *
   * @param orgUuid             the UUID of the org
   * @param includeDeleted      whether to include deleted backup groups
   * @param includeSummaryStats whether to include backup summary stats
   * @param includeLastRun      whether to include last run info in the response
   * @param includeBackupPolicy whether to include backup policy info
   * @param includeLegacyVMware weather to include legacy VMware backup groups
   * @return {@link ListResponse list of backup groups}
   */
  @GET
  @Path("/{orgUuid}/backup-groups-x")
  ListResponse<BackupGroupV2> listV2BackupGroups(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
      OrgUuid orgUuid, @QueryParam("includeDeleted") boolean includeDeleted,
      @QueryParam("includeSummaryStats") boolean includeSummaryStats,
      @QueryParam("includeLastRun") boolean includeLastRun,
      @QueryParam("includeBackupPolicy") boolean includeBackupPolicy,
      @QueryParam("includeLegacyVMware") boolean includeLegacyVMware);

  /**
   * Gets backup group summary stats for the Org.
   * <p>
   * Stat time-range defaults to the past 24 hours.
   *
   * @param orgUuid the UUID of the Org
   * @param filters optional filters that can be used to specify a custom
   *                timeframe.
   * @return {@link OrgBackupSummaryStatsResponse}
   */
  @GET
  @Path("/{orgUuid}/backup-group-summary-stats")
  OrgBackupSummaryStatsResponse getBackupGroupSummaryStats(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @BeanParam GetBackupGroupSummaryStatsFilters filters);

  /**
   * List the existing backup policies that are configured in an organization.
   *
   * @param orgUuid                  the UUID of the organization
   * @param includeVdcScopedPolicies whether to include vDC scoped policies for
   *                                 all vDCs that are children of the org.
   * @return {@link BackupPolicyListResponse}
   */
  @GET
  @Path("/{orgUuid}/backup-policies")
  BackupPolicyListResponse listBackupPolicies(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid,
      @QueryParam("includeVdcScopedPolicies") boolean includeVdcScopedPolicies);

  /**
   * Get details of an individual org-scoped backup policy.
   *
   * @param backupPolicyUid the UID of the backup policy
   * @param orgUuid         the UUID of the organization
   * @return {@link BackupPolicyResponse}
   */
  @GET
  @Path("/{orgUuid}/backup-policies/{backupPolicyUid}")
  BackupPolicyResponse getBackupPolicy(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @PathParam("backupPolicyUid") String backupPolicyUid);

  /**
   * Create a new org-scoped backup policy.
   *
   * @param orgUuid         the UUID of the organization
   * @param creationRequest the creation request body
   * @return {@link BackupPolicyResponse}
   */
  @POST
  @Path("/{orgUuid}/backup-policies")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupPolicyResponse createBackupPolicy(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_CONFIGURATION)
      @PathParam("orgUuid") String orgUuid,
      BackupPolicyUpdateRequest creationRequest);

  /**
   * Update a backup policy.
   *
   * @param orgUuid         the UUID of the organization
   * @param backupPolicyUid the UID of the backup policy
   * @param updateRequest   the update request body
   * @return {@link BackupPolicyResponse}
   */
  @PUT
  @Path("/{orgUuid}/backup-policies/{backupPolicyUid}")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupPolicyResponse updateBackupPolicy(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_CONFIGURATION)
      @PathParam("orgUuid") String orgUuid,
      @PathParam("backupPolicyUid") String backupPolicyUid,
      BackupPolicyUpdateRequest updateRequest);

  /**
   * Gets the org's backup status.
   *
   * @param orgUuid the UUID of the org
   * @return org backup status details
   */
  @GET
  @Path("/{orgUuid}/backup-status")
  OrgBackupStatusResponse getBackupStatus(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Gets the Org's integrated backup status.
   *
   * @param orgUuid the UUID of the org
   * @return org integrated backup status details
   */
  @GET
  @Path("/{orgUuid}/integrated-backup-status")
  OrgIntegratedBackupStatusResponse getIntegratedBackupStatus(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid);

  /**
   * Delete a backup policy.
   *
   * @param orgUuid         the UUID of the organization
   * @param backupPolicyUid the UID of the backup policy
   */
  @DELETE
  @Path("/{orgUuid}/backup-policies/{backupPolicyUid}")
  @Consumes(MediaType.APPLICATION_JSON)
  void deleteBackupPolicy(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_ORG_CONFIGURATION)
      @PathParam("orgUuid") String orgUuid,
      @PathParam("backupPolicyUid") String backupPolicyUid);



  /**
   * Get the list of performance counters that can be used to query for VPGs
   * usage data for this org.
   *
   * @return the list of performance counters
   */
  @GET
  @Path("/performance-counters-vpg")
  PerformanceCounterListResponse getPerformanceCountersForVpg();

  /**
   * Returns aggregated samples for VPGs in an org given a performance serie and
   * time range. <p>
   * The samples returned are dynamic (5 minute samples for range less than a
   * day, hourly for range more than a day, and daily for range more than a month)
   *
   * @param orgUuid the org unique identifier.
   * @param group   performance counter group name
   * @param name    performance counter name
   * @param type    performance counter type
   * @param start   start date
   * @param end     end date
   * @return an aggregated org level Vpg performance serie for the time range
   */
  @GET
  @Path("/{orgUuid}/performance/{group}::{name}::{type}")
  PerfSampleSerieResponse getVpgPerfSamplesFor(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @PathParam("group") String group,
      @PathParam("name") String name, @PathParam("type") String type,
      @QueryParam("start") Long start, @QueryParam("end") Long end);
}
