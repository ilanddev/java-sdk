/*
 * Copyright (c) 2013 - 2024, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.vac;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * VAC Processed Object Restore Point Response.
 *
 * @author <a href="mailto:Pablo.Buendia@1111systems.com">Pablo Buendia</a>
 */
@APIModel
public interface VacProcessedObjectRestorePointResponse {

  /**
   * Internal uuid of the restore point.
   */
  String uuid();

  /**
   * Internal uuid of the processed object.
   */
  String processedObjectUid();

  /**
   * Path to a backup file location.
   */
  Optional<String> filePath();

  /**
   * Array of enabled GFS retention types.
   * Types: "Weekly," "Monthly," "Quarterly," "Yearly"
   */
  Optional<List<String>> gfsType();

  /**
   * UID assigned to a backup chain.
   */
  String backupUid();

  /**
   * UID assigned to a backup job.
   */
  String jobUid();

  /**
   * UID assigned to a repository on which the restore point resides.
   */
  String repositoryUid();

  /**
   * Size of a restore point, in bytes. Includes all virtual machines protected by the same backup job.
   */
  Optional<Long> size();

  /**
   * Total size of protected virtual machine disks, in bytes.
   */
  Optional<Long> provisionedSourceSize();

  /**
   * Used space on protected virtual machine disks, in bytes.
   */
  Optional<Long> usedSourceSize();

  /**
   * Size of backup increment, in bytes.
   */
  Optional<Long> incrementRawDataSize();

  /**
   * Date and time when backup was created.
   */
  Optional<Instant> backupCreationTime();

  /**
   * Date and time when a restore point was created.
   */
  Optional<Instant> fileCreationTime();

}
