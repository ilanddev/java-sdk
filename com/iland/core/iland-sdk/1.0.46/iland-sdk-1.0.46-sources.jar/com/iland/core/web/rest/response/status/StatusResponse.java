/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.status;

import java.io.Serializable;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.request.status.ServiceStatusRequest;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Status Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class StatusResponse implements Serializable {

  private static final long serialVersionUID = -1861450268745263957L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String locationId;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Map<ServiceStatusRequest, ServiceStatusStateResponse> servicesStatus;

  public StatusResponse(final String locationId,
      final Map<ServiceStatusRequest, ServiceStatusStateResponse> servicesStatus) {
    this.locationId = locationId;
    this.servicesStatus = servicesStatus;
  }

  /**
   * Returns the location identifier.
   *
   * @return {@link String}
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Returns a map from service identifier to service status.
   *
   * @return {@link Map} of {@link ServiceStatusRequest} for service identifiers
   * keys to {@link ServiceStatusStateResponse} for service states
   * values.
   */
  public Map<ServiceStatusRequest, ServiceStatusStateResponse> getServicesStatus() {
    return servicesStatus;
  }

}
