/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.org;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.vm.VmResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vm Affinity Rule Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VmAffinityRuleResponse implements Serializable {

  private static final long serialVersionUID = 3203559945528761732L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<VmResponse> vms;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Integer key;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean enabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean userCreated;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Boolean inCompliance;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final AffinityRuleType type;

  public VmAffinityRuleResponse(final List<VmResponse> vms, final Integer key,
      final boolean enabled, final String name, final boolean userCreated,
      final Boolean inCompliance, final String uuid,
      final AffinityRuleType type) {
    this.vms = vms;
    this.key = key;
    this.enabled = enabled;
    this.name = name;
    this.userCreated = userCreated;
    this.inCompliance = inCompliance;
    this.uuid = uuid;
    this.type = type;
  }

  /**
   * Get the list of {@link VmResponse} for the affinity rule.
   *
   * @return {@link List} of {@link VmResponse} vms
   */
  public List<VmResponse> getVms() {
    return vms;
  }

  /**
   * Get the key.
   *
   * @return {@link Integer} key
   */
  public Integer getKey() {
    return key;
  }

  /**
   * Whether the rule is enabled.
   *
   * @return enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Get the rule name.
   *
   * @return {@link String} name
   */
  public String getName() {
    return name;
  }

  /**
   * Where the rule is user created.
   *
   * @return user created
   */
  public boolean isUserCreated() {
    return userCreated;
  }

  /**
   * Whether the rule is in compliance.
   *
   * @return in compliance
   */
  public Boolean isInCompliance() {
    return inCompliance;
  }

  /**
   * Get the rule uuid.
   *
   * @return {@link String} rule uuid
   */
  public String getUUID() {
    return uuid;
  }

  /**
   * Get the rule type.
   * <p>
   * Can be one of 'affinity' or 'anti-affinity'
   *
   * @return {@link AffinityRuleType} rule type
   */
  public AffinityRuleType getType() {
    return type;
  }


  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final VmAffinityRuleResponse that = (VmAffinityRuleResponse) o;

    if (isEnabled() != that.isEnabled())
      return false;
    if (isUserCreated() != that.isUserCreated())
      return false;
    if (getVms() != null ?
        !getVms().equals(that.getVms()) :
        that.getVms() != null)
      return false;
    if (getKey() != null ?
        !getKey().equals(that.getKey()) :
        that.getKey() != null)
      return false;
    if (getName() != null ?
        !getName().equals(that.getName()) :
        that.getName() != null)
      return false;
    if (isInCompliance() != null ?
        !isInCompliance().equals(that.isInCompliance()) :
        that.isInCompliance() != null)
      return false;
    if (getUUID() != null ?
        !getUUID().equals(that.getUUID()) :
        that.getUUID() != null)
      return false;
    return getType() != null ?
        getType().equals(that.getType()) :
        that.getType() == null;
  }

  @Override
  public int hashCode() {
    int result = getVms() != null ? getVms().hashCode() : 0;
    result = 31 * result + (getKey() != null ? getKey().hashCode() : 0);
    result = 31 * result + (isEnabled() ? 1 : 0);
    result = 31 * result + (getName() != null ? getName().hashCode() : 0);
    result = 31 * result + (isUserCreated() ? 1 : 0);
    result = 31 * result + (isInCompliance() != null ?
        isInCompliance().hashCode() :
        0);
    result = 31 * result + (getUUID() != null ? getUUID().hashCode() : 0);
    result = 31 * result + (getType() != null ? getType().hashCode() : 0);
    return result;
  }

}
