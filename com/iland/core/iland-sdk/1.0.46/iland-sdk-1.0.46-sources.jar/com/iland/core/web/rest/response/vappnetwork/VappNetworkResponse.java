/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vappnetwork;

import java.time.Instant;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.response.common.IpRangeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.shared.network.FenceMode;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Network Response
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class VappNetworkResponse extends EntityResponse {

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String orgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vdcUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String primaryDns;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String secondaryDns;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String dnsSuffix;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private FenceMode fenceMode;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String gateway;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String netmask;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Set<IpRangeResponse> ipRanges;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean inherited;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String parentNetworkUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vappUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String routerExternalIp;

  public VappNetworkResponse(final String uuid, final String companyId,
      final boolean deleted, final Instant deletedDate, final String name,
      final Instant updatedDate, final String locationId, final String orgUuid,
      final String vdcUuid, final String description, final String dnsSuffix,
      final FenceMode fenceMode, final String gateway, final boolean inherited,
      final Set<IpRangeResponse> ipRanges, final String netmask,
      final String parentNetworkUuid, final String primaryDns,
      final String secondaryDns, final String vappUuid,
      final String routerExternalIp) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.locationId = locationId;
    this.orgUuid = orgUuid;
    this.vdcUuid = vdcUuid;
    this.description = description;
    this.dnsSuffix = dnsSuffix;
    this.fenceMode = fenceMode;
    this.gateway = gateway;
    this.inherited = inherited;
    this.ipRanges = ipRanges;
    this.netmask = netmask;
    this.parentNetworkUuid = parentNetworkUuid;
    this.primaryDns = primaryDns;
    this.secondaryDns = secondaryDns;
    this.vappUuid = vappUuid;
    this.routerExternalIp = routerExternalIp;
  }

  /**
   * Gets router external ip.
   *
   * @return the router external ip
   */
  public String getRouterExternalIp() {
    return routerExternalIp;
  }

  /**
   * Gets vapp uuid.
   *
   * @return the vapp uuid
   */
  public String getVappUuid() {
    return vappUuid;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets dns suffix.
   *
   * @return the dns suffix
   */
  public String getDnsSuffix() {
    return dnsSuffix;
  }

  /**
   * Gets fence mode.
   *
   * @return the fence mode
   */
  public FenceMode getFenceMode() {
    return fenceMode;
  }

  /**
   * Gets gateway.
   *
   * @return the gateway
   */
  public String getGateway() {
    return gateway;
  }

  /**
   * Is inherited boolean.
   *
   * @return the boolean
   */
  public boolean isInherited() {
    return inherited;
  }

  /**
   * Gets ip ranges.
   *
   * @return the ip ranges
   */
  public Set<IpRangeResponse> getIpRanges() {
    return ipRanges;
  }


  /**
   * Gets location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Gets netmask.
   *
   * @return the netmask
   */
  public String getNetmask() {
    return netmask;
  }

  /**
   * Gets org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets parent network uuid.
   *
   * @return the parent network uuid
   */
  public String getParentNetworkUuid() {
    return parentNetworkUuid;
  }

  /**
   * Gets primary dns.
   *
   * @return the primary dns
   */
  public String getPrimaryDns() {
    return primaryDns;
  }


  /**
   * Gets secondary dns.
   *
   * @return the secondary dns
   */
  public String getSecondaryDns() {
    return secondaryDns;
  }

  /**
   * Gets vdc uuid.
   *
   * @return the vdc uuid
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    if (!super.equals(o))
      return false;

    VappNetworkResponse that = (VappNetworkResponse) o;

    if (inherited != that.inherited)
      return false;
    if (locationId != null ?
        !locationId.equals(that.locationId) :
        that.locationId != null)
      return false;
    if (orgUuid != null ? !orgUuid.equals(that.orgUuid) : that.orgUuid != null)
      return false;
    if (vdcUuid != null ? !vdcUuid.equals(that.vdcUuid) : that.vdcUuid != null)
      return false;
    if (description != null ?
        !description.equals(that.description) :
        that.description != null)
      return false;
    if (primaryDns != null ?
        !primaryDns.equals(that.primaryDns) :
        that.primaryDns != null)
      return false;
    if (secondaryDns != null ?
        !secondaryDns.equals(that.secondaryDns) :
        that.secondaryDns != null)
      return false;
    if (dnsSuffix != null ?
        !dnsSuffix.equals(that.dnsSuffix) :
        that.dnsSuffix != null)
      return false;
    if (fenceMode != that.fenceMode)
      return false;
    if (gateway != null ? !gateway.equals(that.gateway) : that.gateway != null)
      return false;
    if (netmask != null ? !netmask.equals(that.netmask) : that.netmask != null)
      return false;
    if (ipRanges != null ?
        !ipRanges.equals(that.ipRanges) :
        that.ipRanges != null)
      return false;
    if (parentNetworkUuid != null ?
        !parentNetworkUuid.equals(that.parentNetworkUuid) :
        that.parentNetworkUuid != null)
      return false;
    if (vappUuid != null ?
        !vappUuid.equals(that.vappUuid) :
        that.vappUuid != null)
      return false;
    return routerExternalIp != null ?
        routerExternalIp.equals(that.routerExternalIp) :
        that.routerExternalIp == null;
  }

  @Override
  public int hashCode() {
    int result = super.hashCode();
    result = 31 * result + (locationId != null ? locationId.hashCode() : 0);
    result = 31 * result + (orgUuid != null ? orgUuid.hashCode() : 0);
    result = 31 * result + (vdcUuid != null ? vdcUuid.hashCode() : 0);
    result = 31 * result + (description != null ? description.hashCode() : 0);
    result = 31 * result + (primaryDns != null ? primaryDns.hashCode() : 0);
    result = 31 * result + (secondaryDns != null ? secondaryDns.hashCode() : 0);
    result = 31 * result + (dnsSuffix != null ? dnsSuffix.hashCode() : 0);
    result = 31 * result + (fenceMode != null ? fenceMode.hashCode() : 0);
    result = 31 * result + (gateway != null ? gateway.hashCode() : 0);
    result = 31 * result + (netmask != null ? netmask.hashCode() : 0);
    result = 31 * result + (ipRanges != null ? ipRanges.hashCode() : 0);
    result = 31 * result + (inherited ? 1 : 0);
    result = 31 * result + (parentNetworkUuid != null ?
        parentNetworkUuid.hashCode() :
        0);
    result = 31 * result + (vappUuid != null ? vappUuid.hashCode() : 0);
    result = 31 * result + (routerExternalIp != null ?
        routerExternalIp.hashCode() :
        0);
    return result;
  }

  @Override
  public String toString() {
    return "VappNetworkResponse{" + "locationId='" + locationId + '\''
        + ", orgUuid='" + orgUuid + '\'' + ", vdcUuid='" + vdcUuid + '\''
        + ", description='" + description + '\'' + ", primaryDns='" + primaryDns
        + '\'' + ", secondaryDns='" + secondaryDns + '\'' + ", dnsSuffix='"
        + dnsSuffix + '\'' + ", fenceMode=" + fenceMode + ", gateway='"
        + gateway + '\'' + ", netmask='" + netmask + '\'' + ", ipRanges="
        + ipRanges + ", inherited=" + inherited + ", parentNetworkUuid='"
        + parentNetworkUuid + '\'' + ", vappUuid='" + vappUuid + '\''
        + ", routerExternalIp='" + routerExternalIp + '\'' + '}';
  }

}
