/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * BackupGroupStatusDescriptor.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class BackupGroupStatusDescriptor {

  @Expose
  @JsonRequired("The name of the backup group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @JsonRequired("The UID of the backup group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uid;

  @Expose
  @JsonRequired("The backup status of the entity within the referenced backup group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupConfigStatus backupStatus;

  public BackupGroupStatusDescriptor(final String name, final String uid,
      final BackupConfigStatus backupStatus) {
    this.name = name;
    this.uid = uid;
    this.backupStatus = backupStatus;
  }

  /**
   * Gets the name of the backup group.
   *
   * @return {@link String}
   */
  public String getName() {
    return name;
  }

  /**
   * Gets the UID of the backup group.
   *
   * @return {@link String}
   */
  public String getUid() {
    return uid;
  }

  /**
   * The backup status of the entity within the referenced backup group.
   *
   * @return {@link BackupConfigStatus}
   */
  public BackupConfigStatus getBackupStatus() {
    return backupStatus;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BackupGroupStatusDescriptor that = (BackupGroupStatusDescriptor) o;
    return Objects.equals(name, that.name) && Objects.equals(uid, that.uid)
        && backupStatus == that.backupStatus;
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, uid, backupStatus);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("name", name).add("uid", uid)
        .add("backupStatus", backupStatus).toString();
  }
}
