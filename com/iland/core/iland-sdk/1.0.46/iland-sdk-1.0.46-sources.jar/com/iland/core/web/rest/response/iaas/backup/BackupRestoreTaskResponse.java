/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Instant;
import java.util.Optional;
import java.util.Set;

import com.iland.cohesity.iaas.backups.common.enums.RestoreTaskStatus;
import com.iland.cohesity.iaas.backups.common.enums.RestoreTaskType;
import com.iland.core.web.rest.annotation.APIModel;

/**
 * BackupRestoreTaskResponse.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface BackupRestoreTaskResponse {

  /**
   * The user-specified name of the restore task.
   */
  String taskName();

  /**
   * The ID of the associated location.
   */
  String locationId();

  /**
   * The ID of the associated company.
   */
  String companyId();

  /**
   * The UUID of the associated Org.
   */
  String orgUuid();

  /**
   * The UUID of the associated vDC.
   */
  String vdcUuid();

  /**
   * The UID of the task.
   */
  String uid();

  /**
   * The start time of the task.
   */
  Instant startTime();

  /**
   * The end time of the task.
   */
  Optional<Instant> endTime();

  /**
   * The type of the task.
   */
  Optional<RestoreTaskType> type();

  /**
   * The status of the task.
   */
  RestoreTaskStatus status();

  /**
   * Error message associated with task, if applicable.
   */
  Optional<String> errorMessage();

  /**
   * The UID of the associated backup group.
   */
  String backupGroupUid();

  /**
   * The VM recovery options that were selected for the restore. Only applicable
   * if the type of task is {@link RestoreTaskType#RESTORE_VMS}.
   */
  Optional<VMRecoveryOptions> vmRecoveryOptions();

  /**
   * The objects that are being restored from.
   */
  Set<RestoreTaskObject> objects();

  /**
   * The states of the restore task objects.
   */
  Set<RestoreTaskObjectState> objectStates();

}
