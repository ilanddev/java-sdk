/*
 * Copyright (c) 2013 - 2024, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.vac;

import java.time.Instant;
import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * VAC Jobs Processed Object Response.
 *
 * @author <a href="mailto:Pablo.Buendia@1111systems.com">Pablo Buendia</a>
 */
@APIModel
public interface VacProcessedObjectResponse {

  /**
   * Internal uuid of the processed object.
   */
  String uuid();

  /**
   * Name of the processed object.
   */
  String name();

  /**
   * Job UID assigned to a backup job that created the latest restore point.
   */
  String jobUid();

  /**
   * UID assigned to a backup server
   */
  String backupServerUuid();

  /**
   * UID assigned to an organization.
   */
  String organizationUid();

  /**
   * Used space on protected virtual machine disks, in bytes
   */
  Optional<Long> usedSourceSize();

  /**
   * Total size of all restore points, in bytes
   */
  Optional<Long> totalRestorePointSize();

  /**
   * Size of the latest restore point, in bytes.
   */
  Optional<Long> latestRestorePointSize();

  /**
   * Number of restore points.
   */
  Optional<Integer> restorePoints();

  /**
   * Date and time of the latest restore point creation.
   */
  Optional<Instant> latestRestorePointDate();

}
