/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.sdk.connection;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.java_websocket.drafts.Draft_17;
import org.java_websocket.handshake.ServerHandshake;

import com.iland.core.web.rest.response.event.EventResponse;
import com.iland.core.web.rest.response.event.EventTypeResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.SerializationUtil;
import com.iland.core.web.rest.websocket.EventMessage;
import com.iland.core.web.rest.websocket.MessageType;
import com.iland.core.web.rest.websocket.TaskMessage;
import com.iland.core.web.sdk.util.EventFilter;
import com.iland.core.web.sdk.util.SocketSubscription;
import com.iland.core.web.sdk.util.TaskFilter;

/**
 * Web Socket Client.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
public class WebSocketClient {

  private final Logger log = LoggerFactory.getLogger(WebSocketClient.class);

  private final OAuthConnection connection;

  private final String companyId;

  private org.java_websocket.client.WebSocketClient webSocketClient;

  private static String AUTHORIZATION = "AUTHORIZATION";

  private static final String COMPANY_ID = "companyId=";

  private static String TYPE = "type";

  private static final int MAX_TIME_BETWEEN_RETRIES_IN_SECONDS = 60;

  private int numberOfRetries = 0;

  private static final Gson gson = SerializationUtil.getGson(null, false);

  private final List<Consumer<EventResponse>> eventConsumers =
      Collections.synchronizedList(new ArrayList<>());

  private final List<Consumer<TaskResponse>> taskConsumers =
      Collections.synchronizedList(new ArrayList<>());

  private final Object consumerListsLock = new Object();

  public WebSocketClient(final String companyId,
      final OAuthConnection connection) {
    this.connection = connection;
    this.companyId = companyId;
    this.webSocketClient = createWebSocketClient();
  }

  /**
   * Creates a new web socket client. If the socket is closed improperly, ie.
   * a lost connection, then we create a new web socket client.
   *
   * @return {@link org.java_websocket.client.WebSocketClient} web socket client
   */
  private org.java_websocket.client.WebSocketClient createWebSocketClient() {
    final String WEB_SOCKET_URI;
    if (connection.getApiHost().contains("https")) {
      WEB_SOCKET_URI = String.format("wss://%sevent-websocket",
          connection.getApiHost().replace("https://", ""));
    } else {
      WEB_SOCKET_URI = String.format("ws://%sevent-websocket",
          connection.getApiHost().replace("http://", ""));
    }
    URI eventUri = null;
    try {
      eventUri = new URI(WEB_SOCKET_URI);
    } catch (final URISyntaxException e) {
    }
    return new org.java_websocket.client.WebSocketClient(eventUri,
        new Draft_17(), null, 10000) {
      @Override
      public void onMessage(final String message) {
        numberOfRetries = 0;
        if (AUTHORIZATION.equals(message)) {
          send(String.format("%s%s,Bearer %s", COMPANY_ID, companyId,
              connection.getAuthorizationToken().orElseThrow(
                  () -> new IllegalStateException("Client not logged in."))));
        } else {
          final JsonObject messageObj =
              gson.fromJson(message, JsonObject.class);
          if (messageObj.has(TYPE)) {
            final MessageType type =
                MessageType.valueOf(messageObj.get(TYPE).getAsString());
            if (MessageType.EVENT.equals(type)) {
              final EventMessage eventMsg =
                  SerializationUtil.getGson(null, false)
                      .fromJson(message, EventMessage.class);
              final EventResponse event = eventMsg.getData();
              synchronized (eventConsumers) {
                for (final Consumer<EventResponse> eventConsumer : eventConsumers) {
                  try {
                    eventConsumer.accept(event);
                  } catch (final Throwable e) {
                    log.error(
                        "Error when consuming event={} with type={} {}.",
                        event.getUuid(), event.getType(), e.getMessage());
                  }
                }
              }
            }
            if (MessageType.TASK.equals(type)) {
              final TaskMessage taskMessage =
                  SerializationUtil.getGson(null, false)
                      .fromJson(message, TaskMessage.class);
              final TaskResponse task = taskMessage.getData();
              synchronized (taskConsumers) {
                for (final Consumer<TaskResponse> taskConsumer : taskConsumers) {
                  try {
                    taskConsumer.accept(task);
                  } catch (final Throwable e) {
                    log.error("Error when consuming task={} with type={} {}.",
                            task.getUuid(), task.getTaskType(),
                            e.getMessage());
                  }
                }
              }
            }
          }
        }
      }

      @Override
      public void onOpen(final ServerHandshake serverHandshake) {
      }

      @Override
      public void onClose(final int i, final String s, final boolean b) {
        if (i != 4000) {
          try {
            retryConnecting();
          } catch (final Throwable e) {
            log.error(
                "Error when trying to reconnect improperly closed web socket. {}",
                e.getMessage());
          }
        }
        if (i == 1008) {
          try {
            connection.refreshSession();
          } catch (final OAuthException e) {
            log.error("Error trying to refresh session for web socket. {}",
                    e.getMessage());
          }
        }
      }

      @Override
      public void onError(final Exception e) {
      }

    };
  }

  /**
   * This method is used to retry connecting the websocket after it's been improperly closed.
   */
  private void retryConnecting() {
    new Thread(() -> {
      final boolean interrupted = Thread.interrupted();
      try {
        int delayInSeconds = (1 << numberOfRetries);
        if (delayInSeconds > MAX_TIME_BETWEEN_RETRIES_IN_SECONDS) {
          delayInSeconds = MAX_TIME_BETWEEN_RETRIES_IN_SECONDS;
        } else {
          numberOfRetries++;
        }
        Thread.sleep(TimeUnit.SECONDS.toMillis(delayInSeconds));
      } catch (final InterruptedException ie) {
        log.warn(ie.getMessage());
        log.debug("", ie);
      }
      webSocketClient = createWebSocketClient();
      openSocketIfNotOpen();
    }, "ws connection retry thread").run();
  }

  /**
   * Checks to see if the socket is open and open it if not.
   */
  private void openSocketIfNotOpen() {
    synchronized (consumerListsLock) {
      if (!webSocketClient.isOpen()) {
        webSocketClient.connect();
      }
    }
  }

  /**
   * If there are no more consumers on this web socket then disconnect it.
   */
  private void checkIfNoMoreConsumersAndDisconnect() {
    synchronized (consumerListsLock) {
      if (eventConsumers.size() == 0 && taskConsumers.size() == 0) {
        webSocketClient.close(4000);
      }
    }
  }

  /**
   * Assign a event consumer to a web socket and get back a socket subscription.
   *
   * @param consumer {@link Consumer} of {@link EventResponse} callback function
   * @return {@link SocketSubscription} socket subscription
   */
  public SocketSubscription consumeEvents(
      final Consumer<EventResponse> consumer) {
    return consumeEvents(consumer, (EventFilter) null);
  }

  /**
   * Assign a event consumer to a web socket with filtering for event types
   * and get back a socket subscription.
   *
   * @param consumer   {@link Consumer} of {@link EventResponse} callback function
   * @param eventTypes {@link Set} of {@link EventTypeResponse} event type
   * @return {@link SocketSubscription} socket subscription
   */
  public SocketSubscription consumeEvents(
      final Consumer<EventResponse> consumer, final Set<EventTypeResponse> eventTypes) {
    final Consumer<EventResponse> consumerWithTypeFilter = eventResponse -> {
      if (eventTypes.contains(eventResponse.getType())) {
        consumer.accept(eventResponse);
      }
    };
    return consumeEvents(consumerWithTypeFilter, (EventFilter) null);
  }

  /**
   * Assign a event consumer to a web socket with custom filtering for events
   * and get back a socket subscription.
   *
   * @param consumer    {@link Consumer} of {@link EventResponse} callback function
   * @param eventFilter {@link EventFilter} event filter
   * @return {@link WebSocketClient} socket subscription
   */
  public SocketSubscription consumeEvents(
      final Consumer<EventResponse> consumer, final EventFilter eventFilter) {
    openSocketIfNotOpen();
    final Consumer<EventResponse> consumerWithFilter = eventResponse -> {
      if (eventFilter == null || eventFilter.test(eventResponse)) {
        consumer.accept(eventResponse);
      }
    };
    synchronized (consumerListsLock) {
      eventConsumers.add(consumerWithFilter);
      return () -> {
        synchronized (consumerListsLock) {
          eventConsumers.remove(consumerWithFilter);
          checkIfNoMoreConsumersAndDisconnect();
        }
      };
    }
  }

  /**
   * Assign a task consumer to a web socket and get back a socket subscription.
   *
   * @param consumer {@link Consumer} of {@link TaskResponse} callback function
   * @return {@link SocketSubscription} socket subscription
   */
  public SocketSubscription consumeTasks(
      final Consumer<TaskResponse> consumer) {
    return consumeTasks(consumer, null);
  }

  /**
   * Assign a task consumer to a web socket with custom filtering for tasks
   * and get back a socket subscription
   *
   * @param consumer   {@link Consumer} of {@link TaskResponse} callback function
   * @param taskFilter {@link Optional} of {@link TaskFilter} task filter
   * @return {@link SocketSubscription} socket subscription
   */
  public SocketSubscription consumeTasks(final Consumer<TaskResponse> consumer,
      final TaskFilter taskFilter) {
    openSocketIfNotOpen();
    final Consumer<TaskResponse> consumerWithFilter = task -> {
      if (taskFilter == null || taskFilter.test(task)) {
        consumer.accept(task);
      }
    };
    synchronized (consumerListsLock) {
      taskConsumers.add(consumerWithFilter);
      return () -> {
        synchronized (consumerListsLock) {
          taskConsumers.remove(consumerWithFilter);
          checkIfNoMoreConsumersAndDisconnect();
        }
      };
    }
  }

}
