/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Backup summary stats response model.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class BackupSummaryStats {

  /**
   * Specifies the number of runs that were canceled.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the number of runs that were canceled.")
  private final long numCanceledRuns;

  /**
   * Specifies the number of runs that failed to finish.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the number of runs that failed to finish.")
  private final long numFailedRuns;

  /**
   * Specifies the number of runs having SLA violations.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the number of runs having SLA violations.")
  private final long numSlaViolations;

  /**
   * Specifies the number of runs that finished successfully.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the number of runs that finished successfully.")
  private final long numSuccessfulRuns;

  /**
   * Specifies the number of runs that are still running.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the number of runs that are still running.")
  private final long numRunningRuns;

  /**
   * Specifies the average run time of all successful backup runs.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies the average run time of all successful backup runs.")
  private final Long averageRunTimeMillis;

  /**
   * Specifies the time taken for a fastest successful backup run so far.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies the time taken for a fastest successful backup run so far.")
  private final Long fastestRunTimeMillis;

  /**
   * Specifies the time taken for a slowest successful backup run so far.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies the time taken for a slowest successful backup run so far.")
  private final Long slowestRunTimeMillis;

  /**
   * Specifies the total amount of data read from the source (so far).
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the total amount of data read from the source (so far).")
  private final long totalBytesReadFromSource;

  /**
   * Specifies the size of the source object (such as a VM) protected by this
   * task on the primary storage after the snapshot is taken. The logical size
   * of the data on the source if the data is fully hydrated or expanded and not
   * reduced by change-block tracking, compression and deduplication.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired(
      "Specifies the size of the source object (such as a VM) protected by this "
          + "task on the primary storage after the snapshot is taken. The logical size "
          + "of the data on the source if the data is fully hydrated or expanded and not "
          + "reduced by change-block tracking, compression and deduplication.")
  private final long totalLogicalBackupSizeBytes;

  /**
   * Specifies the total amount of physical space used to store the protected
   * object after being reduced by change-block tracking, compression and
   * deduplication. For example, if the logical backup size is 1GB, but only 1MB
   * was used to store it, this field be equal to 1MB.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired(
      "Specifies the total amount of physical space used to store the protected "
          + "object after being reduced by change-block tracking, compression and "
          + "deduplication. For example, if the logical backup size is 1GB, but only 1MB "
          + "was used to store it, this field be equal to 1MB.")
  private final long totalPhysicalBackupSizeBytes;

  /**
   * Instantiates a new Backup summary stats.
   *
   * @param numCanceledRuns              the num canceled runs
   * @param numFailedRuns                the num failed runs
   * @param numSlaViolations             the num sla violations
   * @param numSuccessfulRuns            the num successful runs
   * @param numRunningRuns               the number of running runs
   * @param averageRunTimeMillis         the average run time millis
   * @param fastestRunTimeMillis         the fastest run time millis
   * @param slowestRunTimeMillis         the slowest run time millis
   * @param totalBytesReadFromSource     the total bytes read from source
   * @param totalLogicalBackupSizeBytes  the total logical backup size bytes
   * @param totalPhysicalBackupSizeBytes the total physical backup size bytes
   */
  public BackupSummaryStats(final long numCanceledRuns,
      final long numFailedRuns, final long numSlaViolations,
      final long numSuccessfulRuns, final long numRunningRuns,
      final Long averageRunTimeMillis, final Long fastestRunTimeMillis,
      final Long slowestRunTimeMillis, final long totalBytesReadFromSource,
      final long totalLogicalBackupSizeBytes,
      final long totalPhysicalBackupSizeBytes) {
    this.numCanceledRuns = numCanceledRuns;
    this.numFailedRuns = numFailedRuns;
    this.numSlaViolations = numSlaViolations;
    this.numSuccessfulRuns = numSuccessfulRuns;
    this.numRunningRuns = numRunningRuns;
    this.averageRunTimeMillis = averageRunTimeMillis;
    this.fastestRunTimeMillis = fastestRunTimeMillis;
    this.slowestRunTimeMillis = slowestRunTimeMillis;
    this.totalBytesReadFromSource = totalBytesReadFromSource;
    this.totalLogicalBackupSizeBytes = totalLogicalBackupSizeBytes;
    this.totalPhysicalBackupSizeBytes = totalPhysicalBackupSizeBytes;
  }

  /**
   * Gets num canceled runs.
   *
   * @return the num canceled runs
   */
  public long getNumCanceledRuns() {
    return numCanceledRuns;
  }

  /**
   * Gets num failed runs.
   *
   * @return the num failed runs
   */
  public long getNumFailedRuns() {
    return numFailedRuns;
  }

  /**
   * Gets num sla violations.
   *
   * @return the num sla violations
   */
  public long getNumSlaViolations() {
    return numSlaViolations;
  }

  /**
   * Gets num successful runs.
   *
   * @return the num successful runs
   */
  public long getNumSuccessfulRuns() {
    return numSuccessfulRuns;
  }

  /**
   * Gets the number of running runs.
   *
   * @return the number of running runs
   */
  public long getNumRunningRuns() {
    return numRunningRuns;
  }

  /**
   * Gets average run time millis.
   *
   * @return the average run time millis
   */
  public Long getAverageRunTimeMillis() {
    return averageRunTimeMillis;
  }

  /**
   * Gets fastest run time millis.
   *
   * @return the fastest run time millis
   */
  public Long getFastestRunTimeMillis() {
    return fastestRunTimeMillis;
  }

  /**
   * Gets slowest run time millis.
   *
   * @return the slowest run time millis
   */
  public Long getSlowestRunTimeMillis() {
    return slowestRunTimeMillis;
  }

  /**
   * Gets total bytes read from source.
   *
   * @return the total bytes read from source
   */
  public long getTotalBytesReadFromSource() {
    return totalBytesReadFromSource;
  }

  /**
   * Gets total logical backup size bytes.
   *
   * @return the total logical backup size bytes
   */
  public long getTotalLogicalBackupSizeBytes() {
    return totalLogicalBackupSizeBytes;
  }

  /**
   * Gets total physical backup size bytes.
   *
   * @return the total physical backup size bytes
   */
  public long getTotalPhysicalBackupSizeBytes() {
    return totalPhysicalBackupSizeBytes;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BackupSummaryStats that = (BackupSummaryStats) o;
    return numCanceledRuns == that.numCanceledRuns
        && numFailedRuns == that.numFailedRuns
        && numSlaViolations == that.numSlaViolations
        && numSuccessfulRuns == that.numSuccessfulRuns
        && numRunningRuns == that.numRunningRuns
        && totalBytesReadFromSource == that.totalBytesReadFromSource
        && totalLogicalBackupSizeBytes == that.totalLogicalBackupSizeBytes
        && totalPhysicalBackupSizeBytes == that.totalPhysicalBackupSizeBytes
        && Objects.equals(averageRunTimeMillis, that.averageRunTimeMillis)
        && Objects.equals(fastestRunTimeMillis, that.fastestRunTimeMillis)
        && Objects.equals(slowestRunTimeMillis, that.slowestRunTimeMillis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(numCanceledRuns, numFailedRuns, numSlaViolations,
        numSuccessfulRuns, numRunningRuns, averageRunTimeMillis,
        fastestRunTimeMillis, slowestRunTimeMillis, totalBytesReadFromSource,
        totalLogicalBackupSizeBytes, totalPhysicalBackupSizeBytes);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("numCanceledRuns", numCanceledRuns)
        .add("numFailedRuns", numFailedRuns)
        .add("numSlaViolations", numSlaViolations)
        .add("numSuccessfulRuns", numSuccessfulRuns)
        .add("numRunningRuns", numRunningRuns)
        .add("averageRunTimeMillis", averageRunTimeMillis)
        .add("fastestRunTimeMillis", fastestRunTimeMillis)
        .add("slowestRunTimeMillis", slowestRunTimeMillis)
        .add("totalBytesReadFromSource", totalBytesReadFromSource)
        .add("totalLogicalBackupSizeBytes", totalLogicalBackupSizeBytes)
        .add("totalPhysicalBackupSizeBytes", totalPhysicalBackupSizeBytes)
        .toString();
  }
}
