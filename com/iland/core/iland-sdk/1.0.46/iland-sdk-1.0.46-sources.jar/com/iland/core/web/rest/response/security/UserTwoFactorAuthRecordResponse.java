/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.security;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Two Factor Auth Record Response.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public class UserTwoFactorAuthRecordResponse implements Serializable {

  private static final long serialVersionUID = 1L;

  @JsonRequired("The username of the user.")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String username;

  @JsonRequired("The email address that is associated with the user account.")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String email;

  @JsonRequired("The full name of the user.")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String fullName;

  @JsonRequired("Whether two-factor authentication is configured on the account.")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean configured;

  /**
   * Instantiates a new UserTwoFactorAuthRecordResponse.
   *
   * @param username   The username of the user.
   * @param email      The email address that is associated with the user account.
   * @param fullName   The full name of the user.
   * @param configured Whether two-factor authentication is configured on the account.
   */
  public UserTwoFactorAuthRecordResponse(final String username, final String email,
      final String fullName, final boolean configured) {
    this.username = username;
    this.email = email;
    this.fullName = fullName;
    this.configured = configured;
  }

  /**
   * Gets username.
   *
   * @return username
   */
  public String getUsername() {
    return this.username;
  }

  /**
   * Gets email.
   *
   * @return email
   */
  public String getEmail() {
    return this.email;
  }

  /**
   * Gets fullName.
   *
   * @return fullName
   */
  public String getFullName() {
    return this.fullName;
  }

  /**
   * Indicates whether two-factor auth is configured on the account.
   *
   * @return configured
   */
  public boolean isConfigured() {
    return this.configured;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final UserTwoFactorAuthRecordResponse
        that = (UserTwoFactorAuthRecordResponse) o;
    return Objects.equals(username, that.username) && Objects
        .equals(email, that.email) && Objects.equals(fullName, that.fullName)
        && Objects.equals(configured, that.configured);
  }

  @Override
  public int hashCode() {
    return Objects.hash(username, email, fullName, configured);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("username", username)
        .add("email", email).add("fullName", fullName)
        .add("configured", configured).toString();
  }
}
