/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vpg;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Failover Report Details Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class FailoverReportDetailsResponse implements Serializable {

  private static final long serialVersionUID = -7130945290405474855L;


  public enum Status {

    FETCHING,

    GENERATING,

    READY,

    ERROR

  }


  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String taskUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private LocalDateTime taskCompleteTimestamp;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Status status;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private FailoverReportDataResponse data;

  /**
   * Instantiates a new failover report details.
   *
   * @param locationId
   * @param taskUuid              the task uuid
   * @param taskCompleteTimestamp the task complete timestamp
   * @param status                the status
   * @param data
   */
  public FailoverReportDetailsResponse(final String locationId,
      final String taskUuid, final LocalDateTime taskCompleteTimestamp,
      final Status status, final FailoverReportDataResponse data) {
    this.locationId = locationId;
    this.taskUuid = taskUuid;
    this.taskCompleteTimestamp = taskCompleteTimestamp;
    this.status = status;
    this.data = data;
  }

  /**
   * Gets the task uuid.
   *
   * @return the task uuid
   */
  public String getTaskUuid() {
    return taskUuid;
  }

  /**
   * Gets the task complete timestamp.
   *
   * @return the task complete timestamp
   */
  public LocalDateTime getTaskCompleteTimestamp() {
    return taskCompleteTimestamp;
  }

  /**
   * Gets data.
   *
   * @return the data
   */
  public FailoverReportDataResponse getData() {
    return data;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public Status getStatus() {
    return status;
  }

  /**
   * Gets location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  @Override
  public String toString() {
    return String.format(
        "FailoverReportDetails [taskUuid=%s, taskCompleteTimestamp=%s, status=%s]",
        taskUuid, taskCompleteTimestamp, status);
  }

}
