/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.objectstorage;

import java.util.List;

import com.iland.core.web.rest.response.common.ObjectPagedListResponse;
import com.iland.core.web.rest.response.common.ObjectPagingParams;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * TenantsResponse.
 *
 * @author <a href=“mailto:cjsnyder@iland.com”>Collin Snyder</a>
 */
@APIDoc
public final class TenantsResponse
    extends ObjectPagedListResponse<TenantResponse, ObjectPagingParams> {

  private static final long serialVersionUID = 757518452890949860L;

  /**
   * Instantiates a new tenants response.
   *
   * @param data                  the data
   * @param currentPageParameters the current page params
   * @param nextPageParameters    the next page params
   * @param totalRecords          the total records
   */
  public TenantsResponse(final List<TenantResponse> data,
      final ObjectPagingParams currentPageParameters,
      final ObjectPagingParams nextPageParameters, final long totalRecords) {
    super(data, currentPageParameters, nextPageParameters, totalRecords);
  }
}
