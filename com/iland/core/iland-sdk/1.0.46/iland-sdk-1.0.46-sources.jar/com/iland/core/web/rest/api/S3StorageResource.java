/*
 * Copyright (c) 2013 - 2024, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import java.io.InputStream;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.aws.s3.query.api.AwsS3AlertsApi;
import com.iland.core.aws.s3.query.api.AwsS3BillingApi;
import com.iland.core.aws.s3.query.api.AwsS3CustomerApi;
import com.iland.core.aws.s3.query.api.AwsS3GlobalAlertsApi;
import com.iland.core.aws.s3.query.api.AwsS3UsageApi;
import com.iland.core.services.monocle.api.MonocleAwsBucketService;
import com.iland.core.services.monocle.api.MonocleAwsKeyManagementServiceApi;
import com.iland.core.web.rest.annotations.SecureProductRef;
import com.iland.core.web.rest.request.aws.AwsAccountCreateUpdateRequest;
import com.iland.core.web.rest.request.aws.AwsS3IncreaseStorageRequest;
import com.iland.core.web.rest.request.monocle.AwsAccountKeyRequest;
import com.iland.core.web.rest.request.monocle.AwsAccountS3BucketRequest;
import com.iland.core.web.rest.response.common.SetResponse;
import com.iland.core.web.rest.response.monocle.AwsAccountCreationResponse;
import com.iland.core.web.rest.response.monocle.AwsAccountKeyResponse;
import com.iland.core.web.rest.response.monocle.AwsAccountKeySetResponse;
import com.iland.core.web.rest.response.monocle.S3BucketSetResponse;
import com.iland.core.web.rest.response.monocle.S3IncreaseStoragePriceInfoResponse;
import com.iland.core.web.rest.s3.request.AwsAlertUuid;
import com.iland.core.web.rest.s3.request.AwsDeleteAlertRequest;
import com.iland.core.web.rest.s3.request.AwsEditGlobalAlertExclusionRequest;
import com.iland.core.web.rest.s3.request.AwsEditThresholdAlertRequest;
import com.iland.core.web.rest.s3.request.AwsStorageConfigAlertRequest;
import com.iland.core.web.rest.s3.request.AwsStorageConfigEditRequest;
import com.iland.core.web.rest.s3.request.AwsThresholdAlertRequest;
import com.iland.core.web.rest.s3.response.AwsAccountResponse;
import com.iland.core.web.rest.s3.response.AwsAccountSetResponse;
import com.iland.core.web.rest.s3.response.AwsAccountStorageSetResponse;
import com.iland.core.web.rest.s3.response.AwsAlertResponse;
import com.iland.core.web.rest.s3.response.AwsBillingSummarySetResponse;
import com.iland.core.web.rest.s3.response.AwsContractUsageDayMapResponse;
import com.iland.core.web.rest.s3.response.AwsGlobalAlertExclusionResponse;
import com.iland.core.web.rest.s3.response.AwsMonthTotalUsageByClassForAccountSetResponse;
import com.iland.core.web.rest.s3.response.AwsMonthTotalUsageByClassForContractSetResponse;
import com.iland.core.web.rest.s3.response.AwsStorageClassResponse;
import com.iland.core.web.rest.s3.response.S3ContractResponse;
import com.iland.core.web.rest.s3.response.S3ContractSetResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;
import com.iland.core.web.rest.swagger.annotation.processor.Required;

/**
 * Resource endpoints to get AWS S3 billing and usage info.
 */
@APIProperties(name = "AWS S3 Storage Resource")
@Path("/s3-storage")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface S3StorageResource extends AwsS3AlertsApi, AwsS3BillingApi, AwsS3CustomerApi,
    AwsS3GlobalAlertsApi, AwsS3UsageApi,
    MonocleAwsKeyManagementServiceApi, MonocleAwsBucketService {

  /**
   * Get the AWS S3 contracts given the company id.
   *
   * Status may be ACTIVATED or CANCELLED.
   *
   * @param companyId the company id
   * @return contracts for the company
   */
  @GET
  @Path("/{companyId}/contracts")
  S3ContractSetResponse getContractsForCompany(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      String companyId);

  /**
   * Get a specified S3 contract by its unique UUID.
   *
   * Status may be ACTIVATED or CANCELLED.
   *
   * @param companyId    The ID of the company associated with the contract.
   * @param contractUuid The unique UUID of the contract to retrieve.
   * @return A S3 contract.
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}")
  S3ContractResponse getContractByUuid(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid);

  /**
   * Gets an AWS account by its ID within a specific contract.
   *
   * @param companyId    The ID of the company associated with the contract.
   * @param contractUuid The unique UUID of the contract that contains the account.
   * @param accountId    The ID of the AWS account to retrieve.
   * @return An AWS account.
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}")
  AwsAccountResponse getAccountById(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("accountId") String accountId);

  /**
   * Get the AWS accounts for the given contract uuid and company id.
   *
   * @param companyId    The contract's company id
   * @param contractUuid The contract uuid
   * @return a set of accounts
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/accounts")
  AwsAccountSetResponse getAccountsForContract(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid);

    /**
     * Create AWS account for a given contract uuid, company id and request body.
     *
     * @param companyId                 The contract's company id
     * @param contractUuid              The contract uuid
     * @param awsAccountCreateUpdateRequest aws account creation request
     * @return aws account creation response
     */
    @POST
    @Path("/{companyId}/contracts/{contractUuid}/accounts")
    AwsAccountCreationResponse createAwsAccount(
        @SecureProductRef(Permission.MANAGE_S3_STORAGE_DATA)
        @PathParam("companyId")
        String companyId, @PathParam("contractUuid") String contractUuid,
        AwsAccountCreateUpdateRequest awsAccountCreateUpdateRequest);

    /**
     * Update the name of an AWS account.
     *
     * @param companyId                     The ID of the company associated with the contract.
     * @param contractUuid                  The unique UUID of the contract that contains the account.
     * @param accountId                     The ID of the AWS account to retrieve.
     * @param awsAccountCreateUpdateRequest aws account update request
     */
    @PUT
    @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}")
    void updateAwsAccountName(
        @SecureProductRef(Permission.MANAGE_S3_STORAGE_DATA)
        @PathParam("companyId")
        String companyId, @PathParam("contractUuid") String contractUuid,
        @PathParam("accountId") String accountId,
        AwsAccountCreateUpdateRequest awsAccountCreateUpdateRequest);

  /**
   * Get the monthly storage usage for a given contract.
   *
   * Year month id is in the format YYYYMM, ex: 202409
   * If no year month is provided then it's defaulted to the current month.
   *
   * @param companyId    The contract's company id
   * @param contractUuid The contract id
   * @param regionCode   The contract's region id
   * @param yearMonthId  The month and year period
   * @return a set of usage totals in bytes and storage class
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/regionCode/{regionCode}/month-usage")
  AwsMonthTotalUsageByClassForContractSetResponse getMonthlyStorageUsageByContract(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("regionCode") String regionCode,
      @Required @QueryParam("yearMonthId") Integer yearMonthId);

  /**
   * Get the monthly storage usage for a given account.
   *
   * Year month id is in the format YYYYMM, ex: 202409
   * If no year month is provided then it's defaulted to the current month.
   *
   * @param companyId    The contract's company id
   * @param contractUuid The contract id
   * @param regionCode   The contract's region code
   * @param accountId    The account id
   * @param yearMonthId  The month and year period
   * @return a set of usage totals in bytes and storage class
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/regionCode/{regionCode}/account/{accountId}/month-usage")
  AwsMonthTotalUsageByClassForAccountSetResponse getMonthlyStorageUsageByAccount(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("regionCode") String regionCode,
      @PathParam("accountId") String accountId,
      @Required @QueryParam("yearMonthId") Integer yearMonthId);

  /**
   * Get the daily storage usage for a given contract over a range of time.
   *
   * Start and end date are in epoch milli.
   *
   * @param companyId    The contract's company id
   * @param contractUuid The contract uuid
   * @param regionCode   The contract's region code
   * @param start        start date
   * @param end          end date
   * @return a set of daily storage usage totals in bytes and the storage class.
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/regionCode/{regionCode}/day-usage")
  AwsContractUsageDayMapResponse getDailyUsageForContractByTime(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("regionCode") String regionCode,
      @QueryParam("start") Long start,
      @QueryParam("end") Long end);

  /**
   * Get the monthly storage used in bytes for the accounts of a given contract.
   *
   * If no year month is provided then it's defaulted to the current month.
   * Default page is 0 and default limit is 25.
   *
   * @param companyId    company id
   * @param contractUuid contract uuid
   * @param regionCode   region code
   * @param yearMonthId  year month id
   * @param page         page
   * @param limit        limit
   * @return a set of account ids to their storage used for the given year and month
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/regionCode/{regionCode}/account-usage")
  AwsAccountStorageSetResponse getMonthlyAccountsUsageByContract(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("regionCode") String regionCode,
      @Required @QueryParam("yearMonthId") Integer yearMonthId,
      @QueryParam("page") Integer page, @QueryParam("limit") Integer limit);

  /**
   * Get the daily storage usage in bytes for the given account for a time period.
   *
   * @param companyId    company id
   * @param contractUuid contract uuid
   * @param regionCode   region code
   * @param accountId    account id
   * @param start        start
   * @param end          end
   * @return a map of storage class ids to a list of samples which have the time and storage used in bytes
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/regionCode/{regionCode}/account/{accountId}/day-usage")
  AwsContractUsageDayMapResponse getDailyUsageForAccountByTime(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("regionCode") String regionCode,
      @PathParam("accountId") String accountId,
      @QueryParam("start") Long start,
      @QueryParam("end") Long end);

  /**
   * Get the monthly billing summaries given a contract, region, company and range of dates.
   *
   * @param companyId    company id
   * @param contractUuid contract uuid
   * @param regionCode   region code
   * @param yearMonthIdStart  year month id start- YYYYMM format
   * @param yearMonthIdEnd  year month id end - YYYYMM format
   * @return a set of billing summaries for the given time range
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/regionCode/{regionCode}/monthly-bill")
  AwsBillingSummarySetResponse getMonthlyBillingSummary(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_BILLING)
      @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("regionCode") String regionCode,
      @QueryParam("yearMonthIdStart") Integer yearMonthIdStart,
      @QueryParam("yearMonthIdEnd") Integer yearMonthIdEnd);

  /**
   * Get the daily billing summaries for the given time range.
   *
   * These are summaries of the bill day by day given a start and end date in epoch milli.
   *
   * @param companyId    company id
   * @param contractUuid contract uuid
   * @param regionCode   region code
   * @param start        start
   * @param end          end
   * @return daily billing summaries for the given time range
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/regionCode/{regionCode}/day-bill")
  AwsBillingSummarySetResponse getDailyBillingSummary(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_BILLING)
      @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("regionCode") String regionCode,
      @QueryParam("start") Long start,
      @QueryParam("end") Long end);

  /**
   * Get the monthly storage used CSV.
   *
   * Optional parameters are the accountId and the storageOnly.
   * If you pass in an accountId you will only get the storage usage data pertaining to that account.
   * If you pass storageOnly to true then you will get only the storage usage line items.
   * The following fields are currently returned: aws_offer_name, year_month_id, aws_account_id,
   * product_family, product_grouping, aws_sku,
   * contract_number, is_estimate, month,
   * price_description, usage_total, year,
   * aws_usage_month, company_id, contract_uuid,
   * region_code
   *
   * @param companyId    company id
   * @param contractUuid contract uuid
   * @param regionCode   region code
   * @param accountId    account id
   * @param yearMonthId  year month id
   * @return a monthly storage CSV
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/regionCode/{regionCode}/monthly-storage-csv")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream getMonthlyStorageCSV(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_BILLING)
      @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("regionCode") String regionCode,
      @QueryParam("accountId") String accountId,
      @Required @QueryParam("yearMonthId") Integer yearMonthId);

  /**
   * Get the billing report CSV.
   *
   * @param companyId    company id
   * @param contractUuid contract uuid
   * @param regionCode   region code
   * @param yearMonthId  year month id
   * @return billing report CSV
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/regionCode/{regionCode}/bill-csv")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream getBillingReportCSV(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_BILLING)
      @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("regionCode") String regionCode,
      @Required @QueryParam("yearMonthId") Integer yearMonthId);


  /**
   * Create a storage alert for a given company, region and user.
   *
   * @param companyId  company id.
   * @param request request body containing config to create the alert
   * @return the details for the created alert.
   */
  @POST
  @Path("/{companyId}/storage-alert")
  AwsAlertResponse createStorageAlert(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      AwsThresholdAlertRequest request
  );

  /**
   * Create a billing alert for a given company, region and user.
   *
   * @param companyId  company id.
   * @param request request body containing config to create the alert
   * @return the details for the created alert.
   */
  @POST
  @Path("/{companyId}/billing-alert")
  AwsAlertResponse createBillingAlert(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_BILLING)
      @PathParam("companyId") String companyId,
      AwsThresholdAlertRequest request
  );

  /**
   * Create a storage config alert for a given company, region and user.
   *
   * @param companyId  company id.
   * @param request request body containing config to create the alert
   * @return the details for the created alert.
   */
  @POST
  @Path("/{companyId}/storage-config-alert")
  AwsAlertResponse createStorageConfigAlert(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      AwsStorageConfigAlertRequest request
  );

  /**
   * Get all alerts for a company.
   *
   * @param companyId  company id.
   * @return the alerts for the company.
   */
  @GET
  @Path("/{companyId}/alerts/{contractUuid}")
  SetResponse<AwsAlertResponse> getAlerts(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      @PathParam("contractUuid") String contractUuid
  );
  /**
   * Get all storage classes.
   *
   * @return the existent storage classes.
   */
  @GET
  @Path("/storage-classes")
  SetResponse<AwsStorageClassResponse> getStorageClasses();

  /**
   * Delete an alert for a company, given it's uuid.
   *
   * @param companyId  company id.
   * @param request the alert uuids to be deleted
   */
  @DELETE
  @Path("/{companyId}/alert")
  void deleteAlert(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_BILLING)
      @PathParam("companyId") String companyId,
      AwsDeleteAlertRequest request
  );

  /**
   * Edit a billing alert for a company, given it's uuid.
   *
   * @param companyId company id.
   * @param alertUuid the alert uuid.
   * @param request request body containing config to edit the alert.
   */
  @PUT
  @Path("/{companyId}/alerts/{alertUuid}/billing-alert")
  void editBillingAlert(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_BILLING)
      @PathParam("companyId") String companyId,
      @PathParam("alertUuid") AwsAlertUuid alertUuid,
      AwsEditThresholdAlertRequest request
  );

  /**
   * Edit a storage alert for a company, given it's uuid.
   *
   * @param companyId company id.
   * @param alertUuid the alert uuid.
   * @param request request body containing config to edit the alert.
   */
  @PUT
  @Path("/{companyId}/alerts/{alertUuid}/storage-alert")
  void editStorageAlert(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      @PathParam("alertUuid") AwsAlertUuid alertUuid,
      AwsEditThresholdAlertRequest request
  );

  /**
   * Edit a storage config alert for a company, given it's uuid.
   *
   * @param companyId company id.
   * @param alertUuid the alert uuid.
   * @param request request body containing config to edit the alert.
   */
  @PUT
  @Path("/{companyId}/alerts/{alertUuid}/storage-config-alert")
  void editStorageConfigAlert(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      @PathParam("alertUuid") AwsAlertUuid alertUuid,
      AwsStorageConfigEditRequest request
  );

  /**
   * Retrieve the enabled alert types for a given user.
   *
   * @param companyId the company id
   */
  @GET
  @Path("/{companyId}/global-alerts")
  AwsGlobalAlertExclusionResponse getGlobalAlertExclusions(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId
  );

  /**
   * Add or remove a global alert exclusion based on exclude property.
   * If the exclusion is already configured and exclude is true, no changes are applied.
   * Same applies for the inverse case.
   *
   * @param companyId the company id
   * @param request the request body containing the alert type and exclusion flag
   */
  @POST
  @Path("/{companyId}/global-alerts")
  void editGlobalAlertExclusion(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      AwsEditGlobalAlertExclusionRequest request
  );

  /**
   * Gets the account's keys.
   *
   * @param companyId    The account's company id
   * @param contractUuid The account's contract id
   * @param accountId    The account id
   * @return A list of the account's keys.
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}/keys")
  AwsAccountKeySetResponse getAwsAccountKeys(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("accountId") String accountId);

  /**
   * Generates a new key for this account. An account can only have up to 5 keys
   * and if hits that limit, it will return an error. A description can be
   * sent, but if not it will be autogenerated.
   *
   * @param companyId    The account's company id
   * @param contractUuid The account's contract id
   * @param accountId    The account id
   * @param keyRequest   The key request. Only the description can be set. If
   *                     nothing gets set it will get autogenerated.
   * @return A new key. The secret key field will be populated.
   */
  @POST
  @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}/keys")
  AwsAccountKeyResponse generateAwsAccountKeys(
      @SecureProductRef(Permission.MANAGE_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      @PathParam("contractUuid") String contractUuid,
      @PathParam("accountId") String accountId,
      AwsAccountKeyRequest keyRequest);

  /**
   * Updates the key's description.
   *
   * @param companyId    The account's company id
   * @param contractUuid The account's contract id
   * @param accountId    The account id
   * @param accessKey    The key id.
   * @param keyRequest   The key request. Only the description can be set. If
   *                     nothing gets set it will get autogenerated.
   */
  @PUT
  @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}/keys/{accessKey}/description")
  void updateAwsAccountKey(@SecureProductRef(Permission.MANAGE_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      @PathParam("contractUuid") String contractUuid,
      @PathParam("accountId") String accountId,
      @PathParam("accessKey") String accessKey,
      AwsAccountKeyRequest keyRequest);

  /**
   * Enables a key.
   *
   * @param companyId    The account's company id
   * @param contractUuid The account's contract id
   * @param accountId    The account id
   * @param accessKey    The key id.
   */
  @PUT
  @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}/keys/{accessKey}/enable")
  void enableAwsAccountKey(@SecureProductRef(Permission.MANAGE_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      @PathParam("contractUuid") String contractUuid,
      @PathParam("accountId") String accountId,
      @PathParam("accessKey") String accessKey);

  /**
   * Disables a key
   *
   * @param companyId    The account's company id
   * @param contractUuid The account's contract id
   * @param accountId    The account id
   * @param accessKey    The key id.
   */
  @PUT
  @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}/keys/{accessKey}/disable")
  void disableAwsAccountKey(@SecureProductRef(Permission.MANAGE_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      @PathParam("contractUuid") String contractUuid,
      @PathParam("accountId") String accountId,
      @PathParam("accessKey") String accessKey);

  /**
   * Rotates a key. The key sent in the request won't show up. The new key will
   * have a new access and secret key.
   *
   * @param companyId    The account's company id
   * @param contractUuid The account's contract id
   * @param accountId    The account id
   * @param accessKey    The key id.
   * @return The newly rotated key. It's secret key will be populated.
   */
  @PUT
  @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}/keys/{accessKey}/rotate")
  AwsAccountKeyResponse rotateAwsAccountKey(
      @SecureProductRef(Permission.MANAGE_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      @PathParam("contractUuid") String contractUuid,
      @PathParam("accountId") String accountId,
      @PathParam("accessKey") String accessKey);

  /**
   * Deletes a key.
   *
   * @param companyId    The account's company id
   * @param contractUuid The account's contract id
   * @param accountId    The account id
   * @param accessKey    The key id.
   */
  @DELETE
  @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}/keys/{accessKey}")
  void deleteAwsAccountKey(@SecureProductRef(Permission.MANAGE_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      @PathParam("contractUuid") String contractUuid,
      @PathParam("accountId") String accountId,
      @PathParam("accessKey") String accessKey);


  /**
   * Returns S3 buckets for the specified AWS account.
   * Supports pagination, sorting, and filtering.
   * Supported sort values use bucket fields, for example name or usage_bytes.
   * Prefix sort with '-' for descending order.
   * Filters use key=value format.
   * Supported operators in value are eq, ne, gt, lt, and like.
   *
   * @param companyId company ID associated with the AWS account
   * @param contractUuid contract UUID associated with the AWS account
   * @param accountId AWS account ID
   * @param limit maximum buckets to return (default 200)
   * @param offset zero-based pagination offset (default 0)
   * @param sort optional sort field
   * @param filters optional filter list
   * @return {@link S3BucketSetResponse}
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}/s3-buckets")
  S3BucketSetResponse getS3BucketsForAccount(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      String companyId, @PathParam("contractUuid") String contractUuid,
      @PathParam("accountId") String accountId,
      @QueryParam("limit") @DefaultValue("200") int limit,
      @QueryParam("offset") @DefaultValue("0") int offset,
      @QueryParam("sort") String sort,
      @QueryParam("filter") List<String> filters);

  /**
   * Exports all S3 buckets for the specified account as a CSV file.
   *
   * @param companyId company ID associated with the AWS account
   * @param contractUuid contract UUID associated with the AWS account
   * @param accountId AWS account ID
   * @return an {@link InputStream} containing the CSV export of all buckets for
   *     the specified account
   */
  @GET
  @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}/s3-buckets/export")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream exportS3BucketsForAccount(
      @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA) @PathParam("companyId")
      final String companyId,
      @PathParam("contractUuid") final String contractUuid,
      @PathParam("accountId") final String accountId);

  /**
   * Creates a new S3 bucket for the specified AWS account.
   *
   * @param companyId                 The AWS Account's company id
   * @param contractUuid              The AWS Account's contract id
   * @param accountId                 The AWS Account Id associated with the new bucket.
   * @param awsAccountS3BucketRequest The bucket's name (must follow AWS rules) and whether object lock is enabled on the new bucket.
   */
  @POST
  @Path("/{companyId}/contracts/{contractUuid}/accounts/{accountId}/s3-buckets")
  void createS3BucketForAccount(
      @SecureProductRef(Permission.MANAGE_S3_STORAGE_DATA)
      @PathParam("companyId") String companyId,
      @PathParam("contractUuid") String contractUuid,
      @PathParam("accountId") String accountId,
      AwsAccountS3BucketRequest awsAccountS3BucketRequest);

    /**
     * Get the information about a S3 price increase. Included in the response
     * are the following:
     * - currency
     * - price per unit
     * - total price
     *
     * @param companyId     The AWS Account's company id
     * @param contractUuid  The AWS contract id
     * @param quantityInTib quantity to increase in TiB.
     * @return information about the S3 price increase given the quantity
     */
    @GET
    @Path("/{companyId}/contracts/{contractUuid}/s3-increase-info/")
    S3IncreaseStoragePriceInfoResponse getS3PriceIncreaseCalculation(
        @SecureProductRef(Permission.VIEW_S3_STORAGE_DATA)
        @PathParam("companyId") String companyId,
        @PathParam("contractUuid") String contractUuid,
        @Required @QueryParam("quantity") int quantityInTib);

    /**
     * Increase S3 storage for a given company and their contract, given a quantity
     * in TiB.
     *
     * @param companyId                   The AWS Account's company id
     * @param contractUuid                The AWS contract id
     * @param awsS3IncreaseStorageRequest request for quantity to increase in TiB.
     */
    @POST
    @Path("/{companyId}/contracts/{contractUuid}/s3-increase-storage/")
    void increaseS3Storage(
        @SecureProductRef(Permission.MANAGE_S3_STORAGE_DATA)
        @PathParam("companyId") String companyId,
        @PathParam("contractUuid") String contractUuid,
        AwsS3IncreaseStorageRequest awsS3IncreaseStorageRequest);

}

