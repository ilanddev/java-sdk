/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vappnetwork;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Network Static Route Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappNetworkStaticRouteResponse implements Serializable {

  private static final long serialVersionUID = -3396972690098983587L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String network;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String nextHopIp;

  public VappNetworkStaticRouteResponse(final String name, final String network,
      final String nextHopIp) {
    this.name = name;
    this.network = network;
    this.nextHopIp = nextHopIp;
  }

  /**
   * Gets the name of the static route.
   *
   * @return {@link String} name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the network.
   *
   * @return {@link String} network
   */
  public String getNetwork() {
    return network;
  }

  /**
   * Gets the next hop IP address for the static route.
   *
   * @return {@link String} next hop ip address
   */
  public String getNextHopIP() {
    return nextHopIp;
  }

}
