/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.event;

import java.util.List;

import com.iland.core.web.rest.response.common.PagedListResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * AWS Event List Response.
 */
@APIDoc
public class AwsEventListResponse
    extends PagedListResponse<AwsEventResponse, EventFilterParams> {

  /**
   * Instantiates a new AWS Event list response.
   *
   * @param data              the data
   * @param currentParameters the current parameters
   * @param totalRecords      the total records
   */
  public AwsEventListResponse(final List<AwsEventResponse> data,
      final EventFilterParams currentParameters,
      final EventFilterParams nextParameters, final long totalRecords) {
    super(data, currentParameters, nextParameters, totalRecords);
  }

  @Override
  public String toString() {
    return "AwsEventListResponse{" + "currentPageParameters="
        + currentPageParameters + ", nextPageParameters=" + nextPageParameters
        + ", totalRecords=" + totalRecords + ", data=" + data + '}';
  }

}
