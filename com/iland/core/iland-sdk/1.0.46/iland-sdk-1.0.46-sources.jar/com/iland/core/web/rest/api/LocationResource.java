/*
 * Copyright (c) 2013 - 2017, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.api;

import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.web.rest.request.status.ServiceStatusRequest;
import com.iland.core.web.rest.request.vac.BaCompanyContractUpgradeRequest;
import com.iland.core.web.rest.response.billing.CurrencyCodeResponse;
import com.iland.core.web.rest.response.catalog.CatalogListResponse;
import com.iland.core.web.rest.response.company.VacCompanyQuotaStatusResponse;
import com.iland.core.web.rest.response.location.LocationListResponse;
import com.iland.core.web.rest.response.location.VmConfigurationLimitsResponse;
import com.iland.core.web.rest.response.media.MediaListResponse;
import com.iland.core.web.rest.response.status.StatusResponse;
import com.iland.core.web.rest.response.vac.VacContractListResponse;
import com.iland.core.web.rest.response.vapptemplate.VappTemplateListResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Location ReST resource.
 *
 * @author <a href="mailto:csnydert@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Locations")
@Path("/locations")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface LocationResource {

  /**
   * Get the public catalogs for a data center location.
   *
   * @param locationId the location ID
   * @return list of public catalogs
   */
  @GET
  @Path("/{location}/public-catalogs")
  CatalogListResponse getPublicCatalogs(
      @PathParam("location") String locationId);

  /**
   * Get the public vapp templates for a data center location.
   *
   * @param locationId the location ID
   * @return list of public vapp templates
   */
  @GET
  @Path("/{location}/public-vapp-templates")
  VappTemplateListResponse getPublicVappTemplates(
      @PathParam("location") String locationId);

  /**
   * Get the public media for a data center location.
   *
   * @param locationId the location ID
   * @return list of public media
   */
  @GET
  @Path("/{location}/public-media")
  MediaListResponse getPublicMedia(@PathParam("location") String locationId);

  /**
   * Given a location, get the services status.
   *
   * @param locationId a valid location identifier.
   * @param service    a {@link ServiceStatusRequest}
   * @return service statuses
   */
  @GET
  @Path("/{locationId}/status")
  StatusResponse getStatus(@PathParam("locationId") String locationId,
      @QueryParam("service") ServiceStatusRequest service);

  /**
   * Given a location, get the CPU, memory, and disk limits.
   *
   * @param locationId location id
   * @return cpu, memory and disk limits
   */
  @GET
  @Path("/{locationId}/vm-configuration-limits")
  VmConfigurationLimitsResponse getVmConfigurationLimits(
      @PathParam("locationId") String locationId);

  /**
   * Get the VAC quota status of a company which includes total storage quota,
   * used storage quota and the contracted storage quota values.
   *
   * @param companyId  company id
   * @param locationId location id
   * @return vac quota status response
   */
  @GET
  @Path("/{locationId}/{companyId}/vac-storage-status")
  VacCompanyQuotaStatusResponse getVacQuotaStatus(
      @PathParam("locationId") String locationId,
      @PathParam("companyId") String companyId);

  /**
   * Get the VAC billing currency code for the given company id and location id.
   *
   * @param locationId location id
   * @param companyId  company id
   * @return vac billing currency code
   */
  @GET
  @Path("/{locationId}/{companyId}/vac-currency-code")
  CurrencyCodeResponse getVacBillingCurrencyCode(
      @PathParam("locationId") String locationId,
      @PathParam("companyId") String companyId);

  /**
   * Get the VAC contracts given the location id and company id.
   *
   * @param locationId location id
   * @param companyId  company id
   * @return vac contract list response
   */
  @GET
  @Path("/{locationId}/{companyId}/vac-contracts")
  VacContractListResponse getVacContractsForCompany(
      @PathParam("locationId") String locationId,
      @PathParam("companyId") String companyId);

  /**
   * Request a VAC storage upgrade for given a company and it's location.
   *
   * @param locationId    location id id
   * @param companyId     company id
   * @param updateRequest update request
   */
  @POST
  @Path("/{locationId}/{companyId}/request-upgrade-contract")
  void requestContractUpgrade(@PathParam("locationId") String locationId,
      @PathParam("companyId") String companyId,
      BaCompanyContractUpgradeRequest updateRequest);

  /**
   * Get all the locations.
   *
   * @return a list of all locations
   */
  @GET
  @Path("/")
  LocationListResponse getLocations();

  /**
   * Get location names.
   *
   * @return a map of all locations
   */
  @GET
  @Path("/names")
  Map<String, String> getLocationsNames();

}
