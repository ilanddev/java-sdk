/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.monocle;

/**
 * Support Ticket Status Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public enum SupportTicketStatusResponse {

  WAITING_ON_ILAND,

  COMPLETED,

  WAITING_ON_CUSTOMER,

  WAITING_ON_VENDOR,

  PENDING_COMPLETION,

  SCHEDULED_WITH_CUSTOMER,

  NEW,

  CANCELLED,

  FEATURE_REQUESTED,

}
