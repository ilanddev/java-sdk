/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the "LICENSE.txt" file that accompanied this software. Any inquiries
 *  concerning the scope or enforceability of the license should be addressed
 *  to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 */

package com.iland.core.web.rest.response.iaas.backup;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * DiskBlock.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface DiskBlock {

  /**
   * Specifies the length of the block in bytes.
   */
  long lengthBytes();

  /**
   * Specifies the offset of the block (in bytes) from the beginning of the
   * containing object such as a physical disk or a virtual disk file.
   */
  long offsetBytes();

}
