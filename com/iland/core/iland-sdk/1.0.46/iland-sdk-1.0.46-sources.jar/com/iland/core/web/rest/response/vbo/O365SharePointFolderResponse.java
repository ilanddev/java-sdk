/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.vbo.O365SharePointFolderType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Office 365 VBO SharePoint Folder response.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365SharePointFolderResponse implements Serializable {

  private static final long serialVersionUID = 7865038305308522572L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The type of the backed up SharePoint folder.")
  private final O365SharePointFolderType type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The Veeam native ID of the backed up SharePoint folder.")
  private final String id;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The name of the backed up SharePoint folder.")
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The user, which created the folder.")
  private final String createdBy;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The date and time when the folder was created.")
  private final Instant creationTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The user, which performed the last modifications to the folder.")
  private final String modifiedBy;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The date and time when the folder was modified.")
  private final Instant modificationTime;

  public O365SharePointFolderResponse(final O365SharePointFolderType type,
      final String id, final String name, final String createdBy,
      final Instant creationTime, final String modifiedBy,
      final Instant modificationTime) {
    this.type = type;
    this.id = id;
    this.name = name;
    this.createdBy = createdBy;
    this.creationTime = creationTime;
    this.modifiedBy = modifiedBy;
    this.modificationTime = modificationTime;
  }

  /**
   * Returns the type of the backed up SharePoint folder.
   *
   * @return one of {@link O365SharePointFolderType}
   */
  public O365SharePointFolderType getType() {
    return type;
  }

  /**
   * Returns the ID of the backed up SharePoint folder.
   *
   * @return a Veeam native ID
   */
  public String getId() {
    return id;
  }

  /**
   * Returns the name of the backed up SharePoint folder.
   *
   * @return the name of the backed up SharePoint folder
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the user, which created the folder.
   *
   * @return the user, which created the folder
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * Returns date and time when the folder was created.
   *
   * @return UTC {@link Instant}
   */
  public Instant getCreationTime() {
    return creationTime;
  }

  /**
   * Returns the user, which performed the last modifications to the folder.
   *
   * @return the user, which performed the last modifications to the folder
   */
  public String getModifiedBy() {
    return modifiedBy;
  }

  /**
   * Returns date and time when the folder was modified.
   *
   * @return UTC {@link Instant}
   */
  public Instant getModificationTime() {
    return modificationTime;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final O365SharePointFolderResponse that = (O365SharePointFolderResponse) o;
    return type == that.type && Objects.equals(id, that.id) && Objects
        .equals(name, that.name) && Objects.equals(createdBy, that.createdBy)
        && Objects.equals(creationTime, that.creationTime) && Objects
        .equals(modifiedBy, that.modifiedBy) && Objects
        .equals(modificationTime, that.modificationTime);
  }

  @Override
  public int hashCode() {
    return Objects.hash(type, id, name, createdBy, creationTime, modifiedBy,
        modificationTime);
  }

}
