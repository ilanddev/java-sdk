/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscan;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Network Scan Launch Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public final class LaunchResponse {

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String scanUuid;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String error;

	public LaunchResponse(final String scanUuid, final String error) {
		this.scanUuid = scanUuid;
		this.error = error;
	}

	/**
	 * Get the uuid of the started scan.
	 *
	 * @return {@link String} scan uuid
	 */
	public String getScanUuid() {
		return scanUuid;
	}

	/**
	 * Get the error.
	 *
	 * @return error message
	 */
	public String getError() {
		return error;
	}

}
