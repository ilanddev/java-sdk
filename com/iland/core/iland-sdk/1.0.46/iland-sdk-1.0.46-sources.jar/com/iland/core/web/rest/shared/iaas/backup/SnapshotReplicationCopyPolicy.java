/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.policies.api.enums.ReplicationPeriodicity;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Snapshot Replication Copy Policy.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class SnapshotReplicationCopyPolicy implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Specifies if Snapshots are copied from the first completely successful Group
   * Run or the first partially successful Group Run occurring at the start of the
   * replication schedule. If true, Snapshots are copied from the first Group Run
   * occurring at the start of the replication schedule, even if first Group Run
   * was not completely successful i.e. Snapshots were not captured for all
   * Objects in the Group. If false, Snapshots are copied from the first Group Run
   * occurring at the start of the replication schedule that was completely
   * successful i.e. Snapshots for all the Objects in the Group were successfully
   * captured.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies if Snapshots are copied from the first completely "
      + "successful Group Run or the first partially successful Group Run "
      + "occurring at the start of the replication schedule. If true, "
      + "Snapshots are copied from the first Group Run occurring at the start "
      + "of the replication schedule, even if first Group Run was not "
      + "completely successful i.e. Snapshots were not captured for all "
      + "Objects in the Group. If false, Snapshots are copied from the first "
      + "Group Run occurring at the start of the replication schedule that was "
      + "completely successful i.e. Snapshots for all the Objects in the Group "
      + "were successfully captured.")
  private final boolean copyPartial;

  /**
   * Specifies the number of days to retain copied Snapshots on the target.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the number of days to retain copied Snapshots on "
      + "the target.")
  private final long daysToKeep;

  /**
   * Specifies a factor to multiply the periodicity by, to determine the copy
   * schedule. For example if set to 2 and the periodicity is hourly, then
   * Snapshots from the first eligible Group Run for every 2 hour period is
   * copied.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies a factor to multiply the periodicity by, to "
      + "determine the copy schedule. For example if set to 2 and the "
      + "periodicity is hourly, then Snapshots from the first eligible "
      + "Group Run for every 2 hour period is copied.")
  private final int multiplier;

  /**
   * Specifies the frequency that Snapshots should be copied to the specified
   * target. Used in combination with multipiler.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the frequency that Snapshots should be copied to "
      + "the specified target. Used in combination with multipiler.")
  private final ReplicationPeriodicity periodicity;

  /**
   * Specifies the replication target to copy the Snapshots to.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the replication target to copy the Snapshots to.")
  private final ReplicationTargetSettings target;

  /**
   * Instantiates a new Snapshot replication copy policy.
   *
   * @param copyPartial the copy partial
   * @param daysToKeep  the days to keep
   * @param multiplier  the multiplier
   * @param periodicity the periodicity
   * @param target      the target
   */
  public SnapshotReplicationCopyPolicy(final boolean copyPartial,
      final long daysToKeep, final int multiplier,
      final ReplicationPeriodicity periodicity,
      final ReplicationTargetSettings target) {
    this.copyPartial = copyPartial;
    this.daysToKeep = daysToKeep;
    this.multiplier = multiplier;
    this.periodicity = periodicity;
    this.target = target;
  }

  /**
   * Is copy partial boolean.
   *
   * @return the boolean
   */
  public boolean isCopyPartial() {
    return copyPartial;
  }

  /**
   * Gets days to keep.
   *
   * @return the days to keep
   */
  public long getDaysToKeep() {
    return daysToKeep;
  }

  /**
   * Gets multiplier.
   *
   * @return the multiplier
   */
  public int getMultiplier() {
    return multiplier;
  }

  /**
   * Gets periodicity.
   *
   * @return the periodicity
   */
  public ReplicationPeriodicity getPeriodicity() {
    return periodicity;
  }

  /**
   * Gets target.
   *
   * @return the target
   */
  public ReplicationTargetSettings getTarget() {
    return target;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final SnapshotReplicationCopyPolicy that =
        (SnapshotReplicationCopyPolicy) o;
    return copyPartial == that.copyPartial && daysToKeep == that.daysToKeep
        && multiplier == that.multiplier && periodicity == that.periodicity
        && Objects.equals(target, that.target);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(copyPartial, daysToKeep, multiplier, periodicity, target);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("copyPartial", copyPartial)
        .add("daysToKeep", daysToKeep).add("multiplier", multiplier)
        .add("periodicity", periodicity).add("target", target).toString();
  }
}
