/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.IpRangeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vm Network Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VmNetworkResponse implements Serializable {

  private static final long serialVersionUID = 6981319311219579314L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean vappNetwork;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String fenceMode;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean deleted;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<IpRangeResponse> ipRanges;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String gateway;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String netmask;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String dns1;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String dns2;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String dnsSuffix;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean enabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean inherited;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String parentNetworkName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String parentNetworkUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String parentEntityUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean shared;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String edgeUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String routerExternalIp;

  public VmNetworkResponse(final String uuid, final String name,
      final String description, final boolean vappNetwork,
      final String fenceMode, final boolean deleted,
      final List<IpRangeResponse> ipRanges, final String gateway,
      final String netmask, final String dns1, final String dns2,
      final String dnsSuffix, final boolean enabled, final boolean inherited,
      final String parentNetworkName, final String parentEntityUuid,
      final boolean shared, final String edgeUuid,
      final String routerExternalIp, final String parentNetworkUuid) {
    this.uuid = uuid;
    this.name = name;
    this.description = description;
    this.vappNetwork = vappNetwork;
    this.fenceMode = fenceMode;
    this.deleted = deleted;
    this.ipRanges = ipRanges;
    this.gateway = gateway;
    this.netmask = netmask;
    this.dns1 = dns1;
    this.dns2 = dns2;
    this.dnsSuffix = dnsSuffix;
    this.enabled = enabled;
    this.inherited = inherited;
    this.parentNetworkName = parentNetworkName;
    this.parentEntityUuid = parentEntityUuid;
    this.shared = shared;
    this.edgeUuid = edgeUuid;
    this.routerExternalIp = routerExternalIp;
    this.parentNetworkUuid = parentNetworkUuid;
  }

  /**
   * Return whether the network is a Vapp Network.
   *
   * @return whether network is a vapp network
   */
  public boolean isVappNetwork() {
    return vappNetwork;
  }

  /**
   * Return the networks uuid.
   *
   * @return {@link String} network uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Return the Network Name.
   *
   * @return {@link String} network name
   */
  public String getName() {
    return name;
  }

  /**
   * Return the Network Description.
   *
   * @return {@link String} network description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Return the network fencing mode.
   *
   * @return {@link String} fence mode
   */
  public String getFenceMode() {
    return fenceMode;
  }

  /**
   * Return whether the network has been deleted.
   *
   * @return whether the network was deleted
   */
  public boolean isDeleted() {
    return deleted;
  }

  /**
   * Return the IP Ranges for this network.
   *
   * @return {@link List} of {@link IpRangeResponse} ip ranges
   */
  public List<IpRangeResponse> getIpRanges() {
    return ipRanges;
  }

  /**
   * Get the gateway address.
   *
   * @return {@link String} gateway address
   */
  public String getGateway() {
    return gateway;
  }

  /**
   * Get the netmask.
   *
   * @return {@link String} netmask
   */
  public String getNetmask() {
    return netmask;
  }

  /**
   * Get Dns 1.
   *
   * @return {@link String} dns 1
   */
  public String getDns1() {
    return dns1;
  }

  /**
   * Get Dns 2.
   *
   * @return {@link String} dns 2
   */
  public String getDns2() {
    return dns2;
  }

  /**
   * Get Dns Suffix.
   *
   * @return {@link String} dns suffix
   */
  public String getDnsSuffix() {
    return dnsSuffix;
  }

  /**
   * Whether network is enabled.
   *
   * @return boolean enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Whether Ip Scopes are inherited.
   *
   * @return boolean inherited
   */
  public boolean isInherited() {
    return inherited;
  }

  /**
   * Return the parent network (or null) if there is no parent network.
   * <p>
   * NOTE: This will always return null for Org Vdc Networks as they do not have
   * parent networks.
   *
   * @return {@link String} parent network name
   */
  public String getParentNetworkName() {
    return parentNetworkName;
  }

  /**
   * Returns the parent entity UUID for this network. That is, a vApp UUID for a
   * vApp Network or a vDC UUID for an Org-vDC Network.
   *
   * @return {@link String} entity UUID
   */
  public String getParentEntityUuid() {
    return parentEntityUuid;
  }

  /**
   * Indicates whether the network is shared with other vDCs in the same org.
   *
   * @return boolean value
   */
  public boolean isShared() {
    return shared;
  }

  /**
   * Gets the UUID of the edge gateway that this network is routed through. The
   * field will be null if this is not a NAT routed network.
   *
   * @return {@link String} edge uuid
   */
  public String getEdgeUuid() {
    return edgeUuid;
  }

  /**
   * Gets the external IP of the router if this is a vApp network with static
   * routing. Will be null otherwise.
   *
   * @return {@link String} IP address
   */
  public String getRouterExternalIp() {
    return routerExternalIp;
  }

  /**
   * Gets the UUID of this network's parent network or null if this network does
   * not have a parent network. The parent network of an Org-vDC network is an
   * external network and the parent network of a vApp network is an Org-vDC
   * network.
   *
   * @return {@link String}
   */
  public String getParentNetworkUuid() {
    return parentNetworkUuid;
  }

  /**
   * Indicates whether this network has a parent network.
   *
   * @return boolean value
   */
  public boolean hasParentNetwork() {
    return parentNetworkUuid != null;
  }

}
