/*
 * Copyright (c) 2013 - 2022, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vac.BaJobListResponse;
import com.iland.core.web.rest.response.vac.BaJobResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * VAC Job Resource
 *
 * @author <a href="mailto:smittal@iland.com">Sachin Mittal</a>
 */
@APIProperties(name = "Users")
@Path("/vac-jobs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface VacJobResource {

  /**
   * Get a VAC job given a VAC company uuid and the job's uuid.
   *
   * @param jobUuid the job UUID of vac company
   * @return a list of vac jobs for the given company
   */
  @GET
  @Path("/{jobUuid}")
  BaJobResponse getVacJob(@SecureEntityRef(Permission.VIEW_ILAND_BACKUP_JOB)
  @PathParam("jobUuid") String jobUuid);

  /**
   * Enable a VAC job.
   *
   * @param jobUuid the job UUID of vac job
   * @return a core task
   */
  @POST
  @Path("/{jobUuid}/action/enable")
  TaskResponse enableVacJob(
      @SecureEntityRef(Permission.MANAGE_ILAND_BACKUP_TENANT_JOB)
      @PathParam("jobUuid") String jobUuid);

  /**
   * Disable a VAC job.
   *
   * @param jobUuid the job UUID of vac job
   * @return a core task
   */
  @POST
  @Path("/{jobUuid}/action/disable")
  TaskResponse disableVacJob(
      @SecureEntityRef(Permission.MANAGE_ILAND_BACKUP_TENANT_JOB)
      @PathParam("jobUuid") String jobUuid);

  /**
   * Start a VAC job.
   *
   * @param jobUuid the job UUID of vac job
   * @return a message indicating that the VAC job was started
   */
  @POST
  @Path("/{jobUuid}/action/start")
  TaskResponse startVacJob(
      @SecureEntityRef(Permission.MANAGE_ILAND_BACKUP_TENANT_JOB)
      @PathParam("jobUuid") String jobUuid);

  /**
   * Stop a VAC job.
   *
   * @param jobUuid the job UUID of vac job
   * @return a message indicating that the VAC job was stopped
   */
  @POST
  @Path("/{jobUuid}/action/stop")
  TaskResponse stopVacJob(
      @SecureEntityRef(Permission.MANAGE_ILAND_BACKUP_TENANT_JOB)
      @PathParam("jobUuid") String jobUuid);

  /**
   * Retry a VAC job.
   *
   * @param jobUuid the job UUID of vac job
   * @return a message indicating that the VAC job was retried
   */
  @POST
  @Path("/{jobUuid}/action/retry")
  TaskResponse retryVacJob(
      @SecureEntityRef(Permission.MANAGE_ILAND_BACKUP_TENANT_JOB)
      @PathParam("jobUuid") String jobUuid);

  /**
   * Get the history for a VAC job given a start and end date.
   *
   * If start or end is not passed then it defaults start to a week ago and sets end as current time.
   *
   * @param jobUuid the job UUID of vac job
   * @param start   the start of the vac job history
   * @param end     the end of the vac job history
   * @return the vac job's history
   */
  @GET
  @Path("/{jobUuid}/history")
  BaJobListResponse getVacJobHistory(
      @SecureEntityRef(Permission.VIEW_ILAND_BACKUP_JOB)
      @PathParam("jobUuid") String jobUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end);
}
