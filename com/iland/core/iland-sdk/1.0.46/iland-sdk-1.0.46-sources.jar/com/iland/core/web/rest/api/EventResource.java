/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.core.web.rest.response.event.AwsEventListResponse;
import com.iland.core.web.rest.response.event.EventFilterParams;
import com.iland.core.web.rest.response.event.EventListResponse;
import com.iland.core.web.rest.response.event.EventResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Event REST resource V1.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Events")
@Path("/events")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface EventResource {

  /**
   * Allows a client to perform dynamic event queries.
   *
   * @return the list of queried events
   */
  @GET
  EventListResponse getEvents(@BeanParam EventFilterParams filters);

  /**
   * Allows a client to perform dynamic AWS event queries.
   *
   * @return the list of queried events
   */
  @GET
  @Path("/aws")
  AwsEventListResponse getAwsEvents(@BeanParam EventFilterParams filters);

  /**
   * Get an event by its UUID.
   *
   * @param uuid the UUID of the event to retrieve
   * @return the event
   */
  @GET
  @Path("/{uuid}")
  EventResponse getEvent(@PathParam("uuid") String uuid);

}
