/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.performance;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Perf Sample Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class PerfSampleResponse implements Serializable {

  private static final long serialVersionUID = -5695719615399962858L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant time;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Long value;

  public PerfSampleResponse(final Instant time, final Long value) {
    this.time = time;
    this.value = value;
  }

  /**
   * Returns the time at which the sample was collected.
   *
   * @return {@link Instant} instance.
   */
  public Instant getTime() {
    return time;
  }

  /**
   * Returns the actual value collected.
   *
   * @return {@link Long} instance.
   */
  public Long getValue() {
    return value;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final PerfSampleResponse that = (PerfSampleResponse) o;

    if (!time.equals(that.time))
      return false;
    return value.equals(that.value);
  }

  @Override
  public int hashCode() {
    int result = time.hashCode();
    result = 31 * result + value.hashCode();
    return result;
  }

  @Override
  public String toString() {
    return "PerfSampleResponse{" + "timestamp=" + time + ", value=" + value
        + '}';
  }

}
