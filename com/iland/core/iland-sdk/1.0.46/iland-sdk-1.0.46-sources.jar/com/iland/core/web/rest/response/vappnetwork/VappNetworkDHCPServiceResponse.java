/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vappnetwork;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.IpRangeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Dhcp Service Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappNetworkDHCPServiceResponse implements Serializable {

  private static final long serialVersionUID = 2981938358752800268L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vappUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String networkName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean enabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private IpRangeResponse ipRange;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int defaultLeaseTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int maxLeaseTime;

  public VappNetworkDHCPServiceResponse(final String vappUuid,
      final String networkName, final boolean enabled,
      final IpRangeResponse ipRange, final int defaultLeaseTime,
      final int maxLeaseTime) {
    this.vappUuid = vappUuid;
    this.networkName = networkName;
    this.enabled = enabled;
    this.ipRange = ipRange;
    this.defaultLeaseTime = defaultLeaseTime;
    this.maxLeaseTime = maxLeaseTime;
  }

  /**
   * Gets the UUID of the vApp that this DHCP service is associated with.
   *
   * @return {@link String} vapp uuid
   */
  public String getVappUuid() {
    return vappUuid;
  }

  /**
   * Gets the name of the vApp network the DHCP service pertains to.
   *
   * @return {@link String} network name
   */
  public String getNetworkName() {
    return networkName;
  }

  /**
   * Indicates whether the DHCP service is enabled.
   *
   * @return boolean value indicating whether the DHCP service is enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Get the Ip Range associated with the DHCP service.
   *
   * @return {@link IpRangeResponse} instance
   */
  public IpRangeResponse getIpRange() {
    return ipRange;
  }

  /**
   * Get the default lease time.
   *
   * @return default lease time
   */
  public int getDefaultLeaseTime() {
    return defaultLeaseTime;
  }

  /**
   * Get the max lease time.
   *
   * @return max lease time
   */
  public int getMaxLeaseTime() {
    return maxLeaseTime;
  }


}
