/*
 * Copyright (c) 2013 - 2025, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import com.iland.core.web.rest.annotations.SecureProductRef;
import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.license.api.LicenseApi;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.response.license.VeeamLicenseInfoResponse;
import com.iland.core.web.rest.response.license.VeeamLicenseServerUsageSetResponse;
import com.iland.core.web.rest.response.license.VeeamLicenseSetResponse;
import com.iland.core.web.rest.response.license.VeeamLicenseType;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

@APIProperties(name = "License")
@Path("/license")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface LicenseResource extends LicenseApi {

    /**
     * Get the veeam licenses for a specified company and type.
     *
     * @param companyId        {@link String} company id
     * @param veeamLicenseType {@link VeeamLicenseType} type
     * @param offset           {@link Integer} offset, default is 5
     * @param limit            {@link Integer} limit, default is 0
     * @return a set of licenses
     */
    @Path("/{companyId}/{type}")
    @GET
    VeeamLicenseSetResponse getCompanyVeeamLicensesForType(
        @SecureProductRef(Permission.VIEW_LICENSE_PRODUCT)
        @PathParam("companyId") String companyId,
        @PathParam("type") VeeamLicenseType veeamLicenseType,
        @QueryParam("offset") Integer offset,
        @QueryParam("limit") Integer limit);

    /**
     * Get the veeam license server usage for a specified company, license and hostname.
     *
     * @param companyId   {@link String} company id
     * @param licenseUuid {@link String} license uuid
     * @param hostname    {@link String} hostname
     * @return a set of license server usages
     */
    @Path("/{companyId}/{licenseUuid}/{hostname}")
    @GET
    VeeamLicenseServerUsageSetResponse getVeeamLicenseServerUsage(
        @PathParam("companyId") String companyId,
        @SecureEntityRef(Permission.VIEW_LICENSE)
        @PathParam("licenseUuid") String licenseUuid,
        @PathParam("hostname") String hostname);


    /**
     * Get information about the given company's Veeam licenses and when their
     * contract end date is.
     * If a contract is ending within the month then the value is expiring.
     *
     * @param companyId {@link String} companyId
     * @return number of active, expired,expiring Veeam licenses
     */
    @Path("/{companyId}/veeam-license-info")
    @GET
    VeeamLicenseInfoResponse getVeeamLicenseInfo(
        @SecureProductRef(Permission.VIEW_LICENSE_PRODUCT)
        @PathParam("companyId") String companyId);


    /**
     * Download a Veeam rental license given it's uuid.
     *
     * @param companyId   {@link String} company id
     * @param licenseUuid {@link String} license uuid
     * @return veeam rental license
     */
    @Path("/{companyId}/{licenseUuid}/download")
    @GET
    InputStream downloadVeeamRentalLicense(
        @PathParam("companyId") String companyId,
        @SecureEntityRef(Permission.DOWNLOAD_LICENSE)
        @PathParam("licenseUuid") String licenseUuid);

}
