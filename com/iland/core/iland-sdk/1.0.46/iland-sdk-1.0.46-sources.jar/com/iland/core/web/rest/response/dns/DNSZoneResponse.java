/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.dns;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * DNS Zone Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class DNSZoneResponse implements Serializable {

  private static final long serialVersionUID = -607341535977128803L;

  private static final String RECORD_TTL = "record_ttl";

  private static final String ENABLE_DNS_SEC = "enable_dns_sec";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int id;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String name;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int resourceId;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int serial;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int refresh;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int retry;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int expire;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int minimum;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String soa;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String tags;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String ttl;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(ENABLE_DNS_SEC)
  private boolean enableDNSSEC;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean autoCheck;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int recordId;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String recordHost;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private DNSRecordTypeResponse recordType;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String recordValue;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String recordDescription;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(RECORD_TTL)
  private String recordTTL;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int recordOrdering;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String recordErrors;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean userCanCreate;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean userCanDelete;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean userCanUpdate;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int unpagedRows;

  public DNSZoneResponse(final int id, final String name, final int resourceId,
      final int serial, final int refresh, final int retry, final int expire,
      final int minimum, final String soa, final String tags, final String ttl,
      final boolean enableDNSSEC, final boolean autoCheck, final int recordId,
      final String recordHost, final DNSRecordTypeResponse recordType,
      final String recordValue, final String recordDescription,
      final String recordTTL, final int recordOrdering,
      final String recordErrors, final boolean userCanCreate,
      final boolean userCanDelete, final boolean userCanUpdate,
      final int unpagedRows) {
    this.id = id;
    this.name = name;
    this.resourceId = resourceId;
    this.serial = serial;
    this.refresh = refresh;
    this.retry = retry;
    this.expire = expire;
    this.minimum = minimum;
    this.soa = soa;
    this.tags = tags;
    this.ttl = ttl;
    this.enableDNSSEC = enableDNSSEC;
    this.autoCheck = autoCheck;
    this.recordId = recordId;
    this.recordHost = recordHost;
    this.recordType = recordType;
    this.recordValue = recordValue;
    this.recordDescription = recordDescription;
    this.recordTTL = recordTTL;
    this.recordOrdering = recordOrdering;
    this.recordErrors = recordErrors;
    this.userCanCreate = userCanCreate;
    this.userCanDelete = userCanDelete;
    this.userCanUpdate = userCanUpdate;
    this.unpagedRows = unpagedRows;
  }

  /**
   * Get the zone ID.
   *
   * @return zone id
   */
  public int getId() {
    return id;
  }

  /**
   * Get the zone name.
   *
   * @return zone name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the zone resource ID.
   *
   * @return zone resource ID
   */
  public int getResourceId() {
    return resourceId;
  }

  /**
   * Get the serial.
   *
   * @return serial
   */
  public int getSerial() {
    return serial;
  }

  /**
   * Get the zone refresh.
   *
   * @return zone refresh
   */
  public int getRefresh() {
    return refresh;
  }

  /**
   * Get the zone retry.
   *
   * @return retry
   */
  public int getRetry() {
    return retry;
  }

  /**
   * Get the zone expire.
   *
   * @return expire
   */
  public int getExpire() {
    return expire;
  }

  /**
   * Get the zone minimum.
   *
   * @return minimum
   */
  public int getMinimum() {
    return minimum;
  }

  /**
   * Get the zone SOA.
   *
   * @return SOA
   */
  public String getSoa() {
    return soa;
  }

  /**
   * Get tags for the zone.
   *
   * @return zone tags
   */
  public String getTags() {
    return tags;
  }

  /**
   * Get the zone TTL.
   *
   * @return TTL
   */
  public String getTTL() {
    return ttl;
  }

  /**
   * Is the zone DNS SEC enabled.
   *
   * @return DNS SEC enabled
   */
  public boolean isEnableDNSSEC() {
    return enableDNSSEC;
  }

  /**
   * Is auto-check.
   *
   * @return auto check
   */
  public boolean isAutoCheck() {
    return autoCheck;
  }

  /**
   * Get the record ID.
   *
   * @return record ID
   */
  public int getRecordId() {
    return recordId;
  }

  /**
   * Get the record host.
   *
   * @return record host
   */
  public String getRecordHost() {
    return recordHost;
  }

  /**
   * Get the record type.
   *
   * @return record type
   */
  public DNSRecordTypeResponse getRecordType() {
    return recordType;
  }

  /**
   * Get the record value.
   *
   * @return record value
   */
  public String getRecordValue() {
    return recordValue;
  }

  /**
   * Get the record description
   *
   * @return record description
   */
  public String getRecordDescription() {
    return recordDescription;
  }

  /**
   * Get the record TTL.
   *
   * @return record TTL
   */
  public String getRecordTTL() {
    return recordTTL;
  }

  /**
   * Get the record ordering.
   *
   * @return record ordering
   */
  public int getRecordOrdering() {
    return recordOrdering;
  }

  /**
   * Get record errors.
   *
   * @return record errors
   */
  public String getRecordErrors() {
    return recordErrors;
  }

  /**
   * Is user can create.
   *
   * @return user can create
   */
  public boolean isUserCanCreate() {
    return userCanCreate;
  }

  /**
   * Is user can delete.
   *
   * @return user can delete
   */
  public boolean isUserCanDelete() {
    return userCanDelete;
  }

  /**
   * Get unpaged rows.
   *
   * @return unpaged rows
   */
  public int getUnpagedRows() {
    return unpagedRows;
  }

}
