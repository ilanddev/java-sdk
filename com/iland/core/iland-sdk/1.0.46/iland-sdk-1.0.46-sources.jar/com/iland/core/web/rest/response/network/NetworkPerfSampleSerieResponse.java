/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.network;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Network Perf Sample Serie Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class NetworkPerfSampleSerieResponse implements Serializable {

  private static final long serialVersionUID = -6918274990441137168L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String summary;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int interval;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String group;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String unit;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<NetworkPerfSampleResponse> samples;

  public NetworkPerfSampleSerieResponse(final String summary,
      final int interval, final String group, final String name,
      final String type, final String unit,
      final List<NetworkPerfSampleResponse> samples) {
    this.summary = summary;
    this.interval = interval;
    this.group = group;
    this.name = name;
    this.type = type;
    this.unit = unit;
    this.samples = samples;
  }

  /**
   * Returns the interval in seconds for which performance statistics were
   * collected.
   *
   * @return an {@link Integer} value.
   */
  public int getInterval() {
    return interval;
  }

  /**
   * Returns the list of samples within the interval.
   *
   * @return a {@link List} of {@link NetworkPerfSampleResponse} object.
   */
  public List<NetworkPerfSampleResponse> getSamples() {
    return samples;
  }

  /**
   * Returns serie summary.
   *
   * @return a {@link String}
   */
  public String getSummary() {
    return summary;
  }

  /**
   * Returns the performance counter group.
   *
   * @return one of {@link String}
   */
  public String getGroup() {
    return group;
  }

  /**
   * Returns the name of the counter.
   *
   * @return a {@link String} instance.
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the performance counter rollup type.
   *
   * @return one of {@link String}
   */
  public String getType() {
    return type;
  }

  /**
   * Returns the unit for the values of the performance counter.
   *
   * @return a {@link String}
   */
  public String getUnit() {
    return unit;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final NetworkPerfSampleSerieResponse that =
        (NetworkPerfSampleSerieResponse) o;

    if (interval != that.interval)
      return false;
    if (summary != null ? !summary.equals(that.summary) : that.summary != null)
      return false;
    if (group != null ? !group.equals(that.group) : that.group != null)
      return false;
    if (name != null ? !name.equals(that.name) : that.name != null)
      return false;
    if (type != null ? !type.equals(that.type) : that.type != null)
      return false;
    if (unit != null ? !unit.equals(that.unit) : that.unit != null)
      return false;
    return samples != null ?
        samples.equals(that.samples) :
        that.samples == null;
  }

  @Override
  public int hashCode() {
    int result = summary != null ? summary.hashCode() : 0;
    result = 31 * result + interval;
    result = 31 * result + (group != null ? group.hashCode() : 0);
    result = 31 * result + (name != null ? name.hashCode() : 0);
    result = 31 * result + (type != null ? type.hashCode() : 0);
    result = 31 * result + (unit != null ? unit.hashCode() : 0);
    result = 31 * result + (samples != null ? samples.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "NetworkPerfSampleSerieResponse{" + "summary='" + summary + '\''
        + ", interval=" + interval + ", group='" + group + '\'' + ", name='"
        + name + '\'' + ", type='" + type + '\'' + ", unit='" + unit + '\''
        + ", samples=" + samples + '}';
  }

}
