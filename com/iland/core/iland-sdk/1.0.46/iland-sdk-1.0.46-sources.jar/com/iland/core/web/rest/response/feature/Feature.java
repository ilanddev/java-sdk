/*
 * Copyright (c) 2013 - 2024, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.feature;

import java.util.Optional;
import java.util.UUID;

import org.immutables.value.Value;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * Represents a frontend feature that can be toggled on or off which will
 * affect the behavior of the frontend application. Features can optionally
 * be scoped to specific users.
 */
@APIModel
public interface Feature {
  /**
   * The UUID of the feature.
   */
  UUID uuid();

  /**
   * The name of the feature.
   */
  String name();

  /**
   * The optional description of the feature.
   */
  Optional<String> description();

  /**
   * Whether the feature is currently enabled.
   */
  @Value.Default
  default Boolean enabled() {
    return false;
  }
}
