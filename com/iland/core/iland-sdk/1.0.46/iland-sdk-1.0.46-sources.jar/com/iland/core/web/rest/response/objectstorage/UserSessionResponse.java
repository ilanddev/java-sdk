/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.objectstorage;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * UserSessionResponse.
 *
 * @author <a href=“mailto:cjsnyder@iland.com”>Collin Snyder</a>
 */
@APIModel
public interface UserSessionResponse {

  /**
   * The unique ID of the associated tenant.
   */
  String tenantId();

  /**
   * The S3 access key.
   */
  String accessKey();

  /**
   * The S3 secret key.
   */
  String secretKey();

  /**
   * The S3 session token.
   */
  String sessionToken();

  /**
   * The date/time that the temporary session will expire as a unix timestamp
   * in milliseconds.
   */
  Long expirationTime();

}
