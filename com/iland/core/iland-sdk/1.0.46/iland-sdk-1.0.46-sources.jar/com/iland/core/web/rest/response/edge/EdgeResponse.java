/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.edge;

import java.io.Serializable;
import java.time.Instant;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.shared.nsx.EdgeGatewayBackingType;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vcd Edge Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class EdgeResponse extends EntityResponse implements Serializable {

  private static final long serialVersionUID = 5995944383107290698L;

  private static final String VCLOUD_HREF = "vcloud_href";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Integer status;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String vdcUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String orgUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Set<EdgeInterfaceResponse> interfaces;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean backwardCompatibilityMode;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String gatewayBackingConfig;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Boolean highAvailabilityEnabled;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Boolean defaultDnsRelayRoute;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String locationId;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String description;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCLOUD_HREF)
  private String vCloudHref;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private EdgeGatewayBackingType edgeGatewayBackingType;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final Boolean vdcGroupScoped;

  public EdgeResponse(final String uuid, final String companyId,
      final String name, final boolean deleted, final Instant deletedDate,
      final Instant updatedDate, final Integer status, final String vdcUuid,
      final String orgUuid, final Set<EdgeInterfaceResponse> interfaces,
      final boolean backwardCompatibilityMode,
      final String gatewayBackingConfig, final Boolean highAvailabilityEnabled,
      final Boolean defaultDnsRelayRoute, final String locationId,
      final String description, final String vCloudHref,
      final EdgeGatewayBackingType edgeGatewayBackingType,
      final Boolean vdcGroupScoped) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.status = status;
    this.vdcUuid = vdcUuid;
    this.orgUuid = orgUuid;
    this.interfaces = interfaces;
    this.backwardCompatibilityMode = backwardCompatibilityMode;
    this.gatewayBackingConfig = gatewayBackingConfig;
    this.highAvailabilityEnabled = highAvailabilityEnabled;
    this.defaultDnsRelayRoute = defaultDnsRelayRoute;
    this.locationId = locationId;
    this.description = description;
    this.vCloudHref = vCloudHref;
    this.edgeGatewayBackingType = edgeGatewayBackingType;
    this.vdcGroupScoped = vdcGroupScoped;
  }

  /**
   * Get edge status.
   *
   * @return edge status
   */
  public Integer getStatus() {
    return status;
  }

  /**
   * Get organization uuid.
   *
   * @return organization uuid.
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Get the interfaces associated with an edge.
   *
   * @return {@link Set} of {@link EdgeInterfaceResponse} instances
   */
  public Set<EdgeInterfaceResponse> getInterfaces() {
    return interfaces;
  }

  /**
   * Indicates whether backwards compatibility mode is enabled for the edge.
   *
   * @return boolean value
   */
  public boolean isBackwardCompatibilityMode() {
    return backwardCompatibilityMode;
  }

  /**
   * Gets the gateway backing configuration parameter
   *
   * @return {@link String}
   */
  public String getGatewayBackingConfig() {
    return gatewayBackingConfig;
  }

  /**
   * Indicates whether high availability is enabled for the edge.
   *
   * @return {@link Boolean}
   */
  public Boolean isHighAvailabilityEnabled() {
    return highAvailabilityEnabled;
  }

  /**
   * Indicates whether this edge is the default DNS relay route.
   *
   * @return {@link Boolean}
   */
  public Boolean isDefaultDnsRelayRoute() {
    return defaultDnsRelayRoute;
  }

  /**
   * Gets the UUID of the vDC that this edge belongs to.
   *
   * @return {@link String} vDC UUID
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Gets backward compatibility mode.
   *
   * @return the backward compatibility mode
   */
  public Boolean getBackwardCompatibilityMode() {
    return backwardCompatibilityMode;
  }

  /**
   * Gets default dns relay route.
   *
   * @return the default dns relay route
   */
  public Boolean getDefaultDnsRelayRoute() {
    return defaultDnsRelayRoute;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets high availability enabled.
   *
   * @return the high availability enabled
   */
  public Boolean getHighAvailabilityEnabled() {
    return highAvailabilityEnabled;
  }

  /**
   * Gets location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Gets cloud href.
   *
   * @return the cloud href
   */
  public String getvCloudHref() {
    return vCloudHref;
  }

  /**
   * Gets whether the Edge is backed by NSX-V or NSX-T infrastructure.
   *
   * @return the edge gateway backing type
   */
  public EdgeGatewayBackingType getEdgeGatewayBackingType() {
    return edgeGatewayBackingType;
  }

  /**
   * Gets whether the edge gateway is scoped to a vDC Group rather than a vDC.
   * vDC Group-scoped edges cannot be modified via the Console.
   *
   * @return the boolean
   */
  public Boolean isVdcGroupScoped() {
    return vdcGroupScoped;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final EdgeResponse that = (EdgeResponse) o;

    if (backwardCompatibilityMode != that.backwardCompatibilityMode)
      return false;
    if (status != null ? !status.equals(that.status) : that.status != null)
      return false;
    if (vdcUuid != null ? !vdcUuid.equals(that.vdcUuid) : that.vdcUuid != null)
      return false;
    if (orgUuid != null ? !orgUuid.equals(that.orgUuid) : that.orgUuid != null)
      return false;
    if (interfaces != null ?
        !interfaces.equals(that.interfaces) :
        that.interfaces != null)
      return false;
    if (gatewayBackingConfig != null ?
        !gatewayBackingConfig.equals(that.gatewayBackingConfig) :
        that.gatewayBackingConfig != null)
      return false;
    if (highAvailabilityEnabled != null ?
        !highAvailabilityEnabled.equals(that.highAvailabilityEnabled) :
        that.highAvailabilityEnabled != null)
      return false;
    if (defaultDnsRelayRoute != null ?
        !defaultDnsRelayRoute.equals(that.defaultDnsRelayRoute) :
        that.defaultDnsRelayRoute != null)
      return false;
    if (locationId != null ?
        !locationId.equals(that.locationId) :
        that.locationId != null)
      return false;
    if (description != null ?
        !description.equals(that.description) :
        that.description != null)
      return false;
    return vCloudHref != null ?
        vCloudHref.equals(that.vCloudHref) :
        that.vCloudHref == null;
  }

  @Override
  public int hashCode() {
    int result = status != null ? status.hashCode() : 0;
    result = 31 * result + (vdcUuid != null ? vdcUuid.hashCode() : 0);
    result = 31 * result + (orgUuid != null ? orgUuid.hashCode() : 0);
    result = 31 * result + (interfaces != null ? interfaces.hashCode() : 0);
    result = 31 * result + (backwardCompatibilityMode ? 1 : 0);
    result = 31 * result + (gatewayBackingConfig != null ?
        gatewayBackingConfig.hashCode() :
        0);
    result = 31 * result + (highAvailabilityEnabled != null ?
        highAvailabilityEnabled.hashCode() :
        0);
    result = 31 * result + (defaultDnsRelayRoute != null ?
        defaultDnsRelayRoute.hashCode() :
        0);
    result = 31 * result + (locationId != null ? locationId.hashCode() : 0);
    result = 31 * result + (description != null ? description.hashCode() : 0);
    result = 31 * result + (vCloudHref != null ? vCloudHref.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "VcdEdgeResponse{" + "status=" + status + ", vdcUuid='" + vdcUuid
        + '\'' + ", orgUuid='" + orgUuid + '\'' + ", interfaces=" + interfaces
        + ", backwardCompatibilityMode=" + backwardCompatibilityMode
        + ", gatewayBackingConfig='" + gatewayBackingConfig + '\''
        + ", highAvailabilityEnabled=" + highAvailabilityEnabled
        + ", defaultDnsRelayRoute=" + defaultDnsRelayRoute + ", locationId='"
        + locationId + '\'' + ", description='" + description + '\''
        + ", vCloudHref='" + vCloudHref + '\'' + '}';
  }

}
