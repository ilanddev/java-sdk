/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.recovery;

import java.io.Serializable;
import java.time.Instant;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Disaster Recovery Runbook Report Details Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class DisasterRecoveryRunbookReportDetailsResponse
    implements Serializable {

  private static final long serialVersionUID = 3986045765550791596L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String taskUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant taskComplete;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private StatusResponse status;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Map<String, RecoveryGroupReportDetailsResponse> data;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String startTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String endTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int protectedVmCount;

  public DisasterRecoveryRunbookReportDetailsResponse(final String locationId,
      final String taskUuid, final String type, final Instant taskComplete,
      final StatusResponse status,
      final Map<String, RecoveryGroupReportDetailsResponse> data,
      final String startTime, final String endTime,
      final int protectedVmCount) {
    this.locationId = locationId;
    this.taskUuid = taskUuid;
    this.type = type;
    this.taskComplete = taskComplete;
    this.status = status;
    this.data = data;
    this.startTime = startTime;
    this.endTime = endTime;
    this.protectedVmCount = protectedVmCount;
  }

  /**
   * Gets the task uuid.
   *
   * @return the task uuid
   */
  public String getTaskUuid() {
    return taskUuid;
  }

  /**
   * Gets the task complete timestamp.
   *
   * @return the task complete timestamp
   */
  public Instant getTaskComplete() {
    return taskComplete;
  }

  /**
   * Gets data.
   *
   * @return the data
   */
  public Map<String, RecoveryGroupReportDetailsResponse> getRecoveryGroupDetails() {
    return data;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public StatusResponse getStatus() {
    return status;
  }

  /**
   * Gets location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Get the report type.
   *
   * @return report type
   */
  public String getType() {
    return type;
  }

  /**
   * Get the start time of the runbook operation.
   *
   * @return {@link String} formatted start time
   */
  public String getStartTime() {
    return startTime;
  }

  /**
   * Get the end time of the runbook operation.
   *
   * @return {@link String} formatted end time
   */
  public String getEndTime() {
    return endTime;
  }

  /**
   * Get the total count of protected VMs in the runbook.
   *
   * @return protected VM count
   */
  public int getProtectedVmCount() {
    return protectedVmCount;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final DisasterRecoveryRunbookReportDetailsResponse that =
        (DisasterRecoveryRunbookReportDetailsResponse) o;

    if (protectedVmCount != that.protectedVmCount)
      return false;
    if (locationId != null ?
        !locationId.equals(that.locationId) :
        that.locationId != null)
      return false;
    if (taskUuid != null ?
        !taskUuid.equals(that.taskUuid) :
        that.taskUuid != null)
      return false;
    if (type != null ? !type.equals(that.type) : that.type != null)
      return false;
    if (taskComplete != null ?
        !taskComplete.equals(that.taskComplete) :
        that.taskComplete != null)
      return false;
    if (status != that.status)
      return false;
    if (data != null ? !data.equals(that.data) : that.data != null)
      return false;
    if (startTime != null ?
        !startTime.equals(that.startTime) :
        that.startTime != null)
      return false;
    return endTime != null ?
        endTime.equals(that.endTime) :
        that.endTime == null;
  }

  @Override
  public int hashCode() {
    int result = locationId != null ? locationId.hashCode() : 0;
    result = 31 * result + (taskUuid != null ? taskUuid.hashCode() : 0);
    result = 31 * result + (type != null ? type.hashCode() : 0);
    result = 31 * result + (taskComplete != null ? taskComplete.hashCode() : 0);
    result = 31 * result + (status != null ? status.hashCode() : 0);
    result = 31 * result + (data != null ? data.hashCode() : 0);
    result = 31 * result + (startTime != null ? startTime.hashCode() : 0);
    result = 31 * result + (endTime != null ? endTime.hashCode() : 0);
    result = 31 * result + protectedVmCount;
    return result;
  }

  @Override
  public String toString() {
    return "DisasterRecoveryRunbookReportDetailsResponse{" + "locationId='"
        + locationId + '\'' + ", taskUuid='" + taskUuid + '\'' + ", type='"
        + type + '\'' + ", taskComplete=" + taskComplete + ", status=" + status
        + ", data=" + data + ", startTime='" + startTime + '\'' + ", endTime='"
        + endTime + '\'' + ", protectedVmCount=" + protectedVmCount + '}';
  }

  public enum StatusResponse {

    WAITING,

    GENERATING,

    READY,

    ERROR

  }

}
