/*
 * Copyright (c) 2022, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscanfree;

import java.util.List;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * {@link ScannableStatus Scannable Status}.
 *
 * @author <a href="mailto:tspilman@iland.com">Tag Spilman</a>
 */
@APIModel
public interface ScannableStatus {

	/**
	 * Return whether the source is scannable
	 *
	 * @return true or false
	 */
	boolean isScannable();

	/**
	 * Get the reason the source is not scannable.
	 *
	 * @return the reason
	 */
	String getReason();

	List<ScanTarget> targets();

}
