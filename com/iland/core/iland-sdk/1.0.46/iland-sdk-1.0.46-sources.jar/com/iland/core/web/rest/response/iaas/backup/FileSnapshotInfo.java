/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the "LICENSE.txt" file that accompanied this software. Any inquiries
 *  concerning the scope or enforceability of the license should be addressed
 *  to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Instant;
import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * FileSnapshotInfo.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface FileSnapshotInfo {

  /**
   * Indicates that there is an archival copy of the file backup.
   */
  boolean hasArchivalCopy();

  /**
   * Indicates that there is a local copy of the file backup.
   */
  boolean hasLocalCopy();

  /**
   * Indicates that there is a copy of the file backup in a remote location.
   */
  boolean hasRemoteCopy();

  /**
   * The time that the file was last modified.
   */
  Optional<Instant> modifiedTime();

  /**
   * The size of the file in bytes.
   */
  long sizeBytes();

  /**
   * The snapshot details for the file.
   */
  SnapshotAttempt snapshot();

}
