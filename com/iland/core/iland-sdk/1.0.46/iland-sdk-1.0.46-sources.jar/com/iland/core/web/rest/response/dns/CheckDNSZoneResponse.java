/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.dns;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * DNS Zone Check Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class CheckDNSZoneResponse implements Serializable {

  private static final long serialVersionUID = 5910547491368889109L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean valid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String message;

  public CheckDNSZoneResponse(final boolean valid, final String message) {
    this.valid = valid;
    this.message = message;
  }

  /**
   * Whether the DNS Zone is valid.
   *
   * @return dns zone validity
   */
  public boolean isValid() {
    return valid;
  }

  /**
   * Get the DNS Zone validity message.
   *
   * @return {@link String} zone validity message
   */
  public String getMessage() {
    return message;
  }

}
