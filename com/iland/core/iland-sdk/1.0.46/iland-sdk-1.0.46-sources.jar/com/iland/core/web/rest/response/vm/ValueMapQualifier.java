/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.util.List;

import org.immutables.value.Value;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * Product section property qualifier that requires a string or integer value to
 * be a valid to be one among an enumerated set of options.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public abstract class ValueMapQualifier extends Qualifier {

  /**
   * The enumeration of valid options.
   */
  @Value.Parameter
  public abstract List<String> values();

  @Override
  @Value.Derived
  public QualifierType type() {
    return QualifierType.VALUE_MAP;
  }
}
