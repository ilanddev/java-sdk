/*
 * Copyright (c) 2013 - 2024, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.inject.Qualifier;

/**
 * Annotation to disambiguate a platform-core API bean implementation from the
 * equivalent grpc client implementation (Api). Platform-core jax-rs annotated
 * interfaces will extend base APIs defined in microservices. They usually need
 * to depend on the gRPC client implementation of the same API.
 *
 * @author <a href="mailto:smittal@iland.com">Sachin Mittal</a>
 */
@Qualifier
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD,
    ElementType.PARAMETER})
public @interface PlatformApi {
}
