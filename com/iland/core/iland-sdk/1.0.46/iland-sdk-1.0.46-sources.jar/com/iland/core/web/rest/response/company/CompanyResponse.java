/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.company;

import java.time.Instant;
import java.util.List;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.common.entity.CommonEntityType;
import com.iland.common.entity.EntityType;
import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.response.user.DomainResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Company Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class CompanyResponse extends EntityResponse {

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean hasIaas;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean hasVcc;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean hasVccr;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean hasO365;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean hasCeph;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean hasConnectivity;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean hasAwsS3;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean hasLicense;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private DomainResponse domain;

  @Expose
  @JsonOptional(
      "The optional parent company header, only present on MSP " + "Tenants")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private CompanyHeaderResponse parentCompany;

  @Expose
  @JsonRequired("The list of child company IDs/names - only populated on MSP "
      + "Parent Companies")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<CompanyHeaderResponse> childCompanies;

  public CompanyResponse(final String uuid, final String name,
      final boolean deleted, final Instant deletedDate,
      final Instant updatedDate, final boolean hasIaas, final boolean hasVcc,
      final boolean hasVccr, final boolean hasO365, final boolean hasCeph,
      final boolean hasConnectivity, final boolean hasAwsS3,
      final boolean hasLicense, final DomainResponse domain,
      final CompanyHeaderResponse parentCompany,
      final List<CompanyHeaderResponse> childCompanies) {
    super(uuid, name, deleted, deletedDate, updatedDate, uuid);
    this.hasIaas = hasIaas;
    this.hasVcc = hasVcc;
    this.hasVccr = hasVccr;
    this.hasO365 = hasO365;
    this.hasCeph = hasCeph;
    this.hasConnectivity = hasConnectivity;
    this.hasAwsS3 = hasAwsS3;
    this.hasLicense = hasLicense;
    this.domain = domain;
    this.parentCompany = parentCompany;
    this.childCompanies = childCompanies;
  }

  /**
   * Indicates whether this company has any IaaS assets.
   *
   * @return boolean value
   */
  public boolean hasIaas() {
    return hasIaas;
  }

  /**
   * Indicates whether this company has any VCC-R assets.
   *
   * @return boolean value
   */
  public boolean hasVccr() {
    return hasVcc;
  }

  /**
   * Indicates whether this company has any VCC assets.
   *
   * @return boolean value
   */
  public boolean hasVcc() {
    return hasVcc;
  }

  /**
   * Indicates whether the company has Office 365 backups.
   *
   * @return boolean value
   */
  public boolean hasO365() {
    return hasO365;
  }

  /**
   * Indicates whether the company has Ceph object storage or not.
   *
   * @return boolean value
   */
  public boolean isHasCeph() {
    return hasCeph;
  }

  /**
   * Indicates whether the company has Connectivity.
   */
  public boolean hasConnectivity() {
    return hasConnectivity;
  }

  /**
   * Indicates whether the company has AWS S3.
   */
  public boolean hasAwsS3() {
    return hasAwsS3;
  }

  /**
   * Indicates whether the company has Licenses.
   */
  public boolean hasLicense() {
    return hasLicense;
  }

  /**
   * Get the entity type.
   *
   * @return entity type
   */
  public EntityType getEntityType() {
    return CommonEntityType.COMPANY;
  }

  /**
   * Get the company domain.
   *
   * @return {@link DomainResponse} company domain
   */
  public DomainResponse getDomain() {
    return domain;
  }

  /**
   * Get the parent company header.
   *
   * @return {@link String} parent company header
   */
  public CompanyHeaderResponse getParentCompany() {
    return parentCompany;
  }

  /**
   * Get the list of child companies.
   *
   * @return list of {@link CompanyHeaderResponse}
   */
  public List<CompanyHeaderResponse> getChildCompanies() {
    return childCompanies;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    if (!super.equals(o))
      return false;
    final CompanyResponse that = (CompanyResponse) o;
    return hasIaas == that.hasIaas && hasVcc == that.hasVcc
        && hasO365 == that.hasO365 && hasCeph == that.hasCeph
        && hasConnectivity == that.hasConnectivity && hasLicense == that.hasLicense
        && Objects.equals(
        getDomain(), that.getDomain()) && Objects.equals(this.parentCompany,
        that.parentCompany) && this.childCompanies.equals(that.childCompanies);
  }

  @Override
  public int hashCode() {
    return Objects.hash(super.hashCode(), hasIaas, hasVcc, hasO365, hasCeph,
        hasConnectivity, hasAwsS3, hasLicense, getDomain(), parentCompany, childCompanies);
  }

  @Override
  public String toString() {
    return """
        CompanyResponse{hasIaas=%b, \
        hasVcc=%b, \
        hasO365=%b, \
        hasCeph=%b \
        hasConnectivity=%b \
        hasAwsS3=%b
        hasLicense=%b
        parentCompany=%b \
        childCompanies=%b}
        """.formatted(hasIaas, hasVcc, hasO365, hasCeph,
        hasConnectivity, hasAwsS3, hasLicense, parentCompany, childCompanies);
  }

}
