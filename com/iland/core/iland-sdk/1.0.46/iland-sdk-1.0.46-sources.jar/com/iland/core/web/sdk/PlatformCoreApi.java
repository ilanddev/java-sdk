/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.sdk;

import com.iland.core.web.rest.api.BackupGroupResource;
import com.iland.core.web.rest.api.BackupGroupV2Resource;
import com.iland.core.web.rest.api.CatalogResource;
import com.iland.core.web.rest.api.CompanyLocationResource;
import com.iland.core.web.rest.api.CompanyResource;
import com.iland.core.web.rest.api.CompanySSOResource;
import com.iland.core.web.rest.api.ConnectivityResource;
import com.iland.core.web.rest.api.ConstantsResource;
import com.iland.core.web.rest.api.DRRunbookResource;
import com.iland.core.web.rest.api.DownloadResource;
import com.iland.core.web.rest.api.EdgeGatewayResource;
import com.iland.core.web.rest.api.EdgeResource;
import com.iland.core.web.rest.api.EventResource;
import com.iland.core.web.rest.api.FrontEndFeatureResource;
import com.iland.core.web.rest.api.LicenseResource;
import com.iland.core.web.rest.api.LocationResource;
import com.iland.core.web.rest.api.MediaResource;
import com.iland.core.web.rest.api.NsxTApplicationPortProfileResource;
import com.iland.core.web.rest.api.NsxTEdgeGatewayResource;
import com.iland.core.web.rest.api.NsxTOrgVdcNetworkResource;
import com.iland.core.web.rest.api.O365JobResource;
import com.iland.core.web.rest.api.O365JobSessionResource;
import com.iland.core.web.rest.api.O365OrganizationResource;
import com.iland.core.web.rest.api.O365RestoreSessionResource;
import com.iland.core.web.rest.api.O365SearchBackupsResource;
import com.iland.core.web.rest.api.ObjectStorageResource;
import com.iland.core.web.rest.api.OffsetReplicationResource;
import com.iland.core.web.rest.api.OracleRecoveryResource;
import com.iland.core.web.rest.api.OrgReportingResource;
import com.iland.core.web.rest.api.OrgResource;
import com.iland.core.web.rest.api.OrgVdcNetworkResource;
import com.iland.core.web.rest.api.PhysicalFileRecoveryResource;
import com.iland.core.web.rest.api.S3StorageResource;
import com.iland.core.web.rest.api.SqlRecoveryResource;
import com.iland.core.web.rest.api.TaskResource;
import com.iland.core.web.rest.api.UserResource;
import com.iland.core.web.rest.api.VacCompanyResource;
import com.iland.core.web.rest.api.VacJobProcessedObjectResource;
import com.iland.core.web.rest.api.VacJobResource;
import com.iland.core.web.rest.api.VappNetworkResource;
import com.iland.core.web.rest.api.VappResource;
import com.iland.core.web.rest.api.VappTemplateResource;
import com.iland.core.web.rest.api.VccFailoverPlanResource;
import com.iland.core.web.rest.api.VdcResource;
import com.iland.core.web.rest.api.VmResource;
import com.iland.core.web.rest.api.VpgResource;
import com.iland.core.web.sdk.connection.OAuthConnection;
import com.iland.core.web.sdk.connection.OAuthException;
import com.iland.core.web.sdk.connection.WebSocketClient;

/**
 * Represents the public 11:11 Platform Core API
 */
public interface  PlatformCoreApi {

  void login(final String username, final String password)
      throws OAuthException;

  void logout();

  OAuthConnection getConnection();

  CatalogResource getCatalogResource();

  OrgReportingResource getReportingResource();

  EdgeGatewayResource getEdgeGatewayResource();

  FrontEndFeatureResource getFrontEndFeatureResource();

  NsxTEdgeGatewayResource getNsxTEdgeGatewayResource();

  NsxTApplicationPortProfileResource getNsxTApplicationPortProfileResource();

  NsxTOrgVdcNetworkResource getNsxTOrgVdcNetworkResource();

  EdgeResource getEdgeResource();

  MediaResource getMediaResource();

  OrgResource getOrgResource();

  UserResource getUserResource();

  VappResource getVappResource();

  VappTemplateResource getVappTemplateResource();

  VdcResource getVdcResource();

  SqlRecoveryResource getSqlRecoveryResource();

  OracleRecoveryResource getOracleRecoveryResource();

  PhysicalFileRecoveryResource getPhysicalFileRecoveryResource();

  VmResource getVmResource();

  LocationResource getLocationResource();

  VpgResource getVpgResource();

  CompanyResource getCompanyResource();

  CompanyLocationResource getCompanyLocationResource();

  ConstantsResource getConstantsResource();

  OrgVdcNetworkResource getOrgVdcNetworkResource();

  VappNetworkResource getVappNetworkResource();

  DRRunbookResource getDRRunbookResource();

  OffsetReplicationResource getOffsiteReplicationResource();

  DownloadResource getDownloadResource();

  TaskResource getTaskResource();

  EventResource getEventResource();

  VccFailoverPlanResource getVccFailoverPlanResource();

  WebSocketClient getEventWebSocket(String companyID);

  VacCompanyResource getVacCompanyResource();

  VacJobResource getVacJobResource();

  VacJobProcessedObjectResource getVacJobProcessedObjectResource();

  O365OrganizationResource getO365OrganizationResource();

  O365JobResource getO365JobResource();

  O365JobSessionResource getO365JobSessionResource();

  O365RestoreSessionResource getO365RestoreSessionResource();

  /**
   * Returns the Office 365 Search Backups resource.
   *
   * @return the Office 365 Search Backups resource
   */
  O365SearchBackupsResource getO365SearchBackupsResource();

  BackupGroupResource getBackupGroupResource();

  BackupGroupV2Resource getBackupGroupV2Resource();

  ObjectStorageResource getObjectStorageResource();

  CompanySSOResource getCompanySSOResource();

  ConnectivityResource getConnectivityResource();

  S3StorageResource getS3StorageResource();

  LicenseResource getLicenseResource();
}
