/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * MKS Screen Ticket Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class MksScreenTicketResponse implements Serializable {

  private static final long serialVersionUID = -795783617681207416L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmx;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String ticket;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String host;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String port;

  public MksScreenTicketResponse(final String vmx, final String ticket,
      final String host, final String port) {
    this.vmx = vmx;
    this.ticket = ticket;
    this.host = host;
    this.port = port;
  }

  /**
   * Get the screen ticket.
   *
   * @return {@link String}
   */
  public String getTicket() {
    return ticket;
  }

  /**
   * Get the host for connecting to.
   *
   * @return {@link String} host
   */
  public String getHost() {
    return host;
  }

  /**
   * Get the vmx.
   *
   * @return {@link String} vmx
   */
  public String getVmx() {
    return vmx;
  }

  /**
   * Get the port.
   *
   * @return {@link String} port
   */
  public String getPort() {
    return port;
  }

}
