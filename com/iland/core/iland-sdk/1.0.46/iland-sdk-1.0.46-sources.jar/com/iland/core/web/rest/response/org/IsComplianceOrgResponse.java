/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.org;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Is Compliance Org Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class IsComplianceOrgResponse implements Serializable {

  private static final long serialVersionUID = 3116612019499994417L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean isComplianceOrg;

  /**
   * Instantiates a new Is compliance org.
   *
   * @param isComplianceOrg the is compliance org
   */
  public IsComplianceOrgResponse(final boolean isComplianceOrg) {
    this.isComplianceOrg = isComplianceOrg;
  }

  /**
   * Is compliance org.
   *
   * @return the boolean
   */
  public boolean isComplianceOrg() {
    return isComplianceOrg;
  }

}
