/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.org;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.vapp.VappListResponse;
import com.iland.core.web.rest.response.vapptemplate.VappTemplateListResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Org Expired Items Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class OrgExpiredItemsResponse {

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private VappListResponse expiredVapps;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private VappTemplateListResponse expiredVappsTemplates;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String orgUuid;

  /**
   * Creates a new OrgExpiredItems.
   *
   * @param expiredVapps          {@link VappListResponse} list of expired vApps
   * @param expiredVappsTemplates {@link VappTemplateListResponse} list of
   *                              expired vapp templates vapp templates
   * @param orgUuid               {@link String} org uuid
   */
  public OrgExpiredItemsResponse(final VappListResponse expiredVapps,
      final VappTemplateListResponse expiredVappsTemplates,
      final String orgUuid) {
    this.expiredVapps = expiredVapps;
    this.expiredVappsTemplates = expiredVappsTemplates;
    this.orgUuid = orgUuid;
  }

  /**
   * Gets the expired vapps.
   *
   * @return {@link VappListResponse} expired vApps
   */
  public VappListResponse getExpiredVapps() {
    return expiredVapps;
  }

  /**
   * Gets the expired vapp templates.
   *
   * @return {@link VappTemplateListResponse} expired vApp templates
   */
  public VappTemplateListResponse getExpiredVappsTemplates() {
    return expiredVappsTemplates;
  }

  /**
   * Gets the org uuid.
   *
   * @return {@link String} org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

}
