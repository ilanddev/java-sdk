/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.List;

import com.iland.core.web.rest.response.common.ListResponse;
import com.iland.core.web.rest.shared.iaas.backup.BackupGroupStorageMetric;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * BackupGroupStorageMetricListResponse.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public final class BackupGroupStorageMetricListResponse
    extends ListResponse<BackupGroupStorageMetric> {

  public BackupGroupStorageMetricListResponse(
      final List<BackupGroupStorageMetric> data) {
    super(data);
  }

}
