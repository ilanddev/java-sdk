/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import java.io.InputStream;
import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.common.SnapshotCreateRequest;
import com.iland.core.web.rest.request.common.UpdateMetadataRequest;
import com.iland.core.web.rest.request.iaas.backup.GenerateBackupFileDownloadBundleParams;
import com.iland.core.web.rest.request.iaas.backup.ListBackupSnapshotFilesAndFoldersFilters;
import com.iland.core.web.rest.request.iaas.backup.ListVmBackupGroupRunsFilters;
import com.iland.core.web.rest.request.iaas.backup.RestoreVMBackupParams;
import com.iland.core.web.rest.request.iaas.backup.SearchVmRecoverableFilesAndFoldersFilters;
import com.iland.core.web.rest.request.vm.GuestCustomizationUpdateRequest;
import com.iland.core.web.rest.request.vm.UpdateProductSectionPropertiesRequest;
import com.iland.core.web.rest.request.vm.VirtualDiskRequest;
import com.iland.core.web.rest.request.vm.VirtualNetworkCardRequest;
import com.iland.core.web.rest.request.vm.VmBootOptionsUpdateRequest;
import com.iland.core.web.rest.request.vm.VmCapabilityUpdateRequest;
import com.iland.core.web.rest.request.vm.VmCopyMoveRequest;
import com.iland.core.web.rest.request.vm.VmCpuCountUpdateRequest;
import com.iland.core.web.rest.request.vm.VmDescriptionUpdateRequest;
import com.iland.core.web.rest.request.vm.VmMediaInsertRequest;
import com.iland.core.web.rest.request.vm.VmMemorySizeUpdateRequest;
import com.iland.core.web.rest.request.vm.VmNameUpdateRequest;
import com.iland.core.web.rest.request.vm.VmReconfigureRequest;
import com.iland.core.web.rest.request.vm.VmRelocateRequest;
import com.iland.core.web.rest.request.vm.VmRestoreIntoVappRequest;
import com.iland.core.web.rest.request.vm.VmRestoreRequest;
import com.iland.core.web.rest.request.vm.VmToolsUpgradePolicyUpdateRequest;
import com.iland.core.web.rest.request.vm.VmVirtualDiskCreateRequest;
import com.iland.core.web.rest.request.vm.VmVirtualDiskUpdateRequest;
import com.iland.core.web.rest.response.billing.BillResponse;
import com.iland.core.web.rest.response.billing.BillingSummaryResponse;
import com.iland.core.web.rest.response.common.HasSnapshotResponse;
import com.iland.core.web.rest.response.common.SnapshotResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupRunListResponse;
import com.iland.core.web.rest.response.iaas.backup.DirectoryListingResponse;
import com.iland.core.web.rest.response.iaas.backup.FileSnapshotInfoListResponse;
import com.iland.core.web.rest.response.iaas.backup.FilesystemVolumeListResponse;
import com.iland.core.web.rest.response.iaas.backup.RecoverableFilesSearchResultListResponse;
import com.iland.core.web.rest.response.iaas.backup.VmBackupStatusDetailResponse;
import com.iland.core.web.rest.response.iaas.intbackup.VmIntegratedBackupStatusDetailResponse;
import com.iland.core.web.rest.response.metadata.MetadataListResponse;
import com.iland.core.web.rest.response.performance.PerfSampleSerieResponse;
import com.iland.core.web.rest.response.performance.PerformanceCounterListResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vdc.StorageProfileListResponse;
import com.iland.core.web.rest.response.vm.GuestCustomizationResponse;
import com.iland.core.web.rest.response.vm.GuestToolsResponse;
import com.iland.core.web.rest.response.vm.MksScreenTicketResponse;
import com.iland.core.web.rest.response.vm.ProductSectionListResponse;
import com.iland.core.web.rest.response.vm.RecommendedDiskBusTypeResponse;
import com.iland.core.web.rest.response.vm.RestorePointListResponse;
import com.iland.core.web.rest.response.vm.ScreenTicketResponse;
import com.iland.core.web.rest.response.vm.VirtualDiskListResponse;
import com.iland.core.web.rest.response.vm.VirtualNetworkCardListResponse;
import com.iland.core.web.rest.response.vm.VmBootOptionsResponse;
import com.iland.core.web.rest.response.vm.VmCapabilityResponse;
import com.iland.core.web.rest.response.vm.VmNetworkListResponse;
import com.iland.core.web.rest.response.vm.VmResourceSummaryResponse;
import com.iland.core.web.rest.response.vm.VmResponse;
import com.iland.core.web.rest.response.vm.VmToolsUpgradePolicyResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * VM Resource Interface.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "VMs")
@Path("/vms")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface VmResource {

  /**
   * Return current vm billing for a give Vm.
   * <p>
   * Excluded from public API as its really only intended for consumption in
   * console.
   *
   * @param vmUuid vm uuid
   * @return current billing for VM
   */
  @GET
  @Path("/{vmUuid}/billing-summary")
  BillingSummaryResponse getCurrentBilling(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM_BILLING)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Returns VM Billing for a given invoice period.
   * <p>
   * If month and year are not explicitly supplied the current invoice period is
   * used.
   *
   * @param vmUuid VM uuid
   * @param year   the invoice period year (defaults to current year)
   * @param month  the invoice period month (defaults to the current month) must
   *               be in range 1-12
   * @return billing for the VM and given invoice period
   */
  @GET
  @Path("/{vmUuid}/billing")
  BillResponse getBillingForVm(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM_BILLING)
      @PathParam("vmUuid") String vmUuid, @QueryParam("year") Integer year,
      @QueryParam("month") Integer month);

  /**
   * Retrieve a screen ticket for viewing the console of a given Vm.
   *
   * @param vmUuid vm uuid
   * @return screen ticket
   */
  @GET
  @Path("/{vmUuid}/screen-ticket")
  ScreenTicketResponse getScreenTicket(
      @SecureEntityRef(Permission.ACCESS_ILAND_CLOUD_VM_CONSOLE)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Retrieve a mks screen ticket for viewing the console of a given Vm.
   *
   * @param vmUuid vm uuid
   * @return screen ticket
   */
  @GET
  @Path("/{vmUuid}/mks-screen-ticket")
  MksScreenTicketResponse getMksScreenTicket(
      @SecureEntityRef(Permission.ACCESS_ILAND_CLOUD_VM_CONSOLE)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Upgrade the virtual hardware version of a vm to the latest available
   * version.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-virtual-hardware-version")
  TaskResponse updateVirtualHardwareVersion(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Update the description for a vm.
   *
   * @param vmUuid vm uuid
   * @param spec   specification to update VM description
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-description")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateDescriptionForVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, VmDescriptionUpdateRequest spec);

  /**
   * Retrieve metadata associated with a Vm.
   *
   * @param vmUuid vm uuid
   * @return list of metadata for VM
   */
  @GET
  @Path("/{vmUuid}/metadata")
  MetadataListResponse getMetadataForVm(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Add / update metadata associated with a Vm.
   *
   * @param vmUuid   vm uuid
   * @param metadata list of metadata
   * @return asynchronous task details
   */
  @PUT
  @Path("/{vmUuid}/metadata")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateMetadataForVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, List<UpdateMetadataRequest> metadata);

  /**
   * Delete a specific piece of metadata associated with a Vm by its key.
   *
   * @param vmUuid vm uuid
   * @param key    metadata key
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{vmUuid}/metadata/{key}")
  TaskResponse deleteMetadataForVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, @PathParam("key") String key);

  /**
   * Insert a media to a Vm.
   *
   * @param vmUuid vm uuid
   * @param spec   specification detailing which media to insert into VM
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/insert-media")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse insertMedia(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, VmMediaInsertRequest spec);

  /**
   * Eject a media from a Vm.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/eject-media")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse ejectMedia(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Relocate a Vm to another storage profile.
   *
   * @param vmUuid vm uuid
   * @param spec   specification for relocating VM to another storage profile
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/relocate")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse relocateVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, VmRelocateRequest spec);

  /**
   * Creates a new Vm in the Vapp based on an existing Vm.
   *
   * @param vmUuid vm uuid
   * @param spec   specification for newly copied vm
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/copy")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse copyVm(
      @SecureEntityRef(Permission.COPY_MOVE_RESTORE_ILAND_CLOUD_VM)
      @PathParam("vmUuid") String vmUuid, VmCopyMoveRequest spec);

  /**
   * Moves an existing VM into the specified Vapp.
   *
   * @param vmUuid vm uuid
   * @param spec   specification for newly moved vm
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/move")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse moveVm(
      @SecureEntityRef(Permission.COPY_MOVE_RESTORE_ILAND_CLOUD_VM)
      @PathParam("vmUuid") String vmUuid, VmCopyMoveRequest spec);

  /**
   * Get restore points for the given VM.
   *
   * @param vmUuid vm uuid
   * @return list of restore points
   */
  @GET
  @Path("/{vmUuid}/backups")
  RestorePointListResponse getRestorePoints(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Delete a VM.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{vmUuid}")
  TaskResponse deleteVm(
      @SecureEntityRef(Permission.DELETE_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Restore a VM from a restore point into the same vApp.
   *
   * @param vmUuid vm uuid
   * @param spec   VM restore specification
   * @return asynchronous task details
   */
  @SkipSecurityTest("custom logic in EJB for securing the target restore site")
  @POST
  @Path("/{vmUuid}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse restoreVm(
      @SecureEntityRef(Permission.COPY_MOVE_RESTORE_ILAND_CLOUD_VM)
      @PathParam("vmUuid") String vmUuid, VmRestoreRequest spec);

  /**
   * Restore a VM from a restore point into the given vApp.
   *
   * @param vmUuid vm uuid
   * @param spec   VM restore specification
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/restore-into-vapp")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse restoreVmIntoVapp(
      @SecureEntityRef(Permission.COPY_MOVE_RESTORE_ILAND_CLOUD_VM)
      @PathParam("vmUuid") String vmUuid, VmRestoreIntoVappRequest spec);

  /**
   * Reset the MAC addresses for all VNICs of the VM.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/reset-mac-addresses")
  TaskResponse resetMacAddresses(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Rename a VM.
   *
   * @param vmUuid vm uuid
   * @param spec   specification for renaming the VM
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-name")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse rename(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, VmNameUpdateRequest spec);

  /**
   * Get a list of virtual network cards for the given VM.
   *
   * @param vmUuid vm uuid
   * @return list of virtual network cards
   */
  @GET
  @Path("/{vmUuid}/vnics")
  VirtualNetworkCardListResponse getVirtualNetworkCards(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Get the networks for a given VM.
   *
   * @param vmUuid vm uuid
   * @return list of networks
   */
  @GET
  @Path("/{vmUuid}/networks")
  VmNetworkListResponse getNetworksForVm(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Delete a vnic with the given ID for the given VM.
   *
   * @param vmUuid vm uuid
   * @param vnicId vnic id
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{vmUuid}/vnics/{vnicId}")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse deleteVirtualNetworkCard(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, @PathParam("vnicId") String vnicId);

  /**
   * Update virtual network cards for a VM.
   *
   * @param vmUuid vm uuid
   * @param vnics  of instances
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-vnics")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateVirtualNetworkCards(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid,
      List<VirtualNetworkCardRequest> vnics);

  /**
   * Delete a virtual disk from a VM.
   *
   * @param vmUuid   vm uuid
   * @param diskName diskName
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{vmUuid}/disks/{diskName}")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse deleteVirtualDisk(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid,
      @PathParam("diskName") String diskName);

  /**
   * Get the snapshot for the given VM.
   *
   * @param vmUuid vm uuid
   * @return snapshot
   */
  @GET
  @Path("/{vmUuid}/snapshot")
  SnapshotResponse getSnapshotForVm(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Check for the existence of a snapshot for the given VM.
   *
   * @param vmUuid vm uuid
   * @return boolean indicating whether snapshot exists
   */
  @GET
  @Path("/{vmUuid}/has-snapshot")
  HasSnapshotResponse hasVmSnapshot(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Create a snapshot for the given VM.
   *
   * @param vmUuid vm uuid
   * @param spec   specification for creating a VM snapshot
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/create-snapshot")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse createSnapshotForVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_SNAPSHOTS)
      @PathParam("vmUuid") String vmUuid, SnapshotCreateRequest spec);

  /**
   * Restore a VM from a snapshot.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/restore-snapshot")
  TaskResponse restoreSnapshotForVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_SNAPSHOTS)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Remove a snapshot from a VM.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/remove-snapshot")
  TaskResponse removeSnapshotForVm(
      @Context @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_SNAPSHOTS)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Get the recommended hard disk bus type for the given VM.
   *
   * @param vmUuid vm uuid
   * @return recommended hard disk bus type
   */
  @GET
  @Path("/{vmUuid}/recommended-disk-bus-type")
  RecommendedDiskBusTypeResponse getRecommendedDiskBusType(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Get VMWare tools information for the given VM.
   *
   * @param vmUuid vm uuid
   * @return guest tools information
   */
  @GET
  @Path("/{vmUuid}/guest-tools")
  GuestToolsResponse getGuestTools(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Upgrade VMWare tools for the given VM.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/upgrade-guest-tools")
  TaskResponse upgradeGuestTools(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Get VM performance data for the given VM, counter, and time range.
   *
   * @param vmUuid   VM uuid
   * @param group    the performance counter group
   * @param name     the performance counter name
   * @param type     the performance counter type
   * @param start    start date
   * @param end      end date
   * @param interval interval
   * @param limit    limit
   * @return performance samples serie for the given VM, counter and date range
   */
  @GET
  @Path("/{vmUuid}/performance/{group}::{name}::{type}")
  PerfSampleSerieResponse getPerformanceForVm(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid, @PathParam("group") String group,
      @PathParam("name") String name, @PathParam("type") String type,
      @QueryParam("start") Long start, @QueryParam("end") Long end,
      @QueryParam("interval") String interval,
      @QueryParam("limit") String limit);

  /**
   * Get the list of performance counters that can be used to query for VM
   * performance data.
   *
   * @param vmUuid VM UUID
   * @return the list of performance counters
   */
  @GET
  @Path("/{vmUuid}/performance-counters")
  PerformanceCounterListResponse getPerformanceCountersForVm(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Power on a VM.
   *
   * @param vmUuid                  vm uuid
   * @param forceGuestCustomization optional param to force guest
   *                                re-customization on restart defaults to false
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/poweron")
  TaskResponse powerOnVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_POWER_STATE)
      @PathParam("vmUuid") String vmUuid,
      @QueryParam("forceGuestCustomization") boolean forceGuestCustomization);

  /**
   * Power off a VM.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/poweroff")
  TaskResponse powerOffVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_POWER_STATE)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Suspend a VM.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/suspend")
  TaskResponse suspendVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_POWER_STATE)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Shutdown a VM guest operating system.
   * <p>
   * This action requires VMWare tools to be installed.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/shutdown")
  TaskResponse shutdownVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_POWER_STATE)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Reset a VM.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/reset")
  TaskResponse resetVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_POWER_STATE)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Reboot a VM.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/reboot")
  TaskResponse rebootVm(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_POWER_STATE)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Update the cpu count for the given VM.
   *
   * @param vmUuid vm uuid
   * @param spec   specification detailing number of cpus to update VM with
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-cpu-count")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateCpuCount(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, VmCpuCountUpdateRequest spec);

  /**
   * Update the memory size for the given VM.
   *
   * @param vmUuid vm uuid
   * @param spec   specification detailing memory size to update VM with
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-memory-size")
  TaskResponse updateMemorySize(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, VmMemorySizeUpdateRequest spec);

  /**
   * Get a Vm by UUID.
   *
   * @param vmUuid vm uuid
   * @return vm
   */
  @GET
  @Path("/{vmUuid}")
  VmResponse getVm(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Get a Vm by UUID. Returns most recent version from history if deleted.
   *
   * @param uuid an iland platform VM UUID.
   * @return vm
   */
  @GET
  @Path("/{uuid}/latest")
  VmResponse getVmLatest(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("uuid")
          String uuid);

  /**
   * Get the resource summary for the given VM.
   *
   * @param vmUuid vm uuid
   * @return vm resource summary
   */
  @GET
  @Path("/{vmUuid}/summary")
  VmResourceSummaryResponse getVmSummary(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Update the guest customization section of a VM.
   * <p>
   * The guest customization section includes properties of the guest operating
   * system that can be modified such as passwords, and domain names.
   *
   * @param vmUuid                    vm uuid
   * @param guestCustomizationSection guest customization section
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-guest-customization")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateGuestCustomization(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid,
      GuestCustomizationUpdateRequest guestCustomizationSection);

  /**
   * Get the guest customization section of a Vm.
   * <p>
   * The guest customization section includes properties of the guest operating
   * system that can be modified such as passwords, and domain names.
   *
   * @param vmUuid        vm uuid
   * @param omitPasswords whether to omit the guest customization passwords
   * @return guest customization section
   */
  @GET
  @Path("/{vmUuid}/guest-customization")
  GuestCustomizationResponse getGuestCustomization(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid, @QueryParam("omitPasswords") Boolean omitPasswords);

  /**
   * Get the boot options for a given VM.
   *
   * @param vmUuid vm uuid
   * @return vm boot options
   */
  @GET
  @Path("/{vmUuid}/boot-options")
  VmBootOptionsResponse getBootOptions(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Update boot options associated with a VM.
   * <p>
   * Properties capable of being updated are boot delay and whether to force
   * enter BIOS.
   *
   * @param vmUuid      vm uuid
   * @param bootOptions vm boot options
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-boot-options")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateBootOptions(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid,
      VmBootOptionsUpdateRequest bootOptions);

  /**
   * Get the VMWare tools upgrade policy for the VM.
   *
   * @param vmUuid vm uuid
   * @return vmware tools upgrade polciy
   */
  @GET
  @Path("/{vmUuid}/tools-upgrade-policy")
  VmToolsUpgradePolicyResponse getVmToolsUpgradePolicy(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Update the VMware tools upgrade policy.
   *
   * @param vmUuid vm uuid
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-tools-upgrade-policy")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateVmToolsUpgradePolicy(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid,

      VmToolsUpgradePolicyUpdateRequest upgradePolicy);

  /**
   * Get the VM capabilities for a VM.
   * <p>
   * VM capabilites include cpu and memory hot add abilities.
   *
   * @param vmUuid vm uuid
   * @return vm capabilities
   */
  @GET
  @Path("/{vmUuid}/capabilities")
  VmCapabilityResponse getVmCapabilities(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Update the VM capabilites for a VM.
   * <p>
   * VM capabilities include cpu and memory hot add.
   *
   * @param vmUuid vm uuid
   * @param spec   vm capability spec
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-capabilities")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateVmCapabilities(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, VmCapabilityUpdateRequest spec);

  /**
   * Gets the virtual disks for a VM.
   *
   * @param vmUuid the VM uuid
   * @return list of virtual disks for the VM
   */
  @GET
  @Path("/{vmUuid}/virtual-disks")
  VirtualDiskListResponse getVirtualDisks(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Updates the virtual disks for a VM. The name attribute should be null for
   * new disks.
   *
   * @param vmUuid the VM uuid
   * @param disks  the new list of disks
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-virtual-disks")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateVirtualDisks(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, List<VirtualDiskRequest> disks);

  /**
   * Updates a virtual disk.
   *
   * @param vmUuid the VM uuid
   * @param disk   the new disk
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/update-virtual-disk")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateVirtualDisk(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, VmVirtualDiskUpdateRequest disk);

  /**
   * Updates the virtual disks for a VM.
   *
   * @param vmUuid the VM uuid
   * @param disk   the new disk
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/add-virtual-disk")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse addVirtualDisk(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, VmVirtualDiskCreateRequest disk);

  /**
   * The actual action performed will be to mount the VMWare tools ISO on the
   * given VM. It is the responsiblity of the user to actually log into the VM
   * and install the VMWare tools.
   *
   * @param vmUuid the VM uuid
   * @return asynchrounous task details
   */
  @POST
  @Path("/{vmUuid}/actions/install-vmware-tools")
  TaskResponse installVMWareTools(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Reconfigure a VM.
   *
   * This will update the name and description of the VM as
   * well as the guest customization section, the cpu, memory and disk
   * specifications.
   * <p>
   * Any sections left out of the {@link VmReconfigureRequest} will be left
   * unchanged.
   *
   * @param vmUuid VM uuid
   * @param spec   reconfigure specification
   * @return asynchronous task details
   */
  @POST
  @Path("/{vmUuid}/actions/reconfigure")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse reconfigure(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid, VmReconfigureRequest spec);

  /**
   * Gets the current screen JPEG thumbnail image.
   *
   * @param vmUuid the UUID of the VM
   * @return JPEG thumbnail image
   */
  @GET
  @Path("/{vmUuid}/screen")
  @Produces(IlandVersionedMediaType.V1_IMAGE_JPEG)
  InputStream getScreen(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Enable nested hypervisor for given VM.
   *
   * @param vmUuid the UUID of the VM
   * @return asynchrounous task details
   */
  @POST
  @Path("/{vmUuid}/actions/enable-nested-hypervisor")
  TaskResponse enableNestedHypervisor(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Disable nested hypervisor for given VM.
   *
   * @param vmUuid the UUID of the VM
   * @return asynchrounous task details
   */
  @POST
  @Path("/{vmUuid}/actions/disable-nested-hypervisor")
  TaskResponse disableNestedHypervisor(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid);

  /**
   * Get the storage profiles available to the VM.
   *
   * @param vmUuid          VM uuid
   * @param includeDisabled whether to include disabled profiles (defaults to
   *                        false if not explicitly provided)
   * @return list of storage profiles available to the VM
   */
  @GET
  @Path("/{vmUuid}/available-storage-profiles")
  StorageProfileListResponse getAvailableStorageProfilesForVm(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid,
      @QueryParam("includeDisabled") Boolean includeDisabled);

  /**
   * Get the product sections for a VM.
   *
   * @param vmUuid the UUID of the VM
   * @return a list of product sections
   */
  @GET
  @Path("/{vmUuid}/product-sections")
  ProductSectionListResponse getProductSections(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Update product section properties of a VM.
   *
   * @param vmUuid the UUID of the VM
   * @param params the map of keys/values to update
   * @return a list of product sections
   */
  @POST
  @Path("/{vmUuid}/actions/update-product-section-properties")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateProductSectionProperties(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VM_CONFIGURATION)
      @PathParam("vmUuid") String vmUuid,
      UpdateProductSectionPropertiesRequest params);

  /**
   * Gets the VM's backup status.
   *
   * @param vmUuid the UUID of the VM
   * @return VM backup status details
   */
  @GET
  @Path("/{vmUuid}/backup-status")
  VmBackupStatusDetailResponse getBackupStatus(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Gets the VM's integrated backup status.
   *
   * @param vmUuid the UUID of the VM
   * @return VM integrated backup status details
   */
  @GET
  @Path("/{vmUuid}/integrated-backup-status")
  VmIntegratedBackupStatusDetailResponse getIntegratedBackupStatus(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid);

  /**
   * Searches for recoverable backup files and folders that are associated with
   * the VM.
   *
   * @param vmUuid  the UUID of the VM
   * @param filters optional query filters
   * @return a list of recoverable files and folders
   */
  @GET
  @Path("/{vmUuid}/recoverable-files-and-folders")
  RecoverableFilesSearchResultListResponse searchRecoverableFilesAndFolders(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid,
      @BeanParam SearchVmRecoverableFilesAndFoldersFilters filters);

  /**
   * Lists all backup runs that are associated with the specified VM.
   *
   * @param vmUuid  the UUID of the VM
   * @param filters optional query filters
   * @return a list of backup runs that are associated with the VM
   */
  @GET
  @Path("/{vmUuid}/backup-runs")
  BackupGroupRunListResponse listBackupRuns(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid, @BeanParam ListVmBackupGroupRunsFilters filters);

  /**
   * Lists all snapshots that are available for a specified file, in association
   * with a specific backup group.
   *
   * @param vmUuid         the UUID of the VM
   * @param backupGroupUid the UID of the backup group
   * @param filename       the name of the file
   * @return list of all snapshots available for the file
   */
  @GET
  @Path("/{vmUuid}/backup-groups/{backupGroupUid}/files/{filename}")
  FileSnapshotInfoListResponse listBackupFileSnapshots(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid, @PathParam("backupGroupUid") String backupGroupUid,
      @PathParam("filename") @Encoded String filename);

  /**
   * Downloads a file from a specified backup run.
   *
   * @param vmUuid       the UUID of the VM
   * @param backupRunUid the UID of the backup run that created the snapshot
   * @param filename     the name of the file
   * @return content of the file
   */
  @GET
  @Path("/{vmUuid}/backup-runs/{backupRunUid}/files/{filename}")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream downloadBackupFileSnapshot(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid, @PathParam("backupRunUid") String backupRunUid,
      @PathParam("filename") @Encoded String filename);

  /**
   * Lists all volumes that are present on a VM backup snapshot.
   *
   * @param vmUuid        the UUID of the VM
   * @param backupRunUid  the UID of the backup run
   * @param attemptNumber the snapshot attempt number
   * @return list of vm backup volume snapshots
   */
  @GET
  @Path("/{vmUuid}/backup-runs/{backupRunUid}/volumes")
  FilesystemVolumeListResponse listBackupVolumeSnapshots(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid, @PathParam("backupRunUid") String backupRunUid,
      @QueryParam("attemptNumber") Integer attemptNumber);

  /**
   * Gets a directory listing for a VM backup snapshot.
   *
   * @param vmUuid        the UUID of the VM
   * @param backupRunUid  the UID of the backup run that the snapshot is associated with
   * @param volumeName    the name of the volume
   * @param directoryPath the full directory path to list
   * @param filters       optional query filters
   * @return vm backup directory listing
   */
  @GET
  @Path("/{vmUuid}/backup-runs/{backupRunUid}/volumes/{volumeName}/directories/{directoryPath}/contents")
  DirectoryListingResponse listBackupDirectoryContents(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid, @PathParam("backupRunUid") String backupRunUid,
      @PathParam("volumeName") @Encoded String volumeName,
      @PathParam("directoryPath") @Encoded String directoryPath,
      @BeanParam ListBackupSnapshotFilesAndFoldersFilters filters);

  /**
   * Generates a new downloadable bundle (ZIP archive) of a collection of
   * file snapshots. The returned task includes a {@code download_token} in its
   * {@code otherAttributes} which can be used with the prepared download
   * endpoint. Query the task individually via GET /tasks/{uuid} to retrieve
   * the token after creation.
   *
   * @param vmUuid the UUID of the VM
   * @param params the specification for which files to download
   * @return asynchronous task that indicates eventual completion and
   * success/failure
   */
  @POST
  @Path("/{vmUuid}/actions/generate-backup-file-download-bundle")
  TaskResponse generateBackupFileDownloadBundle(
      @SecureEntityRef(Permission.COPY_MOVE_RESTORE_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid, GenerateBackupFileDownloadBundleParams params);

  /**
   * Downloads the backup file bundle (ZIP archive) that is associated with the
   * specified bundle task.
   *
   * @param vmUuid   the UUID of the VM
   * @param taskUuid the UUID of the bundle task
   * @return zip archive content
   */
  @GET
  @Path("/{vmUuid}/backup-file-download-bundles/{taskUuid}")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream downloadBackupFileDownloadBundle(
      @SecureEntityRef(Permission.COPY_MOVE_RESTORE_ILAND_CLOUD_VM) @PathParam("vmUuid")
          String vmUuid, @PathParam("taskUuid") String taskUuid);

  /**
   * Restores a VM backup.
   *
   * @param vmUuid the UUID of the VM
   * @param params restoration parameters
   * @return the restore task, used to track the asynchronous operation
   */
  @SkipSecurityTest("custom security logic in EJB")
  @POST
  @Path("/{vmUuid}/actions/restore-vm-backup")
  TaskResponse restoreVMBackup(
      @SecureEntityRef(Permission.COPY_MOVE_RESTORE_ILAND_CLOUD_VM)
      @PathParam("vmUuid") String vmUuid, RestoreVMBackupParams params);

}
