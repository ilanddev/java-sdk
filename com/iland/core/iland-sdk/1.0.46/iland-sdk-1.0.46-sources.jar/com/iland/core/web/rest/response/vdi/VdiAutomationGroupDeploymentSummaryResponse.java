/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vdi;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VDI Automation Group Deployment Summary Response.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public class VdiAutomationGroupDeploymentSummaryResponse
    implements Serializable {

  private static final long serialVersionUID = -8724504049192071454L;

  @Expose
  @JsonRequired("The unique identifier for the VDI automation group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String automationGroupUuid;

  @Expose
  @JsonRequired("The name of the automation group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String automationGroupName;

  @Expose
  @JsonRequired("The number of pending deploys for the automation group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int numberOfPendingDeploys;

  @Expose
  @JsonRequired("The number of ready deployments for the automation group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int numberOfReadyDeployments;

  @Expose
  @JsonRequired("The number of pending undeployments for the automation group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int numberOfPendingUndeploys;

  @Expose
  @JsonRequired("The number of failed deployments for the automation group.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int numberOfFailedDeploys;

  /**
   * Instantiates a new Vdi automation group deployment summary response.
   *
   * @param automationGroupUuid      the automation group uuid
   * @param automationGroupName      the automation group name
   * @param numberOfPendingDeploys   the number of pending deploys
   * @param numberOfReadyDeployments the number of ready deployments
   * @param numberOfPendingUndeploys the number of pending undeploys
   * @param numberOfFailedDeploys    the number of failed deploys
   */
  public VdiAutomationGroupDeploymentSummaryResponse(
      final String automationGroupUuid, final String automationGroupName,
      final int numberOfPendingDeploys, final int numberOfReadyDeployments,
      final int numberOfPendingUndeploys, final int numberOfFailedDeploys) {
    this.automationGroupUuid = automationGroupUuid;
    this.automationGroupName = automationGroupName;
    this.numberOfPendingDeploys = numberOfPendingDeploys;
    this.numberOfReadyDeployments = numberOfReadyDeployments;
    this.numberOfPendingUndeploys = numberOfPendingUndeploys;
    this.numberOfFailedDeploys = numberOfFailedDeploys;
  }

  /**
   * Gets automation group uuid.
   *
   * @return the automation group uuid
   */
  public String getAutomationGroupUuid() {
    return automationGroupUuid;
  }

  /**
   * Gets automation group name.
   *
   * @return the automation group name
   */
  public String getAutomationGroupName() {
    return automationGroupName;
  }

  /**
   * Gets number of pending deploys.
   *
   * @return the number of pending deploys
   */
  public int getNumberOfPendingDeploys() {
    return numberOfPendingDeploys;
  }

  /**
   * Gets number of ready deployments.
   *
   * @return the number of ready deployments
   */
  public int getNumberOfReadyDeployments() {
    return numberOfReadyDeployments;
  }

  /**
   * Gets number of pending undeploys.
   *
   * @return the number of pending undeploys
   */
  public int getNumberOfPendingUndeploys() {
    return numberOfPendingUndeploys;
  }

  /**
   * Gets number of failed deploys.
   *
   * @return the number of failed deploys
   */
  public int getNumberOfFailedDeploys() {
    return numberOfFailedDeploys;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final VdiAutomationGroupDeploymentSummaryResponse that =
        (VdiAutomationGroupDeploymentSummaryResponse) o;
    return numberOfPendingDeploys == that.numberOfPendingDeploys
        && numberOfReadyDeployments == that.numberOfReadyDeployments
        && numberOfPendingUndeploys == that.numberOfPendingUndeploys
        && numberOfFailedDeploys == that.numberOfFailedDeploys && Objects
        .equals(automationGroupUuid, that.automationGroupUuid) && Objects
        .equals(automationGroupName, that.automationGroupName);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(automationGroupUuid, automationGroupName, numberOfPendingDeploys,
            numberOfReadyDeployments, numberOfPendingUndeploys,
            numberOfFailedDeploys);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("automationGroupUuid", automationGroupUuid)
        .add("automationGroupName", automationGroupName)
        .add("numberOfPendingDeploys", numberOfPendingDeploys)
        .add("numberOfReadyDeployments", numberOfReadyDeployments)
        .add("numberOfPendingUndeploys", numberOfPendingUndeploys)
        .add("numberOfFailedDeploys", numberOfFailedDeploys).toString();
  }
}
