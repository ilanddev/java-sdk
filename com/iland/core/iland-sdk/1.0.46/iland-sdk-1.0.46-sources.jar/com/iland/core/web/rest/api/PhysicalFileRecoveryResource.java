/*
 * Copyright (c) 2013,2014 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 205 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.cohesity.iaas.backups.common.model.BaseVdcUuid;
import com.iland.cohesity.iaas.backups.common.model.VdcUuid;
import com.iland.cohesity.iaas.backups.protectionsources.PublicProtectionSource;
import com.iland.cohesity.iaas.backups.recovery.PhysicalFileRecoveryApi;
import com.iland.cohesity.iaas.backups.recovery.model.DirectoryListing;
import com.iland.cohesity.iaas.backups.recovery.model.DirectoryListingParams;
import com.iland.cohesity.iaas.backups.recovery.model.IndexedObjectSearchResults;
import com.iland.cohesity.iaas.backups.recovery.model.IndexedObjectSnapshotFilters;
import com.iland.cohesity.iaas.backups.recovery.model.IndexedObjectSnapshots;
import com.iland.cohesity.iaas.backups.recovery.model.IndexedObjectsFileFilters;
import com.iland.cohesity.iaas.backups.recovery.model.PhysicalFileRecoveryRequest;
import com.iland.cohesity.iaas.backups.recovery.model.ProtectedObjectDirectoryListFilters;
import com.iland.cohesity.iaas.backups.recovery.model.ProtectedObjectSearchResults;
import com.iland.cohesity.iaas.backups.recovery.model.ProtectedObjectSnapshotFilters;
import com.iland.cohesity.iaas.backups.recovery.model.ProtectedObjectSnapshots;
import com.iland.cohesity.iaas.backups.recovery.model.ProtectedObjectsFilters;
import com.iland.cohesity.iaas.backups.recovery.model.VmDirectoryListing;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Physical File Recovery Resource Interface v1.
 */
@APIProperties(name = "Physical File Recovery")
@Path("/vdcs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
@PlatformApi
public interface PhysicalFileRecoveryResource extends PhysicalFileRecoveryApi {

  /**
   * Searches for recoverable indexed objects within the vDC.
   *
   * @param vdcUuid {@link VdcUuid} the UUID of the vDC
   * @param filters {@link IndexedObjectSnapshotFilters} filters
   * @return {@link IndexedObjectSearchResults} a list of indexed objects
   */
  @POST
  @Path("/{vdcUuid}/search-indexed-objects")
  IndexedObjectSearchResults searchIndexedObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
      BaseVdcUuid vdcUuid, IndexedObjectsFileFilters filters);

  /**
   * Lists available snapshots for an indexed object.
   *
   * @param vdcUuid {@link VdcUuid the UUID of the vDC}
   * @param filters {@link IndexedObjectSnapshotFilters snapshot filters}
   * @return {@link IndexedObjectSnapshots a list of snapshots}
   */
  @POST
  @Path("/{vdcUuid}/list-indexed-object-snapshots")
  IndexedObjectSnapshots listIndexedObjectSnapshots(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
      BaseVdcUuid vdcUuid, IndexedObjectSnapshotFilters filters);

  /**
   * Searches for physical protected objects within a VDC, i.e. a registered
   * agent or {@link PublicProtectionSource protection source}.
   *
   * @param vdcUuid {@link VdcUuid the UUID of the vDC}
   * @param filters {@link ProtectedObjectsFilters filters}
   * @return the {@link ProtectedObjectSearchResults search results}
   */
  @POST
  @Path("/{vdcUuid}/search-protected-objects-physical")
  default ProtectedObjectSearchResults searchPhysicalProtectedObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
      BaseVdcUuid vdcUuid, ProtectedObjectsFilters filters) {
    return PhysicalFileRecoveryApi.super.searchPhysicalProtectedObjects(vdcUuid,
        filters);
  }

  /**
   * Searches for protected objects within a VDC. Reserved for future use.
   *
   * @param vdcUuid {@link VdcUuid the UUID of the vDC}
   * @param filters {@link ProtectedObjectsFilters filters}
   * @return the {@link ProtectedObjectSearchResults search results}
   */
  @POST
  @Path("/{vdcUuid}/search-protected-objects")
  ProtectedObjectSearchResults searchProtectedObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
      BaseVdcUuid vdcUuid, ProtectedObjectsFilters filters);

  /**
   * Lists available snapshots for a protected object.
   *
   * @param vdcUuid {@link VdcUuid the UUID of the vDC}
   * @param filters {@link ProtectedObjectSnapshotFilters snapshot filters}
   * @return a {@link ProtectedObjectSnapshots list of snapshots}
   */
  @POST
  @Path("/{vdcUuid}/list-protected-object-snapshots")
  ProtectedObjectSnapshots listProtectedObjectSnapshots(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
      BaseVdcUuid vdcUuid, ProtectedObjectSnapshotFilters filters);

  /**
   * Lists files and folders for a given protected object and backup run.
   *
   * @param vdcUuid {@link VdcUuid the UUID of the vDC}
   * @param filters {@link ProtectedObjectDirectoryListFilters directory list filters}
   * @return the {@link VmDirectoryListing directory listing}
   */
  @POST
  @Path("/{vdcUuid}/list-protected-object-files")
  VmDirectoryListing listProtectedObjectFiles(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
      BaseVdcUuid vdcUuid, ProtectedObjectDirectoryListFilters filters);

  /**
   * Lists files and folders for a given protected object and backup run.
   *
   * @param vdcUuid {@link VdcUuid the UUID of the vDC}
   * @param filters {@link DirectoryListingParams directory list filters}
   * @return the {@link DirectoryListing directory listing}
   */
  @POST
  @Path("/{vdcUuid}/list-protected-files")
  DirectoryListing listProtectedFiles(
	  @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") BaseVdcUuid vdcUuid,
      DirectoryListingParams filters);

  /**
   * Recover physical files. Files may be recovered to the original source or
   * to a new source.
   *
   * @param vdcUuid {@link VdcUuid the UUID of the vDC}
   * @param request {@link PhysicalFileRecoveryRequest physical file recovery request}
   * @return the {@link TaskResponse task response}
   */
  @POST
  @Path("/{vdcUuid}/actions/restore-physical-files")
  TaskResponse createRecoveryTask(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") BaseVdcUuid vdcUuid,
      PhysicalFileRecoveryRequest request);

}
