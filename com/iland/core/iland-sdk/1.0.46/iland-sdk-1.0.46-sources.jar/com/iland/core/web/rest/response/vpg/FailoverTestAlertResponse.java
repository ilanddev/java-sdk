/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vpg;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Failover Test Alert Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class FailoverTestAlertResponse implements Serializable {

  private static final long serialVersionUID = 7014323154667281745L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vpgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String username;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String email;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int weeksBeforeAlert;

  public FailoverTestAlertResponse(final String vpgUuid, final String username,
      final String email, final int weeksBeforeAlert) {
    this.vpgUuid = vpgUuid;
    this.username = username;
    this.email = email;
    this.weeksBeforeAlert = weeksBeforeAlert;
  }

  /**
   * Get the VPG uuid that the alert is for.
   *
   * @return {@link String} vpg uuid
   */
  public String getVpgUuid() {
    return vpgUuid;
  }

  /**
   * Get the username that the alert is for.
   *
   * @return {@link String} username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Get the email associated with the alert.
   *
   * @return {@link String} email address
   */
  public String getEmail() {
    return email;
  }

  /**
   * Get the number of weeks that must elapse without a test failover before an
   * alert is emailed.
   *
   * @return weeks before alert after last test failover
   */
  public int getWeeksBeforeAlert() {
    return weeksBeforeAlert;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((email == null) ? 0 : email.hashCode());
    result = prime * result + ((username == null) ? 0 : username.hashCode());
    result = prime * result + ((vpgUuid == null) ? 0 : vpgUuid.hashCode());
    result = prime * result + weeksBeforeAlert;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    FailoverTestAlertResponse other = (FailoverTestAlertResponse) obj;
    if (email == null) {
      if (other.email != null)
        return false;
    } else if (!email.equals(other.email))
      return false;
    if (username == null) {
      if (other.username != null)
        return false;
    } else if (!username.equals(other.username))
      return false;
    if (vpgUuid == null) {
      if (other.vpgUuid != null)
        return false;
    } else if (!vpgUuid.equals(other.vpgUuid))
      return false;
    if (weeksBeforeAlert != other.weeksBeforeAlert)
      return false;
    return true;
  }

}
