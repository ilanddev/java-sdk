/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.org;

import java.io.Serializable;
import java.time.Instant;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.response.common.IpRangeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.shared.network.FenceMode;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Org vDC Network Response
 *
 * @author <a href="mailto:aquinones@iland.com">Ari Quinones</a>
 */
@APIDoc
public class OrgVdcNetworkResponse extends EntityResponse
    implements Serializable {

  private static final long serialVersionUID = -6863175860350921628L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String orgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vdcUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String primaryDns;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String secondaryDns;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String dnsSuffix;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final FenceMode fenceMode;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String gateway;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String netmask;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<IpRangeResponse> ipRanges;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean inherited;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String parentNetworkUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String edgeUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean shared;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean retainNetInfoAcrossDeployments;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Boolean subInterface;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Boolean distributedInterface;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Boolean guestVlanAllowed;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Boolean nsxTBacked;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Boolean vdcGroupScoped;

  /**
   * Instantiates a new Org vDC Network Response.
   *
   * @param uuid                           the uuid
   * @param companyId                      the company id
   * @param name                           the name
   * @param deleted                        the deleted
   * @param deletedDate                    the deleted date
   * @param updatedDate                    the updated date
   * @param locationId                     the location id
   * @param orgUuid                        the org uuid
   * @param vdcUuid                        the vdc uuid
   * @param description                    the description
   * @param primaryDns                     the primary dns
   * @param secondaryDns                   the secondary dns
   * @param dnsSuffix                      the dns suffix
   * @param fenceMode                      the fence mode
   * @param gateway                        the gateway
   * @param netmask                        the netmask
   * @param ipRanges                       the ip ranges
   * @param inherited                      the inherited
   * @param parentNetworkUuid              the parent network uuid
   * @param edgeUuid                       the edge uuid
   * @param shared                         the shared
   * @param retainNetInfoAcrossDeployments the retain net info across deployments
   * @param subInterface                   the sub interface
   * @param distributedInterface           the distributed interface
   * @param guestVlanAllowed               the guest vlan allowed
   * @param vdcGroupScoped                 the vdc group scoped
   */
  public OrgVdcNetworkResponse(final String uuid, final String companyId,
      final String name, final boolean deleted, final Instant deletedDate,
      final Instant updatedDate, final String locationId, final String orgUuid,
      final String vdcUuid, final String description, final String primaryDns,
      final String secondaryDns, final String dnsSuffix,
      final FenceMode fenceMode, final String gateway, final String netmask,
      final Set<IpRangeResponse> ipRanges, final boolean inherited,
      final String parentNetworkUuid, final String edgeUuid,
      final boolean shared, final boolean retainNetInfoAcrossDeployments,
      final Boolean subInterface, final Boolean distributedInterface,
      final Boolean guestVlanAllowed, final Boolean nsxTBacked,
      final Boolean vdcGroupScoped) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.locationId = locationId;
    this.orgUuid = orgUuid;
    this.vdcUuid = vdcUuid;
    this.description = description;
    this.primaryDns = primaryDns;
    this.secondaryDns = secondaryDns;
    this.dnsSuffix = dnsSuffix;
    this.fenceMode = fenceMode;
    this.gateway = gateway;
    this.netmask = netmask;
    this.ipRanges = ipRanges;
    this.inherited = inherited;
    this.parentNetworkUuid = parentNetworkUuid;
    this.edgeUuid = edgeUuid;
    this.shared = shared;
    this.retainNetInfoAcrossDeployments = retainNetInfoAcrossDeployments;
    this.subInterface = subInterface;
    this.distributedInterface = distributedInterface;
    this.guestVlanAllowed = guestVlanAllowed;
    this.nsxTBacked = nsxTBacked;
    this.vdcGroupScoped = vdcGroupScoped;
  }

  /**
   * Get location id for Org vDC network response
   *
   * @return {@link String} location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Get org uuid for Org vDC network response
   *
   * @return {@link String} org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Get vDC uuid  for Org vDC network response
   *
   * @return {@link String} vdc uuid
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Get description for Org vDC network response
   *
   * @return {@link String} description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get primary dns for Org vDC network response
   *
   * @return {@link String} primary dns
   */
  public String getPrimaryDns() {
    return primaryDns;
  }

  /**
   * Get secondary dns for Org vDC network response
   *
   * @return {@link String} secondary dns
   */
  public String getSecondaryDns() {
    return secondaryDns;
  }

  /**
   * Get dns suffix for Org vDC network response
   *
   * @return {@link String} dns suffix
   */
  public String getDnsSuffix() {
    return dnsSuffix;
  }

  /**
   * Get fence mode response for Org vDC network response
   *
   * @return {@link FenceMode} fence mode response
   */
  public FenceMode getFenceMode() {
    return fenceMode;
  }

  /**
   * Get gatewary for Org vDC network response
   *
   * @return {@link String} gateway
   */
  public String getGateway() {
    return gateway;
  }

  /**
   * Get netmask for Org vDC network response
   *
   * @return {@link String} netmask
   */
  public String getNetmask() {
    return netmask;
  }

  /**
   * Get set of ip range response for Org vDC network response
   *
   * @return {@link Set} of {@link IpRangeResponse} ip ranges
   */
  public Set<IpRangeResponse> getIpRanges() {
    return ipRanges;
  }

  /**
   * Get inherited boolean for Org vDC network response
   *
   * @return boolean value
   */
  public boolean isInherited() {
    return inherited;
  }

  /**
   * Get parent network uuid for Org vDC network response
   *
   * @return {@link String} parent network uuid
   */
  public String getParentNetworkUuid() {
    return parentNetworkUuid;
  }

  /**
   * Get edge uuid for Org vDC network response
   *
   * @return {@link String} edge uuid
   */
  public String getEdgeUuid() {
    return edgeUuid;
  }

  /**
   * Get shared boolean for Org vDC network response
   *
   * @return boolean value
   */
  public boolean isShared() {
    return shared;
  }

  /**
   * Get retain net info across deployments boolean for Org vDC network response.
   *
   * @return the boolean
   */
  public boolean isRetainNetInfoAcrossDeployments() {
    return retainNetInfoAcrossDeployments;
  }

  /**
   * Get sub interface boolean for Org vDC network response.
   *
   * @return {@link Boolean} the boolean
   */
  public Boolean isSubInterface() {
    return subInterface;
  }

  /**
   * Get distributed interface boolean for Org vDC network response.
   *
   * @return {@link Boolean} the boolean
   */
  public Boolean isDistributedInterface() {
    return distributedInterface;
  }

  /**
   * Get guest vlan allowed boolean for Org vDC network response.
   *
   * @return {@link Boolean} the boolean
   */
  public Boolean isGuestVlanAllowed() {
    return guestVlanAllowed;
  }

  /**
   * Whether the Org vDC network is backed by NSX-T infrastructure.
   *
   * @return {@link Boolean}
   */
  public Boolean isNsxTBacked() {
    return nsxTBacked;
  }

  /**
   * Gets whether the Org vDC network is scoped to a vDC group.
   *
   * @return the boolean
   */
  public Boolean isVdcGroupScoped() {
    return vdcGroupScoped;
  }
}
