/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.event;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityTypeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Event Response.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public class EventResponse implements Serializable {

  private static final long serialVersionUID = -7311875554382992904L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String uuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final EventOwnerType ownerType;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String ownerId;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String entityUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String entityName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final EntityTypeResponse entityType;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final EventTypeResponse type;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final Instant timestamp;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String taskUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String initiatedByUsername;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String initiatedByFullName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String details;

  /**
   * Instantiates a new Event response.
   *
   * @param uuid                the uuid
   * @param ownerType           the owner type
   * @param ownerId             the owner id
   * @param entityUuid          the entity uuid
   * @param entityName          the entity name
   * @param entityType          the entity type
   * @param type                the type
   * @param timestamp           the timestamp
   * @param taskUuid            the task uuid
   * @param initiatedByUsername the initiated by username
   * @param initiatedByFullName the initiated by full name
   * @param details             the details
   */
  public EventResponse(final String uuid, final EventOwnerType ownerType,
      final String ownerId, final String entityUuid, final String entityName,
      final EntityTypeResponse entityType, final EventTypeResponse type,
      final Instant timestamp, final String taskUuid,
      final String initiatedByUsername, final String initiatedByFullName,
      final String details) {
    this.uuid = uuid;
    this.ownerType = ownerType;
    this.ownerId = ownerId;
    this.entityUuid = entityUuid;
    this.entityName = entityName;
    this.entityType = entityType;
    this.type = type;
    this.timestamp = timestamp;
    this.taskUuid = taskUuid;
    this.initiatedByUsername = initiatedByUsername;
    this.initiatedByFullName = initiatedByFullName;
    this.details = details;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets owner type.
   *
   * @return the owner type
   */
  public EventOwnerType getOwnerType() {
    return ownerType;
  }

  /**
   * Gets owner id.
   *
   * @return the owner id
   */
  public String getOwnerId() {
    return ownerId;
  }

  /**
   * Gets entity uuid.
   *
   * @return the entity uuid
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Gets entity type.
   *
   * @return the entity type
   */
  public EntityTypeResponse getEntityType() {
    return entityType;
  }

  /**
   * Gets type.
   *
   * @return the type
   */
  public EventTypeResponse getType() {
    return type;
  }

  /**
   * Gets timestamp.
   *
   * @return the timestamp
   */
  public Instant getTimestamp() {
    return timestamp;
  }

  /**
   * Gets task uuid.
   *
   * @return the task uuid
   */
  public String getTaskUuid() {
    return taskUuid;
  }

  /**
   * Gets initiated by username.
   *
   * @return the initiated by username
   */
  public String getInitiatedByUsername() {
    return initiatedByUsername;
  }

  /**
   * Gets initiated by full name.
   *
   * @return the initiated by full name
   */
  public String getInitiatedByFullName() {
    return initiatedByFullName;
  }

  /**
   * Gets details.
   *
   * @return the details
   */
  public String getDetails() {
    return details;
  }

  /**
   * The name of the entity at the time of the event.
   *
   * @return the name of the entity.
   */
  public String getEntityName() {
    return entityName;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final EventResponse that = (EventResponse) o;
    return Objects.equals(uuid, that.uuid) && ownerType == that.ownerType
        && Objects.equals(ownerId, that.ownerId) && Objects
        .equals(entityUuid, that.entityUuid) && Objects
        .equals(entityName, that.entityName) && entityType == that.entityType
        && type == that.type && Objects.equals(timestamp, that.timestamp)
        && Objects.equals(taskUuid, that.taskUuid) && Objects
        .equals(initiatedByUsername, that.initiatedByUsername) && Objects
        .equals(initiatedByFullName, that.initiatedByFullName) && Objects
        .equals(details, that.details);
  }

  @Override
  public int hashCode() {

    return Objects
        .hash(uuid, ownerType, ownerId, entityUuid, entityName, entityType,
            type, timestamp, taskUuid, initiatedByUsername, initiatedByFullName,
            details);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("EventResponse{");
    sb.append("uuid='").append(uuid).append('\'');
    sb.append(", ownerType=").append(ownerType);
    sb.append(", ownerId='").append(ownerId).append('\'');
    sb.append(", entityUuid='").append(entityUuid).append('\'');
    sb.append(", entityType=").append(entityType);
    sb.append(", type=").append(type);
    sb.append(", timestamp=").append(timestamp);
    sb.append(", taskUuid='").append(taskUuid).append('\'');
    sb.append(", initiatedByUsername='").append(initiatedByUsername)
        .append('\'');
    sb.append(", initiatedByFullName='").append(initiatedByFullName)
        .append('\'');
    sb.append(", details=").append(details);
    sb.append('}');
    return sb.toString();
  }

}
