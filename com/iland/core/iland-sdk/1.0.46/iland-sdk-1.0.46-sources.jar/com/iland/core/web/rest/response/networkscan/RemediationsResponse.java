/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscan;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Remediations.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public final class RemediationsResponse {

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private List<RemediationResponse> remediations;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int numHosts;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int numCves;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int numImpactedHosts;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int numRemediatedCves;

	public RemediationsResponse(final List<RemediationResponse> remediations,
		final int numHosts, final int numCves, final int numImpactedHosts,
		final int numRemediatedCves) {
		this.remediations = remediations;
		this.numHosts = numHosts;
		this.numCves = numCves;
		this.numImpactedHosts = numImpactedHosts;
		this.numRemediatedCves = numRemediatedCves;
	}

	/**
	 * Get a list of remediations.
	 *
	 * @return {@link List} of {@link RemediationResponse} instances
	 */
	public List<RemediationResponse> getRemediations() {
		return remediations;
	}

	/**
	 * Get the number of hosts.
	 *
	 * @return number of hosts
	 */
	public int getNumHosts() {
		return numHosts;
	}

	/**
	 * Get the number of CVEs.
	 *
	 * @return number of CVE's
	 */
	public int getNumCves() {
		return numCves;
	}

	/**
	 * Get the number of impacted hosts.
	 *
	 * @return number of impacted hosts
	 */
	public int getNumImpactedHosts() {
		return numImpactedHosts;
	}

	/**
	 * Get the number of remediated CVE's.
	 *
	 * @return number or remediated CVEs
	 */
	public int getNumRemediatedCves() {
		return numRemediatedCves;
	}

}
