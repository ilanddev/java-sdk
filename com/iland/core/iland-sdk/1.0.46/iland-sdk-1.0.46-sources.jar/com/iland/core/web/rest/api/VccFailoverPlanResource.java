/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.vcctenant.VccFailoverStartCreateRequest;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vcctenant.VccFailoverPlanResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Failover plan resource.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIProperties(name = "Disaster Recovery")
@Path("/vcc-failover-plans")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface VccFailoverPlanResource {

  /**
   * Test failover for a VCC Failover Plan.
   *
   * @param failoverPlanUuid the failover Plan unique identifier
   * @return asynchronous task details
   */
  @SkipSecurityTest("yield.")
  @POST
  @Path("/{failoverPlanUuid}/actions/failover-test")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse failoverTest(
      @SecureEntityRef(Permission.TEST_ILAND_CLOUD_VCC_FAILOVER_PLAN)
      @PathParam("failoverPlanUuid") String failoverPlanUuid);

  /**
   * Start a VCC failover.
   *
   * @param failoverPlanUuid the UUID of the VCC Failover Plan.
   * @param spec             the failover start parameters
   * @return asynchronous task details
   */
  @SkipSecurityTest("yield..")
  @POST
  @Path("/{failoverPlanUuid}/actions/failover-start")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse failoverStart(
      @SecureEntityRef(Permission.START_ILAND_CLOUD_VCC_FAILOVER_PLAN)
      @PathParam("failoverPlanUuid") String failoverPlanUuid,
      VccFailoverStartCreateRequest spec);

  /**
   * Undo an in-progress VCC failover.
   *
   * @param failoverPlanUuid the UUID of the VCC Failover Plan.
   * @return asynchronous task details
   */
  @SkipSecurityTest("yield..")
  @POST
  @Path("/{failoverPlanUuid}/actions/failover-undo")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse failoverUndo(
      @SecureEntityRef(Permission.UNDO_ILAND_CLOUD_VCC_FAILOVER_PLAN)
      @PathParam("failoverPlanUuid") String failoverPlanUuid);

  /**
   * Gets a VCC Failover Plan by UUID.
   *
   * @param failoverPlanUuid the UUID of the VCC-R failover plan.
   * @return the VCC-R failover plan
   */
  @GET
  @Path("/{failoverPlanUuid}")
  VccFailoverPlanResponse getFailoverPlan(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VCC_FAILOVER_PLAN)
      @PathParam("failoverPlanUuid") String failoverPlanUuid);

}
