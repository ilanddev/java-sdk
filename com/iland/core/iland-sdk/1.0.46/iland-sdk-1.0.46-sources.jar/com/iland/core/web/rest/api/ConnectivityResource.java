/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;


import java.util.List;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.connectivity.api.device.DeviceApi;
import com.iland.connectivity.api.instance.BgpApi;
import com.iland.connectivity.api.instance.CatoNetworkInterfaceApi;
import com.iland.connectivity.api.instance.CatoTunnelsApi;
import com.iland.connectivity.api.instance.IpsecVpnTunnelApi;
import com.iland.connectivity.api.instance.NetworkInterfaceApi;
import com.iland.connectivity.api.metric.PerformanceApi;
import com.iland.connectivity.api.model.PerfDatasource;
import com.iland.connectivity.api.model.PerfMetric;
import com.iland.connectivity.api.model.TicketSortField;
import com.iland.connectivity.api.ticket.TicketApi;
import com.iland.connectivity.core.web.rest.response.AlertResponse;
import com.iland.connectivity.core.web.rest.response.BgpResponse;
import com.iland.connectivity.core.web.rest.response.CatoNetworkInterfaceResponse;
import com.iland.connectivity.core.web.rest.response.CatoTunnelsResponse;
import com.iland.connectivity.core.web.rest.response.DeviceResponse;
import com.iland.connectivity.core.web.rest.response.IpsecVpnTunnelResponse;
import com.iland.connectivity.core.web.rest.response.NetworkInterfaceResponse;
import com.iland.connectivity.core.web.rest.response.PerfCounterResponse;
import com.iland.connectivity.core.web.rest.response.PerfSampleResponse;
import com.iland.connectivity.core.web.rest.response.SupportTicketResponse;
import com.iland.connectivity.core.web.rest.response.VlanNetworkInterfaceResponse;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Connectivity Resource.
 *
 * @author <a href="mailto:nkasprzak@1111systems.com">Nick Kasprzak</a>
 */
@APIProperties(name = "Connectivity")
@Path("/connectivity")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface ConnectivityResource
    extends DeviceApi, BgpApi, PerformanceApi, NetworkInterfaceApi, TicketApi,
    IpsecVpnTunnelApi, CatoNetworkInterfaceApi, CatoTunnelsApi {

  /**
   * Get the connectivity devices for the given company.
   *
   * @param companyId company id
   */
  @GET
  @Path("/{companyId}/devices")
  Set<DeviceResponse> getDevicesForCompany(
      @SecureEntityRef(Permission.VIEW_COMPANY)
      @PathParam("companyId")
      String companyId);

  /**
   * Get the specified device given its id.
   *
   * @param deviceId device id
   */
  @GET
  @Path("/devices/{deviceUuid}")
  DeviceResponse getDevice(@SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
  @PathParam("deviceUuid") String deviceId);

  /**
   * Retrieves the performance counters for a specific device identified by its UUID.
   *
   * @param deviceUuid The UUID of the device for which performance counters are to be retrieved.
   * @return A set of PerfCounterResponse objects representing the performance counters for the device.
   */
  @GET
  @Path("/devices/{deviceUuid}/performance-counters")
  Set<PerfCounterResponse> getDevicePerformanceCounters(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid);

  /**
   * Retrieves the performance counters for a specific Border Gateway Protocol (BGP) identified by its UUID.
   *
   * @param bgpUuid The UUID of the BGP for which performance counters are to be retrieved.
   * @return A set of PerfCounterResponse objects representing the performance counters for the BGP.
   */
  @GET
  @Path("/bgp/{deviceUuid}/{bgpUuid}/performance-counters")
  Set<PerfCounterResponse> getBgpPerformanceCounters(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid,
      @PathParam("bgpUuid") String bgpUuid);

  /**
   * Retrieves the performance samples for a specific entity identified by its UUID, data source, and metric within a given time range.
   *
   * @param companyId      The company id for which the entity belongs to.
   * @param uuid           The UUID of the entity for which performance samples are to be retrieved.
   * @param perfDatasource The data source of the performance samples.
   * @param perfMetric     The metric of the performance samples.
   * @param start          The start time of the time range for which performance samples are to be retrieved.
   * @param end            The end time of the time range for which performance samples are to be retrieved.
   * @return A set of PerfSampleResponse objects representing the performance samples for the specified entity.
   */
  @GET
  @Path("/{companyId}/performance/{uuid}/{dataSource}::{metric}")
  List<PerfSampleResponse> getPerformanceSamples(
      @SecureEntityRef(Permission.VIEW_COMPANY) @PathParam("companyId")
      String companyId, @PathParam("uuid") String uuid,
      @PathParam("dataSource") PerfDatasource perfDatasource,
      @PathParam("metric") PerfMetric perfMetric,
      @QueryParam("start") Long start, @QueryParam("end") Long end);

  /**
   * Retrieves the Border Gateway Protocol (BGP) information for a specific device identified by its UUID.
   *
   * @param deviceUuid The UUID of the device for which BGP information is to be retrieved.
   * @return A list of BgpResponse objects representing the BGP information for the device.
   */
  @GET
  @Path("/devices/{deviceUuid}/bgp")
  List<BgpResponse> getBgpForDevice(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid);

  /**
   * Retrieves the Cato Tunnels information for a specific
   * device identified by its UUID.
   *
   * @param deviceUuid The UUID of the device.
   * @return A list of cato tunnels for the device.
   */
  @GET
  @Path("/devices/{deviceUuid}/cato-sdwan-tunnels")
  Set<CatoTunnelsResponse> getCatoTunnelsForDevice(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid);

  /**
   * Retrieves the Cato Interfaces information for a specific
   * device identified by its UUID.
   *
   * @param deviceUuid The UUID of the device.
   * @return A list of cato interfaces for the device
   */
  @GET
  @Path("/devices/{deviceUuid}/cato-sdwan-interfaces")
  Set<CatoNetworkInterfaceResponse> getCatoNetworkInterfacesForDevice(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid);

  /**
   * Retrieves the IPSec VPN Tunnels information for a specific device identified by its UUID.
   *
   * @param deviceUuid The UUID of the device.
   * @return A list of IpsecVpnTunnelResponse objects representing the tunnels for the device.
   */
  @GET
  @Path("/devices/{deviceUuid}/ipsec-vpn-tunnels")
  Set<IpsecVpnTunnelResponse> getIpsecVpnTunnelForDevice(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid);

  /**
   * Retrieves a set of performance counters for IPSec VPN Tunnels associated with the specified UUID.
   *
   * @param deviceUuid         the UUID of the device the IPSec VPN Tunnel belongs to.
   * @param ipsecVpnTunnelUuid the UUID of the tunnel for which to retrieve performance counters
   * @return a set of {@link PerfCounterResponse} objects representing the performance counters
   * for the specified vpn tunnel
   */
  @GET
  @Path("/ipsec-vpn-tunnel/{deviceUuid}/{ipsecVpnTunnelUuid}/performance-counters")
  Set<PerfCounterResponse> getPerformanceCountersForIpsecVpnTunnel(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid,
      @PathParam("ipsecVpnTunnelUuid") String ipsecVpnTunnelUuid);

  /**
   * Retrieves a set of alerts associated with a specific device identified by its UUID.
   *
   * @param deviceUuid The unique identifier (UUID) of the device for which alerts are being requested.
   * @param offset     The starting point for the pagination of results. Defaults to 0.
   * @param limit      The maximum number of alerts to return. Defaults to 25.
   * @param filter     A string used to filter the alerts based on specific criteria.
   * @return A set of the alerts associated with the specified device.
   */
  @GET
  @Path("/devices/{deviceUuid}/alerts")
  List<AlertResponse> getAlertsForDevice(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid,
      @QueryParam("offset") Integer offset, @QueryParam("limit") Integer limit,
      @QueryParam("filter") String filter);

  /**
   * Retrieves a list of ServiceNow tickets, each one associated with a specific alert from a company.
   *
   * @param companyId The unique identifier (UUID) of the company for which tickets are being requested.
   * @param offset    The starting point for the pagination of results. Defaults to 0.
   * @param limit     The maximum number of tickets to return. Defaults to 25.
   * @param filter    A string used to filter the tickets: "priority" and "closed".
   * @param sort      A {@link TicketSortField} which designates the sorting order for the tickets
   * @return A list of the tickets associated with the specified device.
   */
  @GET
  @Path("/support-tickets/{companyId}")
  List<SupportTicketResponse> getTicketsForCompany(
      @SecureEntityRef(Permission.VIEW_COMPANY)
      @PathParam("companyId") String companyId,
      @QueryParam("offset") Integer offset, @QueryParam("limit") Integer limit,
      @QueryParam("filter") String filter,
      @QueryParam("sort") TicketSortField sort);

  /**
   * Retrieves a list of ServiceNow tickets associated with a specific alert from a company's device.
   *
   * @param deviceUuid The company id, along with the device vendor id for which tickets are being requested.
   * @param offset     The starting point for the pagination of results. Defaults to 0.
   * @param limit      The maximum number of tickets to return. Defaults to 25.
   * @param filter     A string used to filter the tickets: "priority" and "closed".
   * @param sort      A {@link TicketSortField} which designates the sorting order for the tickets
   * @return A list of the tickets associated with the specified device.
   */
  @GET
  @Path("/support-tickets/devices/{deviceUuid}")
  List<SupportTicketResponse> getTicketsForDevice(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid,
      @QueryParam("offset") Integer offset, @QueryParam("limit") Integer limit,
      @QueryParam("filter") String filter,
      @QueryParam("sort") TicketSortField sort);

  /**
   * Retrieves a set of network interfaces associated with a specific device identified by its UUID.
   *
   * @param deviceUuid The unique identifier (UUID) of the device for which network interfaces are being requested.
   * @return A set of  network interfaces associated with the specified device. If no network interfaces are found, an empty set is returned.
   */
  @GET
  @Path("/devices/{deviceUuid}/network-interfaces")
  Set<NetworkInterfaceResponse> getNetworkInterfacesForDevice(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid);

  /**
   * Retrieves a set of VLAN network interfaces associated with a specific device identified by its UUID.
   *
   * @param deviceUuid The unique identifier (UUID) of the device for which VLAN network interfaces are being requested.
   *                   This value is used to identify the device.
   * @return A set of VLAN network interfaces associated with the specified device. If no VLAN network interfaces are found, an empty set is returned.
   */
  @GET
  @Path("/devices/{deviceUuid}/vlan-network-interfaces")
  Set<VlanNetworkInterfaceResponse> getVlanNetworkInterfacesForDevice(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid);

  /**
   * Retrieves a set of performance counters for network interfaces associated with the specified network UUID.
   *
   * @param deviceUuid the uuid of the device the network belongs to.
   * @param netUuid the UUID of the network for which to retrieve performance counters
   * @return a set of {@link PerfCounterResponse} objects representing the performance counters
   * for the specified network interfaces
   */
  @GET
  @Path("/network/{deviceUuid}/{netUuid}/performance-counters")
  Set<PerfCounterResponse> getPerformanceCountersForNetworkInterfaces(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid,
      @PathParam("netUuid") String netUuid);

  /**
   * Retrieves a set of performance counters for network interfaces associated with the specified VLAN UUID.
   *
   * @param deviceUuid the uuid of the device the vlan belongs to.
   * @param vlanUuid the UUID of the VLAN for which to retrieve performance counters
   * @return a set of {@link PerfCounterResponse} objects representing the performance counters
   * for the specified VLAN network interfaces
   */
  @GET
  @Path("/network/{deviceUuid}/{vlanUuid}/performance-counters")
  Set<PerfCounterResponse> getPerformanceCountersForVlanNetworkInterfaces(
      @SecureEntityRef(Permission.VIEW_CONNECTIVITY_DEVICE)
      @PathParam("deviceUuid") String deviceUuid,
      @PathParam("vlanUuid") String vlanUuid);

}
