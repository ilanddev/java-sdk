/*
 * Copyright (c) 2025, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.notification;

import java.util.List;

import com.iland.core.api.notification.types.CohesityContinuityStorageAlertTrigger;
import com.iland.core.web.rest.response.common.ListResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Cohesity Continuity Resource Alert List Response.
 */
@APIDoc
public class UserCohesityContinuityResourceAlertListResponse
	extends ListResponse<CohesityContinuityStorageAlertTrigger> {

	public UserCohesityContinuityResourceAlertListResponse(
		final List<CohesityContinuityStorageAlertTrigger> data) {
		super(data);
	}

}
