/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.event;

import java.util.Objects;

import com.iland.core.api.event.AwsAccountBucketCreationEventMetadata;
import com.iland.core.api.event.AwsAccountKeyCreationEventMetadata;
import com.iland.core.api.event.AwsAccountKeyDeleteEventMetadata;
import com.iland.core.api.event.AwsAccountKeyDescriptionUpdateEventMetadata;
import com.iland.core.api.event.AwsAccountKeyDisableEventMetadata;
import com.iland.core.api.event.AwsAccountKeyEnableEventMetadata;
import com.iland.core.api.event.AwsAccountKeyRotateEventMetadata;
import com.iland.core.api.event.AwsAccountUpdateEventMetadata;
import com.iland.core.api.event.AwsS3IncreaseStorageEventMetadata;

/**
 * Aws Event response types. Each one corresponds to a different metadata type
 * and will return a different set of AWS Event Optional fields. It should have
 * the same name as the {@link EventTypeResponse}, as it works as a convenience
 * sublist for better search purposes.
 */
public enum AwsEventTypeResponse {

  S3_STORAGE_ACCOUNT_KEY_CREATE(
      AwsAccountKeyCreationEventMetadata.class.getSimpleName()),

  S3_STORAGE_ACCOUNT_KEY_DESCRIPTION_UPDATE(
      AwsAccountKeyDescriptionUpdateEventMetadata.class.getSimpleName()),

  S3_STORAGE_ACCOUNT_KEY_ENABLE(
      AwsAccountKeyEnableEventMetadata.class.getSimpleName()),

  S3_STORAGE_ACCOUNT_KEY_DISABLE(
      AwsAccountKeyDisableEventMetadata.class.getSimpleName()),

  S3_STORAGE_ACCOUNT_KEY_ROTATE(
      AwsAccountKeyRotateEventMetadata.class.getSimpleName()),

  S3_STORAGE_ACCOUNT_KEY_DELETE(
      AwsAccountKeyDeleteEventMetadata.class.getSimpleName()),

  S3_STORAGE_INCREASE(AwsS3IncreaseStorageEventMetadata.class.getSimpleName()),

  S3_STORAGE_ACCOUNT_BUCKET_CREATE(
      AwsAccountBucketCreationEventMetadata.class.getSimpleName()),

  S3_STORAGE_ACCOUNT_UPDATE(
      AwsAccountUpdateEventMetadata.class.getSimpleName()),

  /**
   * This status is a fallback and should never happen.
   */
  UNKNOWN(null);

  private final String className;

  AwsEventTypeResponse(final String className) {
    this.className = className;
  }

  public static AwsEventTypeResponse of(String className) {
    for (AwsEventTypeResponse a : values()) {
      if (Objects.equals(className, a.className)) {
        return a;
      }
    }
    return UNKNOWN;
  }
}
