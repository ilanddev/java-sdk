/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vappnetwork;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Network Static Routing Service Impl.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappNetworkStaticRoutingServiceResponse implements Serializable {

  private static final long serialVersionUID = -3158357536805032198L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vappUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String networkName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean enabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<VappNetworkStaticRouteResponse> staticRoutes;

  public VappNetworkStaticRoutingServiceResponse(final String vappUuid,
      final String networkName, final boolean enabled,
      final List<VappNetworkStaticRouteResponse> staticRoutes) {
    this.vappUuid = vappUuid;
    this.networkName = networkName;
    this.enabled = enabled;
    if (staticRoutes == null) {
      this.staticRoutes = new ArrayList<>();
    } else {
      this.staticRoutes = staticRoutes;
    }
  }

  /**
   * Gets the unique UUID of the associated VCD Edge.
   *
   * @return {@link String} edge UUID
   */
  public String getVappUuid() {
    return vappUuid;
  }

  /**
   * Get the network name associated with the static routing service.
   *
   * @return {@link String} network name
   */
  public String getNetworkName() {
    return networkName;
  }

  /**
   * Indicates whether the static routes are enabled.
   *
   * @return boolean
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Gets the list of static routes.
   *
   * @return {@link List} of {@link VappNetworkStaticRouteResponse}
   */
  public List<VappNetworkStaticRouteResponse> getRoutes() {
    return staticRoutes;
  }

}
