/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vm;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.DiskTypeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Recommended Disk Bus Type Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class RecommendedDiskBusTypeResponse implements Serializable {

  private static final long serialVersionUID = 217620041835713737L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final DiskTypeResponse busType;

  /**
   * Instantiates a new recommended disk bus type.
   *
   * @param busType the bus type
   */
  public RecommendedDiskBusTypeResponse(final DiskTypeResponse busType) {
    this.busType = busType;
  }

  /**
   * Gets the bus type.
   *
   * @return the bus type
   */
  public DiskTypeResponse getBusType() {
    return busType;
  }

}
