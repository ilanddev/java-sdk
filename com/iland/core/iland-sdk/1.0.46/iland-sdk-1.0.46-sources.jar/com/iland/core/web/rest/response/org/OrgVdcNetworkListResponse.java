/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.org;

import java.util.List;

import com.iland.core.web.rest.response.common.ListResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Org vDC Network List Response
 *
 * @author <a href="mailto:aquinones@iland.com">Ari Quinones</a>
 */
@APIDoc
public class OrgVdcNetworkListResponse
    extends ListResponse<OrgVdcNetworkResponse> {

  public OrgVdcNetworkListResponse(final List<OrgVdcNetworkResponse> data) {
    super(data);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object)
      return true;
    if (object == null || getClass() != object.getClass())
      return false;
    if (!super.equals(object))
      return false;
    OrgVdcNetworkListResponse that = (OrgVdcNetworkListResponse) object;
    if (data != null ? !data.equals(that.data) : that.data != null)
      return false;
    return true;
  }

  @Override
  public int hashCode() {
    int result = super.hashCode();
    result = 31 * result + (data != null ? data.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "OrgVdcNetworkListResponse{" + "data=" + data + '}';
  }

}
