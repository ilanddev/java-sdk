/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vappnetwork;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Network Interface Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappNetworkInterfaceResponse implements Serializable {

  private static final long serialVersionUID = -2478909721373162045L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vappUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vappNetworkUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int vnicId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String ipAddress;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmLocalId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean ipTranslationMapped;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmName;

  public VappNetworkInterfaceResponse(final String vappUuid,
      final String vappNetworkUuid, final String vmUuid, final int vnicId,
      final String ipAddress, final String vmLocalId,
      final boolean ipTranslationMapped, final String vmName) {
    this.vappUuid = vappUuid;
    this.vappNetworkUuid = vappNetworkUuid;
    this.vmUuid = vmUuid;
    this.vnicId = vnicId;
    this.ipAddress = ipAddress;
    this.vmLocalId = vmLocalId;
    this.ipTranslationMapped = ipTranslationMapped;
    this.vmName = vmName;
  }

  /**
   * Get the vApp uuid.
   *
   * @return {@link String} vApp uuid
   */
  public String getVappUuid() {
    return vappUuid;
  }

  /**
   * Get the vApp network uuid.
   *
   * @return {@link String} vApp network uuid
   */
  public String getVappNetworkUuid() {
    return vappNetworkUuid;
  }

  /**
   * Get the VM uuid.
   *
   * @return {@link String} vm uuid
   */
  public String getVmUuid() {
    return vmUuid;
  }

  /**
   * Get the VNIC id.
   *
   * @return vnic id on the VM
   */
  public int getVnicId() {
    return vnicId;
  }

  /**
   * Get the IP address mapped to the interface
   *
   * @return ip address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Get the VM local ID of vm the vnic is mapped to.
   *
   * @return {@link String} vm local id
   */
  public String getVmLocalId() {
    return vmLocalId;
  }

  /**
   * Get whether the interface is already ip translation mapped.
   *
   * @return boolean whether the network interface is already mapped to an ip
   * translation NAT rule
   */
  public boolean isIpTranslationMapped() {
    return ipTranslationMapped;
  }

  /**
   * Get the VM name assocatied with the interface.
   *
   * @return {@link String} vm name
   */
  public String getVmName() {
    return vmName;
  }

}
