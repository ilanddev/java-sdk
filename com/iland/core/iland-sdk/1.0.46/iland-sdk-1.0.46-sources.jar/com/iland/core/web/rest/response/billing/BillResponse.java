/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.billing.BillingModelType;
import com.iland.core.web.rest.response.common.EntityTypeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.shared.billing.CurrencyCode;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * BillResponse.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class BillResponse implements Serializable {

  private static final long serialVersionUID = -1441909998633087844L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private ResourceCostAndUsageResponse bandwidth;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private ResourceCostAndUsageResponse cpu;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private ResourceCostAndUsageResponse memory;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private DiskCostAndUsageResponse disk;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double totalCost;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private double totalCostEstimate;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int year;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int month;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String entityUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String entityName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private EntityTypeResponse entityType;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<BillLineItemResponse> lineItems;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private CurrencyCode currencyCode;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean testDrive;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The type of billing model applied on this bill.")
  private BillingModelType billingModelType;

  public BillResponse(final ResourceCostAndUsageResponse bandwidth,
      final ResourceCostAndUsageResponse cpu,
      final ResourceCostAndUsageResponse memory,
      final DiskCostAndUsageResponse disk, final double totalCost,
      final double totalCostEstimate, final int year, final int month,
      final String entityUuid, final String entityName,
      final EntityTypeResponse entityType,
      final List<BillLineItemResponse> lineItems,
      final CurrencyCode currencyCode, final boolean testDrive,
      final BillingModelType billingModelType) {
    this.bandwidth = bandwidth;
    this.cpu = cpu;
    this.memory = memory;
    this.disk = disk;
    this.totalCost = totalCost;
    this.totalCostEstimate = totalCostEstimate;
    this.year = year;
    this.month = month;
    this.entityUuid = entityUuid;
    this.entityName = entityName;
    this.entityType = entityType;
    this.lineItems = lineItems;
    this.currencyCode = currencyCode;
    this.testDrive = testDrive;
    this.billingModelType = billingModelType;
  }

  /**
   * Get the bandwidth cost and usage.
   *
   * @return bandwidth cost and usage
   */
  public ResourceCostAndUsageResponse getBandwidth() {
    return bandwidth;
  }

  /**
   * Get the CPU cost and usage.
   *
   * @return CPU cost and usage
   */
  public ResourceCostAndUsageResponse getCpu() {
    return cpu;
  }

  /**
   * Get the memory cost and usage.
   *
   * @return memory cost and usage
   */
  public ResourceCostAndUsageResponse getMemory() {
    return memory;
  }

  /**
   * Get the disk cost and usage.
   *
   * @return disk cost and usage
   */
  public DiskCostAndUsageResponse getDisk() {
    return disk;
  }

  /**
   * Get the total cost.
   *
   * @return total cost
   */
  public double getTotalCost() {
    return totalCost;
  }

  /**
   * Get the end of month total cost estimate.
   *
   * @return end of month cost estimate
   */
  public double getTotalCostEstimate() {
    return totalCostEstimate;
  }

  /**
   * Get the billing year.
   *
   * @return year
   */
  public int getYear() {
    return year;
  }

  /**
   * Get the billing month.
   *
   * @return billing month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Get the entity name.
   *
   * @return entity name
   */
  public String getEntityName() {
    return entityName;
  }

  /**
   * Get the enitity UUID.
   *
   * @return entity UUID
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Get the entity type.
   *
   * @return {@link String} entity type
   */
  public EntityTypeResponse getEntityType() {
    return entityType;
  }

  /**
   * Get the line items for the bill.
   *
   * @return {@link List} of {@link BillLineItemResponse} bill line items
   */
  public List<BillLineItemResponse> getLineItems() {
    return lineItems;
  }

  /**
   * Get the currency code.
   *
   * @return currency code
   */
  public CurrencyCode getCurrencyCode() {
    return currencyCode;
  }

  /**
   * Get the test drive flag.
   *
   * @return whether this is a test drive
   */
  public boolean isTestDrive() {
    return testDrive;
  }

  /**
   * Returns the type of the billing model applied on this bill
   *
   * @return one of {@link BillingModelType}
   */
  public BillingModelType getBillingModelType() {
    return billingModelType;
  }


}
