/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Guest Customization Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class GuestCustomizationResponse implements Serializable {

  private static final long serialVersionUID = 1109169761591387625L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean enabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean changeSid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String virtualMachineId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean joinDomain;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean useOrgSettings;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String domainName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String domainUserName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String domainUserPassword;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName("machine_object_ou")
  private final String machineObjectOU;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean adminPasswordEnabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean adminPasswordAuto;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String adminPassword;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean adminAutoLogonEnabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int adminAutoLogonCount;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean resetPasswordRequired;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String computerName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean required;

  public GuestCustomizationResponse(final Boolean enabled,
      final Boolean changeSid, final String virtualMachineId,
      final Boolean joinDomain, final Boolean useOrgSettings,
      final String domainName, final String domainUserName,
      final String domainUserPassword, final String machineObjectOU,
      final Boolean adminPasswordEnabled, final Boolean adminPasswordAuto,
      final String adminPassword, final Boolean adminAutoLogonEnabled,
      final Integer adminAutoLogonCount, final Boolean resetPasswordRequired,
      final String computerName, final Boolean required) {
    if (enabled == null) {
      this.enabled = false;
    } else {
      this.enabled = enabled;
    }
    if (changeSid == null) {
      this.changeSid = false;
    } else {
      this.changeSid = changeSid;
    }
    this.virtualMachineId = virtualMachineId;
    if (joinDomain == null) {
      this.joinDomain = false;
    } else {
      this.joinDomain = joinDomain;
    }
    if (useOrgSettings == null) {
      this.useOrgSettings = false;
    } else {
      this.useOrgSettings = useOrgSettings;
    }
    this.domainName = domainName;
    this.domainUserName = domainUserName;
    this.domainUserPassword = domainUserPassword;
    this.machineObjectOU = machineObjectOU;
    if (adminPasswordEnabled == null) {
      this.adminPasswordEnabled = false;
    } else {
      this.adminPasswordEnabled = adminPasswordEnabled;
    }
    if (adminPasswordAuto == null) {
      this.adminPasswordAuto = false;
    } else {
      this.adminPasswordAuto = adminPasswordAuto;
    }
    this.adminPassword = adminPassword;
    if (adminAutoLogonEnabled == null) {
      this.adminAutoLogonEnabled = false;
    } else {
      this.adminAutoLogonEnabled = adminAutoLogonEnabled;
    }
    if (adminAutoLogonCount == null) {
      this.adminAutoLogonCount = 0;
    } else {
      this.adminAutoLogonCount = adminAutoLogonCount;
    }
    if (resetPasswordRequired == null) {
      this.resetPasswordRequired = false;
    } else {
      this.resetPasswordRequired = resetPasswordRequired;
    }
    this.computerName = computerName;
    if (required == null) {
      this.required = false;
    } else {
      this.required = required;
    }
  }

  /**
   * Whether guest customization is enabled.
   *
   * @return is enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Whether to change SID.
   *
   * @return is change SID.
   */
  public boolean isChangeSid() {
    return changeSid;
  }

  /**
   * Get the virtual machine ID.
   *
   * @return {@link String} virtual machine id
   */
  public String getVirtualMachineId() {
    return virtualMachineId;
  }

  /**
   * Whether join domain is enabled.
   *
   * @return is join domain enabled
   */
  public boolean isJoinDomain() {
    return joinDomain;
  }

  /**
   * Whether to use org settings.
   *
   * @return is use org settings
   */
  public boolean isUseOrgSettings() {
    return useOrgSettings;
  }

  /**
   * Get the domain name.
   *
   * @return {@link String} domain name
   */
  public String getDomainName() {
    return domainName;
  }

  /**
   * Get domain user name.
   *
   * @return {@link String} domain user name
   */
  public String getDomainUserName() {
    return domainUserName;
  }

  /**
   * Get domain user password.
   *
   * @return {@link String} domain user password
   */
  public String getDomainUserPassword() {
    return domainUserPassword;
  }

  /**
   * Get the machine object OU.
   *
   * @return {@link String} machine object OU
   */
  public String getMachineObjectOU() {
    return machineObjectOU;
  }

  /**
   * Whether the admin password is enabled.
   *
   * @return admin password enabled
   */
  public boolean isAdminPasswordEnabled() {
    return adminPasswordEnabled;
  }

  /**
   * Whether the admin password is auto.
   *
   * @return admin password auto
   */
  public boolean isAdminPasswordAuto() {
    return adminPasswordAuto;
  }

  /**
   * Get the admin password.
   *
   * @return {@link String} admin password
   */
  public String getAdminPassword() {
    return adminPassword;
  }

  /**
   * Whether admin auto logon is enabled.
   *
   * @return admin auto logon enabled
   */
  public boolean isAdminAutoLogonEnabled() {
    return adminAutoLogonEnabled;
  }

  /**
   * Get the admin auto logon count.
   *
   * @return admin auto logon count
   */
  public int getAdminAutoLogonCount() {
    return adminAutoLogonCount;
  }

  /**
   * Whether reset password is required.
   *
   * @return password reset required
   */
  public boolean isResetPasswordRequired() {
    return resetPasswordRequired;
  }

  /**
   * Get the computer name.
   *
   * @return {@link String} computer name
   */
  public String getComputerName() {
    return computerName;
  }

  /**
   * Whether required.
   *
   * @return required
   */
  public boolean isRequired() {
    return required;
  }

}
