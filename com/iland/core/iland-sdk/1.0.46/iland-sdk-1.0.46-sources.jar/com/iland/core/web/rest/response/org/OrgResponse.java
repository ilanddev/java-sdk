/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.org;

import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Organization Response.
 *
 * @author <a href="mailto:bsnyderhj@iland.com">Brett Snyder</a>
 */
@APIDoc
public class OrgResponse extends EntityResponse {

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String locationId;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean enabled;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int vappMaxRuntimeLease;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int vappMaxStorageLease;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int vappTemplateMaxStorageLease;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean vappDeleteOnStorageExpire;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean vappTemplateDeleteOnStorageExpire;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean zertoTarget;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean vccrTarget;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String fullname;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String description;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String vcloudHref;

  /**
   * Instantiates a new Org.
   *
   * @param uuid                              the uuid
   * @param companyId                         the company ID
   * @param deleted                           the deleted
   * @param deletedDate                       the deleted date
   * @param name                              the name
   * @param updatedDate                       the updated date
   * @param description                       the description
   * @param enabled                           the enabled
   * @param fullname                          the fullname
   * @param locationId                        the location id
   * @param vappDeleteOnStorageExpire         the vapp delete on storage expire
   * @param vappMaxRuntimeLease               the vapp max runtime lease
   * @param vappMaxStorageLease               the vapp max storage lease
   * @param vappTemplateDeleteOnStorageExpire the vapp template delete on
   *                                          storage expire
   * @param vappTemplateMaxStorageLease       the vapp template max storage lease
   * @param vcloudHref                        the vcloud href
   * @param zertoTarget                       true of false
   * @param vccrTarget                        true or false
   */
  public OrgResponse(final String uuid, final String companyId,
      final boolean deleted, final Instant deletedDate, final String name,
      final Instant updatedDate, final String description,
      final boolean enabled, final String fullname, final String locationId,
      final boolean vappDeleteOnStorageExpire, final int vappMaxRuntimeLease,
      final int vappMaxStorageLease,
      final boolean vappTemplateDeleteOnStorageExpire,
      final int vappTemplateMaxStorageLease, final String vcloudHref,
      final boolean zertoTarget, final boolean vccrTarget) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.description = description;
    this.enabled = enabled;
    this.fullname = fullname;
    this.locationId = locationId;
    this.vappDeleteOnStorageExpire = vappDeleteOnStorageExpire;
    this.vappMaxRuntimeLease = vappMaxRuntimeLease;
    this.vappMaxStorageLease = vappMaxStorageLease;
    this.vappTemplateDeleteOnStorageExpire = vappTemplateDeleteOnStorageExpire;
    this.vappTemplateMaxStorageLease = vappTemplateMaxStorageLease;
    this.vcloudHref = vcloudHref;
    this.zertoTarget = zertoTarget;
    this.vccrTarget = vccrTarget;
  }

  /**
   * Gets location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Is enabled boolean.
   *
   * @return the boolean
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Gets vapp max runtime lease.
   *
   * @return the vapp max runtime lease
   */
  public int getVappMaxRuntimeLease() {
    return vappMaxRuntimeLease;
  }

  /**
   * Gets vapp max storage lease.
   *
   * @return the vapp max storage lease
   */
  public int getVappMaxStorageLease() {
    return vappMaxStorageLease;
  }

  /**
   * Gets vapp template max storage lease.
   *
   * @return the vapp template max storage lease
   */
  public int getVappTemplateMaxStorageLease() {
    return vappTemplateMaxStorageLease;
  }

  /**
   * Is vapp delete on storage expire boolean.
   *
   * @return the boolean
   */
  public boolean isVappDeleteOnStorageExpire() {
    return vappDeleteOnStorageExpire;
  }

  /**
   * Is vapp template delete on storage expire boolean.
   *
   * @return the boolean
   */
  public boolean isVappTemplateDeleteOnStorageExpire() {
    return vappTemplateDeleteOnStorageExpire;
  }

  /**
   * Is zerto target boolean.
   *
   * @return the boolean
   */
  public boolean isZertoTarget() {
    return zertoTarget;
  }

  /**
   * Is VCC-R target?
   *
   * @return the boolean
   */
  public boolean isVccrTarget() {
    return vccrTarget;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets fullname.
   *
   * @return the fullname
   */
  public String getFullname() {
    return fullname;
  }

  /**
   * Gets vcloud href.
   *
   * @return the vcloud href
   */
  public String getVcloudHref() {
    return vcloudHref;
  }

  @Override
  public String getName() {
    return fullname;
  }

}
