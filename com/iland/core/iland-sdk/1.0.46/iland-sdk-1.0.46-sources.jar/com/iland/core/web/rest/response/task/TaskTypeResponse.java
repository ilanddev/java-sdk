/*
 * Copyright (c) 2024, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the "LICENSE.txt" file that accompanied this software. Any inquiries
 *  concerning the scope or enforceability of the license should be addressed
 *  to:
 *
 *  11:11 Systems Inc.
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 */

package com.iland.core.web.rest.response.task;

/**
 * Task Type Reseponse.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
public enum TaskTypeResponse {
  ILAND("iland"),

  REPORTING("reporting"),

  VCD("vcd"),

  VEEAM("veeam"),

  VCCR("vcc-r"),

  VI("vi"),

  ZERTO("zerto"),

  CATALOG_UPLOAD("catalog-upload"),

  VAC("vac"),

  IAAS_BACKUP("iaas-backup"),

  O365_RESTORE("o365-restore");

  private final String value;

  TaskTypeResponse(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  public static TaskTypeResponse fromValue(final String value) {
    if (value != null) {
      for (final TaskTypeResponse b : TaskTypeResponse.values()) {
        if (value.equalsIgnoreCase(b.value)) {
          return b;
        }
      }
    }
    return null;
  }

}
