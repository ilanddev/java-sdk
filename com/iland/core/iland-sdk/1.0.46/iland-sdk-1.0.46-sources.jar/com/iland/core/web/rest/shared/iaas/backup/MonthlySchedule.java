/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Objects;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.policies.api.enums.Day;
import com.iland.cohesity.iaas.backups.policies.api.enums.DayCount;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Monthly Schedule.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class MonthlySchedule implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Specifies the day of the week (such as 'MONDAY') to start the Group Run. Used
   * with day count to define the day in the month to start the Group Run.
   * Specifies a day in a week such as 'SUNDAY', 'MONDAY', etc.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the day of the week (such as 'MONDAY') to "
      + "start the Group Run. Used with day count to define the day in the "
      + "month to start the Group Run. Specifies a day in a week such as "
      + "'SUNDAY', 'MONDAY', etc.")
  private final Day day;

  /**
   * Specifies the day count in the month (such as 'THIRD') to start the Group
   * Run. Used in combination with day to define the day in the month to start
   * the Group Run. Specifies the day count in the month to start the backup.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the day count in the month (such as 'THIRD') "
      + "to start the Group Run. Used in combination with day to define the"
      + " day in the month to start the Group Run. Specifies the day count "
      + "in the month to start the backup.")
  private final DayCount dayCount;

  /**
   * Instantiates a new Monthly schedule.
   *
   * @param day      the day
   * @param dayCount the day count
   */
  public MonthlySchedule(final Day day, final DayCount dayCount) {
    this.day = day;
    this.dayCount = dayCount;
  }

  /**
   * Gets day.
   *
   * @return the day
   */
  public Day getDay() {
    return day;
  }

  /**
   * Gets day count.
   *
   * @return the day count
   */
  public DayCount getDayCount() {
    return dayCount;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final MonthlySchedule that = (MonthlySchedule) o;
    return day == that.day && dayCount == that.dayCount;
  }

  @Override
  public int hashCode() {
    return Objects.hash(day, dayCount);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("day", day)
        .add("dayCount", dayCount).toString();
  }
}
