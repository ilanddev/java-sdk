/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.event;

import java.util.List;

import com.iland.core.web.rest.response.common.PagedListResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Event List Response.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public class EventListResponse
    extends PagedListResponse<EventResponse, EventFilterParams> {

  private static final long serialVersionUID = 8832695002170594373L;

  /**
   * Instantiates a new Event list response.
   *
   * @param data              the data
   * @param currentParameters the current parameters
   * @param totalRecords      the total records
   */
  public EventListResponse(final List<EventResponse> data,
      final EventFilterParams currentParameters,
      final EventFilterParams nextParameters, final long totalRecords) {
    super(data, currentParameters, nextParameters, totalRecords);
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("EventListResponse{");
    sb.append("currentPageParameters=").append(currentPageParameters);
    sb.append(", nextPageParameters=").append(nextPageParameters);
    sb.append(", totalRecords=").append(totalRecords);
    sb.append(", data=").append(data);
    sb.append('}');
    return sb.toString();
  }

}
