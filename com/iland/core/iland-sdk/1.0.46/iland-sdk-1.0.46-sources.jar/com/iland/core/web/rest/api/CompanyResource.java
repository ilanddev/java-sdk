/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SecureProductRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.iam.EnforceTwoFactorAuthForUserRequest;
import com.iland.core.web.rest.request.iam.EnforceTwoFactorAuthRequest;
import com.iland.core.web.rest.request.iam.ResetTwoFactorAuthRequest;
import com.iland.core.web.rest.request.iam.RoleCreateRequest;
import com.iland.core.web.rest.request.iam.RoleUpdateRequest;
import com.iland.core.web.rest.request.user.InviteUserEmailSet;
import com.iland.core.web.rest.request.user.SSOUserCreateRequest;
import com.iland.core.web.rest.request.user.SSOUserCreateRequestSet;
import com.iland.core.web.rest.request.user.UserCreateRequest;
import com.iland.core.web.rest.request.user.UserCreateRequestSet;
import com.iland.core.web.rest.response.billing.CloudTenantBillHistoryResponse;
import com.iland.core.web.rest.response.common.StringListResponse;
import com.iland.core.web.rest.response.company.CompanyResponse;
import com.iland.core.web.rest.response.company.CompanyUserListResponse;
import com.iland.core.web.rest.response.iam.CompanyAdminCountResponse;
import com.iland.core.web.rest.response.iam.CompanyTwoFactorAuthSettingsResponse;
import com.iland.core.web.rest.response.iam.RoleListResponse;
import com.iland.core.web.rest.response.iam.RoleResponse;
import com.iland.core.web.rest.response.search.SearchResultResponse;
import com.iland.core.web.rest.response.user.UserCreationSetResponse;
import com.iland.core.web.rest.response.user.UserResponse;
import com.iland.core.web.rest.response.vac.BaCompanySetResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Company Resource Interface.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Companies")
@Path("/companies")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface CompanyResource {

  /**
   * Gets a company.
   *
   * @param companyId the company identifier
   * @return the company details
   */
  @GET
  @Path("/{companyId}")
  CompanyResponse getCompany(@PathParam("companyId") String companyId);

  /**
   * Creates a new user for a company.
   *
   * @param createRequest new user details
   * @return created user
   */
  @POST
  @Path("/{companyId}/users")
  @Consumes(MediaType.APPLICATION_JSON)
  UserResponse createUser(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId,
      UserCreateRequest createRequest);

  /**
   * Create a new SSO user for a company.
   *
   * @param companyId     company to create users in
   * @param createRequest new user details
   * @return created user
   */
  @POST
  @Path("/{companyId}/sso-user")
  @Consumes(MediaType.APPLICATION_JSON)
  UserResponse createSSOUser(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId, SSOUserCreateRequest createRequest);

  /**
   * Create multiple users for a company.
   *
   * @param companyId            company to create users in
   * @param userCreateRequestSet set of new user details
   */
  @POST
  @Path("/{companyId}/users-batch")
  @Consumes(MediaType.APPLICATION_JSON)
  UserCreationSetResponse createUsers(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId, UserCreateRequestSet userCreateRequestSet);

  /**
   * Create multiple SSO users for a company.
   *
   * @param companyId               company to create users in
   * @param ssoUserCreateRequestSet set of new SSO user details
   */
  @POST
  @Path("/{companyId}/users-sso-batch")
  @Consumes(MediaType.APPLICATION_JSON)
  UserCreationSetResponse createSSOUsers(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId, SSOUserCreateRequestSet ssoUserCreateRequestSet);

  /**
   * Create multiple users from a file.
   *
   * To see an example of a valid CSV file
   * see {@link #downloadExampleUserCreationCSVFile(String, boolean)} where
   * the boolean is set to false.
   *
   * @param companyId   company to create users in
   * @param userCSVFile file to import users from
   */
  @POST
  @Path("/{companyId}/create-users-from-file")
  @Consumes(MediaType.APPLICATION_JSON)
  UserCreationSetResponse createUsersFromFile(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId, byte[] userCSVFile);

  /**
   * Create multiple SSO users from a CSV file.
   *
   * To see an example of valid CSV
   * file see {@link #downloadExampleUserCreationCSVFile(String, boolean)}
   * where the SSO boolean flag is set to true.
   *
   * @param companyId  company to create users in
   * @param ssoCSVFile file to import users from
   */
  @POST
  @Path("/{companyId}/create-sso-users-from-file")
  @Consumes(MediaType.APPLICATION_JSON)
  UserCreationSetResponse createSSOUsersFromFile(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId, byte[] ssoCSVFile);

  /**
   * Download an example of the user creation CSV file.
   *
   * Will include all the domains and all the roles you can use.
   *
   * @param companyId company of the example csv file
   * @return example CSV file for user creation
   */
  @POST
  @Path("/{companyId}/download-user-create-csv-example")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream downloadExampleUserCreationCSVFile(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId,  @QueryParam("ssoUsers") boolean ssoUsers);

  /**
   * Gets all users for a company.
   *
   * @param companyId the company identifier
   * @return list of the companies users
   */
  @GET
  @Path("/{companyId}/users")
  CompanyUserListResponse getUsers(
      @SecureEntityRef(Permission.VIEW_COMPANY_IAM) @PathParam("companyId")
          String companyId, @QueryParam("role") String roleId);

  /**
   * Creates a new role for a company.
   *
   * @param companyId           the company ID
   * @param roleCreationRequest data object specifying new role parameters
   * @return created role
   */
  @POST
  @Path("/{companyId}/roles")
  @Consumes(MediaType.APPLICATION_JSON)
  RoleResponse createRole(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId,
      RoleCreateRequest roleCreationRequest);

  /**
   * Gets all company roles.
   *
   * @param companyId the company ID
   * @param domain    optional user domain to scope the role list to. When
   *                  supplied, must be one of the domain strings returned by
   *                  {@link #getUserDomains(String)} for this company. If the
   *                  domain is not an MSPShared domain, the
   *                  {@code MSP Company Administrator} role is omitted from the
   *                  response.
   * @return the list of company roles
   */
  @GET
  @Path("/{companyId}/roles")
  RoleListResponse getRoles(
      @SecureEntityRef(Permission.VIEW_COMPANY_IAM) @PathParam("companyId")
          String companyId, @QueryParam("domain") String domain);

  /**
   * Gets a company role by ID.
   *
   * @param companyId the company ID
   * @param roleId    the role ID
   * @return the role details
   */
  @GET
  @Path("/{companyId}/roles/{roleId}")
  RoleResponse getRoleResponse(
      @SecureEntityRef(Permission.VIEW_COMPANY_IAM) @PathParam("companyId")
          String companyId, @PathParam("roleId") String roleId);

  /**
   * Modifies a company role.
   *
   * @param companyId         the company ID
   * @param roleId            the role ID
   * @param roleUpdateRequest data object with role update parameters
   * @return the role details
   */
  @PUT
  @Path("/{companyId}/roles/{roleId}")
  @Consumes(MediaType.APPLICATION_JSON)
  RoleResponse updateRole(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId, @PathParam("roleId") String roleId,
      RoleUpdateRequest roleUpdateRequest);

  /**
   * Deletes a company role.
   *
   * @param companyId the company ID
   * @param roleId    the role ID
   */
  @DELETE
  @Path("/{companyId}/roles/{roleId}")
  void deleteRole(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId, @PathParam("roleId") String roleId);

  /**
   * Get the user domains that are associated with this company.
   *
   * @param companyId the company identifier
   * @return list of domains that are associated with the company
   */
  @GET
  @Path("/{companyId}/user-domains")
  StringListResponse getUserDomains(
      @SecureEntityRef(Permission.VIEW_COMPANY_IAM) @PathParam("companyId")
          String companyId);

  /**
   * Get the historical billing for a given company.
   *
   * @param companyId  the company identifier
   * @param locationId the location identifier (optional)
   * @param startYear  the year to start
   * @param startMonth the month to start (1-12)
   * @param endYear    the year to end with
   * @param endMonth   the month to end (1-12)
   * @return map of location to list of bills
   */
  @GET
  @Path("/{companyId}/vcc-backup-tenants-billing")
  CloudTenantBillHistoryResponse getCloudTenantBillingHistory(
      @SecureProductRef(Permission.VIEW_ILAND_BACKUP_BILLING)
      @PathParam("companyId")
          String companyId, @QueryParam("location") String locationId,
      @QueryParam("startYear") Integer startYear,
      @QueryParam("startMonth") Integer startMonth,
      @QueryParam("endYear") Integer endYear,
      @QueryParam("endMonth") Integer endMonth);

  /**
   * Get the historical VAC billing for a given company.
   *
   * @param companyId  the company identifier
   * @param locationId the location identifier (optional)
   * @param startYear  the year to start
   * @param startMonth the month to start (1-12)
   * @param endYear    the year to end with
   * @param endMonth   the month to end (1-12)
   * @return map of location to list of vac bills
   */
  @GET
  @Path("/{companyId}/vac-backup-tenants-billing")
  CloudTenantBillHistoryResponse getBaCompanyBillingHistory(
      @SecureProductRef(Permission.VIEW_ILAND_BACKUP_BILLING)
      @PathParam("companyId")
          String companyId, @QueryParam("location") String locationId,
      @QueryParam("startYear") Integer startYear,
      @QueryParam("startMonth") Integer startMonth,
      @QueryParam("endYear") Integer endYear,
      @QueryParam("endMonth") Integer endMonth);

  /**
   * Updates the company's logo.
   *
   * @param companyId    the company identifier
   * @param pictureBytes a JPEG image
   */
  @POST
  @Path("/{companyId}/logo")
  @Consumes("image/jpeg")
  void updateCompanyLogo(@SecureEntityRef(Permission.MANAGE_COMPANY_SETTINGS)
  @PathParam("companyId") String companyId, byte[] pictureBytes);

  /**
   * Removes the company's logo.
   *
   * @param companyId the company identifier
   */
  @DELETE
  @Path("/{companyId}/logo")
  void removeCompanyLogo(@SecureEntityRef(Permission.MANAGE_COMPANY_SETTINGS)
  @PathParam("companyId") String companyId);

  /**
   * Gets the company logo.
   *
   * @param companyId the company identifier
   * @return the picture as a byte array
   */
  @GET
  @Path("/{companyId}/logo")
  @Produces(IlandVersionedMediaType.V1_IMAGE_JPEG)
  InputStream getLogo(@PathParam("companyId") String companyId);

  /**
   * Perform a full-text search of entities pertaining to this company.
   *
   * @param companyId  the company identifier
   * @param query      query string
   *                   <p>
   *                   <br />
   *                   <p>
   *                   The query string accepts <a target="_blank" href=
   *                   "http://lucene.apache.org/core/2_9_4/queryparsersyntax.html" >Lucene
   *                   </a> style query input.
   *                   </p>
   *                   <br />
   *                   <p>
   *                   For example, to search for networks with IPs in the 10.10.10.X subnet
   *                   you would supply <em>'10.10.10.*'</em> as a query string. Tht *
   *                   represents a wildcard character and can be used anywhere in a query
   *                   EXCEPT for as the first character.
   *                   </p>
   *                   <br />
   *                   <p>
   *                   To search for multiple terms that <b>MUST</b> occur the AND operator
   *                   can be used. E.g. to find documents containing both 'network' and
   *                   'vapp' you would supply the query string <em>'network AND vapp'</em>
   *                   .
   *                   </p>
   * @param pageOffset page offset for return documents
   * @param pageSize   limit to number of hits (default value is 10 and maximum is
   *                   50)
   */
  @GET
  @Path("/{companyId}/search")
  SearchResultResponse search(@PathParam("companyId") String companyId,
      @QueryParam("query") String query,
      @QueryParam("pageOffset") int pageOffset,
      @QueryParam("pageSize") int pageSize);

  /**
   * Get all the VAC companies for a given company.
   *
   * @param companyId company id
   * @return a set of vac companies
   */
  @GET
  @Path("/{companyId}/vac-companies")
  BaCompanySetResponse getVacCompanies(
      @SecureEntityRef(Permission.VIEW_COMPANY) @PathParam("companyId")
          String companyId);

  /**
   * Enforce two factor authentication for the specified user.
   *
   * @param companyId company id
   * @param request  request to enforce two factor auth for user
   */
  @POST
  @Path("/{companyId}/actions/enforce-two-factor-auth")
  @SkipSecurityTest("Need custom test because security logic is in EJB")
  void enforceTwoFactorAuthForUser(@PathParam("companyId") String companyId,
      EnforceTwoFactorAuthForUserRequest request);

  /**
   * Reset two factor authentication for the specified user.
   *
   * After resetting
   * the user's two factor auth credentials, will default back to the global
   * settings for the company regarding two factor authentication.
   *
   * @param companyId company id
   * @param request request to reset two factor auth for user
   */
  @POST
  @Path("/{companyId}/actions/reset-two-factor-auth")
  @SkipSecurityTest("Need custom test because security logic is in EJB")
  void resetTwoFactorAuthForUser(@PathParam("companyId") String companyId,
      ResetTwoFactorAuthRequest request);

  /**
   * Set the two factor authentication settings for a company.
   *
   * Can either set
   * for all users in the company or for specified roles.
   *
   * @param companyId company id
   * @param request   request whether to enforce for all users or specified roles
   */
  @PUT
  @Path("/{companyId}/two-factor-auth-settings")
  @SkipSecurityTest("Need custom test because security logic is in EJB")
  void setCompanyTwoFactorAuthSettings(@PathParam("companyId") String companyId,
      EnforceTwoFactorAuthRequest request);

  /**
   * Get the specified company's two factor authentication settings.
   *
   * @param companyId company id
   * @return company's two factor auth settings
   */
  @GET
  @Path("/{companyId}/two-factor-auth-settings")
  CompanyTwoFactorAuthSettingsResponse getCompanyTwoFactorAuthSettings(
      @SecureEntityRef(Permission.VIEW_COMPANY_IAM) @PathParam("companyId")
          String companyId);

  /**
   * Send a user invitation email to the given user.
   *
   * @param companyId company id
   * @param username  user to send invite email to
   */
  @POST
  @Path("/{companyId}/actions/{username}/send-invite-email")
  void sendUserInvitationEmail(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId, @PathParam("username") String username);

  /**
   * Mark a given user without sending an invitation email.
   *
   * @param companyId company id
   * @param username  user to be marked as invited
   */
  @POST
  @Path("/{companyId}/actions/{username}/mark-as-invited")
  void markUserAsInvited(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId, @PathParam("username") String username);

  /**
   * Send user invitation emails to the given set of users.
   *
   * @param companyId company id
   * @param userNames users to send invite emails to
   */
  @POST
  @Path("/{companyId}/actions/send-invite-emails")
  void sendUsersInvitationEmails(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId, InviteUserEmailSet userNames);

  /**
   * Get the number of company admins in a given company.
   *
   * @param companyId company id
   * @return number of company admins in company
   */
  @GET
  @Path("/{companyId}/company-admin-count")
  CompanyAdminCountResponse getCompanyAdminCount(
      @SecureEntityRef(Permission.MANAGE_COMPANY_IAM) @PathParam("companyId")
          String companyId);

}
