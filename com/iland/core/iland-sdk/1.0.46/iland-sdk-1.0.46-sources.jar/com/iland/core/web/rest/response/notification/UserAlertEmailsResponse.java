/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.notification;

import java.io.Serializable;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Alert Emails Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserAlertEmailsResponse implements Serializable {

  private static final long serialVersionUID = -8608109613729790152L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String username;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Set<String> emails;

  public UserAlertEmailsResponse(final String username,
      final Set<String> emails) {
    this.username = username;
    this.emails = emails;
  }

  /**
   * Get the username.
   *
   * @return {@link String} username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Get the set of alerting emails.
   *
   * @return {@link Set} of {@link String} alerting email addressses
   */
  public Set<String> getEmails() {
    return emails;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserAlertEmailsResponse that = (UserAlertEmailsResponse) o;

    if (username != null ?
        !username.equals(that.username) :
        that.username != null)
      return false;
    return emails != null ? emails.equals(that.emails) : that.emails == null;
  }

  @Override
  public int hashCode() {
    int result = username != null ? username.hashCode() : 0;
    result = 31 * result + (emails != null ? emails.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "UserAlertEmailsResponse{" + "username='" + username + '\''
        + ", emails=" + emails + '}';
  }

}
