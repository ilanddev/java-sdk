/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vappnetwork;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Network NAT Service Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappNetworkNATServiceResponse implements Serializable {

  private static final long serialVersionUID = -949452730277319062L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vappUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String networkName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean enabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<VappNetworkIpTranslationNATRuleResponse> ipTranslationRules;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<VappNetworkPortForwardNATRuleResponse> portForwardingRules;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean enableIpMasquerade;

  public VappNetworkNATServiceResponse(final String vappUuid,
      final String networkName, final boolean enabled, final String type,
      final List<VappNetworkIpTranslationNATRuleResponse> ipTranslationRules,
      final List<VappNetworkPortForwardNATRuleResponse> portForwardingRules,
      final boolean enableIpMasquerade) {
    this.vappUuid = vappUuid;
    this.networkName = networkName;
    this.enabled = enabled;
    this.type = type;
    this.ipTranslationRules = ipTranslationRules;
    this.portForwardingRules = portForwardingRules;
    this.enableIpMasquerade = enableIpMasquerade;
  }

  /**
   * Get the vapp uuid.
   *
   * @return {@link String} vapp uuid
   */
  public String getVappUuid() {
    return vappUuid;
  }

  /**
   * Get the network name.
   *
   * @return {@link String} network name
   */
  public String getNetworkName() {
    return networkName;
  }

  /**
   * Get if NAT service is enabled.
   *
   * @return nat service enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Get the type of NAT service.
   * <p>
   * NOTE: ip translation mode (ipTranslation) or port forwarding mode
   * (portForwarding)
   *
   * @return {@link String} type of NAT service
   */
  public String getType() {
    return type;
  }

  /**
   * Get the list of Ip translation rules. (if this is an ip translation NAT
   * service).
   *
   * @return {@link List} of {@link VappNetworkIpTranslationNATRuleResponse} instance
   */
  public List<VappNetworkIpTranslationNATRuleResponse> getIpTranslationRules() {
    return ipTranslationRules;
  }

  /**
   * Get the list of port forwarding rules. (if this is an port forwarding NAT
   * service).
   *
   * @return {@link List} of {@link VappNetworkPortForwardNATRuleResponse} instance
   */
  public List<VappNetworkPortForwardNATRuleResponse> getPortForwardingRules() {
    return portForwardingRules;
  }

  /**
   * Get if NAT service allows IP masquerade.
   * <p>
   * NOTE: only applicable for a port forwarding NAT service.
   *
   * @return enabled ip masquerade
   */
  public boolean isEnableIpMasqerade() {
    return enableIpMasquerade;
  }

}
