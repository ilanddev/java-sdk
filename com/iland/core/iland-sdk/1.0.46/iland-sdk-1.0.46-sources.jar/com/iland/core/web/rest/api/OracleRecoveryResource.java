/*
 * Copyright (c) 2025, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.cohesity.iaas.backups.common.model.BaseVdcUuid;
import com.iland.cohesity.iaas.backups.common.model.RecoverableOracleSearchInformation;
import com.iland.cohesity.iaas.backups.recovery.OracleRecoveryApi;
import com.iland.cohesity.iaas.backups.recovery.model.OracleOverwriteOriginalTaskParams;
import com.iland.cohesity.iaas.backups.recovery.model.OracleRestoreAsNewDatabaseNewInstanceTaskParams;
import com.iland.cohesity.iaas.backups.recovery.model.SearchRecoverableOracleSnapshotsFilters;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Oracle Recovery Resource Interface.
 */
@APIProperties(name = "Oracle Recovery")
@Path("/vdcs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
@PlatformApi
public interface OracleRecoveryResource extends OracleRecoveryApi {

	/**
	 * Searches for recoverable Oracle snapshots within the vDC.
	 *
	 * @param vdcUuid the UUID of the vDC
	 * @param filters optional query filters
	 * @return a list of recoverable VM snapshots
	 */
	@POST
	@Path("/{vdcUuid}/recoverable-oracle-snapshots")
	RecoverableOracleSearchInformation searchRecoverableOracleSnapshots(
		@SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
		BaseVdcUuid vdcUuid, SearchRecoverableOracleSnapshotsFilters filters);

	/**
	 * Create a new Oracle recovery task that will overwrite the original database.
	 *
	 * @param vdcUuid the UUID of the vDC
	 * @param params  restoration parameters
	 * @return the restore task, used to track the asynchronous operation
	 */
	@POST
	@Path("/{vdcUuid}/actions/restore-oracle-snapshot-overwrite-original")
	TaskResponse createOracleRestoreOverwriteOriginalTask(
		@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
		@PathParam("vdcUuid") BaseVdcUuid vdcUuid,
		OracleOverwriteOriginalTaskParams params);

	/**
	 * Create a new Oracle recovery task that will create a new database on a
	 * different server instance from the original.
	 *
	 * @param vdcUuid the UUID of the vDC
	 * @param params  restoration parameters
	 * @return the restore task, used to track the asynchronous operation
	 */
	@POST
	@Path("/{vdcUuid}/actions/restore-oracle-snapshot-as-new-database")
	TaskResponse createOracleRestoreAsNewDatabaseTask(
		@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
		@PathParam("vdcUuid") BaseVdcUuid vdcUuid,
		OracleRestoreAsNewDatabaseNewInstanceTaskParams params);

}
