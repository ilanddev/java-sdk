/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vapptemplate;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Download Details.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappTemplateDownloadDetailsResponse implements Serializable {

  private static final long serialVersionUID = 5378953354480285968L;

  private static final String ENABLED = "enabled";

  private static final String NAME = "name";

  private static final String SIZE_IN_BYTES = "size_in_bytes";


  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(ENABLED)
  @Expose
  private final boolean enabled;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(NAME)
  @Expose
  private final String downloadName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(SIZE_IN_BYTES)
  @Expose
  private final Long downloadSizeBytes;

  /**
   * Instantiates a new Download details.
   *
   * @param enabled           the enabled
   * @param downloadName      the download name
   * @param downloadSizeBytes the download size bytes
   */
  public VappTemplateDownloadDetailsResponse(final boolean enabled,
      final String downloadName, final Long downloadSizeBytes) {
    this.enabled = enabled;
    this.downloadName = downloadName;
    this.downloadSizeBytes = downloadSizeBytes;
  }

  /**
   * Is enabled boolean.
   *
   * @return the boolean
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Gets download name.
   *
   * @return the download name
   */
  public String getName() {
    return downloadName;
  }

  /**
   * Gets download size bytes.
   *
   * @return the download size bytes
   */
  public Long getSizeInBytes() {
    return downloadSizeBytes;
  }

}
