/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Objects;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * OrgBackupStatusResponse.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public final class OrgBackupStatusResponse {

  @Expose
  @JsonRequired("The UUID of the org.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @JsonRequired("The backup status configuration for all child vDCs of the org.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<VdcBackupStatusResponse> childVdcStatuses;

  public OrgBackupStatusResponse(final String uuid,
      final Set<VdcBackupStatusResponse> childVdcStatuses) {
    this.uuid = uuid;
    this.childVdcStatuses = childVdcStatuses;
  }

  /**
   * Gets the UUID of the org.
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets backup status info for child vDCs.
   */
  public Set<VdcBackupStatusResponse> getChildVdcStatuses() {
    return childVdcStatuses;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final OrgBackupStatusResponse that = (OrgBackupStatusResponse) o;
    return Objects.equals(uuid, that.uuid) && Objects
        .equals(childVdcStatuses, that.childVdcStatuses);
  }

  @Override
  public int hashCode() {
    return Objects.hash(uuid, childVdcStatuses);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("uuid", uuid)
        .add("childVdcStatuses", childVdcStatuses).toString();
  }
}
