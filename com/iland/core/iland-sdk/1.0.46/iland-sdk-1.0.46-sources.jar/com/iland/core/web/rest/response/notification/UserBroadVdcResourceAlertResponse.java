/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.notification;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Broad Vdc Resource Alert Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserBroadVdcResourceAlertResponse implements Serializable {

  private static final long serialVersionUID = 1777266999658517873L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String username;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String vdcUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String group;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String name;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String type;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean active;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int threshold;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String vdcType;

  public UserBroadVdcResourceAlertResponse(final String username,
      final String vdcUuid, final String group, final String name,
      final String type, final boolean active, final int threshold,
      final String vdcType) {
    this.username = username;
    this.vdcUuid = vdcUuid;
    this.group = group;
    this.name = name;
    this.type = type;
    this.active = active;
    this.threshold = threshold;
    this.vdcType = vdcType;
  }

  /**
   * Get the vdc uuid.
   *
   * @return {@link String} vdc uuid
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Get the group.
   *
   * @return {@link String} group
   */
  public String getGroup() {
    return group;
  }

  /**
   * Get the name.
   *
   * @return {@link String} name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the type.
   *
   * @return {@link String} type
   */
  public String getType() {
    return type;
  }

  /**
   * Is active.
   *
   * @return is active
   */
  public boolean isActive() {
    return active;
  }

  /**
   * Get the threshold.
   *
   * @return {@link String} threshold
   */
  public long getThreshold() {
    return threshold;
  }

  /**
   * Get the username.
   *
   * @return {@link String} username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Get the vdc type.
   *
   * @return {@link String} vdc type
   */
  public String getVdcType() {
    return vdcType;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserBroadVdcResourceAlertResponse that =
        (UserBroadVdcResourceAlertResponse) o;

    if (active != that.active)
      return false;
    if (threshold != that.threshold)
      return false;
    if (username != null ?
        !username.equals(that.username) :
        that.username != null)
      return false;
    if (vdcUuid != null ? !vdcUuid.equals(that.vdcUuid) : that.vdcUuid != null)
      return false;
    if (group != null ? !group.equals(that.group) : that.group != null)
      return false;
    if (name != null ? !name.equals(that.name) : that.name != null)
      return false;
    if (type != null ? !type.equals(that.type) : that.type != null)
      return false;
    return vdcType != null ?
        vdcType.equals(that.vdcType) :
        that.vdcType == null;
  }

  @Override
  public int hashCode() {
    int result = username != null ? username.hashCode() : 0;
    result = 31 * result + (vdcUuid != null ? vdcUuid.hashCode() : 0);
    result = 31 * result + (group != null ? group.hashCode() : 0);
    result = 31 * result + (name != null ? name.hashCode() : 0);
    result = 31 * result + (type != null ? type.hashCode() : 0);
    result = 31 * result + (active ? 1 : 0);
    result = 31 * result + threshold;
    result = 31 * result + (vdcType != null ? vdcType.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "UserBroadVdcResourceAlertResponse{" + "username='" + username + '\''
        + ", vdcUuid='" + vdcUuid + '\'' + ", group='" + group + '\''
        + ", name='" + name + '\'' + ", type='" + type + '\'' + ", active="
        + active + ", threshold=" + threshold + ", vdcType='" + vdcType + '\''
        + '}';
  }

}
