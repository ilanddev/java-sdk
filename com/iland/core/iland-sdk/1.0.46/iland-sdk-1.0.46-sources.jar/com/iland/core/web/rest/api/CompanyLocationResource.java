/*
 * Copyright (c) 2013,2014 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 205 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */
package com.iland.core.web.rest.api;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.cohesity.iaas.backups.backupgroups.BackupGroupV2PlatformCompanyLocationApi;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.BackupGroupV2;
import com.iland.cohesity.iaas.backups.common.model.CompanyId;
import com.iland.cohesity.iaas.backups.common.model.ListResponse;
import com.iland.cohesity.iaas.backups.common.model.LocationId;
import com.iland.cohesity.iaas.backups.protectionsources.OracleProtectionSourceModel;
import com.iland.cohesity.iaas.backups.protectionsources.ProtectionSourcePlatformCompanyLocationApi;
import com.iland.cohesity.iaas.backups.protectionsources.PublicProtectionSource;
import com.iland.cohesity.iaas.backups.protectionsources.SqlProtectionSourceModel;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.vac.BaCompanyCreateRequest;
import com.iland.core.web.rest.request.vbo.O365OrganizationCreateModifyRequest;
import com.iland.core.web.rest.request.vpg.VpgSubEntityRequest;
import com.iland.core.web.rest.response.catalog.CatalogListResponse;
import com.iland.core.web.rest.response.edge.EdgeListResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupListResponse;
import com.iland.core.web.rest.response.iaas.backup.CompanyLocationBackupStatusResponse;
import com.iland.core.web.rest.response.iaas.intbackup.CompanyLocationIntegratedBackupStatusResponse;
import com.iland.core.web.rest.response.location.VmProtectionStatusSummaryResponse;
import com.iland.core.web.rest.response.media.MediaListResponse;
import com.iland.core.web.rest.response.org.OrgListResponse;
import com.iland.core.web.rest.response.org.OrgVdcNetworkListResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vac.BaCompanySetResponse;
import com.iland.core.web.rest.response.vapp.VappListResponse;
import com.iland.core.web.rest.response.vappnetwork.VappNetworkListResponse;
import com.iland.core.web.rest.response.vapptemplate.VappTemplateListResponse;
import com.iland.core.web.rest.response.vbo.O365AuditLogEventSetResponse;
import com.iland.core.web.rest.response.vbo.O365BackupRepositorySetResponse;
import com.iland.core.web.rest.response.vbo.O365BillSetResponse;
import com.iland.core.web.rest.response.vbo.O365DeviceCodeResponse;
import com.iland.core.web.rest.response.vbo.O365OrganizationResponse;
import com.iland.core.web.rest.response.vbo.O365OrganizationSetResponse;
import com.iland.core.web.rest.response.vdc.VdcListResponse;
import com.iland.core.web.rest.response.vm.VmListResponse;
import com.iland.core.web.rest.response.vpg.ExpandedVpgListResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Company Location ReST resource.
 *
 * @author <a href="mailto:csnydert@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Companies")
@Path("/companies/{companyId}/location")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface CompanyLocationResource extends
    BackupGroupV2PlatformCompanyLocationApi,
    ProtectionSourcePlatformCompanyLocationApi {

  /**
   * Get the orgs for a datacenter location.
   *
   * @param locationId the location ID
   * @return list of orgs
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/orgs")
  OrgListResponse getOrgs(@PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the vDCs for a datacenter location.
   *
   * @param locationId the location ID
   * @return list of vDCs
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/vdcs")
  VdcListResponse getVdcs(@PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the vApps for a datacenter location.
   *
   * @param locationId the location ID
   * @return list of vApps
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")

  @GET
  @Path("/{location}/vapps")
  VappListResponse getVapps(@PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the VMs for a datacenter location.
   *
   * @param locationId the location ID
   * @return list of VMs
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/vms")
  VmListResponse getVms(@PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the media for a datacenter location.
   *
   * @param locationId the location ID
   * @return list of media
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/media")
  MediaListResponse getMediaForCompany(@PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the vApp templates for a datacenter location.
   *
   * @param locationId the location ID
   * @return list of vApp templates
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/vapp-templates")
  VappTemplateListResponse getVappTemplatesForCompany(
      @PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the edges for a datacenter location.
   *
   * @param locationId the location ID
   * @return list of edges
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/edges")
  EdgeListResponse getEdges(@PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the VPGs for a datacenter location.
   *
   * @param locationId the location ID
   * @return list of VPGs
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/vpgs")
  ExpandedVpgListResponse getVpgs(@PathParam("companyId") String companyId,
      @PathParam("location") String locationId,
      @QueryParam("expand") List<VpgSubEntityRequest> expand);

  /**
   * Get the vac companies for a datacenter location.
   *
   * @param locationId location id
   * @return list of vac cloud comopanies
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/vac-companies")
  BaCompanySetResponse getVacCompanies(@PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the org vdc networks for the datacenter location.
   *
   * @param locationId the location ID
   * @return a list of org vdc networks
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/org-vdc-networks")
  OrgVdcNetworkListResponse getOrgVdcNetworks(
      @PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the vapp networks for the datacenter location.
   *
   * @param locationId the location ID
   * @return a list of org vdc networks
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/vapp-networks")
  VappNetworkListResponse getVappNetworks(
      @PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the catalogs for the datacenter location.
   *
   * @param locationId the location ID
   * @return a list of catalogs
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/catalogs")
  CatalogListResponse getCatalogs(@PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Create a VAC company.
   *
   * @param locationId             location id
   * @param companyId              iland company id
   * @param baCompanyCreateRequest backup company create request
   * @return create VAC company task response
   */
  @POST
  @Path("/{locationId}/actions/create-vac-company")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse createVacCompany(@PathParam("locationId") String locationId,
      @SecureEntityRef(Permission.CREATE_ILAND_BACKUP_TENANT)
      @PathParam("companyId") String companyId,
      BaCompanyCreateRequest baCompanyCreateRequest);

  /**
   * Get the Office 365 VBO Organizations given a company and location.
   *
   * @param companyId  the company identifier (aka CRM # id)
   * @param locationId the location identifier
   * @return a {@link O365OrganizationSetResponse} instance.
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/o365-organizations")
  O365OrganizationSetResponse getO365Organizations(
      @PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the historical Office 365 billing for a given company.
   *
   * @param companyId  the company identifier
   * @param locationId the location identifier
   * @param startYear  the year to start
   * @param startMonth the month to start (1-12)
   * @param endYear    the year to end with
   * @param endMonth   the month to end (1-12)
   * @return set of office 365 bills
   */
  @GET
  @Path("/{locationId}/o365-billing")
  O365BillSetResponse getO365BillingHistory(
      @PathParam("companyId")
          String companyId, @PathParam("locationId") String locationId,
      @QueryParam("startYear") Integer startYear,
      @QueryParam("startMonth") Integer startMonth,
      @QueryParam("endYear") Integer endYear,
      @QueryParam("endMonth") Integer endMonth);

  /**
   * Add a Microsoft Office 365 VBO organization. This only supports the
   * Office365 online type and not on-premises / hybrid type.
   *
   * @param companyId  iland company id
   * @param locationId the location id
   * @param request    the organization create request
   * @return a {@link O365OrganizationResponse} instance
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @POST
  @Path("/{locationId}/actions/create-o365-org")
  @Consumes(MediaType.APPLICATION_JSON)
  O365OrganizationResponse createO365Organization(
      @SecureEntityRef(Permission.CREATE_ILAND_O365_ORGANIZATION)
      @PathParam("companyId") String companyId,
      @PathParam("locationId") String locationId,
      O365OrganizationCreateModifyRequest request);

  /**
   * Get a list of Vbo Repositories for the company not assigned to any org, if any exists.
   *
   * @param companyId  iland company id
   * @param locationId the location id
   * @return a {@link O365BackupRepositorySetResponse} instance
   */
  @GET
  @Path("/{locationId}/get-o365-repos-unassigned")
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  O365BackupRepositorySetResponse getVboRepositoryUnassigned(
      @PathParam("companyId") String companyId,
      @PathParam("locationId") String locationId);

  /**
   * Get a device code response from Microsoft Azure to validate in the Microsoft
   * authentication portal. This is to be used while creating an org.
   *
   * @param companyId  iland company id
   * @param locationId the location id
   * @param repoId the backup repository id
   * @return a {@link O365DeviceCodeResponse} instance
   */
  @GET
  @Path("/{locationId}/actions/get-o365-device-code")
  @Consumes(MediaType.APPLICATION_JSON)
  O365DeviceCodeResponse getO365DeviceCode(
      @SecureEntityRef(Permission.CREATE_ILAND_O365_ORGANIZATION)
      @PathParam("companyId") String companyId,
      @PathParam("locationId") String locationId,
      @QueryParam("repoId") String repoId);


  /**
   * Get the protection sources for the given org.
   *
   * @param companyId     company ID
   * @param locationId     location ID
   * @param hostType    e.g. "linux" or "windows"
   * @param environment e.g. "*" or "sql"
   * @return a list of protection sources
   * @deprecated
   */
  @GET
  @Path("/companies/{companyId}/location/{location}/{hostType: (\\*|linux|windows)}/{environment: (\\*|sql)}")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  ListResponse<PublicProtectionSource> listProtectionSourcesForCompanyLocationDeprecated(
      @PathParam("companyId") CompanyId companyId,
      @PathParam("location") LocationId locationId,
      @PathParam("hostType") String hostType,
      @PathParam("environment") String environment);

  /**
   * Get the protection sources for the given org.
   *
   * @param companyId     company ID
   * @param locationId     location ID
   * @param hostType    e.g. "linux" or "windows"
   * @param environment e.g. "*" or "sql"
   * @return a list of protection sources
   */
  @GET
  @Path("/{location}/{hostType: (\\*|linux|windows)}/{environment: (\\*|sql)}")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  ListResponse<PublicProtectionSource> listProtectionSourcesForCompanyLocation(
      @PathParam("companyId") CompanyId companyId,
      @PathParam("location") LocationId locationId,
      @PathParam("hostType") String hostType,
      @PathParam("environment") String environment);

  /**
   * Get the SQL protection sources for the given org.
   *
   * @param companyId     company ID
   * @param locationId     location ID
   * @return a list of SQL protection sources
   */
  @GET
  @Path("/{location}/sql-protection-sources")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  ListResponse<SqlProtectionSourceModel> listSqlProtectionSourcesForCompanyLocation(
      @PathParam("companyId") CompanyId companyId, @PathParam("location") LocationId locationId);

  /**
   * Get the Oracle protection sources for the given org.
   *
   * @param companyId  company ID
   * @param locationId location ID
   * @return a list of SQL protection sources
   */
  @GET
  @Path("/{location}/oracle-protection-sources")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  ListResponse<OracleProtectionSourceModel> listOracleProtectionSourcesForCompanyLocation(
      @PathParam("companyId") CompanyId companyId,
      @PathParam("location") LocationId locationId);

  /**
   * List the existing backup groups that are configured in a specified
   * company-location.
   *
   * @param locationId          the location ID
   * @param companyId           the company ID
   * @param includeDeleted      whether to include deleted backup groups
   * @param includeSummaryStats whether to include backup summary stats
   * @param includeLastRun      whether to include last run info in the response
   * @param includeBackupPolicy whether to include backup policy info in the response
   * @return {@link BackupGroupListResponse}
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/backup-groups")
  BackupGroupListResponse listBackupGroups(
      @PathParam("companyId") String companyId,
      @PathParam("location") String locationId,
      @QueryParam("includeDeleted") boolean includeDeleted,
      @QueryParam("includeSummaryStats") boolean includeSummaryStats,
      @QueryParam("includeLastRun") boolean includeLastRun,
      @QueryParam("includeBackupPolicy") boolean includeBackupPolicy);

  /**
   * List the existing backup groups that are configured in a specified
   * company-location.
   *
   * @param locationId          the location ID
   * @param companyId           the company ID
   * @param includeDeleted      whether to include deleted backup groups
   * @param includeSummaryStats whether to include backup summary stats
   * @param includeLastRun      whether to include last run info in the response
   * @param includeBackupPolicy whether to include backup policy info in the response
   * @param includeLegacyVMware weather to include legacy VMware backup groups
   * @return {@link ListResponse list of backup groups}
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/backup-groups-x")
  ListResponse<BackupGroupV2> listV2BackupGroups(
      @PathParam("companyId") CompanyId companyId,
      @PathParam("location") LocationId locationId,
      @QueryParam("includeDeleted") boolean includeDeleted,
      @QueryParam("includeSummaryStats") boolean includeSummaryStats,
      @QueryParam("includeLastRun") boolean includeLastRun,
      @QueryParam("includeBackupPolicy") boolean includeBackupPolicy,
      @QueryParam("includeLegacyVMware") boolean includeLegacyVMware);

  /**
   * Gets the backup status of entities within the company-location.
   *
   * @param locationId the location ID
   * @param companyId  the company ID
   * @return backup status details
   */
  @GET
  @Path("/{location}/iaas-backup-status")
  CompanyLocationBackupStatusResponse getBackupStatus(
      @PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Gets the integrated backup status of entities within the company-location.
   *
   * @param locationId the location ID
   * @param companyId  the company ID
   * @return backup status details
   */
  @GET
  @Path("/{location}/iaas-integrated-backup-status")
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  CompanyLocationIntegratedBackupStatusResponse getIntegratedBackupStatus(
      @PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the Office 365 VBO audit log given a company and location.
   *
   * @param companyId  the company identifier (aka CRM # id)
   * @param locationId the location identifier
   * @param page       the page number
   * @param pageSize   the page size
   * @return office 365 audit log
   */
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  @GET
  @Path("/{location}/o365-audit-log")
  O365AuditLogEventSetResponse getO365AuditLog(
      @PathParam("companyId") String companyId,
      @PathParam("location") String locationId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize);

  /**
   * Get Office 365 VBO backup repositories for the company and location.
   *
   * @param companyId  the company identifier (aka CRM # id)
   * @param locationId the location identifier
   * @return the {@link O365BackupRepositorySetResponse}
   */
  @GET
  @Path("/{location}/o365-backup-repositories")
  O365BackupRepositorySetResponse getVboBackupRepositories(
      @PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

  /**
   * Get the number of VMs protected and unprotected for a given company, location
   * and user making request.
   *
   * @param companyId  the company identifier (aka CRM # id)
   * @param locationId the location identifier
   * @return number of protected and unprotected VMs
   */
  @GET
  @Path("/{location}/vms-protection-status-summary")
  @SkipSecurityTest("We need to verify based upon a uuid that is a combination of the company/product/location. Custom security logic in EJB.")
  VmProtectionStatusSummaryResponse getVmProtectionSummary(
      @PathParam("companyId") String companyId,
      @PathParam("location") String locationId);

}

