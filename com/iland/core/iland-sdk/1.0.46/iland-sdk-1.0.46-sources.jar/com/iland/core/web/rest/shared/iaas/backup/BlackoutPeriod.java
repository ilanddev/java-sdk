/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.policies.api.enums.Day;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.shared.time.TimeOfDay;

/**
 * Blackout Period.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class BlackoutPeriod implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Blackout Day.
   * <p>
   * Specifies a day in the week when no new group runs should be started such as
   * 'SUNDAY'. If not set, the time range applies to all days. Specifies a day
   * in a week such as 'SUNDAY', 'MONDAY', etc.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Blackout Day. Specifies a day in the week when no new "
      + "group runs should be started such as 'SUNDAY'. If not set, the "
      + "time range applies to all days. Specifies a day in a week such "
      + "as 'SUNDAY', 'MONDAY', etc.")
  private final Day day;

  /**
   * Specifies the end time of the blackout time range.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the end time of the blackout time range.")
  private final TimeOfDay endTime;

  /**
   * Specifies the start time of the blackout time range.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the start time of the blackout time range.")
  private final TimeOfDay startTime;

  /**
   * Instantiates a new BlackoutPeriod.
   *
   * @param day       Blackout Day. <p> Specifies a day in the week when no new
   *                  Job Runs should be started such as 'SUNDAY'. If not set,
   *                  the time range applies to all days. Specifies a day in a
   *                  week such as 'SUNDAY', 'MONDAY', etc.
   * @param endTime   Specifies the end time of the blackout time range.
   * @param startTime Specifies the start time of the blackout time range.
   */
  public BlackoutPeriod(final Day day, final TimeOfDay endTime,
      final TimeOfDay startTime) {
    this.day = day;
    this.endTime = endTime;
    this.startTime = startTime;
  }

  /**
   * Blackout Day.
   * <p>
   * Specifies a day in the week when no new Job Runs should be started such as
   * 'SUNDAY'. If not set, the time range applies to all days. Specifies a day
   * in a week such as 'SUNDAY', 'MONDAY', etc.
   *
   * @return day
   */
  public Optional<Day> getDay() {
    return Optional.ofNullable(this.day);
  }

  /**
   * Specifies the end time of the blackout time range.
   *
   * @return endTime
   */
  public TimeOfDay getEndTime() {
    return this.endTime;
  }

  /**
   * Specifies the start time of the blackout time range.
   *
   * @return startTime
   */
  public TimeOfDay getStartTime() {
    return this.startTime;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BlackoutPeriod that = (BlackoutPeriod) o;
    return Objects.equals(day, that.day) && Objects
        .equals(endTime, that.endTime) && Objects
        .equals(startTime, that.startTime);
  }

  @Override
  public int hashCode() {
    return Objects.hash(day, endTime, startTime);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("day", day)
        .add("endTime", endTime).add("startTime", startTime).toString();
  }
}
