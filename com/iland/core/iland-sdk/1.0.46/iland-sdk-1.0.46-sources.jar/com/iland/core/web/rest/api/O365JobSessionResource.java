/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.response.vbo.O365JobSessionLogItemSetResponse;
import com.iland.core.web.rest.response.vbo.O365JobSessionResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Office 365 VBO Job Session Resource.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIProperties(name = "Office 365 Backup")
@Path("/o365-job-sessions")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface O365JobSessionResource {

  /**
   * Get an Office 365 VBO Job Session given its UUID.
   *
   * @param uuid The Office 365 VBO Job Session UUID
   * @return a {@link O365JobSessionResponse} instance
   */
  @GET
  @Path("/{uuid}")
  O365JobSessionResponse getJobSessionByUuid(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_JOB_SESSION)
      @PathParam("uuid") String uuid);

  /**
   * Get an Office 365 Job Session log items given the job session UUID.
   *
   * @param uuid The Office 365 VBO Job Session UUID
   * @return a {@link O365JobSessionLogItemSetResponse} instance
   */
  @GET
  @Path("/{uuid}/log-items")
  O365JobSessionLogItemSetResponse getJobSessionLogItemsFor(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_JOB_SESSION)
      @PathParam("uuid") String uuid);

}
