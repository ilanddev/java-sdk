/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.api.vbo.O365ExchangeItemFormat;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.vbo.O365ChannelExportRequest;
import com.iland.core.web.rest.request.vbo.O365ExchangeRestoreOptionsRequest;
import com.iland.core.web.rest.request.vbo.O365OneDriveRestoreOptionsRequest;
import com.iland.core.web.rest.request.vbo.O365RestoreSessionSendToEmailRequest;
import com.iland.core.web.rest.request.vbo.O365SearchRequest;
import com.iland.core.web.rest.request.vbo.O365SharePointRestoreOptionsRequest;
import com.iland.core.web.rest.request.vbo.O365TeamOptionsRequest;
import com.iland.core.web.rest.request.vbo.O365TeamRestoreOptionsRequest;
import com.iland.core.web.rest.request.vbo.O365TeamSearchRequest;
import com.iland.core.web.rest.request.vbo.O365TeamSendToEmailOptionsRequest;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vbo.O365DeviceCodeResponse;
import com.iland.core.web.rest.response.vbo.O365ExchangeFolderSetResponse;
import com.iland.core.web.rest.response.vbo.O365ExchangeItemSetResponse;
import com.iland.core.web.rest.response.vbo.O365ExchangeMailboxPaginatedSetResponse;
import com.iland.core.web.rest.response.vbo.O365OneDriveDocumentSetResponse;
import com.iland.core.web.rest.response.vbo.O365OneDriveFolderSetResponse;
import com.iland.core.web.rest.response.vbo.O365OneDriveSetResponse;
import com.iland.core.web.rest.response.vbo.O365RestoreSessionEventSetResponse;
import com.iland.core.web.rest.response.vbo.O365RestoreSessionResponse;
import com.iland.core.web.rest.response.vbo.O365SharePointAttachmentSetResponse;
import com.iland.core.web.rest.response.vbo.O365SharePointDocumentSetResponse;
import com.iland.core.web.rest.response.vbo.O365SharePointFolderSetResponse;
import com.iland.core.web.rest.response.vbo.O365SharePointItemSetResponse;
import com.iland.core.web.rest.response.vbo.O365SharePointLibrarySetResponse;
import com.iland.core.web.rest.response.vbo.O365SharePointListSetResponse;
import com.iland.core.web.rest.response.vbo.O365SharePointSiteSetResponse;
import com.iland.core.web.rest.response.vbo.O365TeamChannelResponse;
import com.iland.core.web.rest.response.vbo.O365TeamChannelSetResponse;
import com.iland.core.web.rest.response.vbo.O365TeamFileResponse;
import com.iland.core.web.rest.response.vbo.O365TeamFileSetResponse;
import com.iland.core.web.rest.response.vbo.O365TeamItemSetResponse;
import com.iland.core.web.rest.response.vbo.O365TeamPostResponse;
import com.iland.core.web.rest.response.vbo.O365TeamPostSetResponse;
import com.iland.core.web.rest.response.vbo.O365TeamResponse;
import com.iland.core.web.rest.response.vbo.O365TeamSetResponse;
import com.iland.core.web.rest.response.vbo.O365TeamTabResponse;
import com.iland.core.web.rest.response.vbo.O365TeamTabSetResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Office 365 VBO Restore Session Resource.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIProperties(name = "Office 365 Backup")
@Path("/o365-restore-sessions")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface O365RestoreSessionResource {

  /**
   * Get an Office 365 VBO Restore Session given its UUID.
   *
   * @param uuid the Office 365 VBO Restore Session UUID
   * @return a {@link O365RestoreSessionResponse} instance
   */
  @GET
  @Path("/{uuid}")
  O365RestoreSessionResponse getRestoreSessionByUuid(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid);

  /**
   * Get Office 365 VBO Restore Session events given the restore session UUID.
   *
   * @param uuid the Office 365 VBO Restore Session UUID
   * @return a {@link O365RestoreSessionEventSetResponse} instance
   */
  @GET
  @Path("/{uuid}/events")
  O365RestoreSessionEventSetResponse getRestoreSessionEvents(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid);

  /**
   * Stop an Office 365 VBO Restore Session given the restore session UUID.
   *
   * @param uuid the Office 365 VBO Restore Session UUID
   */
  @POST
  @Path("/{uuid}/actions/stop")
  @Consumes(MediaType.APPLICATION_JSON)
  void stopRestoreSession(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid);

  /**
   * Get Office 365 VBO Exchange mailboxes given a restore session UUID.
   *
   * @param uuid     the Office 365 VBO restore session UUID
   * @param page     the page number
   * @param pageSize the page size
   * @param query    the text to search for the name of the mailbox
   * @return a {@link O365ExchangeMailboxPaginatedSetResponse} instance
   */
  @GET
  @Path("/{uuid}/exchange-mailboxes")
  O365ExchangeMailboxPaginatedSetResponse getExchangeMailboxes(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("query") String query);

  /**
   * Restore an Office 365 VBO Exchange mailbox to either original location
   * or a different location given the restore session UUID and mailbox ID.
   * This method will return TaskResponse object immediately and submits the
   * restoration task in the background.
   *
   * @param uuid      the Office 365 VBO Restore Session iland UUID
   * @param mailboxId the Veeam native mailbox identifier
   * @param request   a {@link O365ExchangeRestoreOptionsRequest} instance
   * @return a {@link TaskResponse} instance
   */
  @POST
  @Path("/{uuid}/exchange-mailboxes/{mailboxId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse restoreExchangeMailbox(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("mailboxId") String mailboxId,
      O365ExchangeRestoreOptionsRequest request);

  /**
   * Get Office 365 VBO Exchange folders given a restore session UUID.
   *
   * @param uuid      the Office 365 VBO restore session UUID
   * @param mailboxId the Veeam native mailbox identifier
   * @param page      the page number
   * @param pageSize  the page size
   * @param parentId  the Veeam native parent folder identifier or null for parent mailbox
   * @return a {@link O365ExchangeFolderSetResponse} instance
   */
  @GET
  @Path("/{uuid}/exchange-mailboxes/{mailboxId}/folders")
  O365ExchangeFolderSetResponse getExchangeFolders(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("mailboxId") String mailboxId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("parentId") String parentId);

  /**
   * Restore an Office 365 VBO Exchange folder to original location or a different location given the
   * restore session UUID, mailbox ID and folder ID.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param mailboxId The Veeam native mailbox identifier
   * @param folderId  The Veeam native folder identifier
   * @param request   a {@link O365ExchangeRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/exchange-mailboxes/{mailboxId}/folders/{folderId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreExchangeFolder(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("mailboxId") String mailboxId,
      @PathParam("folderId") String folderId,
      O365ExchangeRestoreOptionsRequest request);

  /**
   * Get Office 365 VBO Exchange items given a restore session UUID.
   *
   * @param uuid      The Office 365 VBO restore session UUID
   * @param mailboxId The Veeam native mailbox identifier
   * @param page      the page number
   * @param pageSize  the page size
   * @param folderId  The Veeam native parent folder identifier or null for parent mailbox
   * @return a {@link O365ExchangeItemSetResponse} instance
   */
  @GET
  @Path("/{uuid}/exchange-mailboxes/{mailboxId}/items")
  O365ExchangeItemSetResponse getExchangeItems(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("mailboxId") String mailboxId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("folderId") String folderId);

  /**
   * Restore an Office 365 VBO Exchange item to original location or different location given the
   * restore session UUID, mailbox ID and item ID.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param mailboxId The Veeam native mailbox identifier
   * @param itemId    The Veeam native item identifier
   * @param request   a {@link O365ExchangeRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/exchange-mailboxes/{mailboxId}/items/{itemId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreExchangeItem(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("mailboxId") String mailboxId,
      @PathParam("itemId") String itemId,
      O365ExchangeRestoreOptionsRequest request);

  /**
   * Get Office 365 VBO One Drives given a restore session UUID.
   *
   * @param uuid     The Office 365 VBO restore session UUID.
   * @param page     the page
   * @param pageSize the page size
   * @param query    the optional text to search for the name of one drive. Needs minimum 2 chars.
   * @return a {@link O365OneDriveSetResponse} instance
   */
  @GET
  @Path("/{uuid}/onedrive-drives")
  O365OneDriveSetResponse getOneDrives(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("query") String query);

  /**
   * Restore an Office 365 VBO One Drive to a location given the
   * restore session UUID and one drive ID. This method will return
   * TaskResponse object immediately and submits the restoration task
   * in the background.
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID.
   * @param oneDriveId The Veeam native one drive identifier.
   * @param request    a {@link O365OneDriveRestoreOptionsRequest} instance
   * @return a {@link TaskResponse} instance
   */
  @POST
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse restoreOneDriveTo(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      O365OneDriveRestoreOptionsRequest request);

  /**
   * Send an Office 365 VBO One Drive to an email given the
   * restore session UUID and one drive ID.
   * <p>
   * The maximum size of the combined files of a One Drive you can send through email is 100 MB
   * and the maximum number of files you can send is 200.
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID.
   * @param oneDriveId The Veeam native one drive identifier.
   * @param request    a {@link O365RestoreSessionSendToEmailRequest} instance
   */
  @POST
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/actions/send-email")
  @Consumes(MediaType.APPLICATION_JSON)
  void sendOneDriveToEmail(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      O365RestoreSessionSendToEmailRequest request);

  /**
   * Get Office 365 VBO One Drive folders given a restore session UUID.
   *
   * @param uuid       The Office 365 VBO restore session UUID
   * @param oneDriveId the one drive id
   * @param page       the page
   * @param pageSize   the page size
   * @param parentId   the parent folder or null for parent drive
   * @return a {@link O365OneDriveFolderSetResponse} instance
   */
  @GET
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/folders")
  O365OneDriveFolderSetResponse getOneDriveFolders(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("parentId") String parentId);

  /**
   * Restore an Office 365 VBO one drive folder to a location given the
   * restore session UUID, one drive ID and folder ID.
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID.
   * @param oneDriveId The Veeam native one drive identifier.
   * @param folderId   The Veeam native folder identifier.
   * @param request    a {@link O365OneDriveRestoreOptionsRequest} instance
   * @return a {@link TaskResponse} instance
   */
  @POST
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/folders/{folderId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse restoreOneDriveFolderTo(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      @PathParam("folderId") String folderId,
      O365OneDriveRestoreOptionsRequest request);

  /**
   * Send an Office 365 VBO one drive folder to an email given the
   * restore session UUID, one drive ID and folder ID.
   * <p>
   * The maximum size of the combined files of a folder you can send through email is 100 MB
   * and the maximum number of files you can send is 200.
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID.
   * @param oneDriveId The Veeam native one drive identifier.
   * @param folderId   The Veeam native folder identifier.
   * @param request    a {@link O365RestoreSessionSendToEmailRequest} instance
   */
  @POST
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/folders/{folderId}/actions/send-email")
  @Consumes(MediaType.APPLICATION_JSON)
  void sendOneDriveFolderToEmail(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      @PathParam("folderId") String folderId,
      O365RestoreSessionSendToEmailRequest request);

  /**
   * Get Office 365 VBO One Drive Documents given a restore session UUID.
   *
   * @param uuid       The Office 365 VBO restore session UUID
   * @param oneDriveId the one drive id
   * @param page       the page
   * @param pageSize   the page size
   * @param parentId   the parent folder or null for parent drive
   * @return a {@link O365OneDriveDocumentSetResponse} instance
   */
  @GET
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/documents")
  O365OneDriveDocumentSetResponse getOneDriveDocuments(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("parentId") String parentId);

  /**
   * Restore an Office 365 VBO one drive document to a location given the
   * restore session UUID, one drive ID and document ID.
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID.
   * @param oneDriveId The Veeam native one drive identifier.
   * @param documentId The Veeam native document identifier.
   * @param request    a {@link O365OneDriveRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/documents/{documentId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreOneDriveDocumentTo(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      @PathParam("documentId") String documentId,
      O365OneDriveRestoreOptionsRequest request);

  /**
   * Sends an Office 365 VBO one drive document to an email given the
   * restore session UUID, one drive ID and document ID.
   * <p>
   * The maximum size of a document you can send through email is 100 MB.
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID.
   * @param oneDriveId The Veeam native one drive identifier.
   * @param documentId The Veeam native document identifier.
   * @param request    a {@link O365RestoreSessionSendToEmailRequest} instance
   */
  @POST
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/documents/{documentId}/actions/send-email")
  @Consumes(MediaType.APPLICATION_JSON)
  void sendOneDriveDocumentToEmail(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      @PathParam("documentId") String documentId,
      O365RestoreSessionSendToEmailRequest request);

  /**
   * Searches for  OneDrive Items in OneDrive
   *
   * @param uuid       Office 365 VBO restore session UUID
   * @param oneDriveId The Veeam native one drive identifier.
   * @param page       The page number
   * @param pageSize   The page size
   * @param query      Search query request
   * @return a {@link O365OneDriveDocumentSetResponse} instance
   */
  @POST
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/actions/search")
  @Consumes(MediaType.APPLICATION_JSON)
  O365OneDriveDocumentSetResponse searchOneDriveItems(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      @QueryParam("offset") int page,
      @QueryParam("limit") int pageSize,
      O365SearchRequest query);


  /**
   * Searches for  OneDrive Items in OneDrive Folder
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID.
   * @param oneDriveId The Veeam native one drive identifier.
   * @param folderId   The Veeam native folder identifier.
   * @param page       The page number
   * @param pageSize   The page size
   * @param query      Search query request
   * @return a {@link O365OneDriveDocumentSetResponse} instance
   */
  @POST
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/folders/{folderId}/actions/search")
  @Consumes(MediaType.APPLICATION_JSON)
  O365OneDriveDocumentSetResponse searchOneDriveFolderItems(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      @PathParam("folderId") String folderId,
      @QueryParam("offset") int page,
      @QueryParam("limit") int pageSize,
      O365SearchRequest query);

  /**
   * Searches for  Sharepoint Items
   * Returns a stream of backed up Sharepoint items.
   *
   * @param uuid           Office 365 VBO restore session UUID
   * @param siteId         the parent Sharepoint site Veeam native ID
   * @param page           the page number
   * @param pageSize       the page size
   * @return a {@link O365OneDriveDocumentSetResponse} instance
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/actions/search")
  @Consumes(MediaType.APPLICATION_JSON)
  O365SharePointItemSetResponse searchSharePointItems(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("siteId") String siteId,
      @QueryParam("offset") int page,
      @QueryParam("limit") int pageSize,
      O365SearchRequest query);


  /**
   * Searches for  Sharepoint Items in specified folder
   * Returns a stream of backed up Sharepoint items.
   *
   * @param uuid           Office 365 VBO restore session UUID
   * @param siteId         the parent Sharepoint site Veeam native ID
   * @param folderId       the one drive folder Veeam native ID
   * @param page           the page number
   * @param pageSize       the page size
   * @return a {@link O365OneDriveDocumentSetResponse} instance
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/folders/{folderId}/actions/search")
  @Consumes(MediaType.APPLICATION_JSON)
  O365SharePointItemSetResponse searchSharePointFolderItems(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("siteId") String siteId,
      @PathParam("folderId") String folderId,
      @QueryParam("offset") int page,
      @QueryParam("limit") int pageSize,
      O365SearchRequest query);

  /**
   * Get Office 365 VBO teams given a restore session UUID.
   *
   * @param uuid        The Office 365 VBO restore session UUID
   * @param displayName the optional display name of the teams whose representation you want
   *                    to get from the server. Null value will bring all teams for this org.
   * @param page        the page
   * @param pageSize    the page size
   * @param query       the text to search for the name of the site. Needs minimum 2 chars.
   *                    Please note using this parameter will override the displayName (2nd argument)
   * @return a response representing collection of {@link O365TeamResponse}s
   */
  @GET
  @Path("/{uuid}/teams")
  O365TeamSetResponse getTeams(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @QueryParam("displayName") String displayName,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("query") String query);

  /**
   * Get Microsoft Teams channels for a team given a restore session UUID.
   *
   * @param uuid        The Office 365 VBO restore session UUID
   * @param teamId      the native ID of the organization team
   * @param page        the page
   * @param pageSize    the page size
   * @param displayName the display name of the channel whose representation you want to
   *                    get from the server. Null value will bring all channels for this team.
   * @return a response representing collection of {@link O365TeamChannelResponse} instances
   */
  @GET
  @Path("/{uuid}/teams/{teamId}/channels")
  O365TeamChannelSetResponse getTeamChannels(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("displayName") String displayName);

  /**
   * Get Microsoft Teams tabs for a channel given a restore session UUID.
   *
   * @param uuid      The Office 365 VBO restore session UUID
   * @param teamId    the native ID of the organization team
   * @param channelId the native ID of the team channel
   * @param page      the page
   * @param pageSize  the page size
   * @return a response representing collection of {@link O365TeamTabResponse} instances
   */
  @GET
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/tabs")
  O365TeamTabSetResponse getTeamsTabs(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize);

  /**
   * Get Microsoft Teams posts for a channel given a restore session UUID.
   *
   * @param uuid      The Office 365 VBO restore session UUID
   * @param teamId    the native ID of the organization team
   * @param channelId Specifies the optional channel ID whose posts the server will return in the resource representation. If you do not specify this parameter,
   *                  the server will return a representation of posts pertaining to all channels of the backed-up team.
   * @param parentId  Specifies what information the server will return in the resource representation. Possible values:
   *                  parentID — ID of a parent post. In the response, the server will return a representation of child posts of the specified parent post.
   *                  -1 — specifies that the server will return a representation of parent posts only.
   *                  If you do not specify this parameter, the server will return a representation of all parent and child posts.
   * @param page      the page
   * @param pageSize  the page size
   * @return a response representing collection of {@link O365TeamPostResponse} instances
   */
  @GET
  @Path("/{uuid}/teams/{teamId}/posts")
  O365TeamPostSetResponse getTeamsPosts(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @QueryParam("channelId") String channelId,
      @QueryParam("parentId") String parentId, @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize);

  /**
   * Get Microsoft Teams files for a team given a restore session UUID.
   *
   * @param uuid      The Office 365 VBO restore session UUID
   * @param teamId    the ID of the organization team
   * @param channelId Specifies the optional channel ID whose posts the server will return in the resource representation. If you do not specify this parameter,
   *                  the server will return a representation of files pertaining to all channels of the backed-up team.
   * @param parentId  Specifies what information the server will return in the resource representation. Possible values:
   *                  parentID — ID of a parent folder. In the response, the server will return a representation of files in the specified folder.
   *                  null — specifies that the server will return a representation of all root folders of team channels.
   *                  If you do not specify this parameter, the server will return a representation of all files in all folders.
   * @param page      the page
   * @param pageSize  the page size
   * @return a response representing collection of {@link O365TeamFileResponse} instances
   */
  @GET
  @Path("/{uuid}/teams/{teamId}/files")
  O365TeamFileSetResponse getTeamsFiles(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @QueryParam("channelId") String channelId,
      @QueryParam("parentId") String parentId, @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize);

  /**
   * Searches for Teams Items in Microsoft Office 365 organization.
   *
   * @param uuid           Office 365 VBO restore session UUID
   * @param teamId         Specifies the ID of the organization team
   * @param page           the page number
   * @param pageSize       the page size
   * @param query          the Search query.
   * @return a {@link O365TeamItemSetResponse} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/actions/search")
  @Consumes(MediaType.APPLICATION_JSON)
  O365TeamItemSetResponse searchTeamsItems(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("teamId") String teamId,
      @QueryParam("offset") int page,
      @QueryParam("limit") int pageSize,
      O365TeamSearchRequest query);

  /**
   * Searches for Teams Items in specified channel
   *
   * @param uuid           Office 365 VBO restore session UUID
   * @param teamId         Specifies the ID of the organization team
   * @param channelId      Specifies the ID of the teams channel
   * @param page           the page number
   * @param pageSize       the page size
   * @param query          the Search query.
   * @return a {@link O365TeamItemSetResponse} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/actions/search")
  @Consumes(MediaType.APPLICATION_JSON)
  O365TeamItemSetResponse searchTeamsChannelItems(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      @QueryParam("offset") int page,
      @QueryParam("limit") int pageSize,
      O365TeamSearchRequest query);

  /**
   * Get Office 365 VBO Sharepoint sites given a restore session UUID.
   *
   * @param uuid     The Office 365 VBO restore session UUID
   * @param parentId the parent folder or null for parent site.
   * @param page     the page. default is 0 is nothing specified
   * @param pageSize the page size. default is 50 is nothing specified
   * @param query    the text to search for the name of the site
   * @return a {@link O365SharePointSiteSetResponse} instance
   */
  @GET
  @Path("/{uuid}/sharepoint-sites")
  O365SharePointSiteSetResponse getSharepointSites(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @QueryParam("parentId") String parentId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("query") String query);

  /**
   * Get Office 365 VBO SharePoint folders given a restore session UUID.
   *
   * @param uuid     The Office 365 VBO restore session UUID
   * @param siteId   the sharepoint site id
   * @param page     the page
   * @param pageSize the page size
   * @param parentId the parent folder or null for parent site
   * @return a {@link O365SharePointFolderSetResponse} instance
   */
  @GET
  @Path("/{uuid}/sharepoint-sites/{siteId}/folders")
  O365SharePointFolderSetResponse getSharepointFolders(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("parentId") String parentId);

  /**
   * Get Office 365 VBO SharePoint documents given a restore session UUID.
   *
   * @param uuid     The Office 365 VBO restore session UUID
   * @param siteId   the sharepoint site id
   * @param page     the page
   * @param pageSize the page size
   * @param parentId the parent folder or null for parent folder
   * @return a {@link O365SharePointDocumentSetResponse} instance
   */
  @GET
  @Path("/{uuid}/sharepoint-sites/{siteId}/documents")
  O365SharePointDocumentSetResponse getSharepointDocuments(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("parentId") String parentId);

  /**
   * Get Office 365 VBO SharePoint items given a restore session UUID.
   *
   * @param uuid     The Office 365 VBO restore session UUID
   * @param siteId   the sharepoint site id
   * @param page     the page
   * @param pageSize the page size
   * @param parentId the parent folder or null for parent folder
   * @return a {@link O365SharePointItemSetResponse} instance
   */
  @GET
  @Path("/{uuid}/sharepoint-sites/{siteId}/items")
  O365SharePointItemSetResponse getSharepointItems(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize,
      @QueryParam("parentId") String parentId);

  /**
   * Get Office 365 VBO SharePoint libraries given a restore session UUID.
   *
   * @param uuid     The Office 365 VBO restore session UUID
   * @param siteId   the sharepoint site id
   * @param page     the page
   * @param pageSize the page size
   * @return a {@link O365SharePointLibrarySetResponse} instance
   */
  @GET
  @Path("/{uuid}/sharepoint-sites/{siteId}/libraries")
  O365SharePointLibrarySetResponse getSharepointLibraries(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize);

  /**
   * Get Office 365 VBO SharePoint lists given a restore session UUID.
   *
   * @param uuid     The Office 365 VBO restore session UUID
   * @param siteId   the sharepoint site id
   * @param page     the page
   * @param pageSize the page size
   * @return a {@link O365SharePointListSetResponse} instance
   */
  @GET
  @Path("/{uuid}/sharepoint-sites/{siteId}/lists")
  O365SharePointListSetResponse getSharepointLists(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize);

  /**
   * Get Office 365 VBO SharePoint attachments given a restore session UUID.
   *
   * @param uuid     The Office 365 VBO restore session UUID
   * @param siteId   the sharepoint site id
   * @param itemId   the sharepoint item id
   * @param page     the page
   * @param pageSize the page size
   * @return a {@link O365SharePointAttachmentSetResponse} instance
   */
  @GET
  @Path("/{uuid}/sharepoint-sites/{siteId}/items/{itemId}/attachments")
  O365SharePointAttachmentSetResponse getSharepointAttachments(
      @SecureEntityRef(Permission.VIEW_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("itemId") String itemId, @QueryParam("page") Integer page,
      @QueryParam("pageSize") Integer pageSize);

  /**
   * Restore an Office 365 VBO SharePoint Site given the restore session UUID
   * its Veeam native id. This method will return TaskResponse object immediately
   * and submits the restoration task in the background.
   *
   * @param uuid    The Office 365 VBO Restore Session iland UUID
   * @param siteId  The Veeam native SharePoint Site identifier
   * @param request a {@link O365SharePointRestoreOptionsRequest} instance
   * @return a {@link TaskResponse} instance
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse restoreSharePointSiteTo(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      O365SharePointRestoreOptionsRequest request);

  /**
   * Restore an Office 365 VBO SharePoint List given the restore session UUID
   * its Veeam native id.
   *
   * @param uuid    The Office 365 VBO Restore Session iland UUID
   * @param siteId  The Veeam native SharePoint identifier
   * @param listId  The Veeam native SharePoint List identifier
   * @param request a {@link O365SharePointRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/lists/{listId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreSharePointListTo(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("listId") String listId,
      O365SharePointRestoreOptionsRequest request);

  /**
   * Restore an Office 365 VBO SharePoint Library given the restore session UUID
   * its Veeam native id.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param siteId    The Veeam native SharePoint identifier
   * @param libraryId The Veeam native SharePoint Library identifier
   * @param request   a {@link O365SharePointRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/libraries/{libraryId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreSharePointLibraryTo(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("libraryId") String libraryId,
      O365SharePointRestoreOptionsRequest request);

  /**
   * Send an Office 365 VBO SharePoint Library given the restore session UUID
   * its Veeam native id to an email.
   * <p>
   * The maximum size of the combined files of a library you can send through email is 100 MB
   * and the maximum number of files you can send is 200.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param siteId    The Veeam native SharePoint identifier
   * @param libraryId The Veeam native SharePoint Library identifier
   * @param request   a {@link O365RestoreSessionSendToEmailRequest} instance
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/libraries/{libraryId}/actions/send-email")
  @Consumes(MediaType.APPLICATION_JSON)
  void sendSharePointLibraryToEmail(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("libraryId") String libraryId,
      O365RestoreSessionSendToEmailRequest request);

  /**
   * Restore an Office 365 VBO SharePoint Item given the restore session UUID
   * its Veeam native id.
   *
   * @param uuid    The Office 365 VBO Restore Session iland UUID
   * @param siteId  The Veeam native SharePoint identifier
   * @param itemId  The Veeam native SharePoint Item identifier
   * @param request a {@link O365SharePointRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/items/{itemId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreSharePointItemTo(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("itemId") String itemId,
      O365SharePointRestoreOptionsRequest request);

  /**
   * Restore an Office 365 VBO SharePoint Document given the restore session UUID
   * its Veeam native id.
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID
   * @param siteId     The Veeam native SharePoint identifier
   * @param documentId The Veeam native SharePoint Document identifier
   * @param request    a {@link O365SharePointRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/documents/{documentId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreSharePointDocumentTo(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("documentId") String documentId,
      O365SharePointRestoreOptionsRequest request);

  /**
   * Send an Office 365 VBO SharePoint Document given the restore session UUID
   * its Veeam native id to an email.
   * <p>
   * The maximum size of a document you can send through email is 100 MB.
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID
   * @param siteId     The Veeam native SharePoint identifier
   * @param documentId The Veeam native SharePoint Document identifier
   * @param request    a {@link O365RestoreSessionSendToEmailRequest} instance
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/documents/{documentId}/actions/send-email")
  @Consumes(MediaType.APPLICATION_JSON)
  void sendSharePointDocumentToEmail(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("documentId") String documentId,
      O365RestoreSessionSendToEmailRequest request);

  /**
   * Restore an Office 365 VBO SharePoint Folder given the restore session UUID
   * its Veeam native id.
   *
   * @param uuid     The Office 365 VBO Restore Session iland UUID
   * @param siteId   The Veeam native SharePoint identifier
   * @param folderId The Veeam native SharePoint Folder identifier
   * @param request  a {@link O365SharePointRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/folders/{folderId}/actions/restore")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreSharePointFolderTo(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("folderId") String folderId,
      O365SharePointRestoreOptionsRequest request);

  /**
   * Send an Office 365 VBO SharePoint Folder given the restore session UUID
   * its Veeam native id to an email.
   * <p>
   * The maximum size of the combined files of a folder you can send through email is 100 MB
   * and the maximum number of files you can send is 200.
   *
   * @param uuid     The Office 365 VBO Restore Session iland UUID
   * @param siteId   The Veeam native SharePoint identifier
   * @param folderId The Veeam native SharePoint Folder identifier
   * @param request  a {@link O365RestoreSessionSendToEmailRequest} instance
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/folders/{folderId}/actions/send-email")
  @Consumes(MediaType.APPLICATION_JSON)
  void sendSharePointFolderToEmail(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("folderId") String folderId,
      O365RestoreSessionSendToEmailRequest request);

  /**
   * Download an Office 365 VBO SharePoint Folder given the restore session UUID.
   * The Response object will contain the file download as a zip
   *
   * @param uuid     The Office 365 VBO Restore Session iland UUID
   * @param siteId   The Veeam native SharePoint identifier
   * @param folderId The Veeam native SharePoint Folder identifier
   * @return the input stream to the file being downloaded
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/folders/{folderId}/actions/save")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveSharePointFolder(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("folderId") String folderId);

  /**
   * Download an Office 365 VBO SharePoint Document given the restore session UUID.
   * The Response object will contain the file download as a zip
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID
   * @param siteId     The Veeam native SharePoint identifier
   * @param documentId The Veeam native SharePoint Document identifier
   * @return the input stream to the file being downloaded
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/documents/{documentId}/actions/save")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveSharePointDocument(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("documentId") String documentId);

  /**
   * Download an Office 365 VBO SharePoint Library given the restore session UUID.
   * The Response object will contain the file download as a zip
   *
   * @param uuid          The Office 365 VBO Restore Session iland UUID
   * @param siteId        The Veeam native SharePoint site identifier
   * @param libraryItemId The Veeam native SharePoint Library identifier
   * @return the input stream to the file being downloaded
   */
  @POST
  @Path("/{uuid}/sharepoint-sites/{siteId}/libraries/{libraryItemId}/actions/save")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveSharePointLibrary(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("siteId") String siteId,
      @PathParam("libraryItemId") String libraryItemId);

  /**
   * Download an Office 365 VBO OneDrive Folder given the restore session UUID.
   * The Response object will contain the file download as a zip
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID
   * @param oneDriveId The Veeam native OneDrive identifier
   * @param folderId   The Veeam native OneDrive Folder identifier
   * @return the input stream to the file being downloaded
   */
  @POST
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/folders/{folderId}/actions/save")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveOneDriveFolder(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      @PathParam("folderId") String folderId);

  /**
   * Download an Office 365 VBO OneDrive document given the restore session UUID.
   * The Response object will contain the file download as a zip
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID
   * @param oneDriveId The Veeam native OneDrive identifier
   * @param documentId The Veeam native OneDrive Document identifier
   * @return the input stream to the file being downloaded
   */
  @POST
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/documents/{documentId}/actions/save")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveOneDriveDocument(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId,
      @PathParam("documentId") String documentId);

  /**
   * Download an entire Office 365 VBO OneDrive given the restore session UUID.
   * The Response object will contain the file download as a zip
   *
   * @param uuid       The Office 365 VBO Restore Session iland UUID
   * @param oneDriveId The Veeam native OneDrive identifier
   * @return the input stream to the file being downloaded
   */
  @POST
  @Path("/{uuid}/onedrive-drives/{oneDriveId}/actions/save")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveEntireOneDrive(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("oneDriveId") String oneDriveId);

  /**
   * Download an Office 365 VBO Mailbox folder given the restore session UUID.
   * The Response object will contain the file download as a .pst file
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param mailboxId The Veeam native exchange mailbox identifier
   * @param folderId  The Veeam native exchange folder identifier
   * @return the input stream to the file being downloaded
   */
  @POST
  @Path("/{uuid}/exchange-mailboxes/{mailboxId}/folders/{folderId}/actions/save")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveExchangeMailboxFolder(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("mailboxId") String mailboxId,
      @PathParam("folderId") String folderId);

  /**
   * Download an Office 365 VBO Exchange item given the restore session UUID.
   * The Response object will contain the file download as either .pst or .msg
   * file as per requested option
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param mailboxId The Veeam native exchange mailbox identifier
   * @param itemId    The Veeam native exchange item identifier
   * @param format    The download format either MSG or PST.
   * @return the input stream to the file being downloaded
   */
  @POST
  @Path("/{uuid}/exchange-mailboxes/{mailboxId}/items/{itemId}/actions/save")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveExchangeMailboxItem(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("mailboxId") String mailboxId,
      @PathParam("itemId") String itemId,
      @QueryParam("format") O365ExchangeItemFormat format);

  /**
   * Begin preparing an entire Office 365 VBO Mailbox for download given the restore session UUID.
   * The Response object will contain the task to track the preparation progress.
   * Query the task individually via GET /tasks/{uuid} to retrieve the
   * {@code download_token} from {@code otherAttributes} for use with the
   * prepared download endpoint.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param mailboxId The Veeam native exchange mailbox identifier
   * @return the task that tracks the download preparation
   */
  @POST
  @Path("/{uuid}/exchange-mailboxes/{mailboxId}/actions/save")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse prepareExchangeMailboxExport(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("mailboxId") String mailboxId);

  /**
   * Download a VBO restore session file that was prepared using an asynchronous task.
   * The Response object will contain the file download with the appropriate extension.
   *
   * @param uuid the o365 restore session uuid
   * @param prepareDownloadTaskUuid      The prepare download asynchronous task UUID
   * @return the input stream to the file being downloaded
   */
  @POST
  @Path("/{uuid}/download/{prepareDownloadTaskUuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream downloadVboFile(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("prepareDownloadTaskUuid") String prepareDownloadTaskUuid);

  /**
   * Searches for Exchange Items in Mailbox
   *
   * @param uuid      Office 365 VBO restore session UUID
   * @param mailboxId The Veeam native mailbox identifier
   * @param page      the page number
   * @param pageSize  the page size
   * @param query     Search query request
   * @return a {@link O365ExchangeItemSetResponse} instance
   */
  @POST
  @Path("/{uuid}/exchange-mailboxes/{mailboxId}/actions/search")
  @Consumes(MediaType.APPLICATION_JSON)
  O365ExchangeItemSetResponse searchExchangeMailbox(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("mailboxId") String mailboxId,
      @QueryParam("offset") int page,
      @QueryParam("limit") int pageSize,
      O365SearchRequest query);

  /**
   * Searches for Exchange Items in Mailbox folder
   *
   * @param uuid       ffice 365 VBO restore session UUID
   * @param mailboxId The Veeam native mailbox identifier
   * @param folderId  The Veeam native mailbox folder identifier
   * @param page      the page number
   * @param pageSize  the page size
   * @param query     Search query request
   * @return a {@link O365ExchangeItemSetResponse} instance
   */
  @POST
  @Path("/{uuid}/exchange-mailboxes/{mailboxId}/folders/{folderId}/actions/search")
  @Consumes(MediaType.APPLICATION_JSON)
  O365ExchangeItemSetResponse searchExchangeMailboxFolder(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      @PathParam("mailboxId") String mailboxId,
      @PathParam("folderId")  String folderId,
      @QueryParam("offset") int page,
      @QueryParam("limit") int pageSize,
      O365SearchRequest query);

  /**
   * Export backed-up Microsoft Teams posts for the specified post ids
   * given the restore session UUID. The Response object will contain the .html
   * file.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param teamId    the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365TeamOptionsRequest} instance
   * @return the input stream to the file being downloaded from Veeam
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/posts/action/export")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream exportRestoreSessionTeamsPosts(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365TeamOptionsRequest request);

  /**
   * Export all the backed-up Microsoft Teams posts for the specified channel id for
   * the specified time period given the restore session UUID. The Response object will
   * contain the .html file.
   *
   * @param uuid    The Office 365 VBO Restore Session iland UUID
   * @param teamId  the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request a {@link O365ChannelExportRequest} instance
   * @return the input stream to the file being downloaded from Veeam
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/posts/action/export-all")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream exportRestoreSessionTeamsPostsByChannel(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365ChannelExportRequest request);

  /**
   * Download backed-up Microsoft Teams posts for the specified channel ids as .msg
   * files given the restore session UUID. The Response object will contain the .msg
   * file.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param teamId    the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @return the input stream to the file being downloaded from Veeam
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/posts/action/save-all")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveRestoreSessionTeamsPostsByChannel(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId);

  /**
   * Download backed-up Microsoft Teams posts for the specified post ids as .msg files
   * given the restore session UUID. The Response object will contain the .msg file.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param teamId    the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365TeamOptionsRequest} instance
   * @return the input stream to the file being downloaded from Veeam
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/posts/action/save")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveRestoreSessionTeamsPosts(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365TeamOptionsRequest request);

  /**
   * Send all the backed-up Microsoft Teams posts as an email attachment given the
   * restore session UUID and channel Id.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param teamId    the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365RestoreSessionSendToEmailRequest} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/posts/action/send-all-email")
  @Consumes(MediaType.APPLICATION_JSON)
  void sendRestoreSessionTeamsPostsByChannel(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365RestoreSessionSendToEmailRequest request);

  /**
   * Send backed-up Microsoft Teams posts as an email attachment given the restore
   * session UUID and post Ids.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param teamId    the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365TeamSendToEmailOptionsRequest request} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/posts/action/send-email")
  @Consumes(MediaType.APPLICATION_JSON)
  void sendRestoreSessionTeamsPosts(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365TeamSendToEmailOptionsRequest request);

  /**
   * Download backed-up Microsoft Teams files for the specified channel id as a zip file
   * given the restore session UUID. The Response object will contain the .zip file.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param teamId    the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @return the input stream to the file being downloaded from Veeam
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/files/action/save-all")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveRestoreSessionTeamsFilesByChannel(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId);

  /**
   * Download backed-up Microsoft Teams files for the specified file ids as a zip file
   * given the restore session UUID. The Response object will contain the .zip file.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param teamId    the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365TeamOptionsRequest} instance
   * @return the input stream to the file being downloaded from Veeam
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/files/action/save")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream saveRestoreSessionTeamsFiles(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365TeamOptionsRequest request);

  /**
   * Send backed-up Microsoft Teams files as an email attachment given the restore
   * session UUID and channel Ids.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param teamId    the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365RestoreSessionSendToEmailRequest} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/files/action/send-all-email")
  @Consumes(MediaType.APPLICATION_JSON)
  void sendRestoreSessionTeamsFilesByChannel(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365RestoreSessionSendToEmailRequest request);

  /**
   * Send backed-up Microsoft Teams files as an email attachment given the restore
   * session UUID and file Ids.
   *
   * @param uuid      The Office 365 VBO Restore Session iland UUID
   * @param teamId    the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365TeamSendToEmailOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/files/action/send-email")
  @Consumes(MediaType.APPLICATION_JSON)
  void sendRestoreSessionTeamsFiles(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365TeamSendToEmailOptionsRequest request);

  /**
   * Restores all the backed-up Microsoft Teams for an Org.
   * This method will return TaskResponse object immediately and submits the
   * restoration task in the background.
   *
   * @param uuid    The Office 365 VBO Restore Session iland UUID
   * @param request a {@link O365TeamRestoreOptionsRequest} instance
   * @return a {@link TaskResponse} instance
   */
  @POST
  @Path("/{uuid}/teams/action/restore-all-teams")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse restoreEntireTeamsForOrg(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid,
      O365TeamRestoreOptionsRequest request);

  /**
   * Restores specified backed-up Microsoft Teams by team ID for an Org given the
   * restore session UUID and team ID.
   *
   * @param uuid    The Office 365 VBO Restore Session iland UUID
   * @param teamId  the ID of the organization team
   * @param request a {@link O365TeamRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/action/restore-team")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse restoreTeamsByTeamId(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      O365TeamRestoreOptionsRequest request);

  /**
   * Restores specified backed-up Microsoft Teams channel by channel ID for an org
   * given the restore session UUID, team ID and channel ID.
   *
   * @param uuid      specifies the ID of the restore session
   * @param teamId    the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365TeamRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/action/restore-channel")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreTeamsChannelByChannelId(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365TeamRestoreOptionsRequest request);

  /**
   * Restores specified backed-up Microsoft Teams channel tabs by tab ID for an org
   * given the restore session UUID, team ID and channel ID.
   *
   * @param uuid      specifies the ID of the restore session
   * @param teamId    the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365TeamRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/tabs/action/restore-tabs")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreTeamsChannelTabsByTabId(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365TeamRestoreOptionsRequest request);

  /**
   * Restores specified backed-up Microsoft Teams posts by post ID for an Org
   * given the restore session UUID, team ID.
   *
   * @param uuid      specifies the ID of the restore session
   * @param teamId    Specifies the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365TeamRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/posts/action/restore-posts")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreTeamsPostsByPostId(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365TeamRestoreOptionsRequest request);

  /**
   * Restores backed-up Microsoft Teams posts by channel ID for an Org given
   * restore session UUID, team ID.
   *
   * @param uuid      specifies the ID of the restore session
   * @param teamId    Specifies the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365TeamRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/posts/action/restore-all-posts")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreTeamsPostsByChannelId(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365TeamRestoreOptionsRequest request);

  /**
   * Restores specified backed-up Microsoft Teams files by file ID for an Org
   * given restore session UUID, team ID.
   *
   * @param uuid      specifies the ID of the restore session
   * @param teamId    Specifies the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365TeamRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/files/action/restore-files")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreTeamsFilesByFileId(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365TeamRestoreOptionsRequest request);

  /**
   * Restores specified backed-up Microsoft Teams files by channel ID for an Org
   * given restore session UUID, team ID.
   *
   * @param uuid      specifies the ID of the restore session
   * @param teamId    Specifies the ID of the organization team
   * @param channelId the ID of the organization team channel
   * @param request   a {@link O365TeamRestoreOptionsRequest} instance
   */
  @POST
  @Path("/{uuid}/teams/{teamId}/channels/{channelId}/files/action/restore-all-files")
  @Consumes(MediaType.APPLICATION_JSON)
  void restoreTeamsFilesByChannelId(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid, @PathParam("teamId") String teamId,
      @PathParam("channelId") String channelId,
      O365TeamRestoreOptionsRequest request);

  /**
   * Get a device code response from Microsoft Azure to validate in the Microsoft
   * authentication portal. This is to be used while restoring in a session.
   *
   * @return a {@link O365DeviceCodeResponse} instance
   */
  @GET
  @Path("/{uuid}/actions/get-o365-device-code")
  @Consumes(MediaType.APPLICATION_JSON)
  O365DeviceCodeResponse getO365DeviceCode(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("uuid") String uuid);
}