/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.billing.BillingModelType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Bandwidth Usage Summary Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class BandwidthUsageSummaryResponse implements Serializable {

  private static final long serialVersionUID = -9553278388270122L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final double reservedAmount;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final double totalUsage;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final double burstUsage;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final int month;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final int year;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final BillingModelType billingModelType;

  public BandwidthUsageSummaryResponse(final double reservedAmount,
      final double totalUsage, final double burstUsage, final int month,
      final int year, final BillingModelType billingModelType) {
    this.reservedAmount = reservedAmount;
    this.totalUsage = totalUsage;
    this.burstUsage = burstUsage;
    this.month = month;
    this.year = year;
    this.billingModelType = billingModelType;
  }

  /**
   * Get reserved bandwidth amount in GB.
   *
   * @return reserved bandwidth amount
   */
  public double getReservedAmount() {
    return reservedAmount;
  }

  /**
   * Get total bandwidth usage in GB.
   *
   * @return total bandwidth usage
   */
  public double getTotalUsage() {
    return totalUsage;
  }

  /**
   * Get burst usage in GB.
   *
   * @return burst bandwidth usage
   */
  public double getBurstUsage() {
    return burstUsage;
  }

  /**
   * Get bandwidth summary's month.
   *
   * @return month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Get bandwidth summary's year.
   *
   * @return year
   */
  public int getYear() {
    return year;
  }

  /**
   * Returns the billing model type for the month the bandwidth summary
   * corresponds to.
   *
   * @return one of {@link BillingModelType}
   */

  public BillingModelType getBillingModelType() {
    return billingModelType;
  }

}
