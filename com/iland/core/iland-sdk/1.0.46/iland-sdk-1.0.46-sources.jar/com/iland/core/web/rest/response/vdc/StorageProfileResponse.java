/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vdc;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Storage Profile Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class StorageProfileResponse implements Serializable {

  private static final long serialVersionUID = 417740632982765773L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vdcUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Boolean enabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean defaultProfile;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String unit;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long limit;

  @Expose
  @SerializedName("storage_used_in_mb")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Integer storageUsedInMB;

  public StorageProfileResponse(final String uuid, final String vdcUuid,
      final String name, final boolean enabled, final boolean defaultProfile,
      final String unit, final long limit, final Integer storageUsedInMB) {
    this.uuid = uuid;
    this.vdcUuid = vdcUuid;
    this.name = name;
    this.enabled = enabled;
    this.defaultProfile = defaultProfile;
    this.unit = unit;
    this.limit = limit;
    this.storageUsedInMB = storageUsedInMB;
  }

  /**
   * Get the storage profile uuid.
   *
   * @return {@link String} uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Get the Vdc Uuid associated with this storage profile.
   *
   * @return {@link String} vdc uuid;
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Get the storage profile name
   *
   * @return {@link String} name
   */
  public String getName() {
    return name;
  }

  /**
   * Get whether the storage profile is enabled.
   *
   * @return is enabled
   */
  public Boolean isEnabled() {
    return enabled;
  }

  /**
   * Get whether the storage profile is the default.
   *
   * @return is enabled
   */
  public boolean isDefault() {
    return defaultProfile;
  }

  /**
   * Get the storage profile unit.
   *
   * @return {@link String} unit
   */
  public String getUnit() {
    return unit;
  }

  /**
   * Get the storage profile limit.
   *
   * @return limit
   */
  public long getLimit() {
    return limit;
  }

  /**
   * Get the storage used in MB.
   *
   * @return storage used in MB
   */
  public Integer getStorageUsedInMB() {
    return storageUsedInMB;
  }

}
