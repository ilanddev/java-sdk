/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscan;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * History Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public final class HistoryResponse {

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int historyId;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String uuid;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int ownerId;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String status;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int creationDate;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int lastModificationDate;

	public HistoryResponse(final int historyId, final String uuid,
		final int ownerId, final String status, final int creationDate,
		final int lastModificationDate) {
		this.historyId = historyId;
		this.uuid = uuid;
		this.ownerId = ownerId;
		this.status = status;
		this.creationDate = creationDate;
		this.lastModificationDate = lastModificationDate;
	}

	/**
	 * Get the history ID.
	 *
	 * @return history id
	 */
	public int getHistoryId() {
		return historyId;
	}

	/**
	 * Get the history uuid.
	 *
	 * @return {@link String} history uuid
	 */
	public String getUuid() {
		return uuid;
	}

	/**
	 * Get the owner ID.
	 *
	 * @return owner ID
	 */
	public int getOwnerId() {
		return ownerId;
	}

	/**
	 * Get the status.
	 *
	 * @return {@link String} status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Get the creation date.
	 *
	 * @return creation date
	 */
	public int getCreationDate() {
		return creationDate;
	}

	/**
	 * Get the last modification date.
	 *
	 * @return last modification date
	 */
	public int getLastModificationDate() {
		return lastModificationDate;
	}

}
