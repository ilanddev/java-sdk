/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.sdk;

import com.iland.core.web.rest.api.BackupGroupResource;
import com.iland.core.web.rest.api.BackupGroupV2Resource;
import com.iland.core.web.rest.api.CatalogResource;
import com.iland.core.web.rest.api.CompanyLocationResource;
import com.iland.core.web.rest.api.CompanyResource;
import com.iland.core.web.rest.api.CompanySSOResource;
import com.iland.core.web.rest.api.ConnectivityResource;
import com.iland.core.web.rest.api.ConstantsResource;
import com.iland.core.web.rest.api.DRRunbookResource;
import com.iland.core.web.rest.api.DownloadResource;
import com.iland.core.web.rest.api.EdgeGatewayResource;
import com.iland.core.web.rest.api.EdgeResource;
import com.iland.core.web.rest.api.EventResource;
import com.iland.core.web.rest.api.FrontEndFeatureResource;
import com.iland.core.web.rest.api.LicenseResource;
import com.iland.core.web.rest.api.LocationResource;
import com.iland.core.web.rest.api.MediaResource;
import com.iland.core.web.rest.api.NsxTApplicationPortProfileResource;
import com.iland.core.web.rest.api.NsxTEdgeGatewayResource;
import com.iland.core.web.rest.api.NsxTOrgVdcNetworkResource;
import com.iland.core.web.rest.api.O365JobResource;
import com.iland.core.web.rest.api.O365JobSessionResource;
import com.iland.core.web.rest.api.O365OrganizationResource;
import com.iland.core.web.rest.api.O365RestoreSessionResource;
import com.iland.core.web.rest.api.O365SearchBackupsResource;
import com.iland.core.web.rest.api.ObjectStorageResource;
import com.iland.core.web.rest.api.OffsetReplicationResource;
import com.iland.core.web.rest.api.OracleRecoveryResource;
import com.iland.core.web.rest.api.OrgReportingResource;
import com.iland.core.web.rest.api.OrgResource;
import com.iland.core.web.rest.api.OrgVdcNetworkResource;
import com.iland.core.web.rest.api.PhysicalFileRecoveryResource;
import com.iland.core.web.rest.api.ProtectionSourceResource;
import com.iland.core.web.rest.api.S3StorageResource;
import com.iland.core.web.rest.api.SqlRecoveryResource;
import com.iland.core.web.rest.api.TaskResource;
import com.iland.core.web.rest.api.UserResource;
import com.iland.core.web.rest.api.VacCompanyResource;
import com.iland.core.web.rest.api.VacJobProcessedObjectResource;
import com.iland.core.web.rest.api.VacJobResource;
import com.iland.core.web.rest.api.VappNetworkResource;
import com.iland.core.web.rest.api.VappResource;
import com.iland.core.web.rest.api.VappTemplateResource;
import com.iland.core.web.rest.api.VccFailoverPlanResource;
import com.iland.core.web.rest.api.VdcResource;
import com.iland.core.web.rest.api.VmResource;
import com.iland.core.web.rest.api.VpgResource;
import com.iland.core.web.sdk.connection.WebSocketClient;

/**
 * Public API Client.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class Client extends AbstractClient implements PlatformCoreApi {

  public Client(final String clientName, final String clientSecret) {
    super(clientName, clientSecret);
  }

  public Client(final String apiHost, final String apiPort,
      final String ssoHost, final String ssoPort, final String clientName,
      final String clientSecret) {
    super(apiHost, apiPort, ssoHost, ssoPort, clientName, clientSecret);
  }

  @Override
  public CatalogResource getCatalogResource() {
    return connection.getResource(CatalogResource.class);
  }

  /**
   * Get the reporting resource.
   *
   * @return {@link OrgReportingResource} instance
   */
  @Override
  public OrgReportingResource getReportingResource() {
    return connection.getResource(OrgReportingResource.class);
  }

  @Override
  public EdgeGatewayResource getEdgeGatewayResource() {
    return connection.getResource(EdgeGatewayResource.class);
  }

  @Override
  public FrontEndFeatureResource getFrontEndFeatureResource() {
    return connection.getResource(FrontEndFeatureResource.class);
  }

  @Override
  public NsxTEdgeGatewayResource getNsxTEdgeGatewayResource() {
    return connection.getResource(NsxTEdgeGatewayResource.class);
  }

  @Override
  public NsxTApplicationPortProfileResource getNsxTApplicationPortProfileResource() {
    return connection.getResource(NsxTApplicationPortProfileResource.class);
  }

  @Override
  public NsxTOrgVdcNetworkResource getNsxTOrgVdcNetworkResource() {
    return connection.getResource(NsxTOrgVdcNetworkResource.class);
  }

  @Override
  public EdgeResource getEdgeResource() {
    return connection.getResource(EdgeResource.class);
  }

  @Override
  public MediaResource getMediaResource() {
    return connection.getResource(MediaResource.class);
  }

  @Override
  public OrgResource getOrgResource() {
    return connection.getResource(OrgResource.class);
  }

  @Override
  public UserResource getUserResource() {
    return connection.getResource(UserResource.class);
  }

  @Override
  public VappResource getVappResource() {
    return connection.getResource(VappResource.class);
  }

  @Override
  public VappTemplateResource getVappTemplateResource() {
    return connection.getResource(VappTemplateResource.class);
  }

  @Override
  public VdcResource getVdcResource() {
    return connection.getResource(VdcResource.class);
  }

  @Override
  public SqlRecoveryResource getSqlRecoveryResource() {
    return connection.getResource(SqlRecoveryResource.class);
  }

  @Override
  public OracleRecoveryResource getOracleRecoveryResource() {
    return connection.getResource(OracleRecoveryResource.class);
  }

  @Override
  public PhysicalFileRecoveryResource getPhysicalFileRecoveryResource() {
    return connection.getResource(PhysicalFileRecoveryResource.class);
  }

  @Override
  public VmResource getVmResource() {
    return connection.getResource(VmResource.class);
  }

  @Override
  public LocationResource getLocationResource() {
    return connection.getResource(LocationResource.class);
  }

  @Override
  public VpgResource getVpgResource() {
    return connection.getResource(VpgResource.class);
  }

  @Override
  public CompanyResource getCompanyResource() {
    return connection.getResource(CompanyResource.class);
  }

  @Override
  public CompanyLocationResource getCompanyLocationResource() {
    return connection.getResource(CompanyLocationResource.class);
  }

  @Override
  public ConstantsResource getConstantsResource() {
    return connection.getResource(ConstantsResource.class);
  }

  @Override
  public OrgVdcNetworkResource getOrgVdcNetworkResource() {
    return connection.getResource(OrgVdcNetworkResource.class);
  }

  @Override
  public VappNetworkResource getVappNetworkResource() {
    return connection.getResource(VappNetworkResource.class);
  }

  @Override
  public DRRunbookResource getDRRunbookResource() {
    return connection.getResource(DRRunbookResource.class);
  }

  @Override
  public OffsetReplicationResource getOffsiteReplicationResource() {
    return connection.getResource(OffsetReplicationResource.class);
  }

  /**
   * Get the download resource.
   *
   * @return {@link DownloadResource} the download resource
   */
  @Override
  public DownloadResource getDownloadResource() {
    return connection.getResource(DownloadResource.class);
  }

  /**
   * Get the task resource.
   *
   * @return {@link TaskResource} the task resource
   */
  @Override
  public TaskResource getTaskResource() {
    return connection.getResource(TaskResource.class);
  }

  /**
   * Get the event resource.
   *
   * @return {@link EventResource} the event resource
   */
  @Override
  public EventResource getEventResource() {
    return connection.getResource(EventResource.class);
  }

  /**
   * Returns the VCC failover plan resource.
   *
   * @return {@link VccFailoverPlanResource} the VCC-R failover plan resource
   */
  @Override
  public VccFailoverPlanResource getVccFailoverPlanResource() {
    return connection.getResource(VccFailoverPlanResource.class);
  }

  /**
   * Get a web socket client.
   *
   * @param companyID {@link String} company id
   * @return {@link WebSocketClient} web socket client
   */
  @Override
  public WebSocketClient getEventWebSocket(final String companyID) {
    return new WebSocketClient(companyID, connection);
  }

  /**
   * Returns the VAC company resource.
   *
   * @return {@link VacCompanyResource} the VAC company resource
   */
  @Override
  public VacCompanyResource getVacCompanyResource() {
    return connection.getResource(VacCompanyResource.class);
  }

  /**
   * Returns the VAC job resource.
   *
   * @return {@link VacCompanyResource} the VAC company resource
   */
  @Override
  public VacJobResource getVacJobResource() {
    return connection.getResource(VacJobResource.class);
  }

  @Override
  public VacJobProcessedObjectResource getVacJobProcessedObjectResource() {
    return connection.getResource(VacJobProcessedObjectResource.class);
  }

  /**
   * Returns the Office 365 VBO organization resource.
   *
   * @return {@link O365OrganizationResource} the Office 365 VBO organization resource
   */
  @Override
  public O365OrganizationResource getO365OrganizationResource() {
    return connection.getResource(O365OrganizationResource.class);
  }

  /**
   * Returns the Office 365 Job resource.
   *
   * @return {@link O365JobResource} the office 365 VBO Job resource
   */
  @Override
  public O365JobResource getO365JobResource() {
    return connection.getResource(O365JobResource.class);
  }

  /**
   * Returns the Office 365 Job Session resource.
   *
   * @return {@link O365JobSessionResource} the office 365 VBO Job Session resource
   */
  @Override
  public O365JobSessionResource getO365JobSessionResource() {
    return connection.getResource(O365JobSessionResource.class);
  }

  /**
   * Returns the Office 365 Restore Session resource.
   *
   * @return {@link O365RestoreSessionResource} the office 365 VBO Job Session resource
   */
  @Override
  public O365RestoreSessionResource getO365RestoreSessionResource() {
    return connection.getResource(O365RestoreSessionResource.class);
  }

  /**
   * Returns the Office 365 Search Backups resource.
   *
   * @return {@link O365SearchBackupsResource} the Office 365 Search Backups
   *     resource
   */
  @Override
  public O365SearchBackupsResource getO365SearchBackupsResource() {
    return connection.getResource(O365SearchBackupsResource.class);
  }

  /**
   * Returns the Backup Group Resource.
   *
   * @return {@link BackupGroupResource}
   */
  @Override
  public BackupGroupResource getBackupGroupResource() {
    return connection.getResource(BackupGroupResource.class);
  }

  /**
   * Returns the Backup Group Resource.
   *
   * @return {@link BackupGroupResource}
   */
  @Override
  public BackupGroupV2Resource getBackupGroupV2Resource() {
    return connection.getResource(BackupGroupV2Resource.class);
  }

  /**
   * Returns the Protection Source Resource.
   *
   * @return {@link ProtectionSourceResource}
   */
  public ProtectionSourceResource getProtectionSourceResource() {
    return connection.getResource(ProtectionSourceResource.class);
  }

  /**
   * Returns the Object Storage Resource.
   *
   * @return {@link ObjectStorageResource}
   */
  @Override
  public ObjectStorageResource getObjectStorageResource() {
    return connection.getResource(ObjectStorageResource.class);
  }

  @Override
  public CompanySSOResource getCompanySSOResource() {
    return connection.getResource(CompanySSOResource.class);
  }

  @Override
  public ConnectivityResource getConnectivityResource() {
    return connection.getResource(ConnectivityResource.class);
  }

  @Override
  public S3StorageResource getS3StorageResource() {
    return connection.getResource(S3StorageResource.class);
  }

  @Override
  public LicenseResource getLicenseResource() {
    return connection.getResource(LicenseResource.class);
  }

}
