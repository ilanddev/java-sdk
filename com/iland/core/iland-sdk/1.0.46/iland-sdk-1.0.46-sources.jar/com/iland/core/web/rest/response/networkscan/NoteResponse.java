/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscan;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Note Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public final class NoteResponse {

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String title;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private String message;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private int severity;

	public NoteResponse(final String title, final String message,
		final int severity) {
		this.title = title;
		this.message = message;
		this.severity = severity;
	}

	/**
	 * Get the note title.
	 *
	 * @return {@link String} title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Get the note message.
	 *
	 * @return {@link String} message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Get the note severity.
	 *
	 * @return severity
	 */
	public int getSeverity() {
		return severity;
	}

}
