/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vapptemplate;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.NetworkIpScopeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.shared.network.FenceMode;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * vApp Template Network Configuration Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappTemplateNetworkConfigurationResponse implements Serializable {

  private static final long serialVersionUID = 5926856013460991366L;

  @Expose
  @SerializedName("name")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @SerializedName("description")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String description;

  @Expose
  @SerializedName("fence_mode")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final FenceMode fenceMode;

  @Expose
  @SerializedName("ip_scope")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final NetworkIpScopeResponse ipScope;

  @Expose
  @SerializedName("parent_network_name")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String parentNetworkName;

  /**
   * Instantiates a new Vapp template network configuration.
   *
   * @param name              the name
   * @param description       the description
   * @param fenceMode         the network adapter type
   * @param ipScope           the ip scope
   * @param parentNetworkName the parent network name
   */
  public VappTemplateNetworkConfigurationResponse(final String name,
      final String description, final FenceMode fenceMode,
      final NetworkIpScopeResponse ipScope, final String parentNetworkName) {
    this.name = name;
    this.description = description;
    this.fenceMode = fenceMode;
    this.ipScope = ipScope;
    this.parentNetworkName = parentNetworkName;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets network adapter type.
   *
   * @return the network adapter type
   */
  public FenceMode getFenceMode() {
    return fenceMode;
  }

  /**
   * Gets ip scope.
   *
   * @return the ip scope
   */
  public NetworkIpScopeResponse getIpScope() {
    return ipScope;
  }

  /**
   * Gets parent network name.
   *
   * @return the parent network name
   */
  public String getParentNetworkName() {
    return parentNetworkName;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }
}
