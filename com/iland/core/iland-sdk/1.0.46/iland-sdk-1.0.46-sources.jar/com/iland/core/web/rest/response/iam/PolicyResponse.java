/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.iam;

import java.io.Serializable;
import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.iam.IamEntityType;
import com.iland.core.api.iam.Permission;
import com.iland.core.api.iam.PolicyType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Policy Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class PolicyResponse implements Serializable {

  private static final long serialVersionUID = -518983931435797208L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String entityUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private IamEntityType domain;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private PolicyType type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Set<Permission> permissions;

  public PolicyResponse(final String entityUuid, final IamEntityType domain,
      final PolicyType type, final Set<Permission> permissions) {
    this.entityUuid = entityUuid;
    this.domain = domain;
    this.type = type;
    this.permissions = permissions;
  }

  /**
   * Get the entity uuid.
   *
   * @return {@link String} entity uuid
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Get the entity domain.
   *
   * @return {@link IamEntityType} entity domain
   */
  public IamEntityType getDomain() {
    return domain;
  }

  /**
   * Get the policy type.
   *
   * @return {@link PolicyType} policy type
   */
  public PolicyType getType() {
    return type;
  }

  /**
   * Get the set of permisssions.
   *
   * @return {@link Set} of {@link Permission}
   */
  public Set<Permission> getPermissions() {
    return permissions;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final PolicyResponse that = (PolicyResponse) o;

    if (entityUuid != null ?
        !entityUuid.equals(that.entityUuid) :
        that.entityUuid != null)
      return false;
    if (domain != that.domain)
      return false;
    if (type != that.type)
      return false;
    return permissions != null ?
        permissions.equals(that.permissions) :
        that.permissions == null;
  }

  @Override
  public int hashCode() {
    int result = entityUuid != null ? entityUuid.hashCode() : 0;
    result = 31 * result + (domain != null ? domain.hashCode() : 0);
    result = 31 * result + (type != null ? type.hashCode() : 0);
    result = 31 * result + (permissions != null ? permissions.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "PolicyResponse{" + "entityUuid='" + entityUuid + '\'' + ", domain="
        + domain + ", type=" + type + ", permissions=" + permissions + '}';
  }

}
