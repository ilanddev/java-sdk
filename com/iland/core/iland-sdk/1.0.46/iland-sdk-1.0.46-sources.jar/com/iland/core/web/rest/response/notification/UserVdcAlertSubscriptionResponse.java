/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.notification;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Vdc Alert Subscription Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserVdcAlertSubscriptionResponse implements Serializable {

  private static final long serialVersionUID = -8343463385602918044L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String username;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private AllocationModelResponse allocationModel;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean active;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int threshold;

  public UserVdcAlertSubscriptionResponse(final String username,
      final AllocationModelResponse allocationModel, final boolean active,
      final int threshold) {
    this.username = username;
    this.allocationModel = allocationModel;
    this.active = active;
    this.threshold = threshold;
  }

  /**
   * Whether subscription is active.
   *
   * @return is active
   */
  public boolean isActive() {
    return active;
  }

  /**
   * Get the username.
   *
   * @return {@link String} username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Get the threshold.
   *
   * @return the threshold
   */
  public int getThreshold() {
    return threshold;
  }

  /**
   * Get the allocation model.
   *
   * @return {@link AllocationModelResponse} allocation model
   */
  public AllocationModelResponse getAllocationModel() {
    return allocationModel;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserVdcAlertSubscriptionResponse that =
        (UserVdcAlertSubscriptionResponse) o;

    if (active != that.active)
      return false;
    if (threshold != that.threshold)
      return false;
    if (username != null ?
        !username.equals(that.username) :
        that.username != null)
      return false;
    return allocationModel != null ?
        allocationModel.equals(that.allocationModel) :
        that.allocationModel == null;
  }

  @Override
  public int hashCode() {
    int result = username != null ? username.hashCode() : 0;
    result = 31 * result + (allocationModel != null ?
        allocationModel.hashCode() :
        0);
    result = 31 * result + (active ? 1 : 0);
    result = 31 * result + threshold;
    return result;
  }

  @Override
  public String toString() {
    return "UserVdcAlertSubscriptionResponse{" + "username='" + username + '\''
        + ", allocationModel='" + allocationModel + '\'' + ", active=" + active
        + ", threshold=" + threshold + '}';
  }

}
