/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vapp;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Resource Summary Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class VappResourceSummaryResponse implements Serializable {

  private static final long serialVersionUID = -5268072154901725493L;

  private static final String RESERVED_CPU = "reserved_cpu";

  private static final String RESERVED_MEMORY = "reserved_mem";

  private static final String CONSUMED_CPU = "consumed_cpu";

  private static final String CONSUMED_MEMORY = "consumed_mem";

  private static final String CONSUMED_DISK = "consumed_disk";

  private static final String PROVISIONED_DISK = "provisioned_disk";

  private static final String NUMBER_OF_VMS = "number_of_vms";

  private static final String CONFIGURED_DISK = "configured_disk";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(RESERVED_CPU)
  private double reservedCpu;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(RESERVED_MEMORY)
  private double reservedMem;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(CONSUMED_CPU)
  private double consumedCpu;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(CONSUMED_MEMORY)
  private double consumedMem;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(CONSUMED_DISK)
  private double consumedDisk;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(PROVISIONED_DISK)
  private double provisionedDisk;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(CONFIGURED_DISK)
  private double configuredDisk;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(NUMBER_OF_VMS)
  private long numberOfVms;

  public VappResourceSummaryResponse(final double reservedCpu,
      final double reservedMem, final double consumedCpu,
      final double consumedMem, final double consumedDisk,
      final double provisionedDisk, final long numberOfVms,
      final double configuredDisk) {
    this.reservedCpu = reservedCpu;
    this.reservedMem = reservedMem;
    this.consumedCpu = consumedCpu;
    this.consumedMem = consumedMem;
    this.consumedDisk = consumedDisk;
    this.provisionedDisk = provisionedDisk;
    this.configuredDisk = configuredDisk;
    this.numberOfVms = numberOfVms;
  }

  /**
   * Get reserved cpu.
   *
   * @return reserved cpu
   */
  public double getReservedCpu() {
    return reservedCpu;
  }

  /**
   * Get reserved mem.
   *
   * @return reserved mem
   */
  public double getReservedMem() {
    return reservedMem;
  }

  /**
   * Get consumed cpu.
   *
   * @return consumed cpu
   */
  public double getConsumedCpu() {
    return consumedCpu;
  }

  /**
   * Get consumed mem.
   *
   * @return consumed mem
   */
  public double getConsumedMem() {
    return consumedMem;
  }

  /**
   * Get consumed disk.
   *
   * @return consumed disk
   */
  public double getConsumedDisk() {
    return consumedDisk;
  }

  /**
   * Get provisioned disk.
   *
   * @return provisioned disk
   */
  public double getProvisionedDisk() {
    return provisionedDisk;
  }

  /**
   * Get configured disk.
   *
   * @return configured disk
   */
  public double getConfiguredDisk() {
    return configuredDisk;
  }

  /**
   * Return the number of VMs.
   *
   * @return number of VMs
   */
  public long getNumberOfVms() {
    return numberOfVms;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("VappResourceSummaryResponse{");
    sb.append("reservedCpu=").append(reservedCpu);
    sb.append(", reservedMem=").append(reservedMem);
    sb.append(", consumedCpu=").append(consumedCpu);
    sb.append(", consumedDisk=").append(configuredDisk);
    sb.append(", provisionedDisk=").append(provisionedDisk);
    sb.append(", numberOfVms=").append(numberOfVms);
    sb.append(", configuredDisk=").append(configuredDisk);
    sb.append("}");
    return sb.toString();
  }

}
