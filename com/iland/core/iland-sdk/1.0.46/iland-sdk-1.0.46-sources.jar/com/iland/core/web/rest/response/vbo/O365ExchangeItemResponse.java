/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * O365 Exchange Item response.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365ExchangeItemResponse implements Serializable {

  private static final long serialVersionUID = 8363143519698938282L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired(
      "The Veeam native ID of the organization's backed up mailbox item.")
  private final String id;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The sender mailbox email address.")
  private final String from;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The recipient email address in carbon copy.")
  private final String cc;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The recipient address in blind carbon copy.")
  private final String bcc;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The recipient mailbox email address.")
  private final String to;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The date and time when the message was sent.")
  private final Instant sent;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The date and time when the message was received.")
  private final Instant received;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Whether or not that the message was sent with the reminder.")
  private final boolean reminder;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The subject of the email message.")
  private final String subject;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The class of the organization's backed up mailbox item.")
  private final String itemClass;

  public O365ExchangeItemResponse(final String id, final String from, final String cc,
      final String bcc, final String to, final Instant sent,
      final Instant received, final boolean reminder, final String subject,
      final String itemClass) {
    this.id = id;
    this.from = from;
    this.cc = cc;
    this.bcc = bcc;
    this.to = to;
    this.sent = sent;
    this.received = received;
    this.reminder = reminder;
    this.subject = subject;
    this.itemClass = itemClass;
  }

  /**
   * Returns the ID of the organization's backed up mailbox item.
   *
   * @return the exchange item Veeam native ID
   */
  public String getId() {
    return id;
  }

  /**
   * Returns the sender mailbox email address.
   *
   * @return the sender mailbox email address
   */
  public String getFrom() {
    return from;
  }

  /**
   * Returns the recipient email address in carbon copy.
   *
   * @return the recipient email address in carbon copy
   */
  public String getCc() {
    return cc;
  }

  /**
   * Returns the recipient address in blind carbon copy.
   *
   * @return the recipient address in blind carbon copy
   */
  public String getBcc() {
    return bcc;
  }

  /**
   * Returns the recipient mailbox email address.
   *
   * @return the recipient mailbox email address
   */
  public String getTo() {
    return to;
  }

  /**
   * Returns the date and time when the message was sent.
   *
   * @return the date and time when the message was sent as {@link Instant}
   */
  public Instant getSent() {
    return sent;
  }

  /**
   * Returns the date and time when the message was received.
   *
   * @return Specifies the date and time when the message was received as {@link Instant}
   */
  public Instant getReceived() {
    return received;
  }

  /**
   * Returns if whether or not that the message was sent with the reminder.
   *
   * @return true or false
   */
  public boolean isReminder() {
    return reminder;
  }

  /**
   * Returns the subject of the email message.
   *
   * @return the subject of the email message
   */
  public String getSubject() {
    return subject;
  }

  /**
   * Returns the class of the organization's backed up mailbox item.
   *
   * @return the exchange mailbox item class
   */
  public String getItemClass() {
    return itemClass;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final O365ExchangeItemResponse that = (O365ExchangeItemResponse) o;
    return reminder == that.reminder && Objects.equals(id, that.id) && Objects
        .equals(from, that.from) && Objects.equals(cc, that.cc) && Objects
        .equals(bcc, that.bcc) && Objects.equals(to, that.to) && Objects
        .equals(sent, that.sent) && Objects.equals(received, that.received)
        && Objects.equals(subject, that.subject) && Objects
        .equals(itemClass, that.itemClass);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(id, from, cc, bcc, to, sent, received, reminder, subject,
            itemClass);
  }
}
