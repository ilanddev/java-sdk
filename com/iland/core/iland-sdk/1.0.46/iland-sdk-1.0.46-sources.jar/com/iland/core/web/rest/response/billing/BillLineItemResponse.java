/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Bill Line Item Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class BillLineItemResponse implements Serializable {

  private static final long serialVersionUID = -8343041413567742273L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double costPerUnit;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double quantity;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String productId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vdcUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String contractId;

  public BillLineItemResponse(final String name, final double costPerUnit,
      final double quantity, final String productId, final String vdcUuid,
      final String contractId) {
    this.name = name;
    this.costPerUnit = costPerUnit;
    this.quantity = quantity;
    this.productId = productId;
    this.vdcUuid = vdcUuid;
    this.contractId = contractId;
  }

  /**
   * Get the line item name.
   *
   * @return {@link String} item name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the line item cost per unit.
   *
   * @return item cost per unit
   */
  public double getCostPerUnit() {
    return costPerUnit;
  }

  /**
   * Get the quantity of an item.
   *
   * @return item quantity
   */
  public double getQuantity() {
    return quantity;
  }

  /**
   * Get the item's Salesforce product id
   *
   * @return product id
   */
  public String getProductId() {
    return productId;
  }

  /**
   * Gets the associated vDC UUID.
   *
   * @return the vDC UUID
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Gets the associated contract ID.
   *
   * @return the associated contract ID
   */
  public String getContractId() {
    return contractId;
  }
}
