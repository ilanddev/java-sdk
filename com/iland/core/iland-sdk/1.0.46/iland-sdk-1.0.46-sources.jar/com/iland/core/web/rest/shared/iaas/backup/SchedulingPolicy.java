/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.policies.api.enums.Periodicity;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * Scheduling Policy.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class SchedulingPolicy implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * Specifies the time interval between two Group Runs of a continuous backup
   * schedule and any blackout periods when new Group Runs should NOT be started.
   * Set if periodicity is CONTINUOUS.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies the time interval between two Group Runs of a "
      + "continuous backup schedule and any blackout periods when new Group"
      + " Runs should NOT be started. Set if periodicity is CONTINUOUS.")
  private final ContinuousSchedule continuousSchedule;

  /**
   * Specifies a daily or weekly backup schedule. Set if periodicity is DAILY.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies a daily or weekly backup schedule. Set if "
      + "periodicity is DAILY.")
  private final DailySchedule dailySchedule;

  /**
   * Specifies a monthly backup schedule. Set if periodicity is MONTHLY.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies a monthly backup schedule. Set if periodicity is "
      + "MONTHLY.")
  private final MonthlySchedule monthlySchedule;

  /**
   * Specifies how often to start new Group Runs of a Backup Group.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies how often to start new Group Runs of a Backup Group.")
  private final Periodicity periodicity;

  /**
   * Instantiates a new Scheduling policy.
   *
   * @param continuousSchedule the continuous schedule
   * @param dailySchedule      the daily schedule
   * @param monthlySchedule    the monthly schedule
   * @param periodicity        the periodicity
   */
  public SchedulingPolicy(final ContinuousSchedule continuousSchedule,
      final DailySchedule dailySchedule, final MonthlySchedule monthlySchedule,
      final Periodicity periodicity) {
    this.continuousSchedule = continuousSchedule;
    this.dailySchedule = dailySchedule;
    this.monthlySchedule = monthlySchedule;
    this.periodicity = periodicity;
  }

  /**
   * Gets continuous schedule.
   *
   * @return the continuous schedule
   */
  public Optional<ContinuousSchedule> getContinuousSchedule() {
    return Optional.ofNullable(continuousSchedule);
  }

  /**
   * Gets daily schedule.
   *
   * @return the daily schedule
   */
  public Optional<DailySchedule> getDailySchedule() {
    return Optional.ofNullable(dailySchedule);
  }

  /**
   * Gets monthly schedule.
   *
   * @return the monthly schedule
   */
  public Optional<MonthlySchedule> getMonthlySchedule() {
    return Optional.ofNullable(monthlySchedule);
  }

  /**
   * Gets periodicity.
   *
   * @return the periodicity
   */
  public Periodicity getPeriodicity() {
    return periodicity;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final SchedulingPolicy that = (SchedulingPolicy) o;
    return Objects.equals(continuousSchedule, that.continuousSchedule)
        && Objects.equals(dailySchedule, that.dailySchedule) && Objects
        .equals(monthlySchedule, that.monthlySchedule)
        && periodicity == that.periodicity;
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(continuousSchedule, dailySchedule, monthlySchedule, periodicity);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("continuousSchedule", continuousSchedule)
        .add("dailySchedule", dailySchedule)
        .add("monthlySchedule", monthlySchedule).add("periodicity", periodicity)
        .toString();
  }
}
