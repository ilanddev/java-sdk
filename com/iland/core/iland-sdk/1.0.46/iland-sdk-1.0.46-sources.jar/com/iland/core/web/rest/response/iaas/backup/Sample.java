/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Instant;
import java.util.Map;
import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * Sample.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface Sample {

  /**
   * The timestamp of the sample.
   */
  Instant timestamp();

  /**
   * The value in bytes.
   */
  Optional<Long> value();

  /**
   * The component samples that contribute to the total value. A map of backup
   * cluster UID to value in bytes. Value may be null if the component has no
   * contribution.
   */
  Map<String, Long> components();

}
