/*
 * Copyright (c) 2013,2014 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 205 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */
package com.iland.core.web.rest.api;

import java.io.InputStream;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.common.UpdateMetadataRequest;
import com.iland.core.web.rest.request.vapptemplate.VappTemplateUpdateRequest;
import com.iland.core.web.rest.response.metadata.MetadataListResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vapptemplate.VappTemplateConfigurationResponse;
import com.iland.core.web.rest.response.vapptemplate.VappTemplateDownloadDetailsResponse;
import com.iland.core.web.rest.response.vapptemplate.VappTemplateResponse;
import com.iland.core.web.rest.response.vapptemplate.VappTemplateVmListResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Vapp Template Resource Interface v1.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "vApp Templates")
@Path("/vapp-templates")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface VappTemplateResource {

  /**
   * Retrieve a vApp Template.
   *
   * @param templateUuid vapp template uuid
   * @return vapp template object
   */
  @GET
  @Path("/{templateUuid}")
  VappTemplateResponse getVappTemplate(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP_TEMPLATE)
      @PathParam("templateUuid") String templateUuid);

  /**
   * Retrieve a vApp Template's detailed configuration.
   *
   * @param templateUuid vapp template uuid
   * @return vapp template configuration details
   */
  @GET
  @Path("/{templateUuid}/configuration")
  VappTemplateConfigurationResponse getVappTemplateConfiguration(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP_TEMPLATE)
      @PathParam("templateUuid") String templateUuid);

  /**
   * Retrieve a vApp Template's VMs.
   *
   * @param templateUuid vapp template uuid
   * @return vapp template vms list
   */
  @GET
  @Path("/{templateUuid}/vms")
  VappTemplateVmListResponse getVappTemplateVms(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP_TEMPLATE)
      @PathParam("templateUuid") String templateUuid);

  /**
   * Retrieve metadata associated with a vapp template.
   *
   * @param templateUuid vapp template uuid
   * @return list of metadata for the vapp template
   */
  @GET
  @Path("/{templateUuid}/metadata")
  MetadataListResponse getMetadataForVappTemplate(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VAPP_TEMPLATE)
      @PathParam("templateUuid") String templateUuid);

  /**
   * Add / update metadata associated with a vapp template.
   *
   * @param templateUuid vapp template uuid
   * @param metadata     of instances
   * @return asynchronous task details
   */
  @PUT
  @Path("/{templateUuid}/metadata")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateMetadataForVappTemplate(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_TEMPLATE_CONFIGURATION)
      @PathParam("templateUuid") String templateUuid,
      List<UpdateMetadataRequest> metadata);

  /**
   * Delete a specific piece of metadata associated with a vapp template by its
   * key.
   *
   * @param templateUuid vapp template uuid
   * @param key          metadata key
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{templateUuid}/metadata/{key}")
  TaskResponse deleteMetadataForVappTemplate(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_TEMPLATE_CONFIGURATION)
      @PathParam("templateUuid") String templateUuid,
      @PathParam("key") String key);

  /**
   * Update a Vapp Template.
   * <p>
   * Capable of updating the templates name, and description.
   *
   * @param templateUuid vapp template uuid
   * @param req          vapp template update request
   * @return asynchronous task details
   */
  @PUT
  @Path("/{templateUuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateVappTemplate(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_TEMPLATE_CONFIGURATION)
      @PathParam("templateUuid") String templateUuid,
      VappTemplateUpdateRequest req);

  /**
   * Delete a Vapp template.
   *
   * @param templateUuid vapp template uuid
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{templateUuid}")
  TaskResponse deleteVappTemplate(
      @SecureEntityRef(Permission.DELETE_ILAND_CLOUD_VAPP_TEMPLATE)
      @PathParam("templateUuid") String templateUuid);

  /**
   * Enable the download of the vapp template. Returns a CoreTask which monitors
   * the progress of the download. Use {@link #download(String)} endpoint when
   * task progress is synced to download the vapp template.
   *
   * @param templateUuid vapp template uuid
   */
  @POST
  @Path("/{templateUuid}/actions/enable-download")
  TaskResponse enableVappTemplateDownload(
      @SecureEntityRef(Permission.DOWNLOAD_ILAND_CLOUD_VAPP_TEMPLATE)
      @PathParam("templateUuid") String templateUuid);

  /**
   * Download the vApp template. {@link #enableVappTemplateDownload(String)}
   * must be called first and synced before attempting to download.
   *
   * @param templateUuid vapp template uuid
   * @return {@link InputStream} ova file
   */
  @GET
  @Path("/{templateUuid}/download")
  @Produces(IlandVersionedMediaType.V1_APPLICATION_OCTET_STREAM)
  InputStream download(
      @SecureEntityRef(Permission.DOWNLOAD_ILAND_CLOUD_VAPP_TEMPLATE)
      @PathParam("templateUuid") String templateUuid);

  /**
   * Gets download details for the vApp Template. Details include whether the
   * template is enabled for download, and, if enabled, the size and name of the
   * download.
   *
   * @param templateUuid vapp template uuid
   * @return the download details
   */
  @GET
  @Path("/{templateUuid}/download-details")
  VappTemplateDownloadDetailsResponse getDownloadDetails(
      @SecureEntityRef(Permission.DOWNLOAD_ILAND_CLOUD_VAPP_TEMPLATE)
      @PathParam("templateUuid") String templateUuid);

  /**
   * Sync a vapp template item belonging to a catalog with its source object.
   *
   * @param templateUuid vapp template uuid to sync
   * @return asynchronous task details
   */
  @POST
  @Path("/{templateUuid}/actions/sync")
  TaskResponse syncVappTemplate(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VAPP_TEMPLATE_CONFIGURATION)
      @PathParam("templateUuid") String templateUuid);

}
