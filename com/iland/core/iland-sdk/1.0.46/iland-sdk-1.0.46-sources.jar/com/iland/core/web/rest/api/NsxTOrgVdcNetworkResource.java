/*
 * Copyright (c) 2013 - 2024, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.common.location.LocationPrefixedUuid;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.nsxt.NetworkDhcpBindingRequest;
import com.iland.core.web.rest.request.nsxt.NetworkDhcpConfigurationRequest;
import com.iland.core.web.rest.response.nsxt.NetworkDhcpBindings;
import com.iland.core.web.rest.response.nsxt.NetworkDhcpConfiguration;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.shared.vcloud.NetworkConnection;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;
import com.iland.vcloud.nsx.common.model.OrgVdcNetworkUuid;
import com.iland.vcloud.nsxt.vdc.NetworkConnectionApi;
import com.iland.vcloud.nsxt.vdc.VdcNetworkDhcpApi;
import com.iland.vcloud.nsxt.vdc.VdcNetworkDhcpBindingApi;

/**
 * API for interacting with NSX-T backed Organization vDC Networks.
 */
@APIProperties(name = "NSX-T Backed Organization vDC Networks")
@Path("/nsx-t/vdcs/networks")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
// CHECKSTYLE.SUPPRESS: AbbreviationAsWordInName
public interface NsxTOrgVdcNetworkResource extends NetworkConnectionApi,
    VdcNetworkDhcpApi, VdcNetworkDhcpBindingApi {
  /**
   * Gets the Edge Gateway connection details for an Organization vDC Network.
   *
   * @param orgVdcNetworkUuid the Org vDC Network UUID
   * @return {@link NetworkConnection}
   */
  @Path("{orgVdcNetworkUuid}/connection")
  @GET
  NetworkConnection getNetworkEdgeConnection(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_INTERNAL_NETWORK)
      @PathParam("orgVdcNetworkUuid") OrgVdcNetworkUuid orgVdcNetworkUuid);

  /**
   * Modifies the Edge Gateway connection for an Organization vDC Network. The
   * modification is performed asynchronously - a Task is returned to track its
   * progress.
   *
   * @param orgVdcNetworkUuid the Org vDC Network UUID
   * @param request           the desired network connection state
   * @return {@link TaskResponse}
   */
  @Path("{orgVdcNetworkUuid}/connection")
  @PUT
  TaskResponse modifyNetworkEdgeConnection(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_INTERNAL_NETWORK_CONFIGURATION)
      @PathParam("orgVdcNetworkUuid") OrgVdcNetworkUuid orgVdcNetworkUuid,
      NetworkConnection request);


  /**
   * Gets an Organization vDC Network DHCP configuration.
   *
   * @param orgVdcNetworkUuid the Org vDC Network UUID
   * @return {@link NetworkDhcpConfiguration}
   */
  @Path("{orgVdcNetworkUuid}/dhcp")
  @GET
  NetworkDhcpConfiguration getNetworkDhcpConfiguration(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_INTERNAL_NETWORK)
      @PathParam("orgVdcNetworkUuid") OrgVdcNetworkUuid orgVdcNetworkUuid);

  /**
   * Modifies an Organization vDC Network DHCP configuration. The modification is
   * performed asynchronously - a Task is returned to track its progress.
   *
   * @param orgVdcNetworkUuid               the Org vDC Network UUID
   * @param networkDhcpConfigurationRequest the modified DHCP configuration
   * @return {@link TaskResponse}
   */
  @Path("{orgVdcNetworkUuid}/dhcp")
  @POST
  TaskResponse modifyNetworkDhcpConfiguration(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_INTERNAL_NETWORK_CONFIGURATION)
      @PathParam("orgVdcNetworkUuid") OrgVdcNetworkUuid orgVdcNetworkUuid,
      NetworkDhcpConfigurationRequest networkDhcpConfigurationRequest);

  /**
   * Deletes an Organization vDC Network DHCP configuration. The deletion is
   * performed asynchronously - a Task is returned to track its progress.
   *
   * @param orgVdcNetworkUuid the Org vDC Network UUID
   * @return {@link TaskResponse}
   */
  @Path("{orgVdcNetworkUuid}/dhcp")
  @DELETE
  TaskResponse deleteNetworkDhcpConfiguration(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_INTERNAL_NETWORK_CONFIGURATION)
      @PathParam("orgVdcNetworkUuid") OrgVdcNetworkUuid orgVdcNetworkUuid);

  /**
   * Gets a list of Organization vDC Network DHCP Bindings for a given Organization
   * vDC Network.
   *
   * @param orgVdcNetworkUuid the Org vDC Network UUID
   * @return {@link NetworkDhcpBindings}
   */
  @Path("{orgVdcNetworkUuid}/dhcp/bindings")
  @GET
  NetworkDhcpBindings getNetworkDhcpBindings(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_INTERNAL_NETWORK)
      @PathParam("orgVdcNetworkUuid") OrgVdcNetworkUuid orgVdcNetworkUuid);

  /**
   * Creates a new Organization vDC Network DHCP Binding. The creation is performed
   * asynchronously - a Task is returned to track its progress.
   *
   * @param orgVdcNetworkUuid  the UUID of the Org vDC Network to create the binding on
   * @param networkDhcpBindingRequest the DHCP binding to create
   * @return {@link TaskResponse}
   */
  @Path("{orgVdcNetworkUuid}/dhcp/bindings")
  @POST
  TaskResponse createNetworkDhcpBinding(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_INTERNAL_NETWORK_CONFIGURATION)
      @PathParam("orgVdcNetworkUuid") OrgVdcNetworkUuid orgVdcNetworkUuid,
      NetworkDhcpBindingRequest networkDhcpBindingRequest);

  /**
   * Modifies an existing Organization vDC Network DHCP Binding. The modification
   * is performed asynchronously - a Task is returned to track its progress.
   *
   * @param orgVdcNetworkUuid  the UUID of the Org vDC Network to modify the binding on
   * @param networkDhcpBindingRequest the modified DHCP binding
   * @param dhcpBindingId the UUID of the dhcp binding to modify
   * @return {@link TaskResponse}
   */
  @Path("{orgVdcNetworkUuid}/dhcp/bindings/{dhcpBindingId}")
  @PUT
  TaskResponse modifyNetworkDhcpBinding(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_INTERNAL_NETWORK_CONFIGURATION)
      @PathParam("orgVdcNetworkUuid") OrgVdcNetworkUuid orgVdcNetworkUuid,
      @PathParam("dhcpBindingId") LocationPrefixedUuid dhcpBindingId,
      NetworkDhcpBindingRequest networkDhcpBindingRequest);

  /**
   * Deletes an existing Organization vDC Network DHCP Binding. The deletion
   * is performed asynchronously - a Task is returned to track its progress.
   *
   * @param orgVdcNetworkUuid the UUID of the Org vDC Network to delete the binding on
   * @param dhcpBindingId the UUID of the dhcp binding to delete
   * @return {@link TaskResponse}
   */
  @Path("{orgVdcNetworkUuid}/dhcp/bindings/{dhcpBindingId}")
  @DELETE
  TaskResponse deleteNetworkDhcpBinding(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_INTERNAL_NETWORK_CONFIGURATION)
      @PathParam("orgVdcNetworkUuid") OrgVdcNetworkUuid orgVdcNetworkUuid,
      @PathParam("dhcpBindingId") LocationPrefixedUuid dhcpBindingId);
}
