/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vapp;

import java.io.Serializable;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Startup Section Item Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class VappStartupSectionItemResponse implements Serializable {

  private static final long serialVersionUID = 5892571082726390712L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String vmName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int order;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String startupAction;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String stopAction;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int startDelay;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int stopDelay;

  public VappStartupSectionItemResponse(final String vmName, final int order,
      final String startupAction, final String stopAction, final int startDelay,
      final int stopDelay) {
    this.vmName = vmName;
    this.order = order;
    this.startupAction = startupAction;
    this.stopAction = stopAction;
    this.startDelay = startDelay;
    this.stopDelay = stopDelay;
  }

  /**
   * Get the VM name.
   *
   * @return {@link String} vm name
   */
  public String getVmName() {
    return vmName;
  }

  /**
   * Get the order precedence for this item.
   *
   * @return order precedence specifier
   */
  public int getOrder() {
    return order;
  }

  /**
   * Get the startup action associated with this item.
   *
   * @return {@link String} startup action
   */
  public String getStartAction() {
    return startupAction;
  }

  /**
   * Get the stop action associated with this item.
   *
   * @return {@link String} stop action
   */
  public String getStopAction() {
    return stopAction;
  }

  /**
   * Get the item's startup delay.
   *
   * @return start delay in seconds
   */
  public int getStartDelay() {
    return startDelay;
  }

  /**
   * Get the item's stop delay.
   *
   * @return stop delay in seconds
   */
  public int getStopDelay() {
    return stopDelay;
  }

  @Override
  public boolean equals(Object object) {
    if (object == null || getClass() != object.getClass()) {
      return false;
    }
    VappStartupSectionItemResponse that =
        (VappStartupSectionItemResponse) object;
    return Objects.equals(vmName, that.getVmName()) && Objects
        .equals(order, that.getOrder()) && Objects
        .equals(startupAction, that.getStartAction()) && Objects
        .equals(stopAction, that.getStopAction()) && Objects
        .equals(startDelay, that.getStartDelay()) && Objects
        .equals(stopDelay, that.getStopDelay());
  }

  @Override
  public String toString() {
    final StringBuilder sb =
        new StringBuilder("VappStartupSectionItemResponse{");
    sb.append("vnName='").append(vmName).append('\'');
    sb.append(", order=").append(order);
    sb.append(", startupAction='").append(startupAction).append('\'');
    sb.append(", stopAction='").append(stopAction).append('\'');
    sb.append(", startDelay=").append(startDelay);
    sb.append(", stopDelay=").append(stopDelay);
    sb.append('}');
    return sb.toString();
  }

}
