/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Org vDCs Bill Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class OrgVdcBillsResponse implements Serializable {

  private static final long serialVersionUID = -3082720661098294173L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String orgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int month;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private int year;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<BillResponse> vdcBills;

  public OrgVdcBillsResponse(final String orgUuid, final int month,
      final int year, final List<BillResponse> vdcBills) {
    this.orgUuid = orgUuid;
    this.month = month;
    this.year = year;
    this.vdcBills = vdcBills;
  }

  /**
   * Get the list of vDC bills for the given org.
   *
   * @return {@link List} of {@link BillResponse} vDC vdcBills
   */
  public List<BillResponse> getVdcBills() {
    return vdcBills;
  }

  /**
   * Get the org uuid.
   *
   * @return {@link String} org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Get the month.
   *
   * @return month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Get the year.
   *
   * @return year
   */
  public int getYear() {
    return year;
  }

}
