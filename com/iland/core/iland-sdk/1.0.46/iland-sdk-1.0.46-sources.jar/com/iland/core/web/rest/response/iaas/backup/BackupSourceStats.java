/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * BackupSourceStats.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class BackupSourceStats {

  @Expose
  @JsonOptional(
      "Specifies the time the task was unqueued from the queue to start running. "
          + "This field can be used to determine the following times: initial-wait-time "
          + "= admittedTimeUsecs - startTimeUsecs run-time = endTimeUsecs - "
          + "admittedTimeUsecs If the task ends up waiting in other queues, then actual "
          + "run-time will be smaller than the run-time computed this way.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant admittedTime;

  @Expose
  @JsonOptional("Specifies the end time of the backup run.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant endTime;

  @Expose
  @JsonRequired(
      "Specifies the start time of the Protection Run. This time is when the task "
          + "is queued to an internal queue where tasks are waiting to run.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant startTime;

  @Expose
  @JsonOptional(
      "Specifies the actual execution time for the protection run to complete the "
          + "backup task and the copy tasks. This time will not include the time waited "
          + "in various internal queues.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Long timeTakenMillis;

  @Expose
  @JsonRequired("Specifies the total amount of data read from the source (so far).")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long totalBytesReadFromSource;

  @Expose
  @JsonRequired("Specifies the total amount of data expected to be read from the source.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long totalBytesToReadFromSource;

  @Expose
  @JsonRequired(
      "Specifies the size of the source object (such as a VM) protected by this "
          + "task on the primary storage after the snapshot is taken. The logical size "
          + "of the data on the source if the data is fully hydrated or expanded and not "
          + "reduced by change-block tracking, compression and deduplication.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long totalLogicalBackupSizeBytes;

  @Expose
  @JsonRequired(
      "Specifies the total amount of physical space used to store the protected "
          + "object after being reduced by change-block tracking, compression and "
          + "deduplication. For example, if the logical backup size is 1GB, but only 1MB "
          + "was used to store it, this field be equal to 1MB.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long totalPhysicalBackupSizeBytes;

  @Expose
  @JsonRequired(
      "Specifies the size of the source object (such as a VM) protected by this "
          + "task on the primary storage before the snapshot is taken. The logical size "
          + "of the data on the source if the data is fully hydrated or expanded and not "
          + "reduced by change-block tracking, compression and deduplication.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long totalSourceSizeBytes;

  public BackupSourceStats(final Instant admittedTime, final Instant endTime,
      final Instant startTime, final Long timeTakenMillis,
      final long totalBytesReadFromSource,
      final long totalBytesToReadFromSource,
      final long totalLogicalBackupSizeBytes,
      final long totalPhysicalBackupSizeBytes,
      final long totalSourceSizeBytes) {
    this.admittedTime = admittedTime;
    this.endTime = endTime;
    this.startTime = startTime;
    this.timeTakenMillis = timeTakenMillis;
    this.totalBytesReadFromSource = totalBytesReadFromSource;
    this.totalBytesToReadFromSource = totalBytesToReadFromSource;
    this.totalLogicalBackupSizeBytes = totalLogicalBackupSizeBytes;
    this.totalPhysicalBackupSizeBytes = totalPhysicalBackupSizeBytes;
    this.totalSourceSizeBytes = totalSourceSizeBytes;
  }

  /**
   * Specifies the time the task was unqueued from the queue to start running.
   * This field can be used to determine the following times: initial-wait-time
   * = admittedTimeUsecs - startTimeUsecs run-time = endTimeUsecs -
   * admittedTimeUsecs If the task ends up waiting in other queues, then actual
   * run-time will be smaller than the run-time computed this way.
   */
  public Optional<Instant> getAdmittedTime() {
    return Optional.ofNullable(admittedTime);
  }

  /**
   * Specifies the end time of the backup run.
   */
  public Optional<Instant> getEndTime() {
    return Optional.ofNullable(endTime);
  }

  /**
   * Specifies the start time of the Protection Run. This time is when the task
   * is queued to an internal queue where tasks are waiting to run.
   */
  public Instant getStartTime() {
    return startTime;
  }

  /**
   * Specifies the actual execution time for the protection run to complete the
   * backup task and the copy tasks. This time will not include the time waited
   * in various internal queues.
   */
  public Optional<Long> getTimeTakenMillis() {
    return Optional.ofNullable(timeTakenMillis);
  }

  /**
   * Specifies the total amount of data read from the source (so far).
   */
  public long getTotalBytesReadFromSource() {
    return totalBytesReadFromSource;
  }

  /**
   * Specifies the total amount of data expected to be read from the source.
   */
  public long getTotalBytesToReadFromSource() {
    return totalBytesToReadFromSource;
  }

  /**
   * Specifies the size of the source object (such as a VM) protected by this
   * task on the primary storage after the snapshot is taken. The logical size
   * of the data on the source if the data is fully hydrated or expanded and not
   * reduced by change-block tracking, compression and deduplication.
   */
  public long getTotalLogicalBackupSizeBytes() {
    return totalLogicalBackupSizeBytes;
  }

  /**
   * Specifies the total amount of physical space used to store the protected
   * object after being reduced by change-block tracking, compression and
   * deduplication. For example, if the logical backup size is 1GB, but only 1MB
   * was used to store it, this field be equal to 1MB.
   */
  public long getTotalPhysicalBackupSizeBytes() {
    return totalPhysicalBackupSizeBytes;
  }

  /**
   * Specifies the size of the source object (such as a VM) protected by this
   * task on the primary storage before the snapshot is taken. The logical size
   * of the data on the source if the data is fully hydrated or expanded and not
   * reduced by change-block tracking, compression and deduplication.
   */
  public long getTotalSourceSizeBytes() {
    return totalSourceSizeBytes;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BackupSourceStats that = (BackupSourceStats) o;
    return totalBytesReadFromSource == that.totalBytesReadFromSource
        && totalBytesToReadFromSource == that.totalBytesToReadFromSource
        && totalLogicalBackupSizeBytes == that.totalLogicalBackupSizeBytes
        && totalPhysicalBackupSizeBytes == that.totalPhysicalBackupSizeBytes
        && totalSourceSizeBytes == that.totalSourceSizeBytes && Objects
        .equals(admittedTime, that.admittedTime) && Objects
        .equals(endTime, that.endTime) && Objects
        .equals(startTime, that.startTime) && Objects
        .equals(timeTakenMillis, that.timeTakenMillis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(admittedTime, endTime, startTime, timeTakenMillis,
        totalBytesReadFromSource, totalBytesToReadFromSource,
        totalLogicalBackupSizeBytes, totalPhysicalBackupSizeBytes,
        totalSourceSizeBytes);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("admittedTime", admittedTime)
        .add("endTime", endTime).add("startTime", startTime)
        .add("timeTaken", timeTakenMillis)
        .add("totalBytesReadFromSource", totalBytesReadFromSource)
        .add("totalBytesToReadFromSource", totalBytesToReadFromSource)
        .add("totalLogicalBackupSizeBytes", totalLogicalBackupSizeBytes)
        .add("totalPhysicalBackupSizeBytes", totalPhysicalBackupSizeBytes)
        .add("totalSourceSizeBytes", totalSourceSizeBytes).toString();
  }
}
