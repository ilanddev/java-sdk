/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.performance;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Performance Counter Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class PerformanceCounterResponse implements Serializable {

  private static final long serialVersionUID = -3798644405516218868L;

  private static final String GROUP = "group";

  private static final String NAME = "name";

  private static final String TYPE = "type";

  @Expose
  @SerializedName(GROUP)
  private String group;

  @Expose
  @SerializedName(NAME)
  private String name;

  @Expose
  @SerializedName(TYPE)
  private String type;

  public PerformanceCounterResponse(final String group, final String name,
      final String type) {
    this.group = group;
    this.name = name;
    this.type = type;
  }

  /**
   * Get the performance counter group.
   *
   * @return {@link String} performance counter group
   */
  public String getGroup() {
    return group;
  }

  /**
   * Get the performance counter name.
   *
   * @return {@link String} performance counter name
   */
  public String getName() {
    return name;
  }

  /**
   * Get the performance counter type.
   *
   * @return {@link String} performance counter type
   */
  public String getType() {
    return type;
  }

}
