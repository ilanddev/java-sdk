/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.user;

import java.util.Set;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * User Creation Set Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIModel
public interface UserCreationSetResponse {

  /**
   * Set of users creation responses.
   *
   * @return {@link Set} of {@link UserCreationResponse} user creation response
   */
  Set<UserCreationResponse> users();
}
