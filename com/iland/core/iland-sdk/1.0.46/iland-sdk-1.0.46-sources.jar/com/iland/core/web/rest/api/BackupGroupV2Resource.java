/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.cohesity.iaas.backups.backupgroups.BackupGroupV2PlatformApi;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.BackupGroupStateParams;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.BackupGroupV2;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.BlockBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.FileBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.MssqlFileBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.MssqlNativeBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.MssqlVolumeBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.OracleBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.common.model.BackupGroupUid;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Extended Backup Groups Public API.
 */
@APIProperties(name = "Backup Groups (Extended)")
@Path("/backup-groups-x")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface BackupGroupV2Resource extends BackupGroupV2PlatformApi {

	/**
	 * Gets a backup group.
	 *
	 * @param backupGroupUid the {@link BackupGroupUid}
	 * @return a {@link BackupGroupV2 backup group}
	 * @throws NotFoundException if the backup group is not found
	 */
	@GET
	@Path("/{backupGroupUid}")
	BackupGroupV2 getBackupGroup(
		@SecureEntityRef(Permission.VIEW_ILAND_CLOUD_BACKUP_GROUP)
		@PathParam("backupGroupUid") BackupGroupUid backupGroupUid,
		@QueryParam("includeSummaryStats") boolean includeSummaryStats,
		@QueryParam("includeLastRun") boolean includeLastRun,
		@QueryParam("includeBackupPolicy") boolean includeBackupPolicy);

	/**
	 * Update a file-based backup group.
	 *
	 * @param backupGroupUid the UID of the backup group
	 * @param updateRequest  the update request body
	 * @return {@link BackupGroupResponse}
	 * @throws NotFoundException if the backup group is not found
	 */
	@PUT
	@Path("/{backupGroupUid}/file")
	@Consumes(MediaType.APPLICATION_JSON)
	BackupGroupV2 updateBackupGroup(
		@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_BACKUP_GROUP_CONFIGURATION)
		@PathParam("backupGroupUid") BackupGroupUid backupGroupUid,
		FileBasedBackupGroupWithCommonParams updateRequest);

	/**
	 * Update a block-based backup group.
	 *
	 * @param backupGroupUid the UID of the backup group
	 * @param updateRequest  the update request body
	 * @return {@link BackupGroupResponse}
	 * @throws NotFoundException if the backup group is not found
	 */
	@PUT
	@Path("/{backupGroupUid}/block")
	@Consumes(MediaType.APPLICATION_JSON)
	BackupGroupV2 updateBackupGroup(
		@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_BACKUP_GROUP_CONFIGURATION)
		@PathParam("backupGroupUid") BackupGroupUid backupGroupUid,
		BlockBasedBackupGroupWithCommonParams updateRequest);

	/**
	 * Update a MSSQL file-based backup group.
	 *
	 * @param backupGroupUid the UID of the backup group
	 * @param updateRequest  the update request body
	 * @return {@link BackupGroupResponse}
	 * @throws NotFoundException if the backup group is not found
	 */
	@PUT
	@Path("/{backupGroupUid}/mssql/file")
	@Consumes(MediaType.APPLICATION_JSON)
	BackupGroupV2 updateBackupGroup(
		@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_BACKUP_GROUP_CONFIGURATION)
		@PathParam("backupGroupUid") BackupGroupUid backupGroupUid,
		MssqlFileBasedBackupGroupWithCommonParams updateRequest);

	/**
	 * Update a MSSQL volume-based backup group.
	 *
	 * @param backupGroupUid the UID of the backup group
	 * @param updateRequest  the update request body
	 * @return {@link BackupGroupResponse}
	 * @throws NotFoundException if the backup group is not found
	 */
	@PUT
	@Path("/{backupGroupUid}/mssql/volume")
	@Consumes(MediaType.APPLICATION_JSON)
	BackupGroupV2 updateBackupGroup(
		@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_BACKUP_GROUP_CONFIGURATION)
		@PathParam("backupGroupUid") BackupGroupUid backupGroupUid,
		MssqlVolumeBasedBackupGroupWithCommonParams updateRequest);

	/**
	 * Update a MSSQL native-based backup group.
	 *
	 * @param backupGroupUid the UID of the backup group
	 * @param updateRequest  the update request body
	 * @return {@link BackupGroupResponse}
	 * @throws NotFoundException if the backup group is not found
	 */
	@PUT
	@Path("/{backupGroupUid}/mssql/native")
	@Consumes(MediaType.APPLICATION_JSON)
	BackupGroupV2 updateBackupGroup(
		@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_BACKUP_GROUP_CONFIGURATION)
		@PathParam("backupGroupUid") BackupGroupUid backupGroupUid,
		MssqlNativeBasedBackupGroupWithCommonParams updateRequest);

  /**
   * Update a Oracle native-based backup group.
   *
   * @param backupGroupUid the UID of the backup group
   * @param updateRequest  the update request body
   * @return {@link BackupGroupResponse}
   * @throws NotFoundException if the backup group is not found
   */
  @PUT
  @Path("/{backupGroupUid}/oracle")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupGroupV2 updateBackupGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_BACKUP_GROUP_CONFIGURATION)
      @PathParam("backupGroupUid") BackupGroupUid backupGroupUid,
      OracleBasedBackupGroupWithCommonParams updateRequest);

	/**
	 * Pause or resume a backup group. After a backup group is paused, no new runs
	 * will be started but any existing runs will continue to execute.
	 *
	 * @param backupGroupUid the UID of the backup group
	 * @param request        request containing the desired backup group state
	 * @return the updated {@link BackupGroupV2}
	 * @throws NotFoundException if the backup group is not found
	 */
	@POST
	@Path("/{backupGroupUid}/state")
	BackupGroupV2 setState(@SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_BACKUP_GROUP_CONFIGURATION)
			@PathParam("backupGroupUid") BackupGroupUid backupGroupUid,
			BackupGroupStateParams request);

}
