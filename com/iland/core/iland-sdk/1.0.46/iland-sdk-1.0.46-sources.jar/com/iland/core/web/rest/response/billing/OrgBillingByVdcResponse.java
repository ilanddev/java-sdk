/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Org Billing By Vdc Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class OrgBillingByVdcResponse implements Serializable {

  private static final long serialVersionUID = 1536998751213967916L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Map<Long, Map<String, Map<String, BillResponse>>> billingByVdc;

  public OrgBillingByVdcResponse(
      final Map<Long, Map<String, Map<String, BillResponse>>> billingByVdc) {
    this.billingByVdc = billingByVdc;
  }

  /**
   * Get a map of bills by vDC.
   *
   * @return map of org billing broken down by vDC
   */
  public Map<Long, Map<String, Map<String, BillResponse>>> getBillingByVdc() {
    return billingByVdc;
  }

}
