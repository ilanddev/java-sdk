/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Billing Sample Serie Response object.
 *
 * @author <a href="mailto:aquinones@iland.com">Ari Quinones</a>
 */
@APIDoc
public class BillingSampleSerieResponse implements Serializable {

  private static final long serialVersionUID = 3182801364972380539L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String entityUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String entityName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private long interval;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String summary;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private List<BillingSampleResponse> samples;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String currencyCode;

  public BillingSampleSerieResponse(final String entityUuid,
      final String entityName, final long interval, final String summary,
      final List<BillingSampleResponse> samples, final String currencyCode) {
    this.entityUuid = entityUuid;
    this.entityName = entityName;
    this.interval = interval;
    this.summary = summary;
    this.samples = samples;
    this.currencyCode = currencyCode;
  }

  /**
   * Get entity uuid of Billing Sample Serie Response
   *
   * @return {@link String} entity uuid
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Get entity name of Billing Sample Serie Response
   *
   * @return {@link String} entity name
   */
  public String getEntityName() {
    return entityName;
  }

  /**
   * Get interval of Billing Sample Serie Response
   *
   * @return long value
   */
  public long getInterval() {
    return interval;
  }

  /**
   * Get summary of Billing Sample Serie Response
   *
   * @return {@link String} summary
   */
  public String getSummary() {
    return summary;
  }

  /**
   * Get list of billing sample responses of Billing Sample Serie Response
   *
   * @return {@link List} of {@link BillingSampleResponse} samples
   */
  public List<BillingSampleResponse> getSamples() {
    return samples;
  }

  /**
   * Get currency code of Billing Sample Serie Response
   *
   * @return {@link String} currency code
   */
  public String getCurrencyCode() {
    return currencyCode;
  }
}
