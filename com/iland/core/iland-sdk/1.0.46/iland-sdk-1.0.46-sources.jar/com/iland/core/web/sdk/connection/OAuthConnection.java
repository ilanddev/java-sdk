/*
 * Copyright (c) 2013 - 2017, iland Internet Solutions, Corp
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of iland Internet Solutions, Corp nor the names of its
 *       contributors may be used to endorse or promote products derived from this
 *       software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
package com.iland.core.web.sdk.connection;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.common.annotations.VisibleForTesting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;
import org.jboss.resteasy.client.jaxrs.engines.ApacheHttpClient43Engine;
import org.jboss.resteasy.client.jaxrs.internal.LocalResteasyProviderFactory;
import org.jboss.resteasy.spi.ResteasyProviderFactory;

/**
 * OAuthConnection.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class OAuthConnection {

  private static final Logger log = LoggerFactory.getLogger(OAuthConnection.class);

  private static final Gson gson = new GsonBuilder().create();

  private final String oauthHost;

  private final String apiHost;

  // Thread local variable containing API version to be used on next request
  private static final ThreadLocal<Double> resourceVersion =
      ThreadLocal.withInitial(() -> null);

  private final Map<String, String> headers = new ConcurrentHashMap<>();

  private static final Pattern mediaTypePattern =
      Pattern.compile("vnd.ilandcloud.api.v([0-9]+\\.[0-9]+)\\+");

  private static final int CONNECTION_TIMEOUT_MS = 60000;

  private static final int SOCKET_TIMEOUT_MS = 60000;

  private static final String CORE_REALM = "iland-core";

  private static final String USERNAME_FIELD = "username";

  private static final String PASSWORD_FIELD = "password";

  private static final String BEARER = "Bearer ";

  private static final String AUTHORIZATION = "Authorization";

  private static final String GRANT_TYPE = "grant_type";

  private static final String REFRESH_TOKEN = "refresh_token";

  private static final String ACCESS_TOKEN = "access_token";

  private static final String EXPIRES_IN = "expires_in";

  private static final String CLIENT_ID = "client_id";

  private static final String CLIENT_SECRET = "client_secret";

  private static final int TIME_BUFFER = 10;

  private static Double API_VERSION = null;

  private static final String LOGIN_FAILURE_MSG =
      "Failed to log in to the OAuth server.";

  private volatile String username;

  private volatile String password;

  private volatile String clientName;

  private volatile String clientSecret;

  private volatile OAuthGrantApi oauthApi = null;

  private volatile ResteasyClient coreClient = null;

  private volatile ResteasyClient oauthClient = null;

  private volatile AtomicLong tokenExpirationTime = new AtomicLong();

  private volatile String coreAuthorizationHeader = null;

  private volatile String refreshToken = null;

  private volatile String accessToken = null;

  private volatile RequestConfig.Builder requestConfig;

  private volatile PoolingHttpClientConnectionManager
      poolingHttpClientConnectionManager;

  public OAuthConnection(String apiHost, final String apiPort, String ssoHost,
      final String ssoPort, final String clientName,
      final String clientSecret) {
    this.clientName = clientName;
    this.clientSecret = clientSecret;
    if (!ssoHost.startsWith("http")) {
      ssoHost = "http://" + ssoHost;
      log.warn(
          "No protocol specified for SSO host={}. Falling back on HTTP://",
          ssoHost);
    }
    if (ssoPort != null) {
      this.oauthHost = String.format("%s:%s", ssoHost, ssoPort);
    } else {
      this.oauthHost = String.format("%s", ssoHost);
    }

    if (!apiHost.startsWith("http")) {
      apiHost = "http://" + apiHost;
      log.warn(
          "No protocol specified for API host={}. Falling back on HTTP://",
          apiHost);
    }
    if (apiPort != null) {
      this.apiHost = String.format("%s:%s/v1/", apiHost, apiPort);
    } else {
      this.apiHost = String.format("%s/v1/", apiHost);
    }

    poolingHttpClientConnectionManager =
        new PoolingHttpClientConnectionManager();
    requestConfig = RequestConfig.custom();
    final HttpClient client = HttpClientBuilder.create()
        .setConnectionManager(poolingHttpClientConnectionManager)
        .setConnectionManagerShared(true)
        .setDefaultRequestConfig(requestConfig.build()).build();
    final ApacheHttpClient43Engine engine =
        new ApacheHttpClient43Engine(client);
    final ResteasyProviderFactory providerFactory =
        new LocalResteasyProviderFactory();
    providerFactory.registerProvider(
        org.jboss.resteasy.plugins.providers.ByteArrayProvider.class);
    providerFactory.registerProvider(
        org.jboss.resteasy.plugins.providers.InputStreamProvider.class);
    providerFactory.registerProvider(
        org.jboss.resteasy.plugins.providers.multipart.MultipartWriter.class);
    providerFactory.registerProvider(
        org.jboss.resteasy.plugins.providers.StringTextStar.class);
    providerFactory.registerProvider(
        org.jboss.resteasy.plugins.providers.DefaultNumberWriter.class);
    providerFactory.registerProvider(
        org.jboss.resteasy.plugins.providers.FileProvider.class);
    providerFactory.registerProvider(
        org.jboss.resteasy.plugins.providers.multipart.MultipartFormAnnotationWriter.class);
    providerFactory.registerProvider(
        org.jboss.resteasy.plugins.providers.multipart.ListMultipartReader.class);
    providerFactory.registerProvider(
        org.jboss.resteasy.plugins.providers.multipart.MultipartReader.class);
    providerFactory.registerProvider(
        org.jboss.resteasy.plugins.providers.multipart.MultipartRelatedWriter.class);
    coreClient =
        ((ResteasyClientBuilder) ClientBuilder.newBuilder()).httpEngine(engine)
            .providerFactory(providerFactory).build();
    coreClient.register(new CoreAuthHeadersRequestFilter());
    coreClient.register(new ApiClientErrorInterceptor());
    coreClient.register(SdkGsonMessageBodyHandler.class);
  }

  public ResteasyClient getCoreClient() {
    return coreClient;
  }

  public void setDefaultMaxPerRoute(final int maxPerRoute) {
    poolingHttpClientConnectionManager.setDefaultMaxPerRoute(maxPerRoute);
  }

  public void setMaxPerRoute(final HttpRoute route, final int maxPerRoute) {
    poolingHttpClientConnectionManager.setMaxPerRoute(route, maxPerRoute);
  }

  public void setMaxTotal(final int max) {
    poolingHttpClientConnectionManager.setMaxTotal(max);
  }

  public void setConnectionTimeout(final int connectionTimeout) {
    requestConfig.setConnectTimeout(connectionTimeout);
  }

  public void setSoTimeout(final int soTimeout) {
    requestConfig.setSocketTimeout(soTimeout);
  }

  public <T> T getResource(final Class<T> type) {
    return getCoreClient(type);
  }

  /**
   * Sets a header to send with each request to the iland API.
   *
   * @param name  {@link String} the header key
   * @param value {@link String} the header value
   */
  public void setHeader(final String name, final String value) {
    headers.put(name, value);
  }

  /**
   * Sets the API version used for the next request made on the same thread.
   *
   * @param version {@link Double} the version to use.
   */
  public static void setApiVersionForNextRequest(final Double version) {
    resourceVersion.set(version);
  }

  /**
   * Sets the API version to be used for all requests.
   *
   * @param version {@link Double} version to use.
   */
  public static void setApiVersion(final Double version) {
    API_VERSION = version;
  }

  /**
   * Get the authorization token.
   *
   * @return {@link String} authorization token
   */
  public Optional<String> getAuthorizationToken() {
    if (!coreClient.isClosed()) {
      return Optional.ofNullable(accessToken);
    }
    return Optional.empty();
  }

  /**
   * Get the api host.
   *
   * @return {@link String} api host
   */
  public String getApiHost() {
    return apiHost;
  }

  /**
   * Replaces the media type version with a newly specified version.
   *
   * @param mediaType  {@link String} the original media type
   * @param newVersion double new version
   * @return {@link String} new media type with updated version
   */
  @VisibleForTesting
  static String replaceMimeVersion(final String mediaType,
      final double newVersion) {
    if (!mediaType.contains("+")) {
      // if bare version (application/json), add this version
      final String[] parts = mediaType.split("/");
      final String majorType = parts[0];
      final String subType = parts[1];
      return majorType + String.format("/vnd.ilandcloud.api.v%1.1f+",
          newVersion) + subType;
    } else {
      // if it already has a version (application/vnd.ilandcloud.api.v0.4+json),
      // replace it
      final Matcher matcher = mediaTypePattern.matcher(mediaType);
      if (matcher.find()) {
        return matcher.replaceFirst(
            String.format("vnd.ilandcloud.api.v%1.1f+", newVersion));
      }
    }
    // return original if no matches
    return mediaType;
  }

  private class CoreAuthHeadersRequestFilter implements ClientRequestFilter {

    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {
      if (sessionExpired()) {
        try {
          refreshSession();
        } catch (OAuthException e) {
          throw new IllegalStateException("Failed to refresh OAuth session.");
        }
      }
      headers.forEach(
          (key, value) -> requestContext.getHeaders().add(key, value));
      requestContext.getHeaders().add(AUTHORIZATION, coreAuthorizationHeader);
      // set media version if necessary
      final Double threadApiVersion =
          resourceVersion.get() != null ? resourceVersion.get() : API_VERSION;
      if (threadApiVersion != null) {
        final List<Object> currentAcceptType =
            requestContext.getHeaders().remove(HttpHeaders.ACCEPT);
        if (currentAcceptType != null) {
          requestContext.getHeaders().add(HttpHeaders.ACCEPT,
              replaceMimeVersion((String) currentAcceptType.get(0),
                  threadApiVersion));
        }
        // reset thread local variable to clear for next invocation
        resourceVersion.set(null);
      }
    }
  }

  private synchronized <T> T getCoreClient(final Class<T> type) {
    ResteasyWebTarget target = coreClient.target(apiHost);
    return target.proxy(type);
  }

  private boolean sessionExpired() {
    return System.currentTimeMillis() > tokenExpirationTime.get();
  }

  @VisibleForTesting
  synchronized void loginSso() throws OAuthException {
    if (oauthApi == null || oauthClient == null || oauthClient.isClosed()) {
      if (oauthClient != null) {
        oauthClient.close();
      }
      final BasicHttpClientConnectionManager basicHttpClientConnectionManager =
          new BasicHttpClientConnectionManager();
      final RequestConfig.Builder config = RequestConfig.custom();
      config.setConnectTimeout(CONNECTION_TIMEOUT_MS);
      config.setSocketTimeout(SOCKET_TIMEOUT_MS);
      final HttpClient client = HttpClientBuilder.create()
          .setConnectionManager(basicHttpClientConnectionManager)
          .setDefaultRequestConfig(config.build()).build();
      final ApacheHttpClient43Engine engine =
          new ApacheHttpClient43Engine(client);
      oauthClient =
          ((ResteasyClientBuilder) ClientBuilder.newBuilder()).httpEngine(
              engine).build();
      ResteasyWebTarget target = oauthClient.target(oauthHost);
      oauthApi = target.proxy(OAuthGrantApi.class);
      // Create the OAuth server request to retrieve the user's access code.
      final MultivaluedMap<String, String> credentials =
          new MultivaluedHashMap<>();
      credentials.add(GRANT_TYPE, PASSWORD_FIELD);
      credentials.add(USERNAME_FIELD, username);
      credentials.add(PASSWORD_FIELD, password);
      credentials.add(CLIENT_ID, clientName);
      credentials.add(CLIENT_SECRET, clientSecret);
      final Response response =
          oauthApi.getAccessToken(CORE_REALM, credentials);
      final String responseStr = response.readEntity(String.class);
      response.close();
      if (Status.OK.getStatusCode() == response.getStatus()) {
        parseSessionAttributes(responseStr);
      } else {
        throw new OAuthException("Login failed.");
      }
    }
  }

  @VisibleForTesting
  synchronized void refreshSession() throws OAuthException {
    if (sessionExpired()) {
      final MultivaluedMap<String, String> credentials =
          new MultivaluedHashMap<>();
      credentials.add(GRANT_TYPE, REFRESH_TOKEN);
      credentials.add(REFRESH_TOKEN, refreshToken);
      credentials.add(CLIENT_ID, clientName);
      credentials.add(CLIENT_SECRET, clientSecret);
      final Response response =
          oauthApi.getAccessToken(CORE_REALM, credentials);
      final String responseStr = response.readEntity(String.class);
      response.close();
      if (Status.OK.getStatusCode() == response.getStatus()) {
        parseSessionAttributes(responseStr);
      } else {
        oauthApi = null;
        loginSso();
      }
    }
  }

  private void parseSessionAttributes(final String json) {
    final JsonObject obj = gson.fromJson(json, JsonObject.class);
    accessToken = obj.get(ACCESS_TOKEN).getAsString();
    coreAuthorizationHeader = BEARER + accessToken;
    refreshToken = obj.get(REFRESH_TOKEN).getAsString();
    tokenExpirationTime = new AtomicLong(
        ((obj.get(EXPIRES_IN).getAsInt() - TIME_BUFFER) * 1000)
            + System.currentTimeMillis());
  }

  public void login(final String username, final String password)
      throws OAuthException {
    try {
      this.username = username;
      this.password = password;
      loginSso();
    } catch (OAuthException e) {
      throw new OAuthException(LOGIN_FAILURE_MSG);
    }
  }

  public void logout() {
    if (coreClient != null) {
      coreClient.close();
    }
    if (oauthClient != null) {
      oauthClient.close();
    }
  }

  @Override
  protected void finalize() {
    logout();
  }

}
