/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Objects;
import java.util.Optional;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.common.enums.SnapshotTargetType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.shared.iaas.backup.ArchivalExternalTarget;
import com.iland.core.web.rest.shared.iaas.backup.ReplicationTargetSettings;

/**
 * SnapshotTargetSettings.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class SnapshotTargetSettings {

  @Expose
  @JsonOptional("Specifies settings about the archival external target.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final ArchivalExternalTarget archivalTarget;

  @Expose
  @JsonOptional("Specifies settings about the offsite backup replication target.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final ReplicationTargetSettings replicationTarget;

  @Expose
  @JsonOptional("Specifies the type of a snapshot target.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final SnapshotTargetType type;

  public SnapshotTargetSettings(final ArchivalExternalTarget archivalTarget,
      final ReplicationTargetSettings replicationTarget,
      final SnapshotTargetType type) {
    this.archivalTarget = archivalTarget;
    this.replicationTarget = replicationTarget;
    this.type = type;
  }

  /**
   * Specifies settings about the archival external target.
   */
  public Optional<ArchivalExternalTarget> getArchivalTarget() {
    return Optional.ofNullable(archivalTarget);
  }

  /**
   * Specifies settings about the offsite backup replication target.
   */
  public Optional<ReplicationTargetSettings> getReplicationTarget() {
    return Optional.ofNullable(replicationTarget);
  }

  /**
   * Specifies the type of a snapshot target.
   */
  public SnapshotTargetType getType() {
    return type;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final SnapshotTargetSettings that = (SnapshotTargetSettings) o;
    return Objects.equals(archivalTarget, that.archivalTarget) && Objects
        .equals(replicationTarget, that.replicationTarget) && type == that.type;
  }

  @Override
  public int hashCode() {
    return Objects.hash(archivalTarget, replicationTarget, type);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("archivalTarget", archivalTarget)
        .add("replicationTarget", replicationTarget).add("type", type)
        .toString();
  }
}
