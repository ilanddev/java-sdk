/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * CopyRunStats.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class CopyRunStats {

  @Expose
  @JsonOptional(
      "Specifies the time when this replication ended. If not set, then the "
          + "replication has not ended yet.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant endTime;

  @Expose
  @JsonOptional("Specifies whether this archival is incremental for archival targets.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Boolean isIncremental;

  @Expose
  @JsonRequired(
      "Specifies the number of logical bytes transferred for this replication so "
          + "far. This value can never exceed the total logical size of the replicated "
          + "view.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long logicalBytesTransferred;

  @Expose
  @JsonRequired(
      "Specifies the total amount of logical data to be transferred for this "
          + "replication.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long logicalSizeBytes;

  @Expose
  @JsonRequired(
      "Specifies average logical bytes transfer rate in bytes per second for "
          + "archival targets.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long logicalTransferRateBps;

  @Expose
  @JsonRequired(
      "Specifies the number of physical bytes sent over the wire for replication "
          + "targets.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long physicalBytesTransferred;

  @Expose
  @JsonOptional(
      "Specifies the time when this replication was started. If not set, then "
          + "replication has not been started yet.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant startTime;

  public CopyRunStats(final Instant endTime, final Boolean isIncremental,
      final long logicalBytesTransferred, final long logicalSizeBytes,
      final long logicalTransferRateBps, final long physicalBytesTransferred,
      final Instant startTime) {
    this.endTime = endTime;
    this.isIncremental = isIncremental;
    this.logicalBytesTransferred = logicalBytesTransferred;
    this.logicalSizeBytes = logicalSizeBytes;
    this.logicalTransferRateBps = logicalTransferRateBps;
    this.physicalBytesTransferred = physicalBytesTransferred;
    this.startTime = startTime;
  }

  /**
   * Specifies the time when this replication ended. If not set, then the
   * replication has not ended yet.
   */
  public Optional<Instant> getEndTime() {
    return Optional.ofNullable(endTime);
  }

  /**
   * Specifies whether this archival is incremental for archival targets.
   */
  public Optional<Boolean> getIncremental() {
    return Optional.ofNullable(isIncremental);
  }

  /**
   * Specifies the number of logical bytes transferred for this replication so
   * far. This value can never exceed the total logical size of the replicated
   * view.
   */
  public long getLogicalBytesTransferred() {
    return logicalBytesTransferred;
  }

  /**
   * Specifies the total amount of logical data to be transferred for this
   * replication.
   */
  public long getLogicalSizeBytes() {
    return logicalSizeBytes;
  }

  /**
   * Specifies average logical bytes transfer rate in bytes per second for
   * archival targets.
   */
  public long getLogicalTransferRateBps() {
    return logicalTransferRateBps;
  }

  /**
   * Specifies the number of physical bytes sent over the wire for replication
   * targets.
   */
  public long getPhysicalBytesTransferred() {
    return physicalBytesTransferred;
  }

  /**
   * Specifies the time when this replication was started. If not set, then
   * replication has not been started yet.
   */
  public Optional<Instant> getStartTime() {
    return Optional.ofNullable(startTime);
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final CopyRunStats that = (CopyRunStats) o;
    return logicalBytesTransferred == that.logicalBytesTransferred
        && logicalSizeBytes == that.logicalSizeBytes
        && logicalTransferRateBps == that.logicalTransferRateBps
        && physicalBytesTransferred == that.physicalBytesTransferred && Objects
        .equals(endTime, that.endTime) && Objects
        .equals(isIncremental, that.isIncremental) && Objects
        .equals(startTime, that.startTime);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(endTime, isIncremental, logicalBytesTransferred, logicalSizeBytes,
            logicalTransferRateBps, physicalBytesTransferred, startTime);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("endTime", endTime)
        .add("isIncremental", isIncremental)
        .add("logicalBytesTransferred", logicalBytesTransferred)
        .add("logicalSizeBytes", logicalSizeBytes)
        .add("logicalTransferRateBps", logicalTransferRateBps)
        .add("physicalBytesTransferred", physicalBytesTransferred)
        .add("startTime", startTime).toString();
  }
}
