/*
 * Copyright (c) 2013,2014 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 205 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */
package com.iland.core.web.rest.api;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.catalog.CatalogUpdateRequest;
import com.iland.core.web.rest.request.catalog.InitiateOVFUploadRequest;
import com.iland.core.web.rest.request.catalog.VappTemplateFromVappCreateRequest;
import com.iland.core.web.rest.request.common.UpdateMetadataRequest;
import com.iland.core.web.rest.response.catalog.CatalogItemDownloadListResponse;
import com.iland.core.web.rest.response.catalog.CatalogResponse;
import com.iland.core.web.rest.response.media.MediaListResponse;
import com.iland.core.web.rest.response.metadata.MetadataListResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vapptemplate.VappTemplateListResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Catalog Resource Interface v1.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Catalogs")
@Path("/catalogs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface CatalogResource {

  /**
   * Get media for a catalog.
   *
   * @param catalogUuid catalog uuid
   * @return list of medias for the organization
   */
  @GET
  @Path("/{catalogUuid}/media")
  MediaListResponse getMediaForCatalog(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_CATALOG)
      @PathParam("catalogUuid") String catalogUuid);

  /**
   * Get vApp templates for a catalog.
   *
   * @param catalogUuid catalog uuid
   * @return list of vapp templates for the organization in the specified
   * catalog
   */
  @GET
  @Path("/{catalogUuid}/vapp-templates")
  VappTemplateListResponse getVappTemplates(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_CATALOG)
      @PathParam("catalogUuid") String catalogUuid);

  /**
   * Retrieves a catalog.
   *
   * @param catalogUuid the catalog UUID
   * @return the catalog
   */
  @GET
  @Path("/{catalogUuid}")
  CatalogResponse getCatalog(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_CATALOG)
      @PathParam("catalogUuid") String catalogUuid);

  /**
   * Retrieve metadata associated with a catalog.
   *
   * @param catalogUuid catalog UUID
   * @return list of metadata for the catalog
   */
  @GET
  @Path("/{catalogUuid}/metadata")
  MetadataListResponse getMetadata(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_CATALOG)
      @PathParam("catalogUuid") String catalogUuid);

  /**
   * Add / update metadata associated with a catalog.
   *
   * @param catalogUuid catalog uuid
   * @param metadata    list of metadata
   * @return asynchronous task details
   */
  @PUT
  @Path("/{catalogUuid}/metadata")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateMetadata(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_CATALOG_CONFIGURATION)
      @PathParam("catalogUuid") String catalogUuid,
      List<UpdateMetadataRequest> metadata);

  /**
   * Delete a specific piece of metadata associated with a catalog by its key.
   *
   * @param catalogUuid catalog uuid
   * @param key         metadata key
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{catalogUuid}/metadata/{key}")
  TaskResponse deleteMetadata(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_CATALOG_CONFIGURATION)
      @PathParam("catalogUuid") String catalogUuid,
      @PathParam("key") String key);

  /**
   * Update a Catalog.
   * <p>
   * Capable of updating the catalog name and description.
   *
   * @param catalogUuid catalog uuid
   * @param catalog     catalog
   * @return updated catalog
   */
  @PUT
  @Path("/{catalogUuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  CatalogResponse updateCatalog(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_CATALOG_CONFIGURATION)
      @PathParam("catalogUuid") String catalogUuid,
      CatalogUpdateRequest catalog);

  /**
   * Add a Vapp Template to the catalog based on an existing vapp.
   *
   * @param catalogUuid catalog uuid
   * @param spec        add vapp template spec
   * @return asynchronous task details
   */
  @POST
  @Path("/{catalogUuid}/actions/add-vapp-template-from-vapp")

  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse addVappTemplateFromVapp(
      @SecureEntityRef(Permission.CREATE_ILAND_CLOUD_CATALOG_VAPP_TEMPLATES)
      @PathParam("catalogUuid") String catalogUuid,
      VappTemplateFromVappCreateRequest spec);

  /**
   * Delete a Catalog.
   * <p>
   *
   * To delete all the vApp templates and media within the catalog before
   * deleting the catalog itself set deleteTemplatesAndMedia to true.
   * <p>
   * If deleteTemplatesAndMedia is omitted or set to false then just the
   * catalog will be deleted.
   *
   * @param catalogUuid             catalog uuid
   * @param deleteTemplatesAndMedia delete the vapp templates and media
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{catalogUuid}")
  TaskResponse deleteCatalog(
      @SecureEntityRef(Permission.DELETE_ILAND_CLOUD_CATALOG)
      @PathParam("catalogUuid") String catalogUuid,
      @QueryParam("deleteTemplatesAndMedia") Boolean deleteTemplatesAndMedia);

  /**
   * Get a list of catalog item downloads for a given catalog.
   * <p>
   *
   * There are two types of catalog items that will show up: 'media' or
   * 'template'.
   * <p>
   * The item type field will report 'media' or 'vapp_template'.
   * <p>
   * If the item is a media, the 'template' field will be null and vice-versa.
   * (null 'media' field if item is a vapp_template).
   * <p>
   * Only private catalogs will have a list of catalog item downloads returned.
   *
   * @param catalogUuid catalog uuid
   * @return list of catalog item downloads
   */
  @GET
  @Path("/{catalogUuid}/item-downloads")
  CatalogItemDownloadListResponse getCatalogItemDownloads(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_CATALOG)
      @PathParam("catalogUuid") String catalogUuid);

  /**
   * Sync the catalog to the remote subscribed catalog
   *
   * @param catalogUuid uuid of catalog to sync
   * @return asynchronous task details
   */
  @POST
  @Path("/{catalogUuid}/actions/sync")
  TaskResponse syncCatalog(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_CATALOG_CONFIGURATION)
      @PathParam("catalogUuid") String catalogUuid);

  /**
   * Initiate a new OVF template upload.
   *
   * @param catalogUuid uuid of catalog that the template should be uploaded to
   * @return asynchronous task details
   */
  @POST
  @Path("/{catalogUuid}/actions/initiate-ovf-upload")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse initiateOVFUpload(
      @SecureEntityRef(Permission.CREATE_ILAND_CLOUD_CATALOG_VAPP_TEMPLATES)
      @PathParam("catalogUuid") String catalogUuid,
      InitiateOVFUploadRequest body);

}
