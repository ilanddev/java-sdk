/*
 * Copyright (c) 2022, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscanfree;

import java.util.Optional;

import net.codacloud.model.CVR;

import com.iland.coda.api.model.Scan;
import com.iland.core.web.rest.annotation.APIModel;

/**
 * {@link ScanStatus Scan Status}.
 *
 * @author <a href="mailto:tspilman@iland.com">Tag Spilman</a>
 */
@APIModel
public interface ScanStatus {

	/**
	 * Get the scan.
	 *
	 * @return the scan
	 */
	Optional<Scan> getScan();

	/**
	 * Get the report.
	 *
	 * @return the report
	 */
	Optional<CVR> getReport();

}
