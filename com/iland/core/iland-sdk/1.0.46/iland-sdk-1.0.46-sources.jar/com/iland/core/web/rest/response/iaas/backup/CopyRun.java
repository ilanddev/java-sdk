/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.backupgroups.enums.StatusCopyRun;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * CopyRun.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class CopyRun {

  @Expose
  @JsonRequired(
      "Specifies the status information of each task that copies the snapshot "
          + "taken for a backup source.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<CopySnapshotTaskStatus> copySnapshotTasks;

  @Expose
  @JsonOptional(
      "Specifies if an error occurred (if any) while running this task. This field "
          + "is populated when the status is equal to 'FAILURE'.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String error;

  @Expose
  @JsonOptional(
      "Specifies expiry time of the copies of the snapshots in this backup group "
          + "run.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant expiryTime;

  @Expose
  @JsonRequired("Specifies start time of the copy run.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant runStartTime;

  @Expose
  @JsonOptional(
      "Stats for one copy task or aggregated stats of a Copy Run in a backup group "
          + "run.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final CopyRunStats stats;

  @Expose
  @JsonOptional("Specifies the aggregated status of copy tasks.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final StatusCopyRun status;

  @Expose
  @JsonRequired(
      "Specifies settings about a target where a copied snapshot is stored. A "
          + "target can be offsite or an archival external target.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final SnapshotTargetSettings target;

  public CopyRun(final List<CopySnapshotTaskStatus> copySnapshotTasks,
      final String error, final Instant expiryTime, final Instant runStartTime,
      final CopyRunStats stats, final StatusCopyRun status,
      final SnapshotTargetSettings target) {
    this.copySnapshotTasks = copySnapshotTasks;
    this.error = error;
    this.expiryTime = expiryTime;
    this.runStartTime = runStartTime;
    this.stats = stats;
    this.status = status;
    this.target = target;
  }

  /**
   * Specifies the status information of each task that copies the snapshot
   * taken for a backup source.
   */
  public List<CopySnapshotTaskStatus> getCopySnapshotTasks() {
    return copySnapshotTasks;
  }

  /**
   * Specifies if an error occurred (if any) while running this task. This field
   * is populated when the status is equal to 'FAILURE'.
   */
  public Optional<String> getError() {
    return Optional.ofNullable(error);
  }

  /**
   * Specifies expiry time of the copies of the snapshots in this backup group
   * run.
   */
  public Optional<Instant> getExpiryTime() {
    return Optional.ofNullable(expiryTime);
  }

  /**
   * Specifies start time of the copy run.
   */
  public Instant getRunStartTime() {
    return runStartTime;
  }

  /**
   * Stats for one copy task or aggregated stats of a Copy Run in a backup group
   * run.
   */
  public Optional<CopyRunStats> getStats() {
    return Optional.ofNullable(stats);
  }

  /**
   * Specifies the aggregated status of copy tasks.
   */
  public StatusCopyRun getStatus() {
    return status;
  }

  /**
   * Specifies settings about a target where a copied snapshot is stored. A
   * target can be offsite or an archival external target.
   */
  public SnapshotTargetSettings getTarget() {
    return target;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final CopyRun copyRun = (CopyRun) o;
    return Objects.equals(copySnapshotTasks, copyRun.copySnapshotTasks)
        && Objects.equals(error, copyRun.error) && Objects
        .equals(expiryTime, copyRun.expiryTime) && Objects
        .equals(runStartTime, copyRun.runStartTime) && Objects
        .equals(stats, copyRun.stats) && status == copyRun.status && Objects
        .equals(target, copyRun.target);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(copySnapshotTasks, error, expiryTime, runStartTime, stats, status,
            target);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("copySnapshotTasks", copySnapshotTasks).add("error", error)
        .add("expiryTime", expiryTime).add("runStartTime", runStartTime)
        .add("stats", stats).add("status", status).add("target", target)
        .toString();
  }
}
