/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.user;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * User Federated Link Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIModel
public interface UserIdentityProviderLinkResponse {

  /**
   * The identity provider of the user federated link.
   *
   * @return {@link String} identity provider
   */
  String identityProvider();

  /**
   * The user id from the identity provider.
   *
   * @return {@link String} user id
   */
  String userId();

  /**
   * The username of the identity provider that is linked to this user account.
   *
   * @return {@link String} username
   */
  String username();

}
