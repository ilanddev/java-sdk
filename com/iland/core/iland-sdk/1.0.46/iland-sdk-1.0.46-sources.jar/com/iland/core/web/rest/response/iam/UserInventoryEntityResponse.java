/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.iam;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.iam.IamEntityType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * User Inventory Entity Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class UserInventoryEntityResponse implements Serializable {

  private static final long serialVersionUID = 2222216597983265960L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private IamEntityType type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String parentUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private IamEntityType parentType;

  public UserInventoryEntityResponse(final String uuid,
      final IamEntityType type, final String name, final String parentUuid,
      final IamEntityType parentType) {
    this.uuid = uuid;
    this.type = type;
    this.name = name;
    this.parentUuid = parentUuid;
    this.parentType = parentType;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets type.
   *
   * @return the type
   */
  public IamEntityType getType() {
    return type;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets parent uuid.
   *
   * @return the parent uuid
   */
  public String getParentUuid() {
    return parentUuid;
  }

  /**
   * Gets parent type.
   *
   * @return the parent type
   */
  public IamEntityType getParentType() {
    return parentType;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final UserInventoryEntityResponse that = (UserInventoryEntityResponse) o;

    if (uuid != null ? !uuid.equals(that.uuid) : that.uuid != null)
      return false;
    if (type != that.type)
      return false;
    if (name != null ? !name.equals(that.name) : that.name != null)
      return false;
    if (parentUuid != null ?
        !parentUuid.equals(that.parentUuid) :
        that.parentUuid != null)
      return false;
    return parentType == that.parentType;
  }

  @Override
  public int hashCode() {
    int result = uuid != null ? uuid.hashCode() : 0;
    result = 31 * result + (type != null ? type.hashCode() : 0);
    result = 31 * result + (name != null ? name.hashCode() : 0);
    result = 31 * result + (parentUuid != null ? parentUuid.hashCode() : 0);
    result = 31 * result + (parentType != null ? parentType.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "UserInventoryEntityResponse{" + "uuid='" + uuid + '\'' + ", type="
        + type + ", name='" + name + '\'' + ", parentUuid='" + parentUuid + '\''
        + ", parentType=" + parentType + '}';
  }

}


