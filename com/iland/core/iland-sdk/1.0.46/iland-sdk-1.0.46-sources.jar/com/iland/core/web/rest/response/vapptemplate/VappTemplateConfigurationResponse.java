/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vapptemplate;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Template Configuration Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappTemplateConfigurationResponse implements Serializable {

  private static final long serialVersionUID = -6412954179006873839L;

  private static final String UUID = "uuid";

  private static final String NAME = "name";

  private static final String DESCRIPTION = "description";

  private static final String VMS = "vms";

  private static final String NETWORKS = "networks";

  private static final String EULA_SECTIONS = "eula_sections";

  @Expose
  @SerializedName(UUID)
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @SerializedName(NAME)
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @SerializedName(DESCRIPTION)
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String description;

  @Expose
  @SerializedName(VMS)
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<VmTemplateConfigurationResponse> vms;

  @Expose
  @SerializedName(NETWORKS)
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<VappTemplateNetworkConfigurationResponse> networks;

  @Expose
  @SerializedName(EULA_SECTIONS)
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<EulaSection> eulaSections;

  /**
   * Instantiates a new Vapp template configuration.
   *
   * @param uuid         the uuid
   * @param name         the name
   * @param description  the description
   * @param vms          the vms
   * @param networks     the networks
   * @param eulaSections the eula sections
   */
  public VappTemplateConfigurationResponse(final String uuid, final String name,
      final String description, final List<VmTemplateConfigurationResponse> vms,
      final List<VappTemplateNetworkConfigurationResponse> networks,
      final List<EulaSection> eulaSections) {
    this.uuid = uuid;
    this.name = name;
    this.description = description;
    this.vms = vms;
    this.networks = networks;
    this.eulaSections = eulaSections;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets vms.
   *
   * @return the vms
   */
  public List<VmTemplateConfigurationResponse> getVms() {
    return vms;
  }

  /**
   * Gets uuid.
   *
   * @return the uuid
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets networks.
   *
   * @return the networks
   */
  public List<VappTemplateNetworkConfigurationResponse> getNetworks() {
    return networks;
  }

  /**
   * Gets the EULA sections.
   *
   * @return the list of EULA sections
   */
  public List<EulaSection> getEulaSections() {
    return eulaSections;
  }
}
