/*
 * Copyright (c) 2013 - 2017, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.network.OrgVdcNetworkUpdateRequest;
import com.iland.core.web.rest.response.org.OrgVdcNetworkResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Org vDC Network Resource.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "Org vDC Networks")
@Path("/org-vdc-networks")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface OrgVdcNetworkResource {

  /**
   * Modifies an org-vdc network.
   *
   * @param networkUuid the uuid of the org-vdc network
   * @param request     org vdc network update request
   */
  @PUT
  @Path("/{networkUuid}")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateOrgVdcNetwork(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_INTERNAL_NETWORK_CONFIGURATION)
      @PathParam("networkUuid") String networkUuid,
      OrgVdcNetworkUpdateRequest request);

  /**
   * Deletes an org-vdc network.
   *
   * @param networkUuid the uuid of the org-vdc network to delete
   * @param force       pass force = true with recursive = true to remove Org vDC
   *                    network and any object it contains, regardless of their state
   * @param recursive   pass recursive = true to remove Org vDC network and any
   *                    objects it contains that are in a state that normally
   *                    allows removal
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{networkUuid}")
  TaskResponse deleteOrgVdcNetwork(
      @SecureEntityRef(Permission.DELETE_ILAND_CLOUD_INTERNAL_NETWORK)
      @PathParam("networkUuid") String networkUuid, @QueryParam("force")  boolean force, @QueryParam("recursive") boolean recursive);

  /**
   * Get an org-vdc network.
   *
   * @param networkUuid the uuid of the org vdc network
   * @return org vdc network
   */
  @GET
  @Path("/{networkUuid}")
  OrgVdcNetworkResponse getOrgVdcNetwork(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_INTERNAL_NETWORK)
      @PathParam("networkUuid") String networkUuid);

  /**
   * Convert org vdc network to a distributed interface.
   *
   * @param networkUuid the uuid of the org vdc network
   * @return {@link TaskResponse} the task response
   */
  @POST
  @Path("/{networkUuid}/actions/convert-network-to-distributed-interface")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse convertOrgVdcNetworkToDistributedInterface(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_INTERNAL_NETWORK_CONFIGURATION)
      @PathParam("networkUuid")
          String networkUuid);

  /**
   * Convert org vdc network to a sub interface.
   *
   * @param networkUuid the uuid of the org vdc network
   * @return {@link TaskResponse} the task response
   */
  @POST
  @Path("/{networkUuid}/actions/convert-network-to-sub-interface")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse convertOrgVdcNetworkToSubInterface(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_INTERNAL_NETWORK_CONFIGURATION)
      @PathParam("networkUuid")
          String networkUuid);

  /**
   * Convert org vdc network to an internal interface.
   *
   * @param networkUuid the uuid of the org vdc network
   * @return {@link TaskResponse} the task response
   */
  @POST
  @Path("/{networkUuid}/actions/convert-network-to-internal-interface")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse convertOrgVdcNetworkToInternalInterface(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_INTERNAL_NETWORK_CONFIGURATION)
      @PathParam("networkUuid")
          String networkUuid);
}
