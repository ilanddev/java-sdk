/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.io.Serializable;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.vbo.O365JobSessionBottleneck;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Office 365 VBO Job Session Stats Response.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365JobSessionStatsResponse implements Serializable {

  private static final long serialVersionUID = 425677803988308485L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The average speed of data processing.")
  private final long processingRateBytesPS;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The average speed of data processing.")
  private final long processingRateItemsPS;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The average speed of reading data from the backup repository.")
  private final long readRateBytesPS;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The average speed of writing data to the backup repository.")
  private final long writeRateBytesPS;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The amount of data transferred from the source-side to the "
      + "target-side after applying compression and deduplication.")
  private final long transferredDataBytes;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The number of processed objects.")
  private final long processedObjects;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The bottleneck in the data transmission process.")
  private final O365JobSessionBottleneck bottleneck;

  public O365JobSessionStatsResponse(final long processingRateBytesPS,
      final long processingRateItemsPS, final long readRateBytesPS,
      final long writeRateBytesPS, final long transferredDataBytes,
      final long processedObjects, final O365JobSessionBottleneck bottleneck) {
    this.processingRateBytesPS = processingRateBytesPS;
    this.processingRateItemsPS = processingRateItemsPS;
    this.readRateBytesPS = readRateBytesPS;
    this.writeRateBytesPS = writeRateBytesPS;
    this.transferredDataBytes = transferredDataBytes;
    this.processedObjects = processedObjects;
    this.bottleneck = bottleneck;
  }

  /**
   * Return the average speed of data processing.
   *
   * <p>
   * This counter is a ratio between the amount of data that has actually been
   * read and job duration.
   * </p>
   *
   * @return the average speed of data processing given in bytes per second
   */
  public long getProcessingRateBytesPS() {
    return processingRateBytesPS;
  }

  /**
   * Returns the average speed of data processing.
   *
   * <p>
   * This counter is a ratio between the amount of data that has actually been
   * read and job duration.
   * </p>
   *
   * @return the average speed of data processing given in items per second
   */
  public long getProcessingRateItemsPS() {
    return processingRateItemsPS;
  }

  /**
   * Returns the average speed of reading data from the backup repository.
   *
   * @return the average speed of reading data from the backup repository given in bytes per second.
   */
  public long getReadRateBytesPS() {
    return readRateBytesPS;
  }

  /**
   * Returns the average speed of writing data to the backup repository.
   *
   * @return the average speed of writing data to the backup repository given in bytes per second
   */
  public long getWriteRateBytesPS() {
    return writeRateBytesPS;
  }

  /**
   * Returns the amount of data transferred from the source-side to the
   * target-side after applying compression and deduplication.
   *
   * @return The value is given in bytes per second
   */
  public long getTransferredDataBytes() {
    return transferredDataBytes;
  }

  /**
   * Returns the number of processed objects.
   *
   * @return the number of processed objects
   */
  public long getProcessedObjects() {
    return processedObjects;
  }

  /**
   * Returns the bottleneck in the data transmission process.
   *
   * @return the bottleneck in the data transmission process
   */
  public O365JobSessionBottleneck getBottleneck() {
    return bottleneck;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final O365JobSessionStatsResponse that = (O365JobSessionStatsResponse) o;
    return processingRateBytesPS == that.processingRateBytesPS
        && processingRateItemsPS == that.processingRateItemsPS
        && readRateBytesPS == that.readRateBytesPS
        && writeRateBytesPS == that.writeRateBytesPS
        && transferredDataBytes == that.transferredDataBytes
        && processedObjects == that.processedObjects && Objects
        .equals(bottleneck, that.bottleneck);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(processingRateBytesPS, processingRateItemsPS, readRateBytesPS,
            writeRateBytesPS, transferredDataBytes, processedObjects,
            bottleneck);
  }

}

