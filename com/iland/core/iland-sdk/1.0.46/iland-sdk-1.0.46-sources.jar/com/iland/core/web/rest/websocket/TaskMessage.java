/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.websocket;

import com.google.gson.annotations.Expose;

import com.iland.core.web.rest.response.task.TaskResponse;

/**
 * Task WebSocket message.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class TaskMessage extends Message {


  @Expose
  private final TaskResponse data;

  /**
   * Instantiates a new Message. *
   *
   * @param taskResponse the task response
   */
  TaskMessage(final TaskResponse taskResponse) {
    super(MessageType.TASK);
    this.data = taskResponse;
  }

  /**
   * Gets data.
   *
   * @return the data
   */
  public TaskResponse getData() {
    return data;
  }
}
