/*
 * Copyright (c) 2025, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.List;

import com.iland.core.web.rest.response.common.ListResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * A {@link ListResponse list response} composed of {@link BackupGroupSummaryInfo}.
 */
@APIDoc
public final class IaasBackupSummaryListResponse
	extends ListResponse<BackupGroupSummaryInfo> {

	public IaasBackupSummaryListResponse(
		final List<BackupGroupSummaryInfo> data) {
		super(data);
	}

}
