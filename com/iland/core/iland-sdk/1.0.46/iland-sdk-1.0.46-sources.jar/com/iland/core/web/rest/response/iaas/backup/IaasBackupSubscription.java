/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Instant;
import java.util.Optional;

import com.google.gson.annotations.SerializedName;

import com.iland.core.web.rest.annotation.APIModel;
import com.iland.core.web.rest.shared.billing.CurrencyCode;

/**
 * IaaS Backup Subscription.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface IaasBackupSubscription {

  /**
   * The ID of the company that is associated with the bill.
   */
  String companyId();

  /**
   * The ID of the location that is associated with the bill.
   */
  String locationId();

  /**
   * The UUID of the org that is associated with the bill.
   */
  String orgUuid();

  /**
   * The UUID of the vDC that is associated with the bill.
   */
  String vdcUuid();

  /**
   * The time that the subscription became active.
   */
  Instant activationTime();

  /**
   * The time that the subscription was no longer active.
   */
  Optional<Instant> deactivationTime();

  /**
   * The reserved amount in GB.
   */
  long reservedAmountGB();

  /**
   * The reserved cost.
   */
  double reservedCost();

  /**
   * The burst cost per GB-hour.
   */
  @SerializedName("burst_cost_per_gb_hour")
  double burstCostPerGBHour();

  /**
   * The currency for cost data.
   */
  CurrencyCode currencyCode();
}
