/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vac;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VAC Backup Resource Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak<</a>
 */
@APIDoc
public final class BaBackupResourceResponse implements Serializable {

  private static final long serialVersionUID = -4759933771962461892L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired("System ID assigned to a backup resource in Veeam Availability Console RESTful API.")
  private final String id;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired("Name of a cloud repository configured for a company or department.")
  private final String cloudRepositoryName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired("Amount of storage allocated to a company or department in GB.")
  private final long storageQuota;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired(
      "Number of VMs that a company or department can store on a cloud repository."
          + "If quota is unlimited, the property value is 0.")
  private final int vmsQuota;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired("Number of workstations that a company can store on a cloud repository. If quota is unlimited, the property value is 0.")
  private final int workstationsQuota;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired(
      "Amount of data that a company or department can download from the cloud"
          + "repository during a billing period in GB. If quota is unlimited, the property value is 0.")
  private final int trafficQuota;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired("Indicates whether WAN Accelerator is enabled for data transfer to a cloud repository.")
  private final boolean wanAccelerationEnabled;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired("Gets amount of allocated storage space already used by a company or department in GB.")
  private final long usedStorageQuota;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired(
      "Gets amount of data that a company or department has already downloaded"
          + "from a cloud repository during a billing period in GB. If quota is unlimited,"
          + "the property value is -1.")
  private final double usedTrafficQuota;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired("""
      Start date of data collection.
      Date and time string is formatted in accordance with ISO 8601.\
      """)
  private final Instant intervalStartTime;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired("""
      End date of data collection.
      Date and time string is formatted in accordance with ISO 8601.\
      """)
  private final Instant intervalEndTime;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired("The WAN accelerator of the backup resource.")
  private final BaWanAcceleratorResponse wanAccelerator;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired("Gets Number of servers that a company can store on a cloud repository")
  private final int serversQuota;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @JsonRequired("Indicates whether a company has unlimited quota for number of VMs, workstations and server")
  private final boolean quotasAreUnlimited;

  public BaBackupResourceResponse(final String id,
      final String cloudRepositoryName, final long storageQuota,
      final int vmsQuota, final int workstationsQuota, final int trafficQuota,
      final boolean wanAccelerationEnabled, final long usedStorageQuota,
      final double usedTrafficQuota, final Instant intervalStartTime,
      final Instant intervalEndTime,
      final BaWanAcceleratorResponse wanAccelerator, final int serversQuota,
      final boolean quotasAreUnlimited) {
    this.id = id;
    this.cloudRepositoryName = cloudRepositoryName;
    this.storageQuota = storageQuota;
    this.vmsQuota = vmsQuota;
    this.workstationsQuota = workstationsQuota;
    this.trafficQuota = trafficQuota;
    this.wanAccelerationEnabled = wanAccelerationEnabled;
    this.usedStorageQuota = usedStorageQuota;
    this.usedTrafficQuota = usedTrafficQuota;
    this.intervalStartTime = intervalStartTime;
    this.intervalEndTime = intervalEndTime;
    this.wanAccelerator = wanAccelerator;
    this.serversQuota = serversQuota;
    this.quotasAreUnlimited = quotasAreUnlimited;
  }

  /**
   * Gets System ID assigned to a backup resource in Veeam Availability Console
   * RESTful API.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Gets name of a cloud repository configured for a company or department.
   *
   * @return the cloud repsitory name
   */
  public String getCloudRepositoryName() {
    return cloudRepositoryName;
  }

  /**
   * Gets amount of storage allocated to a company or department.
   *
   * @return the storage quota
   */
  public long getStorageQuota() {
    return storageQuota;
  }

  /**
   * Gets Number of VMs that a company or department can store on a cloud repository.
   * If quota is unlimited, the property value is 0..
   *
   * @return the ms quota
   */
  public int getVmsQuota() {
    return vmsQuota;
  }

  /**
   * Gets Number of workstations that a company can store on a cloud repository. If quota is unlimited, the property value is 0.
   *
   * @return the workstations quota
   */
  public int getWorkstationsQuota() {
    return workstationsQuota;
  }

  /**
   * Gets amount of data that a company or department can download from the cloud
   * repository during a billing period. If quota is unlimited, the property value is 0.
   *
   * @return the traffic quota
   */
  public int getTrafficQuota() {
    return trafficQuota;
  }

  /**
   * Indicates whether WAN Accelerator is enabled for data transfer to a cloud repository.
   *
   * @return the boolean
   */
  public boolean isWanAccelerationEnabled() {
    return wanAccelerationEnabled;
  }

  /**
   * Gets amount of allocated storage space already used by a company or department.
   *
   * @return the used storage quota
   */
  public long getUsedStorageQuota() {
    return usedStorageQuota;
  }

  /**
   * Gets amount of data that a company or department has already downloaded
   * from a cloud repository during a billing period. If quota is unlimited,
   * the property value is -1.
   *
   * @return the used traffic quota
   */
  public double getUsedTrafficQuota() {
    return usedTrafficQuota;
  }

  /**
   * Gets start date of data collection.
   *
   * Date and time string is formatted in accordance with ISO 8601.
   *
   * @return the interval start time
   */
  public Instant getIntervalStartTime() {
    return intervalStartTime;
  }

  /**
   * Gets End date of data collection.
   *
   * Date and time string is formatted in accordance with ISO 8601.
   *
   * @return the interval end time
   */
  public Instant getIntervalEndTime() {
    return intervalEndTime;
  }

  /**
   * Get the wan accelerator.
   *
   * @return {@link BaWanAcceleratorResponse} wan accelerator
   */
  public BaWanAcceleratorResponse getWanAccelerator() {
    return wanAccelerator;
  }

  /**
   * Gets Number of servers that a company can store on a cloud repository.
   *
   * @return the servers quota
   */
  public int getServersQuota() {
    return serversQuota;
  }

  /**
   * Indicates whether a company has unlimited quota for number of VMs, workstations and server.
   *
   * @return are quotas unlimited
   */
  public boolean isQuotasAreUnlimited() {
    return quotasAreUnlimited;
  }
}


