/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * O365 Backup Repository Response
 *
 * @author <a href="mailto:smittal@iland.com">Sachin Mittal</a>
 */
@APIModel
public interface O365BackupRepositoryResponse {
  /**
   * The Veeam native id of the backup repository
   */
  String id();

  /**
   * The name of the backup repository
   */
  String name();

  /**
   * The description of the backup repository
   */
  String description();
}