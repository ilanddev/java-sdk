/*
 * Copyright (c) 2013,2014,2015 iland Internet Solutions
 *
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions 1235 North Loop West, Suite 800 Houston, TX 77008
 * USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.reporting.BillingReportRequest;
import com.iland.core.web.rest.request.reporting.ReportFormat;
import com.iland.core.web.rest.response.reporting.AntimalwareOverTimeResponse;
import com.iland.core.web.rest.response.reporting.ComplianceOverTimeResponse;
import com.iland.core.web.rest.response.reporting.EventCountResponse;
import com.iland.core.web.rest.response.reporting.FirewallOverTimeResponse;
import com.iland.core.web.rest.response.reporting.LogInspectionOverTimeResponse;
import com.iland.core.web.rest.response.reporting.ReportHeaderListResponse;
import com.iland.core.web.rest.response.reporting.VulnerabilityOverTimeResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Org Reporting Resource V1.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIProperties(name = "Org Reporting")
@Path("/orgs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface OrgReportingResource {

  /**
   * Generate the vulnerability report for the given organization.
   * <p>
   * Default format is pdf if format is unspecified
   *
   * @param orgUuid           organization uuid
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-vulnerability-report")
  TaskResponse generateVulnerabilityReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the anti-malware report for the given organization and time range.
   * <p>
   * Default format is pdf if format is unspecified
   *
   * @param orgUuid           organization uuid
   * @param start             start
   * @param end               end
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-antimalware-report")
  TaskResponse generateAntiMalwareReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the log inspection report for the given organization and time
   * range.
   * <p>
   * Default format is pdf if format is unspecified
   *
   * @param orgUuid           organization uuid
   * @param start             start
   * @param end               end
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-log-inspection-report")
  TaskResponse generateLogInspectionReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the ecs event history report for the given organization and time
   * range.
   * <p>
   * Default format is pdf if format is unspecified
   *
   * @param orgUuid           organization uuid
   * @param start             start
   * @param end               end
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-event-history-report")
  TaskResponse generateEventHistoryReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the support request history report for the given organization and
   * time range.
   * <p>
   * Default format is pdf if format is unspecified
   *
   * @param orgUuid           organization uuid
   * @param start             start
   * @param end               end
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-support-request-report")
  TaskResponse generateSupportRequestReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the login event history report for the given organization and time
   * range.
   * <p>
   * There is a limit of 1 month duration for requesting login events and if no
   * query params are provided for the time range it will fall back on the past
   * week.
   * <p>
   * Default format is pdf if format is unspecified.
   *
   * @param orgUuid           organization uuid
   * @param start             start
   * @param end               end
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-login-event-report")
  TaskResponse generateLoginEventHistoryReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the firewall event history report for the given organization and
   * time range.
   * <p>
   * Default format is pdf if format is unspecified
   *
   * @param orgUuid           organization uuid
   * @param start             start
   * @param end               end
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-firewall-event-report")
  TaskResponse generateFirewallEventHistoryReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the integrity event history report for the given organization and
   * time range.
   * <p>
   * Default format is pdf if format is unspecified
   *
   * @param orgUuid           organization uuid
   * @param start             start
   * @param end               end
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-integrity-event-report")
  TaskResponse generateIntegrityEventHistoryReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the DPI event history report for the given organization and time
   * range.
   * <p>
   * Default format is pdf if format is unspecified
   *
   * @param orgUuid           organization uuid
   * @param start             start
   * @param end               end
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-dpi-event-report")
  TaskResponse generateDPIEventHistoryReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate a continuity protection summary report for the given organization.
   *
   * @param orgUuid           organization uuid
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-continuity-protection-report")
  TaskResponse generateContinuityProtectionReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the web reputation event history report for the given organization
   * and time range.
   * <p>
   * Default format is pdf if format is unspecified
   *
   * @param orgUuid           organization uuid
   * @param start             start
   * @param end               end
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-web-reputation-event-report")
  TaskResponse generateWebReputationEventHistoryReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the VM encryption report for the given organization.
   * <p>
   * Default format is pdf if format is unspecified
   *
   * @param orgUuid           organization uuid
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-vm-encryption-report")
  TaskResponse generateVmEncryptionReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the HIPAA report for the given organization and time range.
   * <p>
   * Default format is pdf if format is unspecified
   *
   * @param orgUuid           organization uuid
   * @param start             start
   * @param end               end
   * @param reportFormat      report format ('pdf' or 'html')
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-hipaa-report")
  TaskResponse generateHIPAAReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("format") String reportFormat,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the billing report for a given organization.
   * <p>
   * Only available as report type of 'csv'.
   *
   * @param orgUuid           org uuid
   * @param billingReportSpec {@link BillingReportRequest} billing report
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation, superseded by BillingReportSpec's email property
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return {@link TaskResponse} asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-billing-report")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse generateBillingReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_BILLING)
      @PathParam("orgUuid") String orgUuid,
      BillingReportRequest billingReportSpec,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Generate the vm inventory report for a given organization.
   * <p>
   * Only available as report type of 'csv'.
   *
   * @param orgUuid           org uuid
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation, superseded by BillingReportSpec's email property
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return {@link TaskResponse} asynchronous task
   */
  @POST
  @Path("/{orgUuid}/actions/generate-vm-inventory-report")
  TaskResponse generateVmInventoryReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Get the continuity protection reports for the organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization UUID
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/continuity-protection-reports")
  ReportHeaderListResponse getContinuityProtectionReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @QueryParam("format") ReportFormat reportFormat,
      @QueryParam("latest") Boolean latest);

  /**
   * Get the billing reports for the organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization UUID
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/billing-reports")
  ReportHeaderListResponse getBillingReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_BILLING)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the VM inventory reports for the organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization UUID
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/vm-inventory-reports")
  ReportHeaderListResponse getVmInventoryReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG) @PathParam("orgUuid")
          String orgUuid, @QueryParam("format") ReportFormat reportFormat,
      @QueryParam("latest")

          Boolean latest);

  /**
   * Get the support request reports available for download for the given
   * organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/support-request-reports")
  ReportHeaderListResponse getSupportRequestReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the cloud event history reports available for download for the given
   * organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/cloud-event-reports")
  ReportHeaderListResponse getCloudEventReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the login event history reports available for download for the given
   * organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/login-event-reports")
  ReportHeaderListResponse getLoginEventReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the VM encryption reports available for download for the given
   * organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/vm-encryption-reports")
  ReportHeaderListResponse getVMEncryptionReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the HIPAA reports available for download for the given organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/hipaa-reports")
  ReportHeaderListResponse getHIPAAReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the web reputation event reports available for download for the given
   * organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/web-reputation-event-reports")
  ReportHeaderListResponse getWebReputationEventReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the DPI event reports available for download for the given
   * organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/dpi-event-reports")
  ReportHeaderListResponse getDPIEventReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the integrity event reports available for download for the given
   * organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/integrity-event-reports")
  ReportHeaderListResponse getIntegrityEventReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the firewall event reports available for download for the given
   * organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/firewall-event-reports")
  ReportHeaderListResponse getFirewallEventReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the log inspection reports available for download for the given
   * organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/log-inspection-event-reports")
  ReportHeaderListResponse getLogInspectionEventReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the anti-malware reports available for download for the given
   * organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/anti-malware-event-reports")
  ReportHeaderListResponse getAntimalwareEventReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat, @QueryParam("latest")

      Boolean latest);

  /**
   * Get the vulnerability reports available for download for the given
   * organization.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param orgUuid organization uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{orgUuid}/vulnerability-reports")
  ReportHeaderListResponse getVulnerabilityReports(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("format") ReportFormat reportFormat,
      @QueryParam("latest") Boolean latest);

  /**
   * Get the compliance over time serie for the given organization and serie
   * name.
   * <p>
   * The default timeframe is the past month if no start and end query params
   * are provided.
   *
   * @param orgUuid organization uuid
   * @param type    type of the compliance over time serie
   * @param start   start date (defaults to one month prior to end param)
   * @param end     end date (defaults to current time if not provided)
   * @param limit   limit on numer of samples to return (defaults to 60)
   * @return the compliance over time serie
   */
  @GET
  @Path("/{orgUuid}/compliance-over-time")
  ComplianceOverTimeResponse getComplianceOverTimeSerie(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("type") ComplianceOverTimeResponse.SerieType type,
      @QueryParam("start") Long start, @QueryParam("end") Long end,
      @QueryParam("limit") Integer limit);

  /**
   * Get the vulnerability over time serie for the given organization and date
   * range.
   * <p>
   * The default timeframe is the past month if no start and end query params
   * are provided.
   *
   * @param orgUuid organization uuid
   * @param start   start date (defaults to Jan 1, 1970)
   * @param end     end date (defaults to current time if not provided)
   * @param limit   limit on numer of samples to return (defaults to 730)
   * @return the vulnerability over time serie
   */
  @GET
  @Path("/{orgUuid}/vulnerability-over-time")
  VulnerabilityOverTimeResponse getVulnerabilityOverTimeSerie(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("limit") Integer limit);

  /**
   * Get the antimalware over time serie for the given organization and date
   * range.
   * <p>
   * The default timeframe is the past month if no start and end query params
   * are provided.
   *
   * @param orgUuid organization uuid
   * @param start   start date (defaults to Jan 1, 1970)
   * @param end     end date (defaults to current time if not provided)
   * @param limit   limit on numer of samples to return (defaults to 730)
   * @return the antimalware over time serie
   */
  @GET
  @Path("/{orgUuid}/anti-malware-over-time")
  AntimalwareOverTimeResponse getAntimalwareOverTimeSerie(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("limit") Integer limit);

  /**
   * Get the log inspection over time serie for the given organization and date
   * range.
   * <p>
   * The default timeframe is the past month if no start and end query params
   * are provided.
   *
   * @param orgUuid organization uuid
   * @param start   start date (defaults to Jan 1, 1970)
   * @param end     end date (defaults to current time if not provided)
   * @param limit   limit on numer of samples to return (defaults to 730)
   * @return the log inspection over time serie
   */
  @GET
  @Path("/{orgUuid}/log-inspection-over-time")
  LogInspectionOverTimeResponse getLogInspectionOverTimeSerie(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("limit") Integer limit);

  /**
   * Get the firewall over time serie for the given organization and date range.
   * <p>
   * The default timeframe is the past month if no start and end query params
   * are provided.
   *
   * @param orgUuid organization uuid
   * @param start   start date (defaults to Jan 1, 1970)
   * @param end     end date (defaults to current time if not provided)
   * @param limit   limit on numer of samples to return (defaults to 730)
   * @return the firewall over time serie
   */
  @GET
  @Path("/{orgUuid}/firewall-over-time")
  FirewallOverTimeResponse getFirewallOverTimeSerie(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid, @QueryParam("start") Long start,
      @QueryParam("end") Long end, @QueryParam("limit") Integer limit);

  /**
   * Get the number of events for the given organization, date range, and report
   * type.
   * <p>
   * Date range limited to 24 hours. If dates not specified then range is set to
   * last 24 hours.
   *
   * @param orgUuid    organization uuid
   * @param reportType type of report to filter on
   * @param start      start date (defaults to yesterday)
   * @param end        end date (defaults to today)
   */
  @GET
  @Path("/{orgUuid}/report-count")
  EventCountResponse getCount(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_ORG_SECURITY)
      @PathParam("orgUuid") String orgUuid,
      @QueryParam("reportType") String reportType,
      @QueryParam("start") Long start, @QueryParam("end") Long end);

}
