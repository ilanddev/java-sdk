/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.user;

import java.io.Serializable;
import java.time.Instant;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Account Event Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class AccountEventResponse implements Serializable {

  private static final long serialVersionUID = -7446906222319602774L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant time;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String clientName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String userId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String sessionId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String ipAddress;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String error;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Map<String, String> details;

  public AccountEventResponse(final Instant time, final String type,
      final String clientName, final String userId, final String sessionId,
      final String ipAddress, final String error,
      final Map<String, String> details) {
    this.time = time;
    this.type = type;
    this.clientName = clientName;
    this.userId = userId;
    this.sessionId = sessionId;
    this.ipAddress = ipAddress;
    this.error = error;
    this.details = details;
  }

  /**
   * Gets time.
   *
   * @return the time
   */
  public Instant getTime() {
    return time;
  }

  /**
   * Gets type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Gets client id.
   *
   * @return the client id
   */
  public String getClientName() {
    return clientName;
  }

  /**
   * Gets user id.
   *
   * @return the user id
   */
  public String getUserId() {
    return userId;
  }

  /**
   * Gets session id.
   *
   * @return the session id
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * Gets ip address.
   *
   * @return the ip address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Gets error.
   *
   * @return the error
   */
  public String getError() {
    return error;
  }

  /**
   * Gets details.
   *
   * @return the details
   */
  public Map<String, String> getDetails() {
    return details;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final AccountEventResponse that = (AccountEventResponse) o;

    if (time != null ? !time.equals(that.time) : that.time != null)
      return false;
    if (type != null ? !type.equals(that.type) : that.type != null)
      return false;
    if (clientName != null ?
        !clientName.equals(that.clientName) :
        that.clientName != null)
      return false;
    if (userId != null ? !userId.equals(that.userId) : that.userId != null)
      return false;
    if (sessionId != null ?
        !sessionId.equals(that.sessionId) :
        that.sessionId != null)
      return false;
    if (ipAddress != null ?
        !ipAddress.equals(that.ipAddress) :
        that.ipAddress != null)
      return false;
    if (error != null ? !error.equals(that.error) : that.error != null)
      return false;
    return details != null ?
        details.equals(that.details) :
        that.details == null;
  }

  @Override
  public int hashCode() {
    int result = time != null ? time.hashCode() : 0;
    result = 31 * result + (type != null ? type.hashCode() : 0);
    result = 31 * result + (clientName != null ? clientName.hashCode() : 0);
    result = 31 * result + (userId != null ? userId.hashCode() : 0);
    result = 31 * result + (sessionId != null ? sessionId.hashCode() : 0);
    result = 31 * result + (ipAddress != null ? ipAddress.hashCode() : 0);
    result = 31 * result + (error != null ? error.hashCode() : 0);
    result = 31 * result + (details != null ? details.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "AccountEventResponse{" + "time=" + time + ", type='" + type + '\''
        + ", clientName='" + clientName + '\'' + ", userId='" + userId + '\''
        + ", sessionId='" + sessionId + '\'' + ", ipAddress='" + ipAddress
        + '\'' + ", error='" + error + '\'' + ", details=" + details + '}';
  }
}
