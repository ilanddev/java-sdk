/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Objects;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VappBackupStatusDetailResponse.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public final class VappBackupStatusDetailResponse
    extends VappBackupStatusResponse {

  @Expose
  @JsonRequired("Whether the vApp has the advanced backups offering.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean hasAdvancedBackups;

  public VappBackupStatusDetailResponse(final String uuid,
      final Set<BackupGroupStatusDescriptor> backupGroups,
      final Set<VmBackupStatusResponse> childStatuses,
      final boolean hasAdvancedBackups) {
    super(uuid, backupGroups, childStatuses);
    this.hasAdvancedBackups = hasAdvancedBackups;
  }

  public VappBackupStatusDetailResponse(final VappBackupStatusResponse base,
      final boolean hasAdvancedBackups) {
    this(base.getUuid(), base.getBackupGroups(), base.getChildVmStatuses(),
        hasAdvancedBackups);
  }

  /**
   * Whether the vApp has the advanced backups offering.
   */
  public boolean getHasAdvancedBackups() {
    return hasAdvancedBackups;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    if (!super.equals(o))
      return false;
    final VappBackupStatusDetailResponse that =
        (VappBackupStatusDetailResponse) o;
    return hasAdvancedBackups == that.hasAdvancedBackups;
  }

  @Override
  public int hashCode() {
    return Objects.hash(super.hashCode(), hasAdvancedBackups);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("hasAdvancedBackups", hasAdvancedBackups).toString();
  }
}
