/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vac;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Ba Company Creation Requirements Response.
 *
 * @author <a href="mailto:nkasprza@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public final class BaCompanyCreationRequirementsResponse implements Serializable {

  private static final long serialVersionUID = 1692674650193640261L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The minimum VAC company creation size in GB.")
  private final int minimumVacCompanyCreationSizeInGb;

  public BaCompanyCreationRequirementsResponse(
      final int minimumVacCompanyCreationSizeInGb) {
    this.minimumVacCompanyCreationSizeInGb = minimumVacCompanyCreationSizeInGb;
  }

  /**
   * Get the minimum VAC company creation size in GB.
   *
   * @return minimum VAC company creation size in GB
   */
  public int getMinimumVacCompanyCreationSizeInGb() {
    return minimumVacCompanyCreationSizeInGb;
  }
}
