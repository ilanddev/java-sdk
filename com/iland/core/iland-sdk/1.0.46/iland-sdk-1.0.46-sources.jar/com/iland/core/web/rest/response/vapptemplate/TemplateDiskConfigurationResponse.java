/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vapptemplate;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Template Disk Configuration.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public class TemplateDiskConfigurationResponse implements Serializable {

  private static final long serialVersionUID = -4179913500199547113L;


  public enum DiskType {

    LSI_LOGIC,

    LSI_LOGIC_SAS,

    PARA_VIRTUAL,

    BUS_LOGIC,

    SATA,

    IDE,

  }


  @Expose
  @SerializedName("name")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String name;

  @Expose
  @SerializedName("size_in_bytes")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long sizeInBytes;

  @Expose
  @SerializedName("disk_type")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final DiskType diskType;

  /**
   * Instantiates a new Template disk configuration.
   *
   * @param name        the name
   * @param sizeInBytes the size in bytes
   * @param diskType    the disk type
   */
  public TemplateDiskConfigurationResponse(final String name,
      final long sizeInBytes, final DiskType diskType) {
    this.name = name;
    this.sizeInBytes = sizeInBytes;
    this.diskType = diskType;
  }

  /**
   * Gets serial version uid.
   *
   * @return the serial version uid
   */
  public static long getSerialVersionUID() {
    return serialVersionUID;
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets size in bytes.
   *
   * @return the size in bytes
   */
  public long getSizeInBytes() {
    return sizeInBytes;
  }

  /**
   * Gets disk type.
   *
   * @return the disk type
   */
  public DiskType getDiskType() {
    return diskType;
  }

}
