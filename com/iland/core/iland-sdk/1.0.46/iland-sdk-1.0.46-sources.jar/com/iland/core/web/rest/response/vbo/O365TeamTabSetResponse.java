/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.util.Set;

import com.iland.core.web.rest.response.common.PaginatedSetResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * O365 Team tab paginated response set.
 *
 * @author <a href="mailto:smittal@iland.com">Sachin Mittal</a>
 */
@APIDoc
public final class O365TeamTabSetResponse
    extends PaginatedSetResponse<O365TeamTabResponse> {

  public O365TeamTabSetResponse(final Set<O365TeamTabResponse> data,
      final int page, final int pageSize) {
    super(data, page, pageSize);
  }
}
