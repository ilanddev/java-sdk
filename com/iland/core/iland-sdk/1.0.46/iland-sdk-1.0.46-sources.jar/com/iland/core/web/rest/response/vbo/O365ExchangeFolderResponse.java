/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.io.Serializable;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.vbo.O365ExchangeFolderType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * O365 Exchange Folder response.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365ExchangeFolderResponse implements Serializable {

  private static final long serialVersionUID = -8312848702754405146L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired(
      "Veeam native ID of the organization's backed up mailbox folder.")
  private final String id;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Name of the organization's backed up mailbox folder.")
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The type of the organization's backed up mailbox folder.")
  private final O365ExchangeFolderType type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired(
      "The description of the organization's backed up mailbox folder.")
  private final String description;

  public O365ExchangeFolderResponse(final String id, final String name,
      final O365ExchangeFolderType type, final String description) {
    this.id = id;
    this.name = name;
    this.type = type;
    this.description = description;
  }

  /**
   * Returns the ID of the organization's backed up mailbox folder.
   *
   * @return the exchange folder Veeam native ID
   */
  public String getId() {
    return id;
  }

  /**
   * Returns the name of the organization's backed up mailbox folder.
   *
   * @return the exchange folder name
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the type of the organization's backed up mailbox folder.
   *
   * @return one of {@link O365ExchangeFolderType}
   */
  public O365ExchangeFolderType getType() {
    return type;
  }

  /**
   * Returns the description of the organization's backed up mailbox folder.
   *
   * @return the exchange folder description
   */
  public String getDescription() {
    return description;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final O365ExchangeFolderResponse that = (O365ExchangeFolderResponse) o;
    return Objects.equals(id, that.id) && Objects.equals(name, that.name)
        && Objects.equals(type, that.type) && Objects
        .equals(description, that.description);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, type, description);
  }

}
