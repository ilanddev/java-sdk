/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * O365 job selected items response for PartialOrganization type.
 *
 * @author <a href="mailto:smittal@iland.com">Sachin Mittal</a>
 */
@APIDoc
public final class O365PartialOrgJobItemsResponse {

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("the Veeam native id of the partial organization.")
  private final String id;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies if this backup job will include Mailbox processing option.")
  private final boolean mailbox;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies if this backup job will include OneDrive processing option.")
  private final boolean oneDrive;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies if this backup job will include Archive Mailbox processing option.")
  private final boolean archiveMailbox;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies if this backup job will include SharePoint sites processing option.")
  private final boolean site;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies if this backup job will include Teams processing option.")
  private final boolean teams;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies if this backup job will include Teams chat processing option.")
  private final Boolean teamsChats;
  /**
   * Creates the O365 PartialOrganization backup item type response.
   *  @param id             the Veeam native id of the partial organization.
   * @param mailbox        Specifies if this backup job will include Mailbox processing option.
   * @param oneDrive       Specifies if this backup job will include OneDrive processing option.
   * @param archiveMailbox Specifies if this backup job will include Archive Mailbox processing option.
   * @param site           Specifies if this backup job will include SharePoint sites processing option.
   * @param teams           Specifies if this backup job will include Teams processing option.
   * @param teamsChats     Specifies if this backup job will include Teams chat processing option.
   */
  public O365PartialOrgJobItemsResponse(final String id, final boolean mailbox,
      final boolean oneDrive, final boolean archiveMailbox, final boolean site,
      final boolean teams, final Boolean teamsChats) {
    this.id = id;
    this.mailbox = mailbox;
    this.oneDrive = oneDrive;
    this.archiveMailbox = archiveMailbox;
    this.site = site;
    this.teams = teams;
    this.teamsChats = teamsChats;
  }

  /**
   * Specifies if this backup job will include Mailbox processing option.
   *
   * @return the Mailbox processing option.
   */
  public boolean isMailbox() {
    return mailbox;
  }

  /**
   * Specifies if this backup job will include OneDrive processing option.
   *
   * @return the OneDrive processing option.
   */
  public boolean isOneDrive() {
    return oneDrive;
  }

  /**
   * Specifies if this backup job will include Archive Mailbox processing option.
   *
   * @return the Archive Mailbox processing option.
   */
  public boolean isArchiveMailbox() {
    return archiveMailbox;
  }

  /**
   * Specifies if this backup job will include SharePoint sites processing option.
   *
   * @return the site processing option.
   */
  public boolean isSite() {
    return site;
  }

  /**
   * Specifies if this backup job will include Teams processing option.
   *
   * @return the teams processing option.
   */
  public boolean isTeams() {
    return teams;
  }

  /**
   * Specifies if this backup job will include Teams chats processing option.
   *
   * @return the teams processing option.
   */
  public Boolean isTeamsChats() {
    return teamsChats;
  }

  /**
   * Specifies the VBO id of the selected item.
   *
   * @return the id of the item
   */
  public String getId() {
    return id;
  }

}