/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.network;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Network Perf Sample Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class NetworkPerfSampleResponse implements Serializable {

  private static final long serialVersionUID = -6538810283371755501L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant time;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Double value;

  public NetworkPerfSampleResponse(final Instant time, final Double value) {
    this.time = time;
    this.value = value;
  }

  /**
   * Returns the time at which the sample was collected.
   *
   * @return {@link Instant} instance.
   */
  public Instant getTime() {
    return time;
  }

  /**
   * Returns the actual value collected.
   *
   * @return {@link Long} instance.
   */
  public Double getValue() {
    return value;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final NetworkPerfSampleResponse that = (NetworkPerfSampleResponse) o;
    if (time != null ? !time.equals(that.time) : that.time != null)
      return false;
    return value != null ? value.equals(that.value) : that.value == null;
  }

  @Override
  public int hashCode() {
    int result = time != null ? time.hashCode() : 0;
    result = 31 * result + (value != null ? value.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "NetworkPerfSampleResponse{ timestamp=" + time + ", value=" + value
        + '}';
  }

}
