/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vpg;

import java.io.Serializable;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VpgEntitiesResonse.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VpgEntitiesResponse implements Serializable {

  private static final long serialVersionUID = -7914109583196262672L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private EnvironmentTypeResponse source;

  /**
   * The target type.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private EnvironmentTypeResponse target;

  /**
   * Instantiates a new entities.
   *
   * @param source the source type
   * @param target the target type
   */
  public VpgEntitiesResponse(final EnvironmentTypeResponse source,
      final EnvironmentTypeResponse target) {
    this.source = source;
    this.target = target;
  }

  /**
   * Gets the source type.
   *
   * @return the source type
   */
  public EnvironmentTypeResponse getSourceType() {
    return source;
  }

  /**
   * Gets the target type.
   *
   * @return the target type
   */
  public EnvironmentTypeResponse getTargetType() {
    return target;
  }

  @Override
  public String toString() {
    return String
        .format("Entities [sourceType=%s, targetType=%s]", source, target);
  }

  @Override
  public int hashCode() {
    return Objects.hash(source.ordinal(), target.ordinal());
  }

  @Override
  public boolean equals(final Object other) {
    if (other == null || !other.getClass().equals(this.getClass())) {
      return false;
    }
    final VpgEntitiesResponse otherRange = (VpgEntitiesResponse) other;
    return Objects.equals(source, otherRange.source) && Objects
        .equals(target, otherRange.target);
  }

}
