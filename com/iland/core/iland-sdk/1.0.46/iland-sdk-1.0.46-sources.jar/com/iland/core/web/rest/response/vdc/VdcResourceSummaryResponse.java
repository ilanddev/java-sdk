/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vdc;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.vapp.VappResourceSummaryResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vdc Resource Summary Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VdcResourceSummaryResponse extends VappResourceSummaryResponse {

  private static final long serialVersionUID = -7310346665234015751L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private long numberOfVapps;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private double allocationCpu;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private double allocationMemory;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private double configuredMemory;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private double configuredCpu;

  public VdcResourceSummaryResponse(final double reservedCpu,
      final double reservedMem, final double consumedCpu,
      final double consumedMem, final double consumedDisk,
      final double provisionedDisk, final long numberOfVms,
      final long numberOfVapps, final double allocationCpu,
      final double allocationMemory, final double configuredMemory,
      final double configuredDisk, final double configuredCpu) {
    super(reservedCpu, reservedMem, consumedCpu, consumedMem, consumedDisk,
        provisionedDisk, numberOfVms, configuredDisk);
    this.numberOfVapps = numberOfVapps;
    this.allocationCpu = allocationCpu;
    this.allocationMemory = allocationMemory;
    this.configuredMemory = configuredMemory;
    this.configuredCpu = configuredCpu;
  }

  /**
   * Return the number of Vapps.
   *
   * @return number of Vapps.
   */
  public long getNumberOfVapps() {
    return numberOfVapps;
  }

  /**
   * Get the vdc allocation cpu value in Ghz.
   * <p>
   * Should be 0 for Vdc types other than allocation model.
   *
   * @return double representing allocation cpu in MHZ
   */
  public double getAllocationCpu() {
    return allocationCpu;
  }

  /**
   * Get the vdc allocation memory value.
   * <p>
   * Should be 0 for Vdc types other than allocation model.
   *
   * @return double representing allocation memory
   */
  public double getAllocationMemory() {
    return allocationMemory;
  }

  /**
   * Get the configured memory for the VDC. The sum of all non-powered-off VM
   * memory allocations.
   *
   * @return double representing configured memory
   */
  public double getConfiguredMemory() {
    return configuredMemory;
  }

  /**
   * Get the configured CPU.
   *
   * @return configured cpu
   */
  public double getConfiguredCpu() {
    return configuredCpu;
  }

}
