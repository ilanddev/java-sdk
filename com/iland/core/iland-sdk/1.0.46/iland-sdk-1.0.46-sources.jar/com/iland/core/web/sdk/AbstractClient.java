/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.sdk;

import com.iland.core.web.sdk.connection.OAuthConnection;
import com.iland.core.web.sdk.connection.OAuthException;

/**
 * AbstractClient.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public abstract class AbstractClient {

  protected final OAuthConnection connection;

  private static final String API_DEFAULT_HOST = "https://api.ilandcloud.com";

  private static final String SSO_DEFAULT_HOST =
      "https://console.ilandcloud.com";

  protected AbstractClient(final String clientName, final String clientSecret) {
    connection =
        new com.iland.core.web.sdk.connection.OAuthConnection(API_DEFAULT_HOST,
            null, SSO_DEFAULT_HOST, null, clientName, clientSecret);
  }

  protected AbstractClient(final String apiHost, final String apiPort,
      final String ssoHost, final String ssoPort, final String clientName,
      final String clientSecret) {
    connection =
        new com.iland.core.web.sdk.connection.OAuthConnection(apiHost, apiPort,
            ssoHost, ssoPort, clientName, clientSecret);
  }

  public void login(final String username, final String password)
      throws OAuthException {
    connection.login(username, password);
  }

  public void logout() {
    connection.logout();
  }

  public OAuthConnection getConnection() {
    return connection;
  }

}
