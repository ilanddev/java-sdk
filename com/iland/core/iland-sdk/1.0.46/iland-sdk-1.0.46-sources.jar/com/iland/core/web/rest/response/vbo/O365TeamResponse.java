/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * O365 Team response.
 *
 * @author <a href="mailto:smittal@iland.com">Sachin Mittal</a>
 */
@APIModel
public interface O365TeamResponse {
  /**
   * Get the team description.
   */
  Optional<String> description();

  /**
   * Get the team display name.
   */
  String displayName();

  /**
   * Get the email associated with this Team.
   */
  Optional<String> mail();

  /**
   * Get the org platform uuid associated with this Team.
   */
  Optional<String> organizationUuid();

  /**
   * Whether this Team is backed up.
   */
  boolean backedUp();

  /**
   * Get the native VBO id for this Team.
   */
  String nativeId();
}
