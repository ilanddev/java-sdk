/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.recovery;

import java.time.Instant;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Disaster Recovery Runbook Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class DisasterRecoveryRunbookResponse extends EntityResponse {

  private static final long serialVersionUID = 5820151414669246910L;

  public static final String RECOVERY_GROUPS = "recovery_groups";

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String orgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant createdDate;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant lastTest;


  // list of VPG uuids for now since one recovery plan is equivalent to one VPG
  // this is an ordered list - where order denotes recovery order
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName(RECOVERY_GROUPS)
  private List<RecoveryGroupDescriptorResponse> recoveryGroupList;

  public DisasterRecoveryRunbookResponse(final String companyId,
      final String locationId, final String orgUuid, final String uuid,
      final String name, final String description,
      final List<RecoveryGroupDescriptorResponse> recoveryGroupList,
      final boolean deleted, final Instant createdDate,
      final Instant deletedDate, final Instant updatedDate,
      final Instant lastTest) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.locationId = locationId;
    this.orgUuid = orgUuid;
    this.description = description;
    this.recoveryGroupList = recoveryGroupList;
    this.createdDate = createdDate;
    this.lastTest = lastTest;
  }

  /**
   * Get the location ID.
   *
   * @return {@link String} location ID
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Get the organization uuid.
   *
   * @return {@link String} organization uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Get the runbook description.
   *
   * @return {@link String} runbook description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get the last test date.
   *
   * @return {@link Instant} last test
   */
  public Instant getLastTest() {
    return lastTest;
  }

  /**
   * Get the list of recovery plan descriptors.
   *
   * @return {@link List} of {@link RecoveryGroupDescriptorResponse} recovery plan
   * descriptors
   */
  public List<RecoveryGroupDescriptorResponse> getRecoveryGroupList() {
    return recoveryGroupList;
  }

  /**
   * Get the runbook creation date.
   *
   * @return {@link Instant} created date
   */
  public Instant getCreatedDate() {
    return createdDate;
  }

}
