/*
 * Copyright (c) 2013 - 2025, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.iam;

import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * Api key Response includes client-secret from keycloak
 *
 */
@APIModel
public interface ApiKeyResponse {

  /**
   * The crmId of the company requesting the api keys
   */
  String companyId();

  /**
   * The clientId represents the client key
   */
  String clientId();

  /**
   * The id represents client in keycloak
   */
  String id();

  /**
   * The clientSecret represents secret generated in keycloak
   */
  String clientSecret();

  /**
   * The description of the client set by the company admin
   */
  Optional<String> description();
}
