/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.backupgroups.enums.StatusCopySnapshotTaskStatus;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.shared.iaas.backup.ProtectionSource;

/**
 * CopySnapshotTaskStatus.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class CopySnapshotTaskStatus {

  @Expose
  @JsonOptional(
      "Specifies if an error occurred (if any) while running this task. This field "
          + "is populated when the status is equal to 'FAILURE'.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String error;

  @Expose
  @JsonRequired("Identifies the vCloud protection source details.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final ProtectionSource source;

  @Expose
  @JsonRequired("Stats for the copy task.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final CopyRunStats stats;

  @Expose
  @JsonRequired("Specifies the status of the source object being protected.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final StatusCopySnapshotTaskStatus status;

  @Expose
  @JsonOptional("Specifies the end time of the copy task.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant taskEndTime;

  @Expose
  @JsonRequired(
      "Specifies the start time of the copy task. Copy run task is started after "
          + "completing backup tasks. It may spawn sub-tasks to copy or replicate "
          + "individual snapshots.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant taskStartTime;

  public CopySnapshotTaskStatus(final String error,
      final ProtectionSource source, final CopyRunStats stats,
      final StatusCopySnapshotTaskStatus status, final Instant taskEndTime,
      final Instant taskStartTime) {
    this.error = error;
    this.source = source;
    this.stats = stats;
    this.status = status;
    this.taskEndTime = taskEndTime;
    this.taskStartTime = taskStartTime;
  }

  /**
   * Specifies if an error occurred (if any) while running this task. This field
   * is populated when the status is equal to 'FAILURE'.
   */
  public Optional<String> getError() {
    return Optional.ofNullable(error);
  }

  /**
   * Identifies the vCloud protection source details.
   */
  public ProtectionSource getSource() {
    return source;
  }

  /**
   * Stats for the copy task.
   */
  public CopyRunStats getStats() {
    return stats;
  }

  /**
   * Specifies the status of the source object being protected.
   */
  public StatusCopySnapshotTaskStatus getStatus() {
    return status;
  }

  /**
   * Specifies the end time of the copy task.
   */
  public Optional<Instant> getTaskEndTime() {
    return Optional.ofNullable(taskEndTime);
  }

  /**
   * Specifies the start time of the copy task. Copy run task is started after
   * completing backup tasks. It may spawn sub-tasks to copy or replicate
   * individual snapshots.
   */
  public Instant getTaskStartTime() {
    return taskStartTime;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final CopySnapshotTaskStatus that = (CopySnapshotTaskStatus) o;
    return Objects.equals(error, that.error) && Objects
        .equals(source, that.source) && Objects.equals(stats, that.stats)
        && status == that.status && Objects
        .equals(taskEndTime, that.taskEndTime) && Objects
        .equals(taskStartTime, that.taskStartTime);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(error, source, stats, status, taskEndTime, taskStartTime);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("error", error)
        .add("source", source).add("stats", stats).add("status", status)
        .add("taskEndTime", taskEndTime).add("taskStartTime", taskStartTime)
        .toString();
  }
}
