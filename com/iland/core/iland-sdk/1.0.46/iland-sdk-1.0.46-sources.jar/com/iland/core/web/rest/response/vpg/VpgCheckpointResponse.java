/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vpg;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VPG Checkpoint Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VpgCheckpointResponse implements Serializable {

  private static final long serialVersionUID = -5439395408459528362L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String checkpointIdentifier;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String tag;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final LocalDateTime timeStamp;

  /**
   * Instantiates a new vpg checkpoint.
   *
   * @param checkpointIdentifier the checkpoint identifier
   * @param tag                  the tag
   * @param timestamp            the timestamp
   */
  public VpgCheckpointResponse(final String checkpointIdentifier,
      final String tag, final LocalDateTime timestamp) {
    this.checkpointIdentifier = checkpointIdentifier;
    this.tag = tag;
    this.timeStamp = timestamp;
  }

  /**
   * Gets the checkpoint identifier.
   *
   * @return the checkpoint identifier
   */
  public String getCheckpointIdentifier() {
    return checkpointIdentifier;
  }

  /**
   * Gets the tag.
   *
   * @return the tag
   */
  public String getTag() {
    return tag;
  }

  /**
   * Gets the timestamp.
   *
   * @return the timestamp
   */
  public LocalDateTime getTimestamp() {
    return timeStamp;
  }

  @Override
  public String toString() {
    return String.format(
        "VpgCheckpointResponse [checkpointIdentifier=%s, tag=%s, timestamp=%s]",
        checkpointIdentifier, tag, timeStamp);
  }

}
