/*
 * Copyright (c) 2013 - 2024, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.iland.core.web.rest.request.feature.FeatureRequest;
import com.iland.core.web.rest.response.feature.FeatureList;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * API for interacting with front end feature state.
 */
@APIProperties(name = "Feature Toggles")
@Path("front-end-features")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface FrontEndFeatureResource {
  /**
   * Queries for the list of frontend features available to the currently authenticated user.
   *
   * @return the list of features
   */
  @GET
  @Path("session")
  FeatureList getSessionFeatures();

  /**
   * Queries for the list of all frontend features.
   *
   * @return the list of features
   */
  @GET
  FeatureList getFeatures();

  /**
   * Adds a new frontend feature. Requires system admin access.
   *
   * @param featureRequest the payload containing the feature to add
   */
  @POST
  void addFeature(FeatureRequest featureRequest);

  /**
   * Queries users for which a provided frontend feature is active. An empty list
   * means the feature is active for all users. Requires system admin access.
   *
   * @param featureUuid the UUID of the feature to get users for
   * @return the list of users or empty list for global features
   */
  @GET
  @Path("{featureUuid}/users")
  List<String> getUsersForFeature(@PathParam("featureUuid") String featureUuid);

  /**
   * Updates an existing frontend feature. Requires system admin access.
   *
   * @param featureUuid    the UUID of the feature to update
   * @param featureRequest the payload containing the feature to update
   */
  @PUT
  @Path("{featureUuid}")
  void updateFeature(@PathParam("featureUuid") String featureUuid,
      FeatureRequest featureRequest);

  /**
   * Deletes an existing frontend feature. Requires system admin access.
   *
   * @param featureUuid the UUID of the feature to delete
   */
  @DELETE
  @Path("{featureUuid}")
  void deleteFeature(@PathParam("featureUuid") String featureUuid);
}
