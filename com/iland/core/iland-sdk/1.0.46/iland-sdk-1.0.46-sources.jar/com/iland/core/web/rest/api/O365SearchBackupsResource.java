/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.vbo.O365SearchQueryRequest;
import com.iland.core.web.rest.response.vbo.O365MailItemSearchSetResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Office 365 Search Backups Resource. Continues a Search Backups session
 * that was opened via
 * {@code POST /o365-organizations/{uuid}/search-backups/{sessionType}/sessions}.
 *
 * <p>The {@code sessionId} is the restore session uuid returned by the
 * open-session call. To stop a session, use the existing
 * {@link O365RestoreSessionResource#stopRestoreSession(String)}.
 *
 */
@APIProperties(name = "Office 365 Backup")
@Path("/o365-search-backups")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface O365SearchBackupsResource {

  /**
   * Search inside an open Search Backups session with free-form text matched
   * against subject, sender and receiver. Requires
   * {@link Permission#MANAGE_ILAND_O365_RESTORE_SESSION} (same as other O365
   * search endpoints). Page with {@code offset}/{@code limit}; {@code limit}
   * must be between 1 and 100, values above 100 are rejected with 400. Stop
   * when a page returns fewer than {@code limit} hits (no total count).
   *
   * @param sessionId the restore session uuid
   * @param mailboxId the Veeam mailbox uuid, or the literal {@code all}
   *                  to search across every mailbox in the session
   * @param offset    the result offset, default 0
   * @param limit     the result limit, default 30, max 100
   * @param request   the free-form search query body; the query must be at
   *                  least 2 characters, blank or shorter queries are
   *                  rejected with 400
   * @return a {@link O365MailItemSearchSetResponse} instance
   */
  @POST
  @Path("/sessions/{sessionId}/mailboxes/{mailboxId}/search")
  @Consumes(MediaType.APPLICATION_JSON)
  O365MailItemSearchSetResponse searchSession(
      @SecureEntityRef(Permission.MANAGE_ILAND_O365_RESTORE_SESSION)
      @PathParam("sessionId") String sessionId,
      @PathParam("mailboxId") String mailboxId,
      @QueryParam("offset") Integer offset, @QueryParam("limit") Integer limit,
      O365SearchQueryRequest request);
}
