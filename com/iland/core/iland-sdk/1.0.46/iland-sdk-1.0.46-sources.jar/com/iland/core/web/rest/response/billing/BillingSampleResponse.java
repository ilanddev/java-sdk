/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;
import java.time.Instant;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Billing Sample Response object.
 *
 * @author <a href="mailto:aquinones@iland.com">Ari Quinones</a>
 */
@APIDoc
public class BillingSampleResponse implements Serializable {

  private static final long serialVersionUID = 5993896619323824426L;


  public enum BillFieldResponse {

    CPU,

    CPU_USAGE,

    CPU_BURST_USAGE,

    CPU_BURST,

    CPU_RES_USAGE,

    MEMORY,

    MEMORY_USAGE,

    MEMORY_BURST,

    MEMORY_BURST_USAGE,

    MEMORY_RES_USAGE,

    DISK,

    DISK_USAGE,

    DISK_BURST,

    DISK_BURST_USAGE,

    BANDWIDTH,

    BANDWIDTH_USAGE,

    BANDWIDTH_BURST,

    BANDWIDTH_RES_USAGE,

    BANDWIDTH_BURST_USAGE;
  }


  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Instant time;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private double value;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final Map<BillFieldResponse, Double> additionalFields;

  public BillingSampleResponse(final Instant time, final double value,
      final Map<BillFieldResponse, Double> additionalFields) {
    this.time = time;
    this.value = value;
    this.additionalFields = additionalFields;
  }

  /**
   * Get time for billing sample request
   *
   * @return {@link Instant} time
   */
  public Instant getTime() {
    return time;
  }

  /**
   * Get value of billing sample request
   *
   * @return double value
   */
  public double getValue() {
    return value;
  }

  /**
   * Get the map of additional fields of billing sample request
   *
   * @return {@link Map} of {@link BillFieldResponse} to {@link Double} additional fields
   */
  public Map<BillFieldResponse, Double> getAdditionalFields() {
    return additionalFields;
  }
}
