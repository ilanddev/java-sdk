/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.catalog;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * CatalogResponse.
 *
 * @author <a href="mailto:aquinones@iland.com">Ari Quinones</a>
 */
@APIDoc
public class CatalogResponse extends EntityResponse implements Serializable {

  private static final long serialVersionUID = -588393425983913367L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean shared;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean catalogPublic;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Long version;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String orgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String description;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vcloudHref;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant createdDate;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private boolean subscribed;

  public CatalogResponse(final String uuid, final String companyId,
      final String name, final boolean deleted, final Instant deletedDate,
      final Instant updatedDate, final String locationId, final boolean shared,
      final boolean catalogPublic, final Long version, final String orgUuid,
      final String description, final String vcloudHref,
      final Instant createdDate, final boolean subscribed) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.locationId = locationId;
    this.shared = shared;
    this.catalogPublic = catalogPublic;
    this.version = version;
    this.orgUuid = orgUuid;
    this.description = description;
    this.vcloudHref = vcloudHref;
    this.createdDate = createdDate;
    this.subscribed = subscribed;
  }

  /**
   * Get the catalog's location id
   *
   * @return {@link String} location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Get the catalog shared boolean
   *
   * @return {@link boolean} is shared
   */
  public boolean isShared() {
    return shared;
  }

  /**
   * Get the public of catalog
   *
   * @return {@link boolean} is catalog public
   */
  public boolean isCatalogPublic() {
    return catalogPublic;
  }

  /**
   * Get the catalog's version
   *
   * @return {@link Long} version
   */
  public Long getVersion() {
    return version;
  }

  /**
   * Get the catalog's org uuid
   *
   * @return {@link String} org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Get the catalog description
   *
   * @return {@link String} description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get the vcloud href of catalog
   *
   * @return {@link String} vcloud href
   */
  public String getVcloudHref() {
    return vcloudHref;
  }

  /**
   * Get the created date of catalog as in instant
   *
   * @return {@link Instant} created date
   */
  public Instant getCreatedDate() {
    return createdDate;
  }

  /**
   * Get is subscribed of catalog
   *
   * @return {@link boolean} is subscribed
   */
  public boolean isSubscribed() {
    return subscribed;
  }

  @Override
  public boolean equals(Object object) {
    if (this == object)
      return true;
    if (object == null || getClass() != object.getClass())
      return false;
    if (!super.equals(object))
      return false;
    CatalogResponse that = (CatalogResponse) object;
    if (isShared() != that.isShared())
      return false;
    if (isCatalogPublic() != that.isCatalogPublic())
      return false;
    if (isSubscribed() != that.isSubscribed())
      return false;
    if (getLocationId() != null ?
        !getLocationId().equals(that.getLocationId()) :
        that.getLocationId() != null)
      return false;
    if (getVersion() != null ?
        !getVersion().equals(that.getVersion()) :
        that.getVersion() != null)
      return false;
    if (getOrgUuid() != null ?
        !getOrgUuid().equals(that.getOrgUuid()) :
        that.getOrgUuid() != null)
      return false;
    if (getDescription() != null ?
        !getDescription().equals(that.getDescription()) :
        that.getDescription() != null)
      return false;
    if (getVcloudHref() != null ?
        !getVcloudHref().equals(that.getVcloudHref()) :
        that.getVcloudHref() != null)
      return false;
    if (getCreatedDate() != null ?
        !getCreatedDate().equals(that.getCreatedDate()) :
        that.getCreatedDate() != null)
      return false;
    return true;
  }

  @Override
  public int hashCode() {
    int result = super.hashCode();
    result = 31 * result + (getLocationId() != null ?
        getLocationId().hashCode() :
        0);
    result = 31 * result + (isShared() ? 1 : 0);
    result = 31 * result + (isCatalogPublic() ? 1 : 0);
    result = 31 * result + (getVersion() != null ? getVersion().hashCode() : 0);
    result = 31 * result + (getOrgUuid() != null ? getOrgUuid().hashCode() : 0);
    result = 31 * result + (getDescription() != null ?
        getDescription().hashCode() :
        0);
    result = 31 * result + (getVcloudHref() != null ?
        getVcloudHref().hashCode() :
        0);
    result = 31 * result + (getCreatedDate() != null ?
        getCreatedDate().hashCode() :
        0);
    result = 31 * result + (isSubscribed() ? 1 : 0);
    return result;
  }

  @Override
  public String toString() {
    return "CatalogResponse{" + "locationId='" + locationId + '\'' + ", shared="
        + shared + ", catalogPublic=" + catalogPublic + ", version=" + version
        + ", orgUuid='" + orgUuid + '\'' + ", description='" + description
        + '\'' + ", vcloudHref='" + vcloudHref + '\'' + ", createdDate="
        + createdDate + ", subscribed=" + subscribed + '}';
  }
}
