/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.List;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * VMBackupSnapshot.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface VMBackupSnapshot {

  /**
   * The ID of the associated company.
   */
  String companyId();

  /**
   * The ID of the associated location.
   */
  String locationId();

  /**
   * The UUID of the associated org.
   */
  String orgUuid();

  /**
   * The UUID of the associated vDC.
   */
  String vdcUuid();

  /**
   * The UUID of the associated vApp.
   */
  String vappUuid();

  /**
   * The UUID of the VM.
   */
  String vmUuid();

  /**
   * The name of the VM.
   */
  String vmName();

  /**
   * The UID of the associated backup group.
   */
  String backupGroupUid();

  /**
   * The name of the associated backup group.
   */
  String backupGroupName();

  /**
   * The operating system type.
   */
  String osType();

  /**
   * List of all snapshot versions that can be restored.
   */
  List<SnapshotVersion> versions();

}
