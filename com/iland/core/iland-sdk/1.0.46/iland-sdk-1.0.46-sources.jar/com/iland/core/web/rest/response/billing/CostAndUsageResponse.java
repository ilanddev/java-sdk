/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Cost And Usage Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class CostAndUsageResponse implements Serializable {

  private static final long serialVersionUID = -5394743914599956989L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double cost;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double usage;

  public CostAndUsageResponse() {
    this.cost = 0;
    this.usage = 0;
  }

  public CostAndUsageResponse(final double cost, final double usage) {
    this.cost = cost;
    this.usage = usage;
  }

  /**
   * Get the cost.
   *
   * @return cost
   */
  public double getCost() {
    return cost;
  }

  /**
   * Get the usage.
   *
   * @return usage
   */
  public double getUsage() {
    return usage;
  }

}
