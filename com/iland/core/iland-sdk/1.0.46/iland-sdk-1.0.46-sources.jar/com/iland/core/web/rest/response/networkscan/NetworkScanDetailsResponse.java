/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.networkscan;

import java.util.List;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Network Scan Details Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public final class NetworkScanDetailsResponse {

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private NetworkScanInfoResponse info;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private RemediationsResponse remediations;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private List<VulnerabilityResponse> vulnerabilities;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private List<HostResponse> hosts;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private List<HostResponse> compHosts;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private List<HistoryResponse> history;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private List<NoteResponse> notes;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private List<VulnerabilityResponse> compliance;

	@Expose
	@Since(ApiVersion.ONE_DOT_ZERO)
	private Map<Integer, List<VulnerabilityResponse>> vulnsByHost;

	public NetworkScanDetailsResponse(final NetworkScanInfoResponse info,
		final RemediationsResponse remediations,
		final List<VulnerabilityResponse> vulnerabilities,
		final List<HostResponse> hosts, final List<HostResponse> compHosts,
		final List<HistoryResponse> history, final List<NoteResponse> notes,
		final List<VulnerabilityResponse> compliance,
		final Map<Integer, List<VulnerabilityResponse>> vulnsByHost) {
		this.info = info;
		this.remediations = remediations;
		this.vulnerabilities = vulnerabilities;
		this.hosts = hosts;
		this.compHosts = compHosts;
		this.history = history;
		this.notes = notes;
		this.compliance = compliance;
		this.vulnsByHost = vulnsByHost;
	}

	/**
	 * Get the scan info.
	 *
	 * @return {@link NetworkScanInfoResponse} scan info
	 */
	public NetworkScanInfoResponse getInfo() {
		return info;
	}

	/**
	 * Get the scan remediations.
	 *
	 * @return {@link RemediationsResponse} remediations
	 */
	public RemediationsResponse getRemediations() {
		return remediations;
	}

	/**
	 * Get a list of discovered vulnerabilities.
	 *
	 * @return {@link List} of {@link VulnerabilityResponse} vulnerabilities
	 */
	public List<VulnerabilityResponse> getVulnerabilities() {
		return vulnerabilities;
	}

	/**
	 * Get a list of hosts scanned.
	 *
	 * @return {@link List} of {@link HostResponse} hosts
	 */
	public List<HostResponse> getHosts() {
		return hosts;
	}

	/**
	 * Get a list of compromised hosts.
	 *
	 * @return {@link List} of {@link HostResponse} compromised hosts
	 */
	public List<HostResponse> getCompHosts() {
		return compHosts;
	}

	/**
	 * Get the history of scan.
	 *
	 * @return of instances
	 */
	public List<HistoryResponse> getHistory() {
		return history;
	}

	/**
	 * Get the notes attached to a scan.
	 *
	 * @return {@link List} of {@link NoteResponse} notes
	 */
	public List<NoteResponse> getNotes() {
		return notes;
	}

	/**
	 * Get the compliance section.
	 *
	 * @return {@link List} of {@link VulnerabilityResponse} vulnerabilities
	 */
	public List<VulnerabilityResponse> getCompliance() {
		return compliance;
	}

	/**
	 * Get the map of vulnerabilities by host.
	 *
	 * @return map of vulnerabilites by host
	 */
	public Map<Integer, List<VulnerabilityResponse>> getVulnsByHost() {
		return vulnsByHost;
	}

}
