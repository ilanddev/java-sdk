/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vappnetwork;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Network Firewall Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappNetworkFirewallResponse implements Serializable {

  private static final long serialVersionUID = 417740632982765773L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vappUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String networkName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean loggingEnabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean enabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String defaultAction;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<VappNetworkFirewallRuleResponse> rules;

  public VappNetworkFirewallResponse(final String vappUuid,
      final String networkName, final boolean loggingEnabled,
      final boolean enabled, final String defaultAction,
      final List<VappNetworkFirewallRuleResponse> rules) {
    this.vappUuid = vappUuid;
    this.networkName = networkName;
    this.loggingEnabled = loggingEnabled;
    this.enabled = enabled;
    this.defaultAction = defaultAction;
    this.rules = rules;
  }

  /**
   * Get the entity uuid.
   *
   * @return {@link String}
   */
  public String getEntityUuid() {
    return vappUuid;
  }

  /**
   * Get whether logging is enabled.
   *
   * @return logging enabled
   */
  public boolean isLoggingEnabled() {
    return loggingEnabled;
  }

  /**
   * Get whether the firewall is enabled.
   *
   * @return is enabled
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Get the default action.
   *
   * @return {@link String} default action
   */
  public String getDefaultAction() {
    return defaultAction;
  }

  /**
   * Get the list of firewall rules associated with this firewall.
   *
   * @return {@link List} of {@link VappNetworkFirewallRuleResponse}
   */
  public List<VappNetworkFirewallRuleResponse> getRules() {
    return rules;
  }

  /**
   * Get the network name associated with this firewall.
   *
   * @return {@link String} network name
   */
  public String getNetworkName() {
    return networkName;
  }

}
