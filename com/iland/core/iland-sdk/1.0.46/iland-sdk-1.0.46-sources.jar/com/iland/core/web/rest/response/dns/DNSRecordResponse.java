/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.dns;

import java.io.Serializable;
import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * DNS Record Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class DNSRecordResponse implements Serializable {

  private static final long serialVersionUID = 5195967821958526372L;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int id;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private int zoneId;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String zoneName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String host;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String description;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Integer ttl;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String ordering;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String ip;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Instant lastModified;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String value;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private DNSRecordTypeResponse type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Integer priority;

  public DNSRecordResponse(final int id, final int zoneId,
      final String zoneName, final String host, final String description,
      final Integer ttl, final String ordering, final String ip,
      final Instant lastModified, final String value,
      final DNSRecordTypeResponse type, final Integer priority) {
    this.id = id;
    this.zoneId = zoneId;
    this.zoneName = zoneName;
    this.host = host;
    this.description = description;
    this.ttl = ttl;
    this.ordering = ordering;
    this.ip = ip;
    this.lastModified = lastModified;
    this.value = value;
    this.type = type;
    this.priority = priority;
  }

  /**
   * Get the DNSRecord last modified date.
   *
   * @return last modified date
   */
  public Instant getLastModified() {
    return lastModified;
  }

  /**
   * Get the DNSRecord value.
   *
   * @return value
   */
  public String getValue() {
    return value;
  }

  /**
   * Get DNSRecord ID.
   *
   * @return id
   */
  public int getId() {
    return id;
  }

  /**
   * Get DNSRecord zone id.
   *
   * @return zone id
   */
  public int getZoneId() {
    return zoneId;
  }

  /**
   * Get the DNSRecord zone name.
   *
   * @return zone name
   */
  public String getZoneName() {
    return zoneName;
  }

  /**
   * Get the DNSRecord ip.
   *
   * @return ip address
   */
  public String getIp() {
    return ip;
  }

  /**
   * Get the DNSRecord host.
   *
   * @return host
   */
  public String getHost() {
    return host;
  }

  /**
   * Get the DNSRecord description.
   *
   * @return description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Get the DNSRecord TTL.
   *
   * @return TTL
   */
  public Integer getTTL() {
    return ttl;
  }

  /**
   * Get the DNSRecord ordering.
   *
   * @return ordering
   */
  public String getOrdering() {
    return ordering;
  }

  /**
   * Get the record type.
   *
   * @return record type
   */
  public DNSRecordTypeResponse getType() {
    return type;
  }

  /**
   * Get the priority.
   *
   * @return priority
   */
  public Integer getPriority() {
    return priority;
  }

}
