/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.event;

import javax.ws.rs.QueryParam;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityTypeResponse;
import com.iland.core.web.rest.response.common.PagingOrder;
import com.iland.core.web.rest.response.common.PagingParams;
import com.iland.core.web.rest.serialization.ApiVersion;

/**
 * Event filter params.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public class EventFilterParams extends PagingParams {

  private static final long serialVersionUID = -5254562800591358476L;

  /**
   * The UUID of the entity that events should be retrieved for. This parameter
   * is required.
   */
  @QueryParam("entityUuid")
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String entityUuid;

  /**
   * The type of entity that events should be retrieved for. This parameter is
   * required.
   */
  @QueryParam("entityType")
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private EntityTypeResponse entityType;

  /**
   * Whether to include events for descendant entities vs. just events
   * that are associated with the entity itself. This option is only valid when
   * an entityType of COMPANY or USER is specified.
   */
  @QueryParam("includeDescendantEvents")
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Boolean includeDescendantEvents;

  /**
   * The type of events to be returned.
   */
  @QueryParam("type")
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private EventTypeResponse type;

  /**
   * The UUID of the task that events are associated with.
   */
  @QueryParam("taskUuid")
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String taskUuid;

  /**
   * The username of the user who invoked the operation that caused the event.
   */
  @QueryParam("initiatedBy")
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String initiatedBy;

  /**
   * Timestamp specified as epoch milliseconds. If specified, only events that
   * occurred after the timestamp will be returned.
   */
  @QueryParam("timestampAfter")
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Long timestampAfter;

  /**
   * Timestamp specified as epoch milliseconds. If specified, only events that
   * occurred before the timestamp will be returned.
   */
  @QueryParam("timestampBefore")
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Long timestampBefore;

  /**
   * A special parameter that enables stable pagination over a result set. When
   * a page is retrieved, the response will include a query_timestamp field
   * which can be specified in subsequent queries for other pages. If not
   * specified, there is no guarantee that new events will not alter the offsets
   * of events during paging.
   */
  @QueryParam("queryTimestamp")
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Long queryTimestamp;

  /**
   * Instantiates a new Event filter params.
   */
  public EventFilterParams() {
  }

  /**
   * Instantiates a new Event filter params.
   *
   * @param entityType the entity type
   * @param entityUuid the entity uuid
   */
  public EventFilterParams(final EntityTypeResponse entityType,
      final String entityUuid) {
    super();
    this.entityType = entityType;
    this.entityUuid = entityUuid;
  }

  /**
   * Instantiates a new Event filter params.
   *
   * @param entityType   the entity type
   * @param entityUuid   the entity uuid
   * @param pagingParams the paging params
   */
  public EventFilterParams(final EntityTypeResponse entityType, final String entityUuid,
      final PagingParams pagingParams) {
    super(pagingParams.getOffset(), pagingParams.getLimit(),
        pagingParams.getOrder());
    this.entityType = entityType;
    this.entityUuid = entityUuid;
  }

  /**
   * Instantiates a new Event filter params.
   *
   * @param offset                  the offset
   * @param limit                   the limit
   * @param order                   the order
   * @param entityUuid              the entity uuid
   * @param entityType              the entity type
   * @param type                    the type
   * @param taskUuid                the task uuid
   * @param initiatedBy             the initiated by
   * @param timestampAfter          the timestamp after
   * @param timestampBefore         the timestamp before
   * @param queryTimestamp          the query timestamp
   * @param includeDescendantEvents the include descendant events
   */
  public EventFilterParams(final Long offset, final Long limit,
      final PagingOrder order, final String entityUuid,
      final EntityTypeResponse entityType, final EventTypeResponse type, final String taskUuid,
      final String initiatedBy, final Long timestampAfter,
      final Long timestampBefore, final Long queryTimestamp,
      final Boolean includeDescendantEvents) {
    super(offset, limit, order);
    this.entityUuid = entityUuid;
    this.entityType = entityType;
    this.type = type;
    this.taskUuid = taskUuid;
    this.initiatedBy = initiatedBy;
    this.timestampAfter = timestampAfter;
    this.timestampBefore = timestampBefore;
    this.queryTimestamp = queryTimestamp;
    this.includeDescendantEvents = includeDescendantEvents;
  }

  /**
   * Sets entity uuid.
   *
   * @param entityUuid the entity uuid
   * @return the entity uuid
   */
  public EventFilterParams setEntityUuid(final String entityUuid) {
    this.entityUuid = entityUuid;
    return this;
  }

  /**
   * Gets entity uuid.
   *
   * @return the entity uuid
   */
  public String getEntityUuid() {
    return entityUuid;
  }

  /**
   * Gets entity type.
   *
   * @return the entity type
   */
  public EntityTypeResponse getEntityType() {
    return entityType;
  }

  /**
   * Gets type.
   *
   * @return the type
   */
  public EventTypeResponse getType() {
    return type;
  }

  /**
   * Gets task uuid.
   *
   * @return the task uuid
   */
  public String getTaskUuid() {
    return taskUuid;
  }

  /**
   * Gets initiated by.
   *
   * @return the initiated by
   */
  public String getInitiatedBy() {
    return initiatedBy;
  }

  /**
   * Gets timestamp after.
   *
   * @return the timestamp after
   */
  public Long getTimestampAfter() {
    return timestampAfter;
  }

  /**
   * Gets timestamp before.
   *
   * @return the timestamp before
   */
  public Long getTimestampBefore() {
    return timestampBefore;
  }

  /**
   * Sets entity type.
   *
   * @param entityType the entity type
   * @return the entity type
   */
  public EventFilterParams setEntityType(final EntityTypeResponse entityType) {
    this.entityType = entityType;
    return this;
  }

  /**
   * Sets type.
   *
   * @param type the type
   * @return the type
   */
  public EventFilterParams setType(final EventTypeResponse type) {
    this.type = type;
    return this;
  }

  /**
   * Sets task uuid.
   *
   * @param taskUuid the task uuid
   * @return the task uuid
   */
  public EventFilterParams setTaskUuid(final String taskUuid) {
    this.taskUuid = taskUuid;
    return this;
  }

  /**
   * Sets initiated by.
   *
   * @param initiatedBy the initiated by
   * @return the initiated by
   */
  public EventFilterParams setInitiatedBy(final String initiatedBy) {
    this.initiatedBy = initiatedBy;
    return this;
  }

  /**
   * Sets timestamp after.
   *
   * @param timestampAfter the timestamp after
   * @return the timestamp after
   */
  public EventFilterParams setTimestampAfter(final Long timestampAfter) {
    this.timestampAfter = timestampAfter;
    return this;
  }

  /**
   * Sets timestamp before.
   *
   * @param timestampBefore the timestamp before
   * @return the timestamp before
   */
  public EventFilterParams setTimestampBefore(final Long timestampBefore) {
    this.timestampBefore = timestampBefore;
    return this;
  }

  /**
   * Gets query timestamp.
   *
   * @return the query timestamp
   */
  public Long getQueryTimestamp() {
    return queryTimestamp;
  }

  /**
   * Sets query timestamp.
   *
   * @param queryTimestamp the query timestamp
   * @return the query timestamp
   */
  public EventFilterParams setQueryTimestamp(final Long queryTimestamp) {
    this.queryTimestamp = queryTimestamp;
    return this;
  }

  /**
   * Gets include descendant events.
   *
   * @return the include descendant events
   */
  public boolean getIncludeDescendantEvents() {
    return includeDescendantEvents == null ? false : includeDescendantEvents;
  }

  /**
   * Sets include descendant events.
   *
   * @param includeDescendantEvents the include descendant events
   * @return the include descendant events
   */
  public EventFilterParams setIncludeDescendantEvents(
      final Boolean includeDescendantEvents) {
    this.includeDescendantEvents = includeDescendantEvents;
    return this;
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder("EventFilterParams{");
    sb.append(", entityUuid='").append(entityUuid).append('\'');
    sb.append(", entityType=").append(entityType);
    sb.append(", type=").append(type);
    sb.append(", taskUuid='").append(taskUuid).append('\'');
    sb.append(", initiatedBy='").append(initiatedBy).append('\'');
    sb.append(", timestampAfter=").append(timestampAfter);
    sb.append(", timestampBefore=").append(timestampBefore);
    sb.append(", includeDescendantEvents=").append(includeDescendantEvents);
    sb.append(", offset=").append(offset);
    sb.append(", limit=").append(limit);
    sb.append(", order=").append(order);
    sb.append('}');
    return sb.toString();
  }

}
