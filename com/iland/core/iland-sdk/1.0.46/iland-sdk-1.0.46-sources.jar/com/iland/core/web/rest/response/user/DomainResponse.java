/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.user;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Domain Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class DomainResponse implements Serializable {

  private static final long serialVersionUID = 4996114489835364270L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String domain;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String domainName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private DomainTypeResponse domainType;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String domainId;

  public DomainResponse(final String domain, final String domainName,
      final DomainTypeResponse domainType, final String domainId) {
    this.domain = domain;
    this.domainName = domainName;
    this.domainType = domainType;
    this.domainId = domainId;
  }

  /**
   * Gets the name of the user domain.
   *
   * @return {@link String} user domain name
   */
  public String getDomainName() {
    return this.domainName;
  }

  /**
   * Gets the type of user domain.
   *
   * @return {@link DomainTypeResponse}
   */
  public DomainTypeResponse getDomainType() {
    return this.domainType;
  }

  /**
   * Gets the ID of the user domain.
   *
   * @return {@link String} domain ID
   */
  public String getDomainId() {
    return this.domainId;
  }

  /**
   * Get the full domain string.
   *
   * @return {@link String} domain string
   */
  public String getDomainString() {
    return this.domain;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final DomainResponse that = (DomainResponse) o;

    if (domain != null ? !domain.equals(that.domain) : that.domain != null)
      return false;
    if (domainName != null ?
        !domainName.equals(that.domainName) :
        that.domainName != null)
      return false;
    if (domainType != that.domainType)
      return false;
    return domainId != null ?
        domainId.equals(that.domainId) :
        that.domainId == null;
  }

  @Override
  public int hashCode() {
    int result = domain != null ? domain.hashCode() : 0;
    result = 31 * result + (domainName != null ? domainName.hashCode() : 0);
    result = 31 * result + (domainType != null ? domainType.hashCode() : 0);
    result = 31 * result + (domainId != null ? domainId.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "DomainResponse{" + "domain='" + domain + '\'' + ", domainName='"
        + domainName + '\'' + ", domainType=" + domainType + ", domainId='"
        + domainId + '\'' + '}';
  }

}
