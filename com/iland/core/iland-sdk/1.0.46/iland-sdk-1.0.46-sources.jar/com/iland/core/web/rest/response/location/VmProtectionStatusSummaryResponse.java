/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.location;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * VM Protection Status Summary Response.
 *
 */
@APIModel
public interface VmProtectionStatusSummaryResponse {

  /**
   * Get the number of protected VMs for a user's company inventory.
   */
  int vmsProtected();

  /**
   * Get the number of unprotected VMs for a user's company inventory.
   */
  int vmsUnProtected();

  /**
   * Get the total number of VMs for a user's company inventory.
   */
  int totalVms();
}
