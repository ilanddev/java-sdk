/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.intbackup;

import java.util.Set;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * VappIntBackupStatusResponse.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface VappIntegratedBackupStatusResponse {

  /**
   * The UUID of the vApp.
   */
  String vappUuid();

  /**
   * The vApp's backup configuration status.
   */
  IntegratedBackupStatus status();

  /**
   * The statuses of child VMs.
   */
  Set<VmIntegratedBackupStatusResponse> vmStatuses();

}
