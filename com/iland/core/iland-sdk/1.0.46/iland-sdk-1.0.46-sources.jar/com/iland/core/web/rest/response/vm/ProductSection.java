/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * The ProductSection specifies product-information for an appliance, such as product name,
 * version, and vendor.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface ProductSection {

  /**
   * Describes product information for the service.
   */
  String info();

  /**
   * Specifies the name of the product.
   */
  Optional<String> product();

  /**
   * Specifies the name of the product vendor.
   */
  Optional<String> vendor();

  /**
   * Specifies the product version in short form.
   */
  Optional<String> version();

  /**
   * Describes the product version in long form.
   */
  Optional<String> fullVersion();

  /**
   * Specifies a URL which shall resolve to a human readable description of the product.
   */
  Optional<String> productUrl();

  /**
   * Specifies a URL which shall resolve to a human readable
   * description of the vendor.
   */
  Optional<String> vendorUrl();

  /**
   * Uniquely identifies the software product (typically using reverse domain name convention).
   */
  Optional<String> productClass();

  /**
   * If multiple instances of the same product are installed, this is used to identify the different instances.
   */
  Optional<String> productInstance();

  /**
   * Properties specify application-level customization parameters and are particularly relevant to
   * appliances that need to be customized during deployment with specific settings such as network identity,
   * the IP addresses of DNS servers, gateways, and others. The keys in this map represent
   * property category labels. Properties that do not explicitly belong
   * to a category are associated with a "DEFAULT" key.
   */
  Map<String, List<ProductSectionProperty>> properties();

}
