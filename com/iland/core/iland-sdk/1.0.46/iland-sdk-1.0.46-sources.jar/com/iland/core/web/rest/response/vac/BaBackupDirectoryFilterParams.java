/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vac;

import com.iland.core.web.rest.response.common.PagingOrder;
import com.iland.core.web.rest.response.common.PagingParams;

/**
 * Backup Directory Filter Params.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 *
 */
public class BaBackupDirectoryFilterParams extends PagingParams {

  private static final long serialVersionUID = 1992777412236980561L;

  public BaBackupDirectoryFilterParams() {
  }

  public BaBackupDirectoryFilterParams(final Long offset, final Long limit,
      final PagingOrder order) {
    super(offset, limit, order);
  }
}
