/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.recovery;

import java.io.Serializable;
import java.time.Instant;
import java.util.Arrays;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vm Bootup Log Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class VmBootupLogResponse implements Serializable {

  private static final long serialVersionUID = 3924804302225925820L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vmUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String vmName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private byte[] screenshot;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Instant timestamp;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String ipAddress;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String errorLog;

  public VmBootupLogResponse(final String vmUuid, final String vmName,
      final byte[] screenshot, final Instant timestamp, final String ipAddress,
      final String errorLog) {
    this.vmUuid = vmUuid;
    this.vmName = vmName;
    this.screenshot = screenshot;
    this.timestamp = timestamp;
    this.ipAddress = ipAddress;
    this.errorLog = errorLog;
  }

  /**
   * Get the VM UUID.
   *
   * @return {@link String} VM UUID
   */
  public String getVmUuid() {
    return vmUuid;
  }

  /**
   * Get the VM name.
   *
   * @return {@link String} VM name
   */
  public String getVmName() {
    return vmName;
  }

  /**
   * Get the VM console screenshot.
   *
   * @return screenshot of VM console
   */
  public byte[] getScreenshot() {
    return screenshot;
  }

  /**
   * Get the timestamp the log was created.
   *
   * @return {@link Instant} log timestamp
   */
  public Instant getTimestamp() {
    return timestamp;
  }

  /**
   * Get the VM IP address.
   *
   * @return {@link String} IP address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Get the VM error log.
   *
   * @return {@link String} error log
   */
  public String getErrorLog() {
    return errorLog;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final VmBootupLogResponse that = (VmBootupLogResponse) o;

    if (vmUuid != null ? !vmUuid.equals(that.vmUuid) : that.vmUuid != null)
      return false;
    if (vmName != null ? !vmName.equals(that.vmName) : that.vmName != null)
      return false;
    if (!Arrays.equals(screenshot, that.screenshot))
      return false;
    if (timestamp != null ?
        !timestamp.equals(that.timestamp) :
        that.timestamp != null)
      return false;
    if (ipAddress != null ?
        !ipAddress.equals(that.ipAddress) :
        that.ipAddress != null)
      return false;
    return errorLog != null ?
        errorLog.equals(that.errorLog) :
        that.errorLog == null;
  }

  @Override
  public int hashCode() {
    int result = vmUuid != null ? vmUuid.hashCode() : 0;
    result = 31 * result + (vmName != null ? vmName.hashCode() : 0);
    result = 31 * result + Arrays.hashCode(screenshot);
    result = 31 * result + (timestamp != null ? timestamp.hashCode() : 0);
    result = 31 * result + (ipAddress != null ? ipAddress.hashCode() : 0);
    result = 31 * result + (errorLog != null ? errorLog.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "VmBootupLogResponse{" + "vmUuid='" + vmUuid + '\'' + ", vmName='"
        + vmName + '\'' + ", screenshot=" + Arrays.toString(screenshot)
        + ", timestamp=" + timestamp + ", ipAddress='" + ipAddress + '\''
        + ", errorLog='" + errorLog + '\'' + '}';
  }

}
