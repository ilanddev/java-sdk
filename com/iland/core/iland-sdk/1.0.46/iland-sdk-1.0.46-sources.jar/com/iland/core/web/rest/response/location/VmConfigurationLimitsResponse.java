/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.location;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vm Configuration Limits Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class VmConfigurationLimitsResponse implements Serializable {

  private static final long serialVersionUID = 1063487020083669675L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long maxMemoryMebibytes;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long minMemoryMebibytes;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long maxCpuCoreCount;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long maxDiskSizeMebibytes;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private long minDiskSizeMebibytes;

  public VmConfigurationLimitsResponse(final long maxMemoryMebibytes,
      final long minMemoryMebibytes, final long maxCpuCoreCount,
      final long maxDiskSizeMebibytes, final long minDiskSizeMebibytes) {
    this.maxMemoryMebibytes = maxMemoryMebibytes;
    this.minMemoryMebibytes = minMemoryMebibytes;
    this.maxCpuCoreCount = maxCpuCoreCount;
    this.maxDiskSizeMebibytes = maxDiskSizeMebibytes;
    this.minDiskSizeMebibytes = minDiskSizeMebibytes;
  }

  /**
   * Get the RAM max limit.
   *
   * @return ram max limit
   */
  public long getMaxMemoryMebibytes() {
    return maxMemoryMebibytes;
  }

  /**
   * Get the RAM min limit.
   *
   * @return ram min limit
   */
  public long getMinMemoryMebibytes() {
    return minMemoryMebibytes;
  }

  /**
   * Get the CPU max limit.
   *
   * @return cpu max limit
   */
  public long getMaxCpuCoreCount() {
    return maxCpuCoreCount;
  }

  /**
   * Get the disk max limit.
   *
   * @return disk max limit
   */
  public long getMaxDiskSizeMebibytes() {
    return maxDiskSizeMebibytes;
  }

  /**
   * Get the disk min limit.
   *
   * @return disk min limit
   */
  public long getMinDiskSizeMebibytes() {
    return minDiskSizeMebibytes;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final VmConfigurationLimitsResponse that =
        (VmConfigurationLimitsResponse) o;

    if (maxMemoryMebibytes != that.maxMemoryMebibytes)
      return false;
    if (minMemoryMebibytes != that.minMemoryMebibytes)
      return false;
    if (maxCpuCoreCount != that.maxCpuCoreCount)
      return false;
    if (maxDiskSizeMebibytes != that.maxDiskSizeMebibytes)
      return false;
    return minDiskSizeMebibytes == that.minDiskSizeMebibytes;
  }

  @Override
  public int hashCode() {
    int result = (int) (maxMemoryMebibytes ^ (maxMemoryMebibytes >>> 32));
    result =
        31 * result + (int) (minMemoryMebibytes ^ (minMemoryMebibytes >>> 32));
    result = 31 * result + (int) (maxCpuCoreCount ^ (maxCpuCoreCount >>> 32));
    result = 31 * result + (int) (maxDiskSizeMebibytes ^ (maxDiskSizeMebibytes
        >>> 32));
    result = 31 * result + (int) (minDiskSizeMebibytes ^ (minDiskSizeMebibytes
        >>> 32));
    return result;
  }

  @Override
  public String toString() {
    return "VmConfigurationLimitsResponse{" + "maxMemoryMebibytes="
        + maxMemoryMebibytes + ", minMemoryMebibytes=" + minMemoryMebibytes
        + ", maxCpuCoreCount=" + maxCpuCoreCount + ", maxDiskSizeMebibytes="
        + maxDiskSizeMebibytes + ", minDiskSizeMebibytes="
        + minDiskSizeMebibytes + '}';
  }

}
