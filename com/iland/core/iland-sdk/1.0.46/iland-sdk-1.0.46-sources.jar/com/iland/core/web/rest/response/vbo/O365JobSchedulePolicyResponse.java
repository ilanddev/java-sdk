/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.api.vbo.O365JobSchedulePolicyDailyType;
import com.iland.core.api.vbo.O365JobSchedulePolicyPeriodicallyEvery;
import com.iland.core.api.vbo.O365JobSchedulePolicyType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Office 365 VBO Job Schedule Policy Response.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365JobSchedulePolicyResponse implements Serializable {

  private static final long serialVersionUID = 958284556330211598L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The job schedule type.")
  private final O365JobSchedulePolicyType type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The days when the backup job will run.")
  private final O365JobSchedulePolicyDailyType dailyType;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The time when the job will start.")
  private final String dailyTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The time interval between the job runs.")
  private final O365JobSchedulePolicyPeriodicallyEvery periodicallyEvery;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Indicates that a backup window feature is enabled for this job.")
  private final boolean backupWindowEnabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The job's backup window settings.")
  private final List<Boolean> backupWindow;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The job's backup window offset.")
  private final int backupWindowMinuteOffset;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("If set to True, indicates that Veeam Backup for Microsoft Office 365 will attempt to restart a backup job if it fails for some reason.")
  private final boolean retryEnabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the number of attempts to run the backup job.")
  private final int retryNumber;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the time intervals between the job retry attempts (minutes).")
  private final int retryWaitInterval;

  public O365JobSchedulePolicyResponse(final O365JobSchedulePolicyType type,
      final O365JobSchedulePolicyDailyType dailyType, final String dailyTime,
      final O365JobSchedulePolicyPeriodicallyEvery periodicallyEvery,
      final boolean backupWindowEnabled, final List<Boolean> backupWindow,
      final int backupWindowMinuteOffset, final boolean retryEnabled,
      final int retryNumber, final int retryWaitInterval) {
    this.type = type;
    this.dailyType = dailyType;
    this.dailyTime = dailyTime;
    this.periodicallyEvery = periodicallyEvery;
    this.backupWindowEnabled = backupWindowEnabled;
    this.backupWindow = backupWindow;
    this.backupWindowMinuteOffset = backupWindowMinuteOffset;
    this.retryEnabled = retryEnabled;
    this.retryNumber = retryNumber;
    this.retryWaitInterval = retryWaitInterval;
  }

  /**
   * Returns the job schedule type.
   *
   * @return one of {@link O365JobSchedulePolicyType}
   */
  public O365JobSchedulePolicyType getType() {
    return type;
  }

  /**
   * Returns the days when the backup job will run.
   *
   * @return one of {@link O365JobSchedulePolicyDailyType}
   */
  public O365JobSchedulePolicyDailyType getDailyType() {
    return dailyType;
  }

  /**
   * Returns the time when the job will start.
   *
   * @return String w/ format such as "19:00:00"
   */
  public String getDailyTime() {
    return dailyTime;
  }

  /**
   * Returns the time interval between the job runs.
   *
   * @return one of {@link O365JobSchedulePolicyPeriodicallyEvery}
   */
  public O365JobSchedulePolicyPeriodicallyEvery getPeriodicallyEvery() {
    return periodicallyEvery;
  }

  public boolean isBackupWindowEnabled() {
    return backupWindowEnabled;
  }

  public List<Boolean> getBackupWindow() {
    return backupWindow;
  }

  public int getBackupWindowMinuteOffset() {
    return backupWindowMinuteOffset;
  }

  /**
   * Returns whether retry is enabled.
   *
   * @return whether retry is enabled.
   */
  public boolean isRetryEnabled() {
    return retryEnabled;
  }

  /**
   * Returns the time intervals between the job retry attempts (minutes).
   *
   * @return the retry wait time interval
   */
  public int getRetryWaitInterval() {
    return retryWaitInterval;
  }

  /**
   * Returns the number of attempts to run the backup job.
   *
   * @return the retry number
   */
  public int getRetryNumber() {
    return retryNumber;
  }

}
