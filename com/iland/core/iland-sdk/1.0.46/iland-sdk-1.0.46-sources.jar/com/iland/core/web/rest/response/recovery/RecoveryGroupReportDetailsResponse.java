/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.recovery;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.vpg.FailoverReportDetailsResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Recovery Group Report Details Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class RecoveryGroupReportDetailsResponse implements Serializable {

  private static final long serialVersionUID = -334950110555359943L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String recoveryGroupUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String failoverStatus;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private FailoverReportDetailsResponse details;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private List<VmBootupLogResponse> bootupLogs;

  public RecoveryGroupReportDetailsResponse(final String recoveryGroupUuid,
      final String failoverStatus, final FailoverReportDetailsResponse details,
      final List<VmBootupLogResponse> bootupLogs) {
    this.recoveryGroupUuid = recoveryGroupUuid;
    this.failoverStatus = failoverStatus;
    this.details = details;
    this.bootupLogs = bootupLogs;
  }

  /**
   * Get the recovery group failover status.
   *
   * @return {@link String} failover status
   */
  public String getRecoveryGroupFailoverStatus() {
    return failoverStatus;
  }

  /**
   * Get the recovery group UUID.
   *
   * @return {@link String} recovery group UUID
   */
  public String getRecoveryGroupUuid() {
    return recoveryGroupUuid;
  }

  /**
   * Get the failover report details.
   *
   * @return {@link FailoverReportDetailsResponse} failover report details
   */
  public FailoverReportDetailsResponse getDetails() {
    return details;
  }

  /**
   * Get the VM bootup logs.
   *
   * @return {@link List} of {@link VmBootupLogResponse} VM bootup logs
   */
  public List<VmBootupLogResponse> getBootupLogs() {
    return bootupLogs;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final RecoveryGroupReportDetailsResponse that =
        (RecoveryGroupReportDetailsResponse) o;

    if (recoveryGroupUuid != null ?
        !recoveryGroupUuid.equals(that.recoveryGroupUuid) :
        that.recoveryGroupUuid != null)
      return false;
    if (failoverStatus != null ?
        !failoverStatus.equals(that.failoverStatus) :
        that.failoverStatus != null)
      return false;
    if (details != null ? !details.equals(that.details) : that.details != null)
      return false;
    return bootupLogs != null ?
        bootupLogs.equals(that.bootupLogs) :
        that.bootupLogs == null;
  }

  @Override
  public int hashCode() {
    int result = recoveryGroupUuid != null ? recoveryGroupUuid.hashCode() : 0;
    result =
        31 * result + (failoverStatus != null ? failoverStatus.hashCode() : 0);
    result = 31 * result + (details != null ? details.hashCode() : 0);
    result = 31 * result + (bootupLogs != null ? bootupLogs.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "RecoveryGroupReportDetailsResponse{" + "recoveryGroupUuid='"
        + recoveryGroupUuid + '\'' + ", failoverStatus='" + failoverStatus
        + '\'' + ", details=" + details + ", bootupLogs=" + bootupLogs + '}';
  }

}
