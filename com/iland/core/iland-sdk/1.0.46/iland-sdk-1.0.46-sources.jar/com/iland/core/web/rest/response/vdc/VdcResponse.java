/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vdc;

import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Virtual Data Center Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VdcResponse extends EntityResponse {

  public static final String VCENTER_MOREF = "vcenter_moref";

  public static final String VCENTER_NAME = "vcenter_name";

  public static final String ALLOC_CPU = "alloc_cpu";

  public static final String ALLOC_MEM = "alloc_mem";

  public static final String VCLOUD_HREF = "vcloud_href";

  public static final String VCENTER_INSTANCE_UUID = "vcenter_instance_uuid";

  public static final String VCENTER_HREF = "vcenter_href";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean enabled;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCENTER_MOREF)
  private String vCenterMoRef;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCENTER_NAME)
  private String vCenterName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String description;

  /**
   * The V cloud href.
   */
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCLOUD_HREF)
  protected String vCloudHref;

  /**
   * Reference vCenter UUID
   */
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCENTER_INSTANCE_UUID)
  private String vCenterInstanceUUID;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCENTER_HREF)
  private String vCenterHref;

  /**
   * Allocation Model
   */
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String allocationModel;

  /**
   * Reserved CPU
   */
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Long reservedCpu;

  /**
   * Reserved MEM
   */
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Long reservedMem;

  /**
   * Disk Limit
   */
  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Long diskLimit;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private long contractedAdvancedDiskLimit;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private long contractedSsdDiskLimit;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private long contractedArchiveDiskLimit;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(ALLOC_CPU)
  private Long allocationCpu;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(ALLOC_MEM)
  private Long allocationMemory;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String maxHardwareVersion;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Integer networkQuota;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Integer usedNetworkCount;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String locationId;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final String orgUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final boolean hasIaasBackups;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final boolean hasAdvancedBackups;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final boolean hasIntegratedBackups;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName("has_cohesity_offsite_replication")
  private boolean hasOffsiteReplication;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private final boolean nsxTBacked;

  public VdcResponse(final String uuid, final String companyId,
      final String name, final boolean deleted, final Instant deletedDate,
      final Instant updatedDate, final boolean enabled,
      final String vCenterMoRef, final String vCenterName,
      final String description, final String vCloudHref,
      final String vCenterInstanceUUID, final String vCenterHref,
      final String allocationModel, final Long reservedCpu,
      final Long reservedMem, final Long diskLimit,
      final long contractedAdvancedDiskLimit, final long contractedSsdDiskLimit,
      final long contractedArchiveDiskLimit, final Long allocationCpu,
      final Long allocationMemory, final String maxHardwareVersion,
      final Integer networkQuota, final Integer usedNetworkCount,
      final String locationId, final String orgUuid,
      final boolean hasAdvancedBackups, final boolean hasIntegratedBackups,
      final boolean hasOffsiteReplication, final boolean nsxTBacked) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.enabled = enabled;
    this.vCenterMoRef = vCenterMoRef;
    this.vCenterName = vCenterName;
    this.description = description;
    this.vCloudHref = vCloudHref;
    this.vCenterInstanceUUID = vCenterInstanceUUID;
    this.vCenterHref = vCenterHref;
    this.allocationModel = allocationModel;
    this.reservedCpu = reservedCpu;
    this.reservedMem = reservedMem;
    this.diskLimit = diskLimit;
    this.contractedAdvancedDiskLimit = contractedAdvancedDiskLimit;
    this.contractedSsdDiskLimit = contractedSsdDiskLimit;
    this.contractedArchiveDiskLimit = contractedArchiveDiskLimit;
    this.allocationCpu = allocationCpu;
    this.allocationMemory = allocationMemory;
    this.maxHardwareVersion = maxHardwareVersion;
    this.networkQuota = networkQuota;
    this.usedNetworkCount = usedNetworkCount;
    this.locationId = locationId;
    this.orgUuid = orgUuid;
    this.hasOffsiteReplication = hasOffsiteReplication;
    this.nsxTBacked = nsxTBacked;
    this.hasIaasBackups = hasAdvancedBackups || hasIntegratedBackups;
    this.hasAdvancedBackups = hasAdvancedBackups;
    this.hasIntegratedBackups = hasIntegratedBackups;
  }

  /**
   * Is enabled boolean.
   *
   * @return the boolean
   */
  public boolean isEnabled() {
    return enabled;
  }

  /**
   * Gets vcenter href.
   *
   * @return the vcenter href
   */
  public String getVcenterHref() {
    return vCenterHref;
  }

  /**
   * Gets vcenter instance uuid.
   *
   * @return the vcenter instance uuid
   */
  public String getVcenterInstanceUuid() {
    return vCenterInstanceUUID;
  }

  /**
   * Gets allocation model.
   *
   * @return the allocation model
   */
  public String getAllocationModel() {
    return allocationModel;
  }

  /**
   * Return the reserved cpu quanity in MHZ.
   *
   * @return {@link Long} reserved cpu
   */
  public Long getReservedCpu() {
    return reservedCpu;
  }

  /**
   * Gets reserved memory.
   *
   * @return the reserved memory
   */
  public Long getReservedMemory() {
    return reservedMem;
  }

  /**
   * Gets disk limit.
   *
   * @return the disk limit
   */
  public Long getDiskLimit() {
    return diskLimit;
  }

  /**
   * Get the allocation quantity for cpu in MHZ.
   * <p>
   * Should be null for Vdc types other than Allocation Model.
   *
   * @return {@link Long} allocation cpu
   */
  public Long getAllocationCpu() {
    return allocationCpu;
  }

  /**
   * Get the allocation quantity for memory.
   * <p>
   * Should be null for Vdc types other than Allocation Model.
   *
   * @return {@link Long} allocation memory
   */
  public Long getAllocationMemory() {
    return allocationMemory;
  }

  /**
   * Get the highest supported virtual hardware version for this vdc.
   *
   * @return {@link String} highest supported virtual hardware version
   */
  public String getMaxHardwareVersion() {
    return maxHardwareVersion;
  }

  /**
   * Gets the network quota for the vDC.
   *
   * @return integer network quota
   */
  public Integer getNetworkQuota() {
    return networkQuota;
  }

  /**
   * Gets the used network count for the vDC.
   *
   * @return integer used network count
   */
  public Integer getUsedNetworkCount() {
    return usedNetworkCount;
  }

  /**
   * Gets location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Gets org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets reserved mem.
   *
   * @return the reserved mem
   */
  public Long getReservedMem() {
    return reservedMem;
  }

  /**
   * Gets center href.
   *
   * @return the center href
   */
  public String getvCenterHref() {
    return vCenterHref;
  }

  /**
   * Gets center instance uuid.
   *
   * @return the center instance uuid
   */
  public String getvCenterInstanceUUID() {
    return vCenterInstanceUUID;
  }

  /**
   * Gets center mo ref.
   *
   * @return the center mo ref
   */
  public String getvCenterMoRef() {
    return vCenterMoRef;
  }

  /**
   * Gets center name.
   *
   * @return the center name
   */
  public String getvCenterName() {
    return vCenterName;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets cloud href.
   *
   * @return the cloud href
   */
  public String getvCloudHref() {
    return vCloudHref;
  }

  /**
   * Get the contracted disk limit for advanced storage in MB.
   *
   * @return contracted disk limit in MB
   */
  public long getContractedAdvancedDiskLimit() {
    return contractedAdvancedDiskLimit;
  }

  /**
   * Get the contracted disk limit for SSD storage in MB.
   *
   * @return contracted disk limit in MB
   */
  public long getContractedSsdDiskLimit() {
    return contractedSsdDiskLimit;
  }

  /**
   * Get the contracted disk limit for archive storage in MB.
   *
   * @return contracted disk limit in MB
   */
  public long getContractedArchiveDiskLimit() {
    return contractedArchiveDiskLimit;
  }

  /**
   * Indicates whether the vDC has IaaS backups (either integrated or advanced).
   *
   * @return boolean value
   */
  public boolean isHasIaasBackups() {
    return hasIaasBackups;
  }

  /**
   * Whether the vDC has the advanced backups offering.
   *
   * @return boolean value.
   */
  public boolean isHasAdvancedBackups() {
    return hasAdvancedBackups;
  }

  /**
   * Whether the vDC has the integrated backups offering.
   *
   * @return boolean value.
   */
  public boolean isHasIntegratedBackups() {
    return hasIntegratedBackups;
  }

  /**
   * Whether the vDC has the offsite replication offering.
   *
   * @return boolean value.
   */
  public boolean isHasOffsiteReplication() {
    return hasOffsiteReplication;
  }

  /**
   * Whether the vDC is backed by NSX-T networking infrastructure.
   *
   * @return boolean value
   */
  public boolean isNsxTBacked() {
    return nsxTBacked;
  }
}
