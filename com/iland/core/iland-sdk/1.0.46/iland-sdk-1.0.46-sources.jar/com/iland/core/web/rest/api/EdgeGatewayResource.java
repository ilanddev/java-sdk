/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.api;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.request.nsx.CRLCreateRequest;
import com.iland.core.web.rest.request.nsx.CSRCreateRequest;
import com.iland.core.web.rest.request.nsx.CertificateCreateRequest;
import com.iland.core.web.rest.request.nsx.CertificateImportRequest;
import com.iland.core.web.rest.request.nsx.EdgeGatewayDhcpUpdateRequest;
import com.iland.core.web.rest.request.nsx.EdgeGatewayFirewallUpdateRequest;
import com.iland.core.web.rest.request.nsx.EdgeGatewayIPsecUpdateRequest;
import com.iland.core.web.rest.request.nsx.EdgeGatewayL2VPNUpdateRequest;
import com.iland.core.web.rest.request.nsx.EdgeGatewayLoadBalancerUpdateRequest;
import com.iland.core.web.rest.request.nsx.EdgeGatewayNATUpdateRequest;
import com.iland.core.web.rest.request.nsx.EdgeGatewayRoutingUpdateRequest;
import com.iland.core.web.rest.request.nsx.EdgeGatewaySSHSettingsUpdateRequest;
import com.iland.core.web.rest.request.nsx.EdgeGatewaySSLVPNUpdateRequest;
import com.iland.core.web.rest.request.nsx.EdgeGatewaySyslogUpdateRequest;
import com.iland.core.web.rest.request.nsx.FirewallRestorePointCreateRequest;
import com.iland.core.web.rest.request.nsx.NATRestorePointCreateRequest;
import com.iland.core.web.rest.request.nsx.RestoreFirewallRequest;
import com.iland.core.web.rest.request.nsx.RestoreNatRequest;
import com.iland.core.web.rest.request.nsx.RoutingBGPConfigUpdateRequest;
import com.iland.core.web.rest.request.nsx.RoutingGlobalConfigUpdateRequest;
import com.iland.core.web.rest.request.nsx.RoutingOSPFConfigUpdateRequest;
import com.iland.core.web.rest.request.nsx.RoutingStaticConfigUpdateRequest;
import com.iland.core.web.rest.request.nsx.SelfSignCertificateRequest;
import com.iland.core.web.rest.response.common.ObjectPagingParams;
import com.iland.core.web.rest.response.nsx.CRLResponse;
import com.iland.core.web.rest.response.nsx.CRLsResponse;
import com.iland.core.web.rest.response.nsx.CSRResponse;
import com.iland.core.web.rest.response.nsx.CSRsResponse;
import com.iland.core.web.rest.response.nsx.CertificateResponse;
import com.iland.core.web.rest.response.nsx.CertificatesResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewayDhcpResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewayDistributedRoutingResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewayFirewallResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewayIPsecResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewayL2VPNResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewayLoadBalancerResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewayNATResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewayRoutingResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewaySSHSettingsResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewaySSLVPNResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewaySyslogResponse;
import com.iland.core.web.rest.response.nsx.EdgeGatewayVNICsResponse;
import com.iland.core.web.rest.response.nsx.FirewallDestinationObjectListResponse;
import com.iland.core.web.rest.response.nsx.FirewallDestinationTypeListResponse;
import com.iland.core.web.rest.response.nsx.FirewallRestorePointDetailsResponse;
import com.iland.core.web.rest.response.nsx.FirewallRestorePointListResponse;
import com.iland.core.web.rest.response.nsx.FirewallRulesInformationResponse;
import com.iland.core.web.rest.response.nsx.FirewallSourceObjectListResponse;
import com.iland.core.web.rest.response.nsx.FirewallSourceTypeListResponse;
import com.iland.core.web.rest.response.nsx.IPsecStatisticsResponse;
import com.iland.core.web.rest.response.nsx.L2VPNStatisticsResponse;
import com.iland.core.web.rest.response.nsx.NATRestorePointDetailsResponse;
import com.iland.core.web.rest.response.nsx.NATRestorePointListResponse;
import com.iland.core.web.rest.response.nsx.RelayTypeListResponse;
import com.iland.core.web.rest.response.nsx.RelayTypeOptionListResponse;
import com.iland.core.web.rest.response.nsx.RoutingBGPConfigResponse;
import com.iland.core.web.rest.response.nsx.RoutingGlobalConfigResponse;
import com.iland.core.web.rest.response.nsx.RoutingOSPFConfigResponse;
import com.iland.core.web.rest.response.nsx.RoutingStaticConfigResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;
import com.iland.vcloud.common.edge.FirewallQueryApi;
import com.iland.vcloud.common.edge.FirewallRestorePointApi;
import com.iland.vcloud.common.edge.NatQueryApi;
import com.iland.vcloud.common.edge.NatRestorePointApi;
import com.iland.vcloud.nsx.common.model.EdgeUuid;

/**
 * Edge Gateway REST resource V1.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIProperties(name = "Edge Gateways")
@Path("/edge-gateways")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
public interface EdgeGatewayResource extends NatQueryApi, NatRestorePointApi,
    FirewallQueryApi, FirewallRestorePointApi {

  /**
   * Get the VNICs configuration for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return edge gateway VNICs
   */
  @GET
  @Path("/{edgeUuid}/vnics")
  EdgeGatewayVNICsResponse getEdgeGatewayVnics(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Get the firewall configuration for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return edge gateway firewall
   */
  @GET
  @Path("/{edgeUuid}/firewall")
  EdgeGatewayFirewallResponse getEdgeGatewayFirewall(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid);

  /**
   * Get the list of firewall source types.
   *
   * @param edgeUuid edge uuid
   * @return the list of firewall source types
   */
  @GET
  @Path("/{edgeUuid}/firewall/sources")
  FirewallSourceTypeListResponse getFirewallSourceTypes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid);

  /**
   * Get the list of firewall source objects.
   *
   * @param edgeUuid edge uuid
   * @param type     firewall source object type
   * @param filters  firewall object paging params
   * @return the list of firewall source objects
   */
  @GET
  @Path("/{edgeUuid}/firewall/sources/{type}")
  FirewallSourceObjectListResponse getFirewallSourceObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid, @PathParam("type") String type,
      @BeanParam ObjectPagingParams filters);

  /**
   * Get the list of firewall source objects.
   *
   * @param edgeUuid edge uuid
   * @param type     firewall source object type
   * @param page  firewall object paging params
   * @param pageSize  firewall object paging params
   * @return the list of firewall source objects
   */
  @GET
  @Path("/{edgeUuid}/firewall/sources/nsxt/{type}")
  FirewallSourceObjectListResponse getFirewallSourceObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid, @PathParam("type") String type,
      @QueryParam("page") Long page, @QueryParam("pageSize") Long pageSize);

  /**
   * Get the list of firewall destination types.
   *
   * @param edgeUuid edge uuid
   * @return the list of firewall destination types
   */
  @GET
  @Path("/{edgeUuid}/firewall/destinations")
  FirewallDestinationTypeListResponse getFirewallDestinationTypes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid);

  /**
   * Get the list of firewall destination objects.
   *
   * @param edgeUuid edge uuid
   * @param type     firewall destination object type
   * @param filters  firewall object paging params
   * @return the list of firewall destination objects
   */
  @GET
  @Path("/{edgeUuid}/firewall/destinations/{type}")
  FirewallDestinationObjectListResponse getFirewallDestinationObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid, @PathParam("type") String type,
      @BeanParam ObjectPagingParams filters);

  /**
   * Retrieves name/ID mappings for all source and destination objects that are assigned to current firewall rules.
   *
   * @param edgeUuid edge uuid
   */
  @GET
  @Path("/{edgeUuid}/firewall/rule-info")
  FirewallRulesInformationResponse getFirewallRulesInformation(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Update the firewall configuration for an edge gateway.
   *
   * @param edgeUuid              edge uuid
   * @param firewallUpdateRequest firewall update request
   * @return updated edge gateway firewall
   */
  @PUT
  @Path("/{edgeUuid}/firewall")
  EdgeGatewayFirewallResponse updateEdgeGatewayFirewall(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_FIREWALL_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      EdgeGatewayFirewallUpdateRequest firewallUpdateRequest);

  /**
   * Update the nat configuration for an edge gateway.
   *
   * @param edgeUuid         edge uuid
   * @param natUpdateRequest nat update request
   * @return updated edge gateway nat
   */
  @PUT
  @Path("/{edgeUuid}/nat")
  EdgeGatewayNATResponse updateEdgeGatewayNAT(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_NAT_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      EdgeGatewayNATUpdateRequest natUpdateRequest);

  /**
   * Get the NAT for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return edge gateway nat
   */
  @GET
  @Path("/{edgeUuid}/nat")
  EdgeGatewayNATResponse getEdgeGatewayNat(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid);

  /**
   * Get the DHCP configuration for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return edge gateway dhcp
   */
  @GET
  @Path("/{edgeUuid}/dhcp")
  EdgeGatewayDhcpResponse getEdgeGatewayDhcp(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Update the DHCP configuration for an edge gateway.
   *
   * @param edgeUuid                     edge uuid
   * @param edgeGatewayDhcpUpdateRequest dhcp update request
   * @return updated edge gateway dhcp
   */
  @PUT
  @Path("/{edgeUuid}/dhcp")
  EdgeGatewayDhcpResponse updateEdgeGatewayDhcp(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_DHCP_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      EdgeGatewayDhcpUpdateRequest edgeGatewayDhcpUpdateRequest);

  /**
   * Create a firewall restore point for an edge gateway's firewall.
   *
   * @param edgeUuid                          edge uuid
   * @param firewallRestorePointCreateRequest firewall restore point create request
   * @return firewall restore point
   */
  @POST
  @Path("/{edgeUuid}/firewall/restore-points")
  FirewallRestorePointDetailsResponse createFirewallRestorePoint(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_FIREWALL_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      FirewallRestorePointCreateRequest firewallRestorePointCreateRequest);

  /**
   * Get the firewall restore points for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return firewall restore points
   */
  @GET
  @Path("/{edgeUuid}/firewall/restore-points")
  FirewallRestorePointListResponse getFirewallRestorePoints(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid);

  /**
   * Get a firewall restore point for a specific edge at a given time.
   * <p>
   * Restore point time is epoch time in milliseconds.
   *
   * @param edgeUuid         edge uuid
   * @param restorePointTime restore point time
   * @return firewall restore point
   */
  @GET
  @Path("/{edgeUuid}/firewall/restore-points/{restorePointTime}")
  FirewallRestorePointDetailsResponse getFirewallRestorePoint(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid,
      @PathParam("restorePointTime") long restorePointTime);

  /**
   * Get the latest Firewall restore point for a specific edge.
   *
   * @param edgeUuid         edge uuid
   * @return firewall restore point
   */
  @GET
  @Path("/{edgeUuid}/firewall/restore-points/latest")
  FirewallRestorePointDetailsResponse getFirewallLatestRestorePoint(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid);

  /**
   * Delete a firewall restore point.
   * <p>
   * Restore point time is epoch time in milliseconds.
   *
   * @param edgeUuid         edge uuid
   * @param restorePointTime restore point time
   */
  @DELETE
  @Path("/{edgeUuid}/firewall/restore-points/{restorePointTime}")
  void deleteFirewallRestorePoint(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_FIREWALL_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      @PathParam("restorePointTime") long restorePointTime);

  /**
   * Restore an edge gateway's firewall configuration to a specified restore point.
   *
   * @param edgeUuid               edge uuid
   * @param restoreFirewallRequest the request body, which specifies the restore point time
   * @return firewall
   */
  @POST
  @Path("/{edgeUuid}/firewall/actions/restore")
  EdgeGatewayFirewallResponse restoreFirewall(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_FIREWALL_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      RestoreFirewallRequest restoreFirewallRequest);

  /**
   * Get the DHCP relay types for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return dhcp relay types
   */
  @GET
  @Path("/{edgeUuid}/dhcp/relays")
  RelayTypeListResponse getEdgeGatewayRelayTypes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Get the DHCP relay type options for a edge gateway's relay type.
   *
   * @param edgeUuid     edge uuid
   * @param relayType    the type of dhcp relay
   * @param pagingParams filters
   * @return dhcp relay type options
   */
  @GET
  @Path("/{edgeUuid}/dhcp/relays/{relayType}")
  RelayTypeOptionListResponse getEdgeGatewayRelayOptions(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid, @PathParam("relayType") String relayType,
      @BeanParam ObjectPagingParams pagingParams);

  /**
   * Create a NAT restore point for an edge gateway's NAT.
   *
   * @param edgeUuid                     edge uuid
   * @param natRestorePointCreateRequest nat restore point create request
   * @return NAT restore point
   */
  @POST
  @Path("/{edgeUuid}/nat/restore-points")
  @Consumes(MediaType.APPLICATION_JSON)
  NATRestorePointDetailsResponse createNATRestorePoint(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_NAT_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      NATRestorePointCreateRequest natRestorePointCreateRequest);

  /**
   * Get the NAT restore points for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return nat restore points
   */
  @GET
  @Path("/{edgeUuid}/nat/restore-points")
  NATRestorePointListResponse getNATRestorePoints(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
      EdgeUuid edgeUuid);

  /**
   * Get a NAT restore point for a specific edge at a given time.
   * <p>
   * Restore point time is epoch time in milliseconds.
   *
   * @param edgeUuid         edge uuid
   * @param restorePointTime restore point time
   * @return NAT restore point
   */
  @GET
  @Path("/{edgeUuid}/nat/restore-points/{restorePointTime}")
  NATRestorePointDetailsResponse getNATRestorePoint(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          EdgeUuid edgeUuid,
      @PathParam("restorePointTime") long restorePointTime);

  /**
   * Get the latest NAT restore point for a specific edge.
   *
   * @param edgeUuid         edge uuid
   * @return NAT restore point
   */
  @GET
  @Path("/{edgeUuid}/nat/restore-points/latest")
  NATRestorePointDetailsResponse getNATLatestRestorePoint(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid") EdgeUuid edgeUuid);

  /**
   * Delete a NAT restore point.
   * <p>
   * Restore point time is epoch time in milliseconds.
   *
   * @param edgeUuid         edge uuid
   * @param restorePointTime restore point time
   */
  @DELETE
  @Path("/{edgeUuid}/nat/restore-points/{restorePointTime}")
  void deleteNATRestorePoint(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_NAT_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      @PathParam("restorePointTime") long restorePointTime);

  /**
   * Restore an edge gateway's NAT configuration to a specified restore point.
   *
   * @param edgeUuid          edge uuid
   * @param restoreNatRequest the request body, which specifies the restore point time
   * @return nat
   */
  @POST
  @Path("/{edgeUuid}/nat/actions/restore")
  EdgeGatewayNATResponse restoreNAT(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_NAT_CONFIGURATION)
      @PathParam("edgeUuid") EdgeUuid edgeUuid,
      RestoreNatRequest restoreNatRequest);

  /**
   * Get the load balancer for an edge gateway.
   * <p>
   * THIS ENDPOINT IS UNDER DEVELOPMENT AND IS SUBJECT TO CHANGE IN THE FUTURE
   *
   * @param edgeUuid edge uuid
   * @return edge gateway load balancer
   */
  @GET
  @Path("/{edgeUuid}/load-balancer")
  EdgeGatewayLoadBalancerResponse getEdgeGatewayLoadBalancer(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Update the load balancer configuration for an edge gateway.
   * <p>
   * THIS ENDPOINT IS UNDER DEVELOPMENT AND IS SUBJECT TO CHANGE IN THE FUTURE
   *
   * @param edgeUuid                  edge uuid
   * @param loadBalancerUpdateRequest load balancer update request
   * @return updated edge gateway load balancer
   */
  @PUT
  @Path("/{edgeUuid}/load-balancer")
  EdgeGatewayLoadBalancerResponse updateEdgeGatewayLoadBalancer(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_LOAD_BALANCER_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      EdgeGatewayLoadBalancerUpdateRequest loadBalancerUpdateRequest);

  /**
   * Get the Routing configuration for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return edge gateway Routing
   */
  @GET
  @Path("/{edgeUuid}/routing")
  EdgeGatewayRoutingResponse getEdgeGatewayRouting(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Update the Routing configuration for an edge gateway.
   *
   * @param edgeUuid                        edge uuid
   * @param edgeGatewayRoutingUpdateRequest Routing update request
   * @return updated edge gateway Routing
   */
  @PUT
  @Path("/{edgeUuid}/routing")
  EdgeGatewayRoutingResponse updateEdgeGatewayRouting(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_STATIC_ROUTING_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      EdgeGatewayRoutingUpdateRequest edgeGatewayRoutingUpdateRequest);

  /**
   * Update the Routing Global configuration for an edge gateway.
   *
   * @param edgeUuid                                    edge uuid
   * @param edgeGatewayRoutingGlobalConfigUpdateRequest Routing global config update request
   * @return updated edge gateway Routing Global config
   */
  @PUT
  @Path("/{edgeUuid}/routing/global-config")
  RoutingGlobalConfigResponse updateEdgeGatewayRoutingGlobalConfig(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_STATIC_ROUTING_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      RoutingGlobalConfigUpdateRequest edgeGatewayRoutingGlobalConfigUpdateRequest);

  /**
   * Update the Routing Static configuration for an edge gateway.
   *
   * @param edgeUuid                                    edge uuid
   * @param edgeGatewayRoutingStaticConfigUpdateRequest Routing static config update request
   * @return updated edge gateway Routing Static config
   */
  @PUT
  @Path("/{edgeUuid}/routing/static-config")
  RoutingStaticConfigResponse updateEdgeGatewayRoutingStaticConfig(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_STATIC_ROUTING_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      RoutingStaticConfigUpdateRequest edgeGatewayRoutingStaticConfigUpdateRequest);

  /**
   * Update the Routing OSPF configuration for an edge gateway.
   *
   * @param edgeUuid                                  edge uuid
   * @param edgeGatewayRoutingOSPFConfigUpdateRequest Routing OSPF config update request
   * @return updated edge gateway Routing OSPF config
   */
  @PUT
  @Path("/{edgeUuid}/routing/ospf-config")
  RoutingOSPFConfigResponse updateEdgeGatewayRoutingOSPFConfig(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_STATIC_ROUTING_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      RoutingOSPFConfigUpdateRequest edgeGatewayRoutingOSPFConfigUpdateRequest);

  /**
   * Update the Routing BGP configuration for an edge gateway.
   *
   * @param edgeUuid                                 edge uuid
   * @param edgeGatewayRoutingBGPConfigUpdateRequest Routing BGP config update request
   * @return updated edge gateway Routing BGP config
   */
  @PUT
  @Path("/{edgeUuid}/routing/bgp-config")
  RoutingBGPConfigResponse updateEdgeGatewayRoutingBGPConfig(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_STATIC_ROUTING_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      RoutingBGPConfigUpdateRequest edgeGatewayRoutingBGPConfigUpdateRequest);

  /**
   * Get the IPsec VPN for an edge gateway.
   *
   * @param edgeUuid          edge uuid
   * @param showSensitiveData show sensitive data
   * @return edge gateway IPsec VPN
   */
  @GET
  @Path("/{edgeUuid}/ipsec")
  EdgeGatewayIPsecResponse getEdgeGatewayIPsec(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid,
      @QueryParam("showSensitiveData") boolean showSensitiveData);

  /**
   * Update the IPsec VPN configuration for an edge gateway.
   *
   * @param edgeUuid                      edge uuid
   * @param edgeGatewayIpsecUpdateRequest IPsec VPN update request
   * @return updated edge gateway IPsec VPN
   */
  @PUT
  @Path("/{edgeUuid}/ipsec")
  EdgeGatewayIPsecResponse updateEdgeGatewayIPsec(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_IPSEC_VPN_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      EdgeGatewayIPsecUpdateRequest edgeGatewayIpsecUpdateRequest);

  /**
   * Retrieve IPSec VPN statistics.
   *
   * @param edgeUuid edge uuid
   * @return edge gateway ipsec statistics
   */
  @GET
  @Path("/{edgeUuid}/ipsec-statistics")
  IPsecStatisticsResponse getIPsecStatistics(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Get the L2 VPN for an edge gateway.
   *
   * @param edgeUuid          edge uuid
   * @param showSensitiveData show sensitive data
   * @return edge gateway l2 vpn
   */
  @GET
  @Path("/{edgeUuid}/l2vpn")
  EdgeGatewayL2VPNResponse getEdgeGatewayL2VPN(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid,
      @QueryParam("showSensitiveData") boolean showSensitiveData);

  /**
   * Update the L2 VPN configuration for an edge gateway.
   *
   * @param edgeUuid                      edge uuid
   * @param edgeGatewayL2VPNUpdateRequest L2 VPN update request
   * @return edge gateway L2 VPN
   */
  @PUT
  @Path("/{edgeUuid}/l2vpn")
  EdgeGatewayL2VPNResponse updateEdgeGatewayL2VPN(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_L2_VPN_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      EdgeGatewayL2VPNUpdateRequest edgeGatewayL2VPNUpdateRequest);

  /**
   * Get the L2 VPN statistics for an edge gateway.
   * <p>
   * THIS ENDPOINT IS UNDER DEVELOPMENT AND IS SUBJECT TO CHANGE IN THE FUTURE
   *
   * @param edgeUuid edge uuid
   * @return edge gateway L2 VPN statistics
   */
  @GET
  @Path("/{edgeUuid}/l2vpn-statistics")
  L2VPNStatisticsResponse getEdgeGatewayL2VPNStatistics(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Get the SSL VPN for an edge gateway.
   * <p>
   * THIS ENDPOINT IS UNDER DEVELOPMENT AND IS SUBJECT TO CHANGE IN THE FUTURE
   *
   * @param edgeUuid edge uuid
   * @return edge gateway ssl vpn
   */
  @GET
  @Path("/{edgeUuid}/sslvpn")
  EdgeGatewaySSLVPNResponse getEdgeGatewaySSLVPN(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Update the SSL VPN configuration for an edge gateway.
   * <p>
   * THIS ENDPOINT IS UNDER DEVELOPMENT AND IS SUBJECT TO CHANGE IN THE FUTURE
   *
   * @param edgeUuid                       edge uuid
   * @param edgeGatewaySSLVPNUpdateRequest SSL VPN update request
   * @return edge gateway SSL VPN
   */
  @PUT
  @Path("/{edgeUuid}/sslvpn")
  EdgeGatewaySSLVPNResponse updateEdgeGatewaySSLVPN(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SSL_VPN_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      EdgeGatewaySSLVPNUpdateRequest edgeGatewaySSLVPNUpdateRequest);

  /**
   * Get the Syslog settings for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return edge gateway syslog
   */
  @GET
  @Path("/{edgeUuid}/syslog")
  EdgeGatewaySyslogResponse getEdgeGatewaySyslog(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Get the SSH Settings for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return edge gateway SSH Settings
   */
  @GET
  @Path("/{edgeUuid}/ssh-settings")
  EdgeGatewaySSHSettingsResponse getEdgeGatewaySSHSettings(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Update the Syslog settings for an edge gateway.
   *
   * @param edgeUuid      edge uuid
   * @param updateRequest syslog update request
   * @return edge gateway syslog
   */
  @PUT
  @Path("/{edgeUuid}/syslog")
  EdgeGatewaySyslogResponse updateEdgeGatewaySyslog(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      EdgeGatewaySyslogUpdateRequest updateRequest);

  /**
   * Update the SSH Settings for an edge gateway.
   *
   * @param edgeUuid      edge uuid
   * @param updateRequest SSH Settings update request
   * @return edge gateway SSH Settings
   */
  @PUT
  @Path("/{edgeUuid}/ssh-settings")
  EdgeGatewaySSHSettingsResponse updateEdgeGatewaySSHSettings(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      EdgeGatewaySSHSettingsUpdateRequest updateRequest);

  /**
   * Get the list of certificates for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return list of certificates
   */
  @GET
  @Path("/{edgeUuid}/certificates")
  CertificatesResponse getCertificates(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Create a certificate for an edge gateway.
   *
   * @param edgeUuid      edge uuid
   * @param createRequest create request
   * @return the certificates created
   */
  @POST
  @Path("/{edgeUuid}/certificates")
  @Consumes(MediaType.APPLICATION_JSON)
  CertificateResponse createCertificate(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_CERTIFICATE_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      CertificateCreateRequest createRequest);

  /**
   * Import a certificate or a certificate chain against a certificate signing request.
   *
   * @param edgeUuid      edge uuid
   * @param csrId         csr id (e.g. csr-1)
   * @param importRequest certificate import request
   * @return the certificate
   */
  @POST
  @Path("/{edgeUuid}/certificate-signing-requests/{csrId}/actions/import-signed-certificate")
  CertificateResponse createSignedCertificate(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_CERTIFICATE_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid, @PathParam("csrId") String csrId,
      CertificateImportRequest importRequest);

  /**
   * Delete a certificate from an edge gateway.
   *
   * @param edgeUuid      edge uuid
   * @param certificateId certificate id (e.g. certificate-1)
   */
  @DELETE
  @Path("/{edgeUuid}/certificates/{certificateId}")
  void deleteCertificate(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_CERTIFICATE_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      @PathParam("certificateId") String certificateId);

  /**
   * Get the list of certificate signing requests (CSR) for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return list of CSRs
   */
  @GET
  @Path("/{edgeUuid}/certificate-signing-requests")
  CSRsResponse getCSRs(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Create a certificate signing request (CSR) for an edge gateway.
   *
   * @param edgeUuid         edge uuid
   * @param csrCreateRequest csr create request
   * @return the csr created
   */
  @POST
  @Path("/{edgeUuid}/certificate-signing-requests")
  @Consumes(MediaType.APPLICATION_JSON)
  CSRResponse createCSR(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_CERTIFICATE_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      CSRCreateRequest csrCreateRequest);

  /**
   * Create a self-signed certificate on an edge gateway.
   *
   * @param edgeUuid                   edge uuid
   * @param csrId                      csr id (e.g. csr-1)
   * @param selfSignCertificateRequest self sign certificate request
   * @return the self-signed certificate
   */
  @POST
  @Path("/{edgeUuid}/certificate-signing-requests/{csrId}/actions/generate-self-signed-certificate")
  @Consumes(MediaType.APPLICATION_JSON)
  CertificateResponse createSelfSignedCertificate(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_CERTIFICATE_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid, @PathParam("csrId") String csrId,
      SelfSignCertificateRequest selfSignCertificateRequest);

  /**
   * Delete a certificate signing request (CSR) from an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @param csrId    csr id (e.g. csr-1)
   */
  @DELETE
  @Path("/{edgeUuid}/certificate-signing-requests/{csrId}")
  void deleteCSR(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_CERTIFICATE_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid, @PathParam("csrId") String csrId);

  /**
   * Get the list of certificate revocation lists (CRLs) for an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @return list of CRLs
   */
  @GET
  @Path("/{edgeUuid}/certificate-revocation-lists")
  CRLsResponse getCRLs(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);

  /**
   * Create a certificate revocation list (CRL) for an edge gateway.
   *
   * @param edgeUuid         edge uuid
   * @param crlCreateRequest crl create request
   * @return the crl created
   */
  @POST
  @Path("/{edgeUuid}/certificate-revocation-lists")
  @Consumes(MediaType.APPLICATION_JSON)
  CRLResponse createCRL(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_CERTIFICATE_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid,
      CRLCreateRequest crlCreateRequest);

  /**
   * Delete a certificate revocation list (CRL) from an edge gateway.
   *
   * @param edgeUuid edge uuid
   * @param crlId    crl id (e.g. crl-1)
   */
  @DELETE
  @Path("/{edgeUuid}/certificate-revocation-lists/{crlId}")
  void deleteCRL(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_CERTIFICATE_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid, @PathParam("crlId") String crlId);

  /**
   * Enable distributed routing for an edge gateway.
   * <p>
   * THIS ENDPOINT IS UNDER DEVELOPMENT AND IS SUBJECT TO CHANGE IN THE FUTURE
   *
   * @param edgeUuid edge uuid
   * @return {@link TaskResponse} a task response
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Path("/{edgeUuid}/actions/enable-distributed-routing")
  TaskResponse enableDistributedRouting(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid);

  /**
   * Disable distributed routing for an edge gateway.
   * <p>
   * THIS ENDPOINT IS UNDER DEVELOPMENT AND IS SUBJECT TO CHANGE IN THE FUTURE
   *
   * @param edgeUuid edge uuid
   * @return {@link TaskResponse} a task response
   */
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Path("/{edgeUuid}/actions/disable-distributed-routing")
  TaskResponse disableDistributedRouting(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_EDGE_SETTINGS_CONFIGURATION)
      @PathParam("edgeUuid") String edgeUuid);

  /**
   * Get the status of distributed routing for an edge gateway.
   * <p>
   * THIS ENDPOINT IS UNDER DEVELOPMENT AND IS SUBJECT TO CHANGE IN THE FUTURE
   *
   * @param edgeUuid edge uuid
   * @return {@link EdgeGatewayDistributedRoutingResponse} a distributed routing response
   */
  @GET
  @Path("/{edgeUuid}/distributed-routing-status")
  EdgeGatewayDistributedRoutingResponse getDistributedRoutingStatus(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_EDGE) @PathParam("edgeUuid")
          String edgeUuid);
}
