/*
 * Copyright (c) 2025, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.notification;

import java.util.List;
import java.util.Objects;

import com.google.common.base.MoreObjects;

import com.iland.core.api.notification.types.AdvancedBackupsAlertTrigger;
import com.iland.core.web.rest.response.common.ListResponse;

/**
 * User Advanced Backup Resource Alert List Response.
 */
public class UserBackupResourceAlertListResponse
	extends ListResponse<AdvancedBackupsAlertTrigger> {

	public UserBackupResourceAlertListResponse(
		final List<AdvancedBackupsAlertTrigger> data) {
		super(data);
	}

	@Override
	public boolean equals(Object object) {
		return object instanceof UserBackupResourceAlertListResponse response
			&& Objects.equals(data, response.data);
	}

	@Override
	public String toString() {
		return MoreObjects.toStringHelper(this).add("data", data).toString();
	}

}
