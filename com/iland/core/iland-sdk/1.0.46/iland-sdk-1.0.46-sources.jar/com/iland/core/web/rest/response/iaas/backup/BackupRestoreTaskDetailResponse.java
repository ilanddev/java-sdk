/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * BackupRestoreTaskDetailResponse.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface BackupRestoreTaskDetailResponse
    extends BackupRestoreTaskResponse {

  /**
   * The UUID of the associated iland task.
   */
  Optional<String> taskUuid();

  /**
   * The username of the user who initiated the restore operation.
   */
  Optional<String> username();

  /**
   * The full name of the user who initiated the restore operation.
   */
  Optional<String> userFullName();

}
