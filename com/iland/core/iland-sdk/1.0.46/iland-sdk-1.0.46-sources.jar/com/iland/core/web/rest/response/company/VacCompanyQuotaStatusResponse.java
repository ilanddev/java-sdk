/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.company;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Company Vac Storage Info Response.
 *
 * @author <a href="mailto:nkasprza@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public final class VacCompanyQuotaStatusResponse implements Serializable {

  private static final long serialVersionUID = -2282096258143289674L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired(
      "The total storage quota of the company in GB. The total storage"
          + "of a company is the summation of the VAC companies storage quotas.")
  private final long totalStorageQuota;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The total used quota of the company in GB. The used storage"
      + "of a company is the summation of the VAC companies used storage.")
  private final long usedStorageQuota;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The total contracted storage in GB of the company.")
  private final long totalContractedQuota;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The total number of contracts that the company has.")
  private final long numberOfContracts;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Whether the company's location can only have VAC companies that use AWS storage")
  private final boolean isLocationAwsOnly;

  public VacCompanyQuotaStatusResponse(final long totalStorageQuota,
      final long usedStorageQuota, final long totalContractedQuota,
      final long numberOfContracts, final boolean isLocationAWSOnly) {
    this.totalStorageQuota = totalStorageQuota;
    this.usedStorageQuota = usedStorageQuota;
    this.totalContractedQuota = totalContractedQuota;
    this.numberOfContracts = numberOfContracts;
    this.isLocationAwsOnly = isLocationAWSOnly;
  }

  /**
   * Get the total storage quota for the company in GB. The total storage quota
   * is a summation of all the VAC companies total storage.
   *
   * @return total storage quota
   */
  public long getTotalStorageQuota() {
    return totalStorageQuota;
  }

  /**
   * Get the used storage quota for the company in GB. The used storage quota
   * is a summation of all the VAC companies used storage.
   *
   * @return used storage quota
   */
  public long getUsedStorageQuota() {
    return usedStorageQuota;
  }

  /**
   * Get the total contracted storage quota for the company in GB.
   *
   * @return total contracted quota
   */
  public long getTotalContractedQuota() {
    return totalContractedQuota;
  }

  /**
   * Get the number of contracts for a given company.
   *
   * @return number of contracts
   */
  public long getNumberOfContracts() {
    return numberOfContracts;
  }

  public boolean isLocationAwsOnly() {
    return isLocationAwsOnly;
  }
}
