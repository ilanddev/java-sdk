/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vm Resource Summary Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class VmResourceSummaryResponse implements Serializable {

  private static final long serialVersionUID = 6054731553425044472L;

  private static final String RESERVED_CPU = "reserved_cpu";

  private static final String RESERVED_MEMORY = "reserved_mem";

  private static final String CONSUMED_CPU = "consumed_cpu";

  private static final String CONSUMED_MEMORY = "consumed_mem";

  private static final String CONSUMED_DISK = "consumed_disk";

  private static final String PROVISIONED_DISK = "provisioned_disk";

  private static final String CONFIGURED_DISK = "configured_disk";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(RESERVED_CPU)
  private double reservedCpu;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(RESERVED_MEMORY)
  private double reservedMem;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(CONSUMED_CPU)
  private double consumedCpu;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(CONSUMED_MEMORY)
  private double consumedMem;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(CONSUMED_DISK)
  private double consumedDisk;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(PROVISIONED_DISK)
  private double provisionedDisk;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(CONFIGURED_DISK)
  private double configuredDisk;

  public VmResourceSummaryResponse(final double reservedCpu,
      final double reservedMem, final double consumedCpu,
      final double consumedMem, final double consumedDisk,
      final double provisionedDisk, final double configuredDisk) {
    this.reservedCpu = reservedCpu;
    this.reservedMem = reservedMem;
    this.consumedCpu = consumedCpu;
    this.consumedMem = consumedMem;
    this.consumedDisk = consumedDisk;
    this.provisionedDisk = provisionedDisk;
    this.configuredDisk = configuredDisk;
  }

  /**
   * Get reserved cpu.
   *
   * @return reserved cpu
   */
  public double getReservedCpu() {
    return reservedCpu;
  }

  /**
   * Get reserved mem.
   *
   * @return reserved mem
   */
  public double getReservedMem() {
    return reservedMem;
  }

  /**
   * Get consumed cpu.
   *
   * @return consumed cpu
   */
  public double getConsumedCpu() {
    return consumedCpu;
  }

  /**
   * Get consumed mem.
   *
   * @return consumed mem
   */
  public double getConsumedMem() {
    return consumedMem;
  }

  /**
   * Get consumed disk.
   *
   * @return consumed disk
   */
  public double getConsumedDisk() {
    return consumedDisk;
  }

  /**
   * Get provisioned disk.
   *
   * @return provisioned disk
   */
  public double getProvisionedDisk() {
    return provisionedDisk;
  }

  /**
   * Get configured disk.
   *
   * @return configured disk
   */
  public double getConfiguredDisk() {
    return configuredDisk;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    final VmResourceSummaryResponse that = (VmResourceSummaryResponse) o;

    if (Double.compare(that.reservedCpu, reservedCpu) != 0)
      return false;
    if (Double.compare(that.reservedMem, reservedMem) != 0)
      return false;
    if (Double.compare(that.consumedCpu, consumedCpu) != 0)
      return false;
    if (Double.compare(that.consumedMem, consumedMem) != 0)
      return false;
    if (Double.compare(that.consumedDisk, consumedDisk) != 0)
      return false;
    if (Double.compare(that.provisionedDisk, provisionedDisk) != 0)
      return false;
    return Double.compare(that.configuredDisk, configuredDisk) == 0;
  }

  @Override
  public int hashCode() {
    int result;
    long temp;
    temp = Double.doubleToLongBits(reservedCpu);
    result = (int) (temp ^ (temp >>> 32));
    temp = Double.doubleToLongBits(reservedMem);
    result = 31 * result + (int) (temp ^ (temp >>> 32));
    temp = Double.doubleToLongBits(consumedCpu);
    result = 31 * result + (int) (temp ^ (temp >>> 32));
    temp = Double.doubleToLongBits(consumedMem);
    result = 31 * result + (int) (temp ^ (temp >>> 32));
    temp = Double.doubleToLongBits(consumedDisk);
    result = 31 * result + (int) (temp ^ (temp >>> 32));
    temp = Double.doubleToLongBits(provisionedDisk);
    result = 31 * result + (int) (temp ^ (temp >>> 32));
    temp = Double.doubleToLongBits(configuredDisk);
    result = 31 * result + (int) (temp ^ (temp >>> 32));
    return result;
  }

  @Override
  public String toString() {
    return "VmResourceSummaryResponse{" + "reservedCpu=" + reservedCpu
        + ", reservedMem=" + reservedMem + ", consumedCpu=" + consumedCpu
        + ", consumedMem=" + consumedMem + ", consumedDisk=" + consumedDisk
        + ", provisionedDisk=" + provisionedDisk + ", configuredDisk="
        + configuredDisk + '}';
  }

}
