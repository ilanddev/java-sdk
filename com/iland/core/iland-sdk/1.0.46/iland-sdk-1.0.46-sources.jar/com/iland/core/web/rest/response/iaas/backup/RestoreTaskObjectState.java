/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the "LICENSE.txt" file that accompanied this software. Any inquiries
 *  concerning the scope or enforceability of the license should be addressed
 *  to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Optional;

import org.immutables.value.Value;

import com.iland.cohesity.iaas.backups.common.enums.RestoreTaskObjectStatus;
import com.iland.core.web.rest.annotation.APIModel;
import com.iland.core.web.rest.shared.iaas.backup.ProtectionSource;

/**
 * RestoreTaskObjectState.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface RestoreTaskObjectState {

  /**
   * The status of the object.
   */
  RestoreTaskObjectStatus status();

  /**
   * Error message, if applicable.
   */
  Optional<String> error();

  /**
   * The source info.
   */
  ProtectionSource source();

}
