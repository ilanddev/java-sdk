/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.math.BigInteger;
import java.time.Instant;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.EntityResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VmResponse.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public class VmResponse extends EntityResponse {

  private static final long serialVersionUID = -4869514557670253582L;

  private static final String VCENTER_MOREF = "vcenter_moref";

  private static final String VCENTER_INSTANCE_UUID = "vcenter_instance_uuid";

  private static final String VCENTER_HREF = "vcenter_href";

  private static final String VCENTER_NAME = "vcenter_name";

  private static final String NUMBER_OF_CPUS = "cpus_number";

  private static final String MEMORY_SIZE = "memory_size";

  private static final String OPERATING_SYSTEM = "os";

  private static final String OPERATING_SYSTEM_DESCRIPTION = "os_description";

  private static final String STORAGE_PROFILES = "storage_profiles";

  private static final String VM_LOCAL_ID = "vm_local_id";

  private static final String CORES_PER_SOCKET = "cores_per_socket";

  private static final String VIM_DATASTORE_REF = "vim_datastore_ref";

  private static final String VCLOUD_HREF = "vcloud_href";

  private static final String MEDIA_INSERTED = "media_inserted";

  private static final String INSERTED_MEDIA_NAME = "inserted_media_name";

  private static final String NESTED_HYPERVISOR_ENABLED =
      "nested_hypervisor_enabled";

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  protected String description;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCLOUD_HREF)
  protected String vCloudHref;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean deployed = false;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCENTER_MOREF)
  private String vCenterMoRef;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCENTER_NAME)
  private String vCenterName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCENTER_INSTANCE_UUID)
  private String vcenterInstanceUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VCENTER_HREF)
  private String vcenterHref;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String status;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(NUMBER_OF_CPUS)
  private Integer numberOfCpus;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(CORES_PER_SOCKET)
  private int coresPerSocket;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(MEMORY_SIZE)
  private BigInteger memorySize;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(OPERATING_SYSTEM)
  private String operatingSystem;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(OPERATING_SYSTEM_DESCRIPTION)
  private String operatingSystemDescription;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(STORAGE_PROFILES)
  private Set<String> storageProfiles;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String hardwareVersion;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String vappUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String vdcUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String orgUuid;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String locationId;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VM_LOCAL_ID)
  private String vappLocalId;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(VIM_DATASTORE_REF)
  private String vimDatastoreRef;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private Instant createdDate;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(MEDIA_INSERTED)
  private boolean mediaInserted;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(INSERTED_MEDIA_NAME)
  private String insertedMediaName;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  @SerializedName(NESTED_HYPERVISOR_ENABLED)
  private boolean nestedHypervisorEnabled;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String allocationModel;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean isProtected;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private boolean isBackupProtected;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private String ipAddress;

  @Since(ApiVersion.ONE_DOT_ZERO)
  @Expose
  private long storageBytes;

  public VmResponse(final String uuid, final String companyId,
      final String name, final boolean deleted, final Instant deletedDate,
      final Instant updatedDate, final String description,
      final String vCloudHref, final boolean deployed,
      final String vCenterMoRef, final String vCenterName,
      final String vcenterInstanceUuid, final String vcenterHref,
      final String status, final Integer numberOfCpus, final int coresPerSocket,
      final BigInteger memorySize, final String operatingSystem,
      final String operatingSystemDescription,
      final Set<String> storageProfiles, final String hardwareVersion,
      final String vappUuid, final String vdcUuid, final String orgUuid,
      final String locationId, final String vappLocalId,
      final String vimDatastoreRef, final Instant createdDate,
      final boolean mediaInserted, final String insertedMediaName,
      final boolean nestedHypervisorEnabled, final String allocationModel,
      final boolean isProtected, final boolean isBackupProtected,
      final String ipAddress, final long storageBytes) {
    super(uuid, name, deleted, deletedDate, updatedDate, companyId);
    this.description = description;
    this.vCloudHref = vCloudHref;
    this.deployed = deployed;
    this.vCenterMoRef = vCenterMoRef;
    this.vCenterName = vCenterName;
    this.vcenterInstanceUuid = vcenterInstanceUuid;
    this.vcenterHref = vcenterHref;
    this.status = status;
    this.numberOfCpus = numberOfCpus;
    this.coresPerSocket = coresPerSocket;
    this.memorySize = memorySize;
    this.operatingSystem = operatingSystem;
    this.operatingSystemDescription = operatingSystemDescription;
    this.storageProfiles = storageProfiles;
    this.hardwareVersion = hardwareVersion;
    this.vappUuid = vappUuid;
    this.vdcUuid = vdcUuid;
    this.orgUuid = orgUuid;
    this.locationId = locationId;
    this.vappLocalId = vappLocalId;
    this.vimDatastoreRef = vimDatastoreRef;
    this.createdDate = createdDate;
    this.mediaInserted = mediaInserted;
    this.insertedMediaName = insertedMediaName;
    this.nestedHypervisorEnabled = nestedHypervisorEnabled;
    this.allocationModel = allocationModel;
    this.isProtected = isProtected;
    this.isBackupProtected = isBackupProtected;
    this.ipAddress = ipAddress;
    this.storageBytes = storageBytes;
  }

  /**
   * Is deployed boolean.
   *
   * @return the boolean
   */
  public boolean isDeployed() {
    return deployed;
  }

  /**
   * Gets vcenter instance uuid.
   *
   * @return the vcenter instance uuid
   */
  public String getVcenterInstanceUuid() {
    return vcenterInstanceUuid;
  }

  /**
   * Gets center name.
   *
   * @return the center name
   */
  public String getvCenterName() {
    return vCenterName;
  }

  /**
   * Gets vcenter href.
   *
   * @return the vcenter href
   */
  public String getVcenterHref() {
    return vcenterHref;
  }

  /**
   * Gets center mo ref.
   *
   * @return the center mo ref
   */
  public String getvCenterMoRef() {
    return vCenterMoRef;
  }

  /**
   * Gets status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Gets number of cpus.
   *
   * @return the number of cpus
   */
  public Integer getNumberOfCpus() {
    return numberOfCpus;
  }

  /**
   * Gets memory size.
   *
   * @return the memory size
   */
  public BigInteger getMemorySize() {
    return memorySize;
  }

  /**
   * Gets operating system.
   *
   * @return the operating system
   */
  public String getOperatingSystem() {
    return operatingSystem;
  }

  /**
   * Gets storage profiles.
   *
   * @return the storage profiles
   */
  public Set<String> getStorageProfiles() {
    return storageProfiles;
  }

  /**
   * Gets hardware version.
   *
   * @return the hardware version
   */
  public String getHardwareVersion() {
    return hardwareVersion;
  }

  /**
   * Gets vapp uuid.
   *
   * @return the vapp uuid
   */
  public String getVappUuid() {
    return vappUuid;
  }

  /**
   * Gets vapp local id.
   *
   * @return the vapp local id
   */
  public String getVappLocalId() {
    return vappLocalId;
  }

  /**
   * Get the vim datastore ref.
   *
   * @return vim datastore ref
   */
  public String getVimDatastoreRef() {
    return vimDatastoreRef;
  }

  /**
   * Get the number of cores per socket.
   *
   * @return cores per socket
   */
  public int getCoresPerSocket() {
    return coresPerSocket;
  }

  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Gets location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Gets org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Gets cloud href.
   *
   * @return the cloud href
   */
  public String getvCloudHref() {
    return vCloudHref;
  }


  /**
   * Gets created date.
   *
   * @return the created date
   */
  public Instant getCreatedDate() {
    return createdDate;
  }

  /**
   * Indicates whether a CD/DVD is inserted in the VM.
   *
   * @return boolean value
   */
  public boolean isMediaInserted() {
    return mediaInserted;
  }

  /**
   * Gets the name of the media that is currently inserted in the VM. Returns an
   * empty string if no media is inserted.
   *
   * @return {@link String} media name
   */
  public String getInsertedMediaName() {
    return insertedMediaName;
  }

  /**
   * Get the operating system description.
   *
   * @return {@link String} operating system description
   */
  public String getOperatingSystemDescription() {
    return operatingSystemDescription;
  }

  /**
   * Get the allocation model.
   *
   * @return {@link String} allocation model
   */
  public String getAllocationModel() {
    return allocationModel;
  }

  /**
   * Is nested hypervisior enabled.
   *
   * @return is nested hypervisor enabled
   */
  public boolean isNestedHypervisorEnabled() {
    return nestedHypervisorEnabled;
  }

  /**
   * Get whether the VM is in the Trend service.
   *
   * @return whether the VM is in Trend
   */
  public boolean isProtected() {
    return isProtected;
  }

  /**
   * Get whether the VM is protected by Advanced Backups.
   *
   * @return whether the VM is protected by Advanced Backups
   */
  public boolean isBackupProtected() {
    return isBackupProtected;
  }

  /**
   * Get the VM's primary IP address.
   *
   * @return the VM's primary IP address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Get the VM's total storage measured in bytes.
   * @return the storage capacity of the VM
   */
  public long getStorageBytes() {
    return storageBytes;
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this)
        .add("description", description)
        .add("vCloudHref", vCloudHref)
        .add("deployed", deployed)
        .add("vCenterMoRef", vCenterMoRef)
        .add("vCenterName", vCenterName)
        .add("vCenterInstanceUuid", vcenterInstanceUuid)
        .add("vCenterHref", vcenterHref)
        .add("status", status)
        .add("numberOfCpus", numberOfCpus)
        .add("coresPerSocket", coresPerSocket)
        .add("memorySize", memorySize)
        .add("operatingSystem", operatingSystem)
        .add("operatingSystemDescription", operatingSystemDescription)
        .add("storageProfiles", storageProfiles)
        .add("hardwareVersion", hardwareVersion)
        .add("vappUuid", vappUuid)
        .add("vdcUuid", vdcUuid)
        .add("orgUuid", orgUuid)
        .add("locationId", locationId)
        .add("vappLocalId", vappLocalId)
        .add("vimDatastoreRef", vimDatastoreRef)
        .add("createdDate", createdDate)
        .add("mediaInserted", mediaInserted)
        .add("insertedMediaName", insertedMediaName)
        .add("allocationModel", allocationModel)
        .add("nestedHypervisorEnabled", nestedHypervisorEnabled)
        .add("isProtected", isProtected)
        .add("isBackupProtected", isBackupProtected)
        .add("ipAddress", ipAddress)
        .add("storageBytes", storageBytes)
        .toString();
  }

}
