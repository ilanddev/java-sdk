/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the "LICENSE.txt" file that accompanied this software. Any inquiries
 *  concerning the scope or enforceability of the license should be addressed
 *  to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.List;

import com.iland.cohesity.iaas.backups.common.enums.CombineMethod;
import com.iland.core.web.rest.annotation.APIModel;


/**
 * DeviceTreeDetails.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface DeviceTreeDetails {

  /**
   * Specifies how to combine the children of this node. The combining strategy
   * for child devices. Some of these strategies imply constraint on the number
   * of child devices. e.g. RAID5 will have 5 children. 'LINEAR' indicates
   * children are juxtaposed to form this device.
   */
  CombineMethod combineMethod();

  /**
   * Specifies the length of this device. This number should match the length
   * that is calculated from the children and combining method.
   */
  long deviceLength();

  /**
   * Specifies the children of this node in the device tree.
   */
  List<DeviceNode> deviceNodes();

  /**
   * Specifies the size of the striped data if the data is striped.
   */
  double stripeSize();

}
