/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 * This software is licensed under the Terms and Conditions contained within the
 * "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 * the scope or enforceability of the license should be addressed to:
 *
 * iland Internet Solutions, Corp 1235 North Loop West, Suite 800 Houston, TX
 * 77008 USA
 *
 * http://www.iland.com
 */

package com.iland.core.web.rest.response.metadata;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * MetadataResponse.
 *
 * @author <a href="mailto:aquinones@iland.com">Ari Quinones</a>
 */
@APIDoc
public class MetadataResponse implements Serializable {

  private static final long serialVersionUID = 6762097503781607386L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String key;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String access;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private Object value;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private String type;

  public MetadataResponse(final String key, final String access,
      final Object value, final String type) {
    this.key = key;
    this.access = access;
    this.value = value;
    this.type = type;
  }

  /**
   * Get the access of metadata response
   *
   * @return {@link String} access
   */
  public String getAccess() {
    return access;
  }

  /**
   * Get the value of metadata response
   *
   * @return {@link Object} value
   */
  public Object getValue() {
    return value;
  }

  /**
   * Get the type of metadata response
   *
   * @return {@link String} type
   */
  public String getType() {
    return type;
  }

  /**
   * Get the key of metadata response
   *
   * @return {@link String} key
   */
  public String getKey() {
    return key;
  }

  @Override
  public boolean equals(Object object) {
    if (this == object)
      return true;
    if (object == null || getClass() != object.getClass())
      return false;
    if (!super.equals(object))
      return false;
    MetadataResponse that = (MetadataResponse) object;
    if (getKey() != null ?
        !getKey().equals(that.getKey()) :
        that.getKey() != null)
      return false;
    if (getAccess() != null ?
        !getAccess().equals(that.getAccess()) :
        that.getAccess() != null)
      return false;
    if (getValue() != null ?
        !getValue().equals(that.getValue()) :
        that.getValue() != null)
      return false;
    if (getType() != null ?
        !getType().equals(that.getType()) :
        that.getType() != null)
      return false;
    return true;
  }

  @Override
  public int hashCode() {
    int result = super.hashCode();
    result = 31 * result + (getKey() != null ? getKey().hashCode() : 0);
    result = 31 * result + (getAccess() != null ? getAccess().hashCode() : 0);
    result = 31 * result + (getValue() != null ? getValue().hashCode() : 0);
    result = 31 * result + (getType() != null ? getType().hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "MetadataResponse{" + "key='" + key + '\'' + ", access='" + access
        + '\'' + ", value=" + value + ", type='" + type + '\'' + '}';
  }
}
