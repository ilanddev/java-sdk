/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.time.Instant;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Office 365 Audit Log Event Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public final class O365AuditLogEventResponse {

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The username the event is attributed to.")
  private final String username;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The location ID of the event.")
  private final String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The Office 365 org UUID of the event.")
  private final String o365OrgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The type of the event.")
  private final String eventType;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The console entity of the event.")
  private final String consoleEntity;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The entity name of the event.")
  private final String entityName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The time of the event.")
  private final Instant time;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The ip address of the event.")
  private final String ipAddress;

  /**
   * Instantiates a new O 365 audit log event response.
   *
   * @param username      the username
   * @param locationId    the location id
   * @param o365OrgUuid   the o 365 org uuid
   * @param eventType     the event type
   * @param consoleEntity the console entity
   * @param entityName    the entity name
   * @param time          the time
   * @param ipAddress     the ip address
   */
  public O365AuditLogEventResponse(final String username,
      final String locationId, final String o365OrgUuid, final String eventType,
      final String consoleEntity, final String entityName, final Instant time,
      final String ipAddress) {
    this.username = username;
    this.locationId = locationId;
    this.o365OrgUuid = o365OrgUuid;
    this.eventType = eventType;
    this.consoleEntity = consoleEntity;
    this.entityName = entityName;
    this.time = time;
    this.ipAddress = ipAddress;
  }

  /**
   * Gets username.
   *
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Gets location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Gets o 365 org uuid.
   *
   * @return the o 365 org uuid
   */
  public String getO365OrgUuid() {
    return o365OrgUuid;
  }

  /**
   * Gets event type.
   *
   * @return the event type
   */
  public String getEventType() {
    return eventType;
  }

  /**
   * Gets console entity.
   *
   * @return the console entity
   */
  public String getConsoleEntity() {
    return consoleEntity;
  }

  /**
   * Gets entity name.
   *
   * @return the entity name
   */
  public String getEntityName() {
    return entityName;
  }

  /**
   * Gets time.
   *
   * @return the time
   */
  public Instant getTime() {
    return time;
  }

  /**
   * Gets ip address.
   *
   * @return the ip address
   */
  public String getIpAddress() {
    return ipAddress;
  }
}
