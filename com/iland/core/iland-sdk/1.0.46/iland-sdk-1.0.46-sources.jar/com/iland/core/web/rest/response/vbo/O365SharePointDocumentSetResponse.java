/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.util.Set;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.common.SetResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Office 365 VBO SharePoint Document set response.
 *
 * @author <a href="mailto:janguenot@iland.com">Julien Anguenot</a>
 */
@APIDoc
public final class O365SharePointDocumentSetResponse
    extends SetResponse<O365SharePointDocumentResponse> {

  private static final long serialVersionUID = 5044794146293496139L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The page number.")
  private final int page;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The page size.")
  private final int pageSize;

  public O365SharePointDocumentSetResponse(
      final Set<O365SharePointDocumentResponse> data, final int page,
      final int pageSize) {
    super(data);
    this.page = page;
    this.pageSize = pageSize;
  }

  /**
   * Returns the page number.
   *
   * @return the page number
   */
  public int getPage() {
    return page;
  }

  /**
   * Returns the page size.
   *
   * @return the page size
   */
  public int getPageSize() {
    return pageSize;
  }

}
