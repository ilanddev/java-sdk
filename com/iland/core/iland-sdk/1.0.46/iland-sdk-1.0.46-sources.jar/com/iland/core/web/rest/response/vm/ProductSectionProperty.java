/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.util.Optional;
import java.util.Set;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * An individual property within a product section.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface ProductSectionProperty {

  /**
   * The property key.
   */
  String key();

  /**
   * The property variable type.
   */
  ProductSectionPropertyType type();

  /**
   * A short human-friendly label.
   */
  Optional<String> label();

  /**
   * A description of the property.
   */
  Optional<String> description();

  /**
   * The category of the property.
   */
  Optional<String> category();

  /**
   * Whether this property represents a password.
   */
  boolean password();

  /**
   * Whether this property is user configurable.
   */
  boolean userConfigurable();

  /**
   * Qualifiers that restrict the set of valid values for the property.
   */
  Set<Qualifier> qualifiers();

  /**
   * The current value of the property.
   */
  Optional<String> value();

}
