/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.objectstorage;

import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * Tenant Key Pair Response.
 *
 * @author <a href=“mailto:nkasprzak@iland.com”>Nick Kasprzak</a>
 */
@APIModel
public interface TenantKeyPairResponse {

  /**
   * The access key.
   */
  String accessKey();

  /**
   * The secret key.
   */
  Optional<String> secretKey();

  /**
   * The username who created the pair.
   */
  Optional<String> username();

  /**
   * The date when the pair was created.
   */
  Optional<Long> createdDate();

  /**
   * A description of the tenant key pair.
   */
  Optional<String> description();
}
