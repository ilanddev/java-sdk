/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.billing;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.shared.billing.CurrencyCode;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Currency Code Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class CurrencyCodeResponse implements Serializable {

  private static final long serialVersionUID = -8636076551351240233L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final CurrencyCode currencyCode;

  public CurrencyCodeResponse(final CurrencyCode code) {
    this.currencyCode = code;
  }

  /**
   * Get the currency code associated with the organization.
   *
   * @return {@link CurrencyCode} currency code
   */
  public CurrencyCode getCurrencyCode() {
    return currencyCode;
  }

}
