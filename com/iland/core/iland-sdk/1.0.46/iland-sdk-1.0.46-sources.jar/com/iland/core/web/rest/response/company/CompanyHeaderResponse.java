/*
 * Copyright (c) 2013 - 2025, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.response.company;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * Headers/short form of a Company.
 */
@APIModel
public interface CompanyHeaderResponse {
  /**
   * The company ID.
   */
  String companyId();

  /**
   * The company name.
   */
  String companyName();
}
