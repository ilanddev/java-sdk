/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.websocket;

import com.google.gson.annotations.Expose;

/**
 * WebSocket Message.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public abstract class Message {

  /**
   * The Type.
   */
  @Expose
  private final MessageType type;

  /**
   * Instantiates a new Message.
   *
   * @param type the type
   */
  public Message(final MessageType type) {
    this.type = type;
  }

  /**
   * Gets type.
   *
   * @return the type
   */
  public MessageType getType() {
    return type;
  }
}
