/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.backupgroups.enums.StatusSourceBackupStatus;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.shared.iaas.backup.ProtectionSource;

/**
 * SourceBackupStatus.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class SourceBackupStatus {

  @Expose
  @JsonOptional(
      "Specifies if an error occurred (if any) while running this task. This field "
          + "is populated when the status is equal to 'FAILURE'.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String error;

  @Expose
  @JsonRequired(
      "Specifies whether this is a 'FULL' or 'REGULAR' backup of the Run. This may "
          + "be true even if the scheduled backup type is 'REGULAR'. This will happen "
          + "when this run corresponds to the first backup run of the group or if no "
          + "previous snapshot information is found.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean isFullBackup;

  @Expose
  @JsonRequired(
      "Specifies the number of times the the task was restarted because of the "
          + "changes on the backup source host.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double numRestarts;

  @Expose
  @JsonRequired(
      "Specifies if app-consistent snapshot was captured. This field is set to "
          + "true, if an app-consistent snapshot was taken by quiescing applications and "
          + "the file system before taking a backup.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean quiesced;

  @Expose
  @JsonRequired(
      "Specifies if the SLA was violated for the backup group run. This field is "
          + "set to true, if time to complete the backup group run is longer than the "
          + "SLA specified.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean slaViolated;

  @Expose
  @JsonRequired("Specifies the vCloud protected source info.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final ProtectionSource source;

  @Expose
  @JsonRequired(
      "Specifies statistics about a Backup task in backup group run. Specifies "
          + "statistics for one backup task. One backup task is used to backup one "
          + "source. This structure is also used to aggregate stats of backup tasks in a "
          + "backup group run.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupSourceStats stats;

  @Expose
  @JsonRequired("Specifies the status of the source object being protected.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final StatusSourceBackupStatus status;

  @Expose
  @JsonRequired("Array of Warnings. "
      + "Specifies the warnings that occurred (if any) while running this task.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<String> warnings;

  public SourceBackupStatus(final String error, final boolean isFullBackup,
      final double numRestarts, final boolean quiesced,
      final boolean slaViolated, final ProtectionSource source,
      final BackupSourceStats stats, final StatusSourceBackupStatus status,
      final Set<String> warnings) {
    this.error = error;
    this.isFullBackup = isFullBackup;
    this.numRestarts = numRestarts;
    this.quiesced = quiesced;
    this.slaViolated = slaViolated;
    this.source = source;
    this.stats = stats;
    this.status = status;
    this.warnings = warnings;
  }

  /**
   * Specifies if an error occurred (if any) while running this task. This field
   * is populated when the status is equal to 'FAILURE'.
   */
  public Optional<String> getError() {
    return Optional.ofNullable(error);
  }

  /**
   * Specifies whether this is a 'FULL' or 'REGULAR' backup of the Run. This may
   * be true even if the scheduled backup type is 'REGULAR'. This will happen
   * when this run corresponds to the first backup run of the group or if no
   * previous snapshot information is found.
   */
  public boolean isFullBackup() {
    return isFullBackup;
  }

  /**
   * Specifies the number of times the the task was restarted because of the
   * changes on the backup source host.
   */
  public double getNumRestarts() {
    return numRestarts;
  }

  /**
   * Specifies if app-consistent snapshot was captured. This field is set to
   * true, if an app-consistent snapshot was taken by quiescing applications and
   * the file system before taking a backup.
   */
  public boolean isQuiesced() {
    return quiesced;
  }

  /**
   * Specifies if the SLA was violated for the backup group run. This field is
   * set to true, if time to complete the backup group run is longer than the
   * SLA specified.
   */
  public boolean isSlaViolated() {
    return slaViolated;
  }

  /**
   * Specifies the vCloud protected source info.
   */
  public ProtectionSource getSource() {
    return source;
  }

  /**
   * Specifies statistics about a Backup task in backup group run. Specifies
   * statistics for one backup task. One backup task is used to backup one
   * source. This structure is also used to aggregate stats of backup tasks in a
   * backup group run.
   */
  public BackupSourceStats getStats() {
    return stats;
  }

  /**
   * Specifies the status of the source object being protected.
   */
  public StatusSourceBackupStatus getStatus() {
    return status;
  }

  /**
   * Array of Warnings.
   * <p>
   * Specifies the warnings that occurred (if any) while running this task.
   */
  public Set<String> getWarnings() {
    return warnings;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final SourceBackupStatus that = (SourceBackupStatus) o;
    return isFullBackup == that.isFullBackup
        && Double.compare(that.numRestarts, numRestarts) == 0
        && quiesced == that.quiesced && slaViolated == that.slaViolated
        && Objects.equals(error, that.error) && Objects
        .equals(source, that.source) && Objects.equals(stats, that.stats)
        && status == that.status && Objects.equals(warnings, that.warnings);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(error, isFullBackup, numRestarts, quiesced, slaViolated, source,
            stats, status, warnings);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("error", error)
        .add("isFullBackup", isFullBackup).add("numRestarts", numRestarts)
        .add("quiesced", quiesced).add("slaViolated", slaViolated)
        .add("source", source).add("stats", stats).add("status", status)
        .add("warnings", warnings).toString();
  }
}
