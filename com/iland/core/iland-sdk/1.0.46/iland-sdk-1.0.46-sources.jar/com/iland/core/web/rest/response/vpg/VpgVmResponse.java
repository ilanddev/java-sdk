/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vpg;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Virtual Protection Group VM Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VpgVmResponse implements Serializable {

  private static final long serialVersionUID = 6832491308440432358L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String location;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String orgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vpgUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmIdentifier;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vpgName;

  /**
   * The organization name.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String organizationName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @SerializedName("actual_rpo")
  private final int actualRPO;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final VpgEntitiesResponse entities;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final VpgStatusResponse status;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final VpgSubStatusResponse subStatus;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final VpgPriorityResponse priority;

  /**
   * The source site.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String sourceSite;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String targetSite;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final LocalDateTime lastTest;

  @SerializedName("provisioned_storage_in_mb")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long provisionedStorageInMB;

  @SerializedName("used_storage_in_mb")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long usedStorageInMB;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final long iops;

  @SerializedName("throughput_in_mb")
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final double throughputInMB;

  public VpgVmResponse(final String uuid, final String location,
      final String orgUuid, final String vpgUuid, final String vmName,
      final String vmIdentifier, final String vpgName,
      final String organizationName, final int actualRPO,
      final VpgEntitiesResponse entities, final VpgStatusResponse status,
      final VpgSubStatusResponse subStatus, final VpgPriorityResponse priority,
      final String sourceSite, final String targetSite,
      final LocalDateTime lastTest, final long provisionedStorageInMB,
      final long usedStorageInMB, final long iops,
      final double throughputInMB) {
    this.location = location;
    this.orgUuid = orgUuid;
    this.vpgUuid = vpgUuid;
    this.uuid = uuid;
    this.vmName = vmName;
    this.vmIdentifier = vmIdentifier;
    this.vpgName = vpgName;
    this.organizationName = organizationName;
    this.actualRPO = actualRPO;
    this.entities = entities;
    this.status = status;
    this.subStatus = subStatus;
    this.priority = priority;
    this.sourceSite = sourceSite;
    this.targetSite = targetSite;
    this.lastTest = lastTest;
    this.provisionedStorageInMB = provisionedStorageInMB;
    this.usedStorageInMB = usedStorageInMB;
    this.iops = iops;
    this.throughputInMB = throughputInMB;
  }

  /**
   * Gets the org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets the location ID.
   *
   * @return the location ID
   */
  public String getLocation() {
    return location;
  }

  /**
   * Gets the parent VPG uuid.
   *
   * @return the parent VPG uuid
   */
  public String getVpgUuid() {
    return vpgUuid;
  }

  /**
   * Gets the VPG VM uuid.
   *
   * @return the VPG vm uuid.
   */
  public String getUuid() {
    return uuid;
  }

  /**
   * Gets the vm name.
   *
   * @return the vm name
   */
  public String getVmName() {
    return vmName;
  }

  /**
   * Gets the vm identifier.
   *
   * @return the vm identifier
   */
  public String getVmIdentifier() {
    return vmIdentifier;
  }

  /**
   * Gets the vpg name.
   *
   * @return the vpg name
   */
  public String getVpgName() {
    return vpgName;
  }

  /**
   * Gets the organization name.
   *
   * @return the organization name
   */
  public String getOrganizationName() {
    return organizationName;
  }

  /**
   * Gets the actual rpo.
   *
   * @return the actual rpo
   */
  public int getActualRPO() {
    return actualRPO;
  }

  /**
   * Gets the entities.
   *
   * @return the entities
   */
  public VpgEntitiesResponse getEntities() {
    return entities;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public VpgStatusResponse getStatus() {
    return status;
  }

  /**
   * Gets the sub status.
   *
   * @return the sub status
   */
  public VpgSubStatusResponse getSubStatus() {
    return subStatus;
  }

  /**
   * Gets the priority.
   *
   * @return the priority
   */
  public VpgPriorityResponse getPriority() {
    return priority;
  }

  /**
   * Gets the source site.
   *
   * @return the source site
   */
  public String getSourceSite() {
    return sourceSite;
  }

  /**
   * Gets the target site.
   *
   * @return the target site
   */
  public String getTargetSite() {
    return targetSite;
  }

  /**
   * Gets the last test.
   *
   * @return the last test
   */
  public LocalDateTime getLastTest() {
    return lastTest;
  }

  /**
   * Gets the provisioned storage in mb.
   *
   * @return the provisioned storage in mb
   */
  public long getProvisionedStorageInMB() {
    return provisionedStorageInMB;
  }

  /**
   * Gets the used storage in mb.
   *
   * @return the used storage in mb
   */
  public long getUsedStorageInMB() {
    return usedStorageInMB;
  }

  /**
   * Gets the iops.
   *
   * @return the iops
   */
  public long getiOPS() {
    return iops;
  }

  /**
   * Gets the throughput in mb.
   *
   * @return the throughput in mb
   */
  public double getThroughputInMB() {
    return throughputInMB;
  }

}
