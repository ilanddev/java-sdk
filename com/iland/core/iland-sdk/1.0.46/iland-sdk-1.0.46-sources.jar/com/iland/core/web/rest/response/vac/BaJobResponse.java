/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vac;

import java.io.Serializable;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vac Job Response
 *
 * @author <a href="mailto:nkasprza@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public final class BaJobResponse implements Serializable {

  private static final long serialVersionUID = -2029430793945386785L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String uuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Name of the job configured in Veeam Backup & Replication.")
  private final String name;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Status of the latest job session."
      + "Possible values: Success, Warning, Failed, Running, No Info")
  private final BaJobStatus status;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Veeam Backup & Replication job type." + ""
      + "Possible values: Backup, Replication, SureBackup, Backup Copy, File to Tape, Backup to Tape"
      + "Copy, SQL Log Backup Job, Oracle Log Backup Job, Quick Migration, SAN Rescan, Failover Plan"
      + "Agent Backup Job (Managed by Agent), Agent Backup Job (Managed by Backup Server)"
      + "Agent Backup Policy, Agent Backup Job, Windows Agent Backup Copy")
  private final BaJobType type;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Date and time when the latest job session started."
      + "Date and time string is formatted in accordance with ISO 8601.")
  private final Instant lastRun;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Date and time when the latest job session finished."
      + "Date and time string is formatted in accordance with ISO 8601.")
  private final Instant endTime;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Time taken to complete the latest job session.")
  private final int duration;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Rate at which VM data was processed during the latest job session.")
  private final double processionRate;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Average time taken to complete a job session.")
  private final int avgDuration;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Total amount of data that was transferred to target during the latest job session.")
  private final double transferredData;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired(
      "Bottleneck in the process of transferring the data from source to target."
          + "Possible values: Source"
          + "Proxy, Network, Target, Source WAN accelerator"
          + "Target WAN accelerator")
  private final BaJobBottleneck bottleneck;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Name of the Veeam Backup & Replication or Veeam Cloud Connect server on which a job was configured.")
  private final String serverName;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Indicates whether a job schedule is enabled.")
  private final boolean isEnabled;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Number of objects processed by the job.")
  private final int numberOfProcessedObjects;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Type of schedule configured for the job."
      + "Possible values: Continuously, Periodically, Monthly, Daily, Chained")
  private final BaJobSchedulingType schedulingType;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The company id of that the VAC job belongs to.")
  private final String companyId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The location id of the VAC job.")
  private final String locationId;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The iland platform uuid of the company for the VAC job.")
  private final String companyUuid;

  public BaJobResponse(final String uuid, final String name,
      final BaJobStatus status, final BaJobType type, final Instant lastRun,
      final Instant endTime, final int duration, final double processionRate,
      final int avgDuration, final double transferredData,
      final BaJobBottleneck bottleneck, final String serverName,
      final boolean isEnabled, final int numberOfProcessedObjects,
      final BaJobSchedulingType schedulingType, final String companyId,
      final String locationId, final String companyUuid) {
    this.uuid = uuid;
    this.name = name;
    this.status = status;
    this.type = type;
    this.lastRun = lastRun;
    this.endTime = endTime;
    this.duration = duration;
    this.processionRate = processionRate;
    this.avgDuration = avgDuration;
    this.transferredData = transferredData;
    this.bottleneck = bottleneck;
    this.serverName = serverName;
    this.isEnabled = isEnabled;
    this.numberOfProcessedObjects = numberOfProcessedObjects;
    this.schedulingType = schedulingType;
    this.companyId = companyId;
    this.locationId = locationId;
    this.companyUuid = companyUuid;
  }

  public String getUuid() {
    return uuid;
  }

  /**
   * Gets name of the job configured in Veeam Backup & Replication.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets status of the latest job session.
   * <p>
   * Possible values:
   * <p>
   * Success
   * Warning
   * Failed
   * Running
   * No Info.
   *
   * @return the status
   */
  public BaJobStatus getStatus() {
    return status;
  }

  /**
   * Gets veeam Backup & Replication job type.
   * <p>
   * Possible values:
   * <p>
   * Backup
   * Replication
   * SureBackup
   * Backup Copy
   * File to Tape
   * Backup to Tape
   * Copy
   * SQL Log Backup Job
   * Oracle Log Backup Job
   * Quick Migration
   * SAN Rescan
   * Failover Plan
   * Agent Backup Job (Managed by Agent)
   * Agent Backup Job (Managed by Backup Server)
   * Agent Backup Policy
   * Agent Backup Job
   * Windows Agent Backup Copy
   *
   * @return the type
   */
  public BaJobType getType() {
    return type;
  }

  /**
   * Gets date and time when the latest job session started.
   * Date and time string is formatted in accordance with ISO 8601.
   *
   * @return the last run
   */
  public Instant getLastRun() {
    return lastRun;
  }

  /**
   * Gets date and time when the latest job session finished.
   * Date and time string is formatted in accordance with ISO 8601.
   *
   * @return the end time
   */
  public Instant getEndTime() {
    return endTime;
  }

  /**
   * Gets time taken to complete the latest job session in seconds.
   *
   * @return the duration
   */
  public int getDuration() {
    return duration;
  }

  /**
   * Gets rate at which VM data was processed during the latest job session in bytes per second (MB/s).
   *
   * @return the procession rate
   */
  public double getProcessionRate() {
    return processionRate;
  }

  /**
   * Gets average time taken to complete a job session in seconds.
   *
   * @return the avg duration
   */
  public int getAvgDuration() {
    return avgDuration;
  }

  /**
   * Gets total amount of data that was transferred to target during the latest job session in MB.
   *
   * @return the transferred data
   */
  public double getTransferredData() {
    return transferredData;
  }

  /**
   * Gets bottleneck in the process of transferring the data from source to target.
   * <p>
   * Possible values:
   * <p>
   * Source
   * Proxy
   * Network
   * Target
   * Source WAN accelerator
   * Target WAN accelerator
   *
   * @return the bottleneck
   */
  public BaJobBottleneck getBottleneck() {
    return bottleneck;
  }

  /**
   * Gets name of the Veeam Backup & Replication or Veeam Cloud Connect server
   * on which a job was configured.
   *
   * @return the server name
   */
  public String getServerName() {
    return serverName;
  }

  /**
   * Indicates whether a job schedule is enabled.
   *
   * @return the boolean
   */
  public boolean isEnabled() {
    return isEnabled;
  }

  /**
   * Gets number of VMs protected by the job.
   *
   * @return the protected v ms
   */
  public int getNumberOfProcessedObjects() {
    return numberOfProcessedObjects;
  }

  /**
   * Gets type of schedule configured for the job.
   * <p>
   * Possible values:
   * <p>
   * Continuously
   * Periodically
   * Monthly
   * Daily
   * Chained.
   *
   * @return the scheduling type
   */
  public BaJobSchedulingType getSchedulingType() {
    return schedulingType;
  }

  /**
   * Gets the company id.
   *
   * @return the company id
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * Gets the location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Gets the iland company uuid for the VAC job
   *
   * @return the company uuid
   */
  public String getCompanyUuid() {
    return companyUuid;
  }

  /**
   * VAC job status.
   */
  public enum BaJobStatus {

    UNKNOWN("Unknown"),

    NONE("None"),

    IDLE("Idle"),

    SUCCESS("Success"),

    WARNING("Warning"),

    FAILED("Failed"),

    RUNNING("Running"),

    STARTING("Starting"),

    STOPPING("Stopping"),

    ENABLING("Enabling"),

    DISABLING("Disabling"),

    WAITINGTAPE("WaitingTape"),

    WAITINGREPOSITORY("WaitingRepository");
    private String value;

    /**
     * Get the VAC value of the job status.
     *
     * @return {@link String} vac value
     */
    public String getValue() {
      return value;
    }

    public static Map<String, BaJobStatus> statusMap = new HashMap<>();

    static {
      for (final BaJobStatus baJobStatus : values()) {
        statusMap.put(baJobStatus.getValue(), baJobStatus);
      }
    }

    BaJobStatus(final String value) {
      this.value = value;
    }

    /**
     * Gets a Ba Job status enum given the VAC value.
     *
     * @param value {@link String} value
     * @return {@link BaJobStatus} ba job status
     */
    public static BaJobStatus getBaJobStatus(final String value) {
      return statusMap.getOrDefault(value, UNKNOWN);
    }

  }


  /**
   * Vac job type.
   */
  public enum BaJobType {

    UNKNOWN("Unknown"),

    BACKUPVM("BackupVm"),

    REPLICATIONVM("ReplicationVM"),

    COPYVM("CopyVm"),

    COPYFILE("CopyFile"),

    FILETOTAPE("FileToTape"),

    BACKUPTOTAPE("BackupToTape"),

    BACKUPCOPY("BackupCopy"),

    IMMEDIATELYBACKUPCOPY("ImmediatelyBackupCopy"),

    SQLLOGBACKUP("SqlLogBackup"),

    ORACLELOGBACKUP("OracleLogBackup"),

    SUREBACKUP("SureBackup"),

    AGENTPOLICY("AgentPolicy"),

    AGENTBACKUPJOB("AgentBackupJob"),

    BACKUPFILE("BackupFile"),

    BACKUPFILECOPY("BackupFileCopy"),

    AZUREBACKUPJOB("AzureBackupJob"),

    AWSBACKUPJOB("AwsBackupJob"),

    AHVSTORAGESNAPSHOTJOB("AhvStorageSnapshotJob"),

    CDPREPLICATIONVM("CdpReplicationVM"),

    GOOGLEBACKUPJOB("GoogleBackupJob"),

    POSTGRESQLLOGBACKUP("PostgreSqlLogBackup"),

    OBJECTSTORAGEBACKUP("ObjectStorageBackup"),

    OBJECTSTORAGEBACKUPCOPY("ObjectStorageBackupCopy");

    private String value;

    BaJobType(final String value) {
      this.value = value;
    }

    /**
     * Get the VAC value of the job type.
     *
     * @return {@link String} vac value
     */
    public String getValue() {
      return value;
    }

    public static Map<String, BaJobType> statusMap = new HashMap<>();

    static {
      for (final BaJobType baJobType : values()) {
        statusMap.put(baJobType.getValue(), baJobType);
      }
    }

    /**
     * Get a BaJobType enum given the VAC value.
     *
     * @param value {@link String} value
     * @return {@link BaJobType} ba job type
     */
    public static BaJobType getBaJobType(final String value) {
      return statusMap.getOrDefault(value, UNKNOWN);
    }

  }


  /**
   * VAC job bottleneck.
   */
  public enum BaJobBottleneck {

    SOURCE("Source"),

    PROXY("Proxy"),

    NETWORK("Network"),

    TARGET("Target"),

    SOURCE_WAN_ACCELERATOR("Source WAN Accelerator"),

    TARGET_WAN_ACCELERATOR("Target WAN Accelerator"),

    UNKNOWN("Unknown");

    private String value;

    BaJobBottleneck(final String value) {
      this.value = value;
    }

    /**
     * Get the VAC value of the job bottleneck.
     *
     * @return {@link String} vac value
     */
    public String getValue() {
      return value;
    }

    public static Map<String, BaJobBottleneck> statusMap = new HashMap<>();

    static {
      for (final BaJobBottleneck baJobBottleneck : values()) {
        statusMap.put(baJobBottleneck.getValue(), baJobBottleneck);
      }
    }

    /**
     * Get the BaJobBottleneck enum given the VAC value.
     *
     * @param value {@link String} value
     * @return {@link BaJobBottleneck} ba job bottleneck
     */
    public static BaJobBottleneck getBaJobBottleneck(final String value) {
      return statusMap.getOrDefault(value, UNKNOWN);
    }

  }


  /**
   * VAC job scheduling type.
   */
  public enum BaJobSchedulingType {

    CONTINUOUSLY("Continuously"),

    PERIODICALLY("Periodically"),

    MONTHLY("Monthly"),

    DAILY("Daily"),

    CHAINED("Chained"),

    DISABLED("Disabled"),

    NOTSCHEDULED("NotScheduled"),

    BACKUPWINDOW("BackupWindow"),
    UNKNOWN("Unknown");

    private String value;

    BaJobSchedulingType(final String value) {
      this.value = value;
    }

    /**
     * Get the VAC value of the job scheduling type.
     *
     * @return {@link String} vac value
     */
    public String getValue() {
      return value;
    }

    public static Map<String, BaJobSchedulingType> statusMap = new HashMap<>();

    static {
      for (final BaJobSchedulingType baJobSchedulingType : values()) {
        statusMap.put(baJobSchedulingType.getValue(), baJobSchedulingType);
      }
    }

    /**
     * Get the BaSchedulingType enum from the VAC value.
     *
     * @param value {@link String} vac value
     * @return {@link BaJobSchedulingType} ba job scheduling type
     */
    public static BaJobSchedulingType getBaJobSchedulingType(
        final String value) {
      return statusMap.getOrDefault(value, UNKNOWN);
    }

  }

}
