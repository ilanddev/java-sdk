/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.vdc;

import java.time.Instant;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vdc Storage Profile Summary Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VdcStorageProfileSummaryResponse {

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vdcUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int year;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final int month;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant time;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<StorageProfileBillResponse> storageProfileBills;

  /**
   * Instantiates a new vDC storage profile summary response.
   *
   * @param vdcUuid             the vdc uuid
   * @param year                the year
   * @param month               the month
   * @param time                the time
   * @param storageProfileBills the storageProfileBills
   */
  public VdcStorageProfileSummaryResponse(final String vdcUuid, final int year,
      final int month, final Instant time,
      final List<StorageProfileBillResponse> storageProfileBills) {
    this.vdcUuid = vdcUuid;
    this.year = year;
    this.month = month;
    this.time = time;
    this.storageProfileBills = storageProfileBills;
  }

  /**
   * Gets vdc uuid.
   *
   * @return the vdc uuid
   */
  public String getVdcUuid() {
    return vdcUuid;
  }

  /**
   * Gets year.
   *
   * @return the year
   */
  public int getYear() {
    return year;
  }

  /**
   * Gets month.
   *
   * @return the month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Gets time.
   *
   * @return the time
   */
  public Instant getTime() {
    return time;
  }

  /**
   * Gets storageProfileBills.
   *
   * @return {@link List} of {@link StorageProfileBillResponse} the storage
   * profile bills
   */
  public List<StorageProfileBillResponse> getStorageProfileBills() {
    return storageProfileBills;
  }

}
