/*
 * Copyright (c) 2013 - 2019, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.common.enums.BackupPolicyScopeType;
import com.iland.cohesity.iaas.backups.policies.api.enums.ProtectionType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.shared.iaas.backup.BlackoutPeriod;
import com.iland.core.web.rest.shared.iaas.backup.DatalockConfig;
import com.iland.core.web.rest.shared.iaas.backup.ExtendedRetentionPolicy;
import com.iland.core.web.rest.shared.iaas.backup.SchedulingPolicy;
import com.iland.core.web.rest.shared.iaas.backup.SnapshotArchivalCopyPolicy;
import com.iland.core.web.rest.shared.iaas.backup.SnapshotReplicationCopyPolicy;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Backup Policy Response.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public final class BackupPolicyResponse implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * The type of the policy (discriminates between user-defined and
   * iland-defined policies).
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The type of the policy (discriminates between "
      + "org or vdc scoped policies).")
  private final BackupPolicyScopeType scope;

  /**
   * Array of Blackout Periods.
   * <p>
   * If specified, this field defines black periods when new group Runs are not
   * started. If a group Run has been scheduled but not yet executed and the
   * blackout period starts, the behavior depends on the policy field
   * AbortInBlackoutPeriod.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Array of Blackout Periods. If specified, this field "
      + "defines black periods when new group Runs are not started. If a "
      + "group Run has been scheduled but not yet executed and the blackout"
      + " period starts, the behavior depends on the policy field "
      + "AbortInBlackoutPeriod.")
  private final List<BlackoutPeriod> blackoutPeriods;

  /**
   * Specifies WORM retention type for the snapshots. When a WORM retention type
   * is specified, the snapshots of the Protection Groups using this policy will
   * be kept for the last N days as specified in the duration of the datalock.
   * During that time, the snapshots cannot be deleted.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies WORM retention type for the snapshots. When a WORM"
      + " retention type is specified, the snapshots of the Protection Groups"
      + " using this policy will be kept for the last N days as specified in the"
      + " duration of the datalock. During that time, the snapshots cannot be"
      + " deleted.")
  private final DatalockConfig datalockConfig;

  /**
   * Specifies WORM retention type for the snapshots. When a WORM retention type
   * is specified, the snapshots of the Protection Groups using this policy will
   * be kept for the last N days as specified in the duration of the datalock.
   * During that time, the snapshots cannot be deleted.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies WORM retention type for the snapshots. When a WORM"
      + " retention type is specified, the snapshots of the Protection Groups"
      + " using this policy will be kept for the last N days as specified in the"
      + " duration of the datalock. During that time, the snapshots cannot be"
      + " deleted.")
  private final DatalockConfig datalockConfigLog;

  /**
   * Specifies WORM retention type for the snapshots. When a WORM retention type
   * is specified, the snapshots of the Protection Groups using this policy will
   * be kept for the last N days as specified in the duration of the datalock.
   * During that time, the snapshots cannot be deleted.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies WORM retention type for the snapshots. When a WORM"
      + " retention type is specified, the snapshots of the Protection Groups"
      + " using this policy will be kept for the last N days as specified in the"
      + " duration of the datalock. During that time, the snapshots cannot be"
      + " deleted.")
  private final DatalockConfig datalockConfigSystem;

  /**
   * Specifies how many days to retain Snapshots on the Cohesity Cluster.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies how many days to retain Snapshots on the Cohesity "
      + "Cluster.")
  private final long daysToKeep;

  /**
   * Specifies the number of days to retain log run if Log Schedule exists.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies the number of days to retain log run if Log "
      + "Schedule exists.")
  private final Long daysToKeepLog;

  /**
   * Specifies the number of days to retain BMR run if System Schedule exists.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies the number of days to retain BMR run if System "
      + "Schedule exists.")
  private final Long daysToKeepSystem;

  /**
   * Description of the Backup Policy.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Description of the Backup Policy.")
  private final String description;

  /**
   * Specifies additional retention policies that should be applied to the
   * backup snapshots. A backup snapshot will be retained up to a time that is
   * the maximum of all retention policies that are applicable to it.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies additional retention policies that should be "
      + "applied to the backup snapshots. A backup snapshot will be retained "
      + "up to a time that is the maximum of all retention policies that are "
      + "applicable to it.")
  private final List<ExtendedRetentionPolicy> extendedRetentionPolicies;

  /**
   * Specifies the Full (no CBT) backup schedule of a Backup group and how
   * long Snapshots captured by this schedule are retained on the Cohesity
   * Cluster.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies the Full (no CBT) backup schedule of a Backup "
      + "group and how long Snapshots captured by this schedule are retained on"
      + " the Cohesity Cluster.")
  private final SchedulingPolicy fullSchedulingPolicy;

  /**
   * Specifies a unique Policy id.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies a unique Policy id.")
  private final String uid;

  /**
   * Specifies the CBT-based backup schedule of a Backup group and how long
   * Snapshots captured by this schedule are retained on the Cohesity Cluster.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the CBT-based backup schedule of a Backup "
      + "group and how long Snapshots captured by this schedule are "
      + "retained on the Cohesity Cluster.")
  private final SchedulingPolicy incrementalSchedulingPolicy;

  /**
   * Specifies the epoch time (in milliseconds) when the Backup Policy was
   * last modified.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies the epoch time (in milliseconds) when the "
      + "Backup Policy was last modified.")
  private final Instant lastModifiedTimeMsecs;

  /**
   * Specifies settings that define a backup schedule for a Backup group.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies settings that define a backup schedule for a "
      + "Backup group.")
  private final SchedulingPolicy logSchedulingPolicy;

  /**
   * Specifies settings that define a backup schedule for a Backup group.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies settings that define a backup schedule for a "
      + "Backup group.")
  private final SchedulingPolicy systemSchedulingPolicy;

  /**
   * Specifies the name of the Backup Policy.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the name of the Backup Policy.")
  private final String name;

  /**
   * Specifies the number of times to retry capturing Snapshots before the group
   * Run fails.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the number of times to retry capturing Snapshots "
      + "before the group Run fails.")
  private final int retries;

  /**
   * Specifies the number of minutes before retrying a failed Backup group.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the number of minutes before retrying a failed "
      + "Backup group.")
  private final int retryIntervalMins;

  /**
   * Specifies the period of time before skipping the execution of new group Runs
   * if an existing queued group Run of the same Backup group has not started.
   * For example if this field is set to 30 minutes and a group Run is scheduled
   * to start at 5:00 AM every day but does not start due to conflicts (such as
   * too many groups are running). If the new group Run does not start by 5:30AM,
   * the Cohesity Cluster will skip the new group Run. If the original group Run
   * completes before 5:30AM the next day, a new group Run is created and starts
   * executing. This field is optional.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies the period of time before skipping the "
      + "execution of new group Runs if an existing queued group Run of the "
      + "same Backup group has not started. For example if this field "
      + "is set to 30 minutes and a group Run is scheduled to start at 5:00 AM "
      + "every day but does not start due to conflicts (such as too many groups"
      + " are running). If the new group Run does not start by 5:30AM, the "
      + "Cohesity Cluster will skip the new group Run. If the original group Run "
      + "completes before 5:30AM the next day, a new group Run is created and "
      + "starts executing. This field is optional.")
  private final Integer skipIntervalMins;

  /**
   * Array of External Targets.
   * <p>
   * Specifies settings for copying Snapshots to  Archival External Targets
   * (such as AWS or Tape). It also defines the retention of copied Snapshots on
   * an External Targets such as AWS and Tape.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Array of External Targets. Specifies settings for "
      + "copying Snapshots to Archival External Targets (such as AWS or "
      + "Tape). It also defines the retention of copied Snapshots on an "
      + "External Targets such as AWS and Tape.")
  private final List<SnapshotArchivalCopyPolicy> snapshotArchivalCopyPolicies;

  /**
   * Array of Remote Clusters.
   * <p>
   * Specifies settings for copying Snapshots to Remote Clusters. It also
   * defines the retention of copied Snapshots on a Remote Cluster.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Array of Remote Clusters. Specifies settings for copying"
      + " Snapshots to Remote Clusters. It also defines the retention of "
      + "copied Snapshots on a Remote Cluster.")
  private final List<SnapshotReplicationCopyPolicy>
      snapshotReplicationCopyPolicies;

  /**
   * Specifies the iland datacenter location identifier.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the iland datacenter location identifier.")
  private final String locationId;

  /**
   * Specifies the UUID of the associated iland IaaS organization.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the UUID of the associated iland IaaS organization.")
  private final String orgUuid;

  /**
   * Specifies the UUID of the associated iland IaaS organization.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Specifies the ID of the associated iland company.")
  private final String companyId;

  /**
   * Specifies the associated iland IaaS vdc UUID. Only applicable
   * if the policy is vdc-scoped.
   */
  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Specifies the associated iland IaaS vdc UUID. Only applicable"
      + "if the policy is vdc-scoped.")
  private final String vdcUuid;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonOptional("Indicates what is the backup type during policy creation.")
  private final ProtectionType protectionType;

  /**
   * Instantiates a new Backup policy response.
   *
   * @param scope                           the scope
   * @param blackoutPeriods                 the blackout periods
   * @param datalockConfig                  Specifies WORM retention type for the snapshots
   * @param datalockConfigLog               Specifies WORM retention type for the snapshots
   * @param datalockConfigSystem            Specifies WORM retention type for the snapshots
   * @param daysToKeep                      the days to keep
   * @param daysToKeepLog                   the days to keep log
   * @param daysToKeepSystem                the days to keep system
   * @param description                     the description
   * @param extendedRetentionPolicies       the extended retention policies
   * @param fullSchedulingPolicy            the full scheduling policy
   * @param uid                             the uid
   * @param incrementalSchedulingPolicy     the incremental scheduling policy
   * @param lastModifiedTimeMsecs           the last modified time msecs
   * @param logSchedulingPolicy             the log scheduling policy
   * @param systemSchedulingPolicy          the system scheduling policy
   * @param name                            the name
   * @param retries                         the retries
   * @param retryIntervalMins               the retry interval mins
   * @param skipIntervalMins                the skip interval mins
   * @param snapshotArchivalCopyPolicies    the snapshot archival copy policies
   * @param snapshotReplicationCopyPolicies the snapshot replication copy policies
   * @param locationId                      the location id
   * @param orgUuid                         the org uuid
   * @param companyId                       the company id
   * @param vdcUuid                         the vdc uuid
   * @param protectionType                  the backup protection type
   */
  public BackupPolicyResponse(final BackupPolicyScopeType scope,
                              final List<BlackoutPeriod> blackoutPeriods,
                              final DatalockConfig datalockConfig,
                              final DatalockConfig datalockConfigLog,
                              final DatalockConfig datalockConfigSystem, final long daysToKeep,
                              final Long daysToKeepLog, final Long daysToKeepSystem,
                              final String description,
                              final List<ExtendedRetentionPolicy> extendedRetentionPolicies,
                              final SchedulingPolicy fullSchedulingPolicy, final String uid,
                              final SchedulingPolicy incrementalSchedulingPolicy,
                              final Instant lastModifiedTimeMsecs,
                              final SchedulingPolicy logSchedulingPolicy,
                              final SchedulingPolicy systemSchedulingPolicy, final String name,
                              final int retries, final int retryIntervalMins,
                              final Integer skipIntervalMins,
                              final List<SnapshotArchivalCopyPolicy> snapshotArchivalCopyPolicies,
                              final List<SnapshotReplicationCopyPolicy> snapshotReplicationCopyPolicies,
                              final String locationId, final String orgUuid, final String companyId,
                              final String vdcUuid, ProtectionType protectionType) {
    this.scope = scope;
    this.blackoutPeriods = blackoutPeriods;
    this.datalockConfig = datalockConfig;
    this.datalockConfigLog = datalockConfigLog;
    this.datalockConfigSystem = datalockConfigSystem;
    this.daysToKeep = daysToKeep;
    this.daysToKeepLog = daysToKeepLog;
    this.daysToKeepSystem = daysToKeepSystem;
    this.description = description;
    this.extendedRetentionPolicies = extendedRetentionPolicies;
    this.fullSchedulingPolicy = fullSchedulingPolicy;
    this.uid = uid;
    this.incrementalSchedulingPolicy = incrementalSchedulingPolicy;
    this.lastModifiedTimeMsecs = lastModifiedTimeMsecs;
    this.logSchedulingPolicy = logSchedulingPolicy;
    this.systemSchedulingPolicy = systemSchedulingPolicy;
    this.name = name;
    this.retries = retries;
    this.retryIntervalMins = retryIntervalMins;
    this.skipIntervalMins = skipIntervalMins;
    this.snapshotArchivalCopyPolicies = snapshotArchivalCopyPolicies;
    this.snapshotReplicationCopyPolicies = snapshotReplicationCopyPolicies;
    this.locationId = locationId;
    this.orgUuid = orgUuid;
    this.companyId = companyId;
    this.vdcUuid = vdcUuid;
    this.protectionType = protectionType;
  }

  /**
   * Gets scope.
   *
   * @return the scope
   */
  public BackupPolicyScopeType getScope() {
    return scope;
  }

  /**
   * Gets blackout periods.
   *
   * @return the blackout periods
   */
  public List<BlackoutPeriod> getBlackoutPeriods() {
    return blackoutPeriods;
  }

  /**
   * Gets datalock configuration.
   *
   * @return the datalock configuration
   */
  public DatalockConfig getDatalockConfig() {
    return datalockConfig;
  }

  /**
   * Gets datalock configuration.
   *
   * @return the datalock configuration
   */
  public DatalockConfig getDatalockConfigLog() {
    return datalockConfigLog;
  }

  /**
   * Gets datalock configuration.
   *
   * @return the datalock configuration
   */
  public DatalockConfig getDatalockConfigSystem() {
    return datalockConfigSystem;
  }

  /**
   * Gets days to keep.
   *
   * @return the days to keep
   */
  public long getDaysToKeep() {
    return daysToKeep;
  }

  /**
   * Gets days to keep log.
   *
   * @return the days to keep log
   */
  public Optional<Long> getDaysToKeepLog() {
    return Optional.ofNullable(daysToKeepLog);
  }

  /**
   * Gets days to keep system.
   *
   * @return the days to keep system
   */
  public Optional<Long> getDaysToKeepSystem() {
    return Optional.ofNullable(daysToKeepSystem);
  }

  /**
   * Gets description.
   *
   * @return the description
   */
  public Optional<String> getDescription() {
    return Optional.ofNullable(description);
  }

  /**
   * Gets extended retention policies.
   *
   * @return the extended retention policies
   */
  public List<ExtendedRetentionPolicy> getExtendedRetentionPolicies() {
    return extendedRetentionPolicies;
  }

  /**
   * Gets full scheduling policy.
   *
   * @return the full scheduling policy
   */
  public Optional<SchedulingPolicy> getFullSchedulingPolicy() {
    return Optional.ofNullable(fullSchedulingPolicy);
  }

  /**
   * Gets uid.
   *
   * @return the uid
   */
  public String getUid() {
    return uid;
  }

  /**
   * Gets incremental scheduling policy.
   *
   * @return the incremental scheduling policy
   */
  public SchedulingPolicy getIncrementalSchedulingPolicy() {
    return incrementalSchedulingPolicy;
  }

  /**
   * Gets last modified time msecs.
   *
   * @return the last modified time msecs
   */
  public Optional<Instant> getLastModifiedTimeMsecs() {
    return Optional.ofNullable(lastModifiedTimeMsecs);
  }

  /**
   * Gets log scheduling policy.
   *
   * @return the log scheduling policy
   */
  public Optional<SchedulingPolicy> getLogSchedulingPolicy() {
    return Optional.ofNullable(logSchedulingPolicy);
  }

  /**
   * Gets system scheduling policy.
   *
   * @return the system scheduling policy
   */
  public Optional<SchedulingPolicy> getSystemSchedulingPolicy() {
    return Optional.ofNullable(systemSchedulingPolicy);
  }

  /**
   * Gets name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Gets retries.
   *
   * @return the retries
   */
  public int getRetries() {
    return retries;
  }

  /**
   * Gets retry interval mins.
   *
   * @return the retry interval mins
   */
  public int getRetryIntervalMins() {
    return retryIntervalMins;
  }

  /**
   * Gets skip interval mins.
   *
   * @return the skip interval mins
   */
  public Optional<Integer> getSkipIntervalMins() {
    return Optional.ofNullable(skipIntervalMins);
  }

  /**
   * Gets snapshot archival copy policies.
   *
   * @return the snapshot archival copy policies
   */
  public List<SnapshotArchivalCopyPolicy> getSnapshotArchivalCopyPolicies() {
    return snapshotArchivalCopyPolicies;
  }

  /**
   * Gets snapshot replication copy policies.
   *
   * @return the snapshot replication copy policies
   */
  public List<SnapshotReplicationCopyPolicy> getSnapshotReplicationCopyPolicies() {
    return snapshotReplicationCopyPolicies;
  }

  /**
   * Gets location id.
   *
   * @return the location id
   */
  public String getLocationId() {
    return locationId;
  }

  /**
   * Gets org uuid.
   *
   * @return the org uuid
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets company id.
   *
   * @return the company id
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * Gets vdc uuid.
   *
   * @return the vdc uuid
   */
  public Optional<String> getVdcUuid() {
    return Optional.ofNullable(vdcUuid);
  }

  /**
   * Gets the protection type
   * @return the protection type
   */
  public ProtectionType getProtectionType() {
    return protectionType;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BackupPolicyResponse that = (BackupPolicyResponse) o;
    return daysToKeep == that.daysToKeep && retries == that.retries
        && retryIntervalMins == that.retryIntervalMins && scope == that.scope
        && Objects.equals(blackoutPeriods, that.blackoutPeriods)
        && Objects.equals(daysToKeepLog, that.daysToKeepLog) && Objects.equals(
        description, that.description) && Objects.equals(
        extendedRetentionPolicies, that.extendedRetentionPolicies)
        && Objects.equals(fullSchedulingPolicy, that.fullSchedulingPolicy)
        && Objects.equals(uid, that.uid) && Objects.equals(
        incrementalSchedulingPolicy, that.incrementalSchedulingPolicy)
        && Objects.equals(lastModifiedTimeMsecs, that.lastModifiedTimeMsecs)
        && Objects.equals(logSchedulingPolicy, that.logSchedulingPolicy)
        && Objects.equals(name, that.name) && Objects.equals(skipIntervalMins,
        that.skipIntervalMins) && Objects.equals(snapshotArchivalCopyPolicies,
        that.snapshotArchivalCopyPolicies) && Objects.equals(
        snapshotReplicationCopyPolicies, that.snapshotReplicationCopyPolicies)
        && Objects.equals(locationId, that.locationId) && Objects.equals(
        orgUuid, that.orgUuid) && Objects.equals(companyId, that.companyId)
        && Objects.equals(vdcUuid, that.vdcUuid) && Objects.equals(
        datalockConfig, that.datalockConfig) && Objects.equals(
        datalockConfigLog, that.datalockConfigLog) && Objects.equals(
        datalockConfigSystem, that.datalockConfigSystem);
  }

  @Override
  public int hashCode() {
    return Objects.hash(scope, blackoutPeriods, datalockConfig,
        datalockConfigLog, datalockConfigSystem, daysToKeep, daysToKeepLog,
        description, extendedRetentionPolicies, fullSchedulingPolicy, uid,
        incrementalSchedulingPolicy, lastModifiedTimeMsecs, logSchedulingPolicy,
        name, retries, retryIntervalMins, skipIntervalMins,
        snapshotArchivalCopyPolicies, snapshotReplicationCopyPolicies,
        locationId, orgUuid, companyId, vdcUuid);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("scope", scope)
        .add("blackoutPeriods", blackoutPeriods)
        .add("datalockConfig", datalockConfig)
        .add("datalockConfigLog", datalockConfigLog)
        .add("datalockConfigSystem", datalockConfigSystem)
        .add("daysToKeep", daysToKeep).add("daysToKeepLog", daysToKeepLog)
        .add("description", description)
        .add("extendedRetentionPolicies", extendedRetentionPolicies)
        .add("fullSchedulingPolicy", fullSchedulingPolicy).add("uid", uid)
        .add("incrementalSchedulingPolicy", incrementalSchedulingPolicy)
        .add("lastModifiedTimeMsecs", lastModifiedTimeMsecs)
        .add("logSchedulingPolicy", logSchedulingPolicy).add("name", name)
        .add("retries", retries).add("retryIntervalMins", retryIntervalMins)
        .add("skipIntervalMins", skipIntervalMins)
        .add("snapshotArchivalCopyPolicies", snapshotArchivalCopyPolicies)
        .add("snapshotReplicationCopyPolicies", snapshotReplicationCopyPolicies)
        .add("locationId", locationId).add("orgUuid", orgUuid)
        .add("companyId", companyId).add("vdcUuid", vdcUuid).toString();
  }

}
