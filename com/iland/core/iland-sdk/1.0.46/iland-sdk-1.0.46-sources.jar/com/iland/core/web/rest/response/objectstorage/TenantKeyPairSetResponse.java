/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */
package com.iland.core.web.rest.response.objectstorage;

import java.util.Set;

import com.iland.core.web.rest.response.common.SetResponse;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Tenant Key Pair Set Response.
 *
 * @author <a href=“mailto:nkasprzak@iland.com”>Nick Kasprzak</a>
 */
@APIDoc
public final class TenantKeyPairSetResponse
    extends SetResponse<TenantKeyPairResponse> {

  private static final long serialVersionUID = -545571515967336469L;

  public TenantKeyPairSetResponse(final Set<TenantKeyPairResponse> data) {
    super(data);
  }

}
