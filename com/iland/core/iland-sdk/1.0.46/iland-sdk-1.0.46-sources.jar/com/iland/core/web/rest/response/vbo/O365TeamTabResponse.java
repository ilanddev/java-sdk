/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * O365 Team tab response.
 *
 * @author <a href="mailto:smittal@iland.com">Sachin Mittal</a>
 */
@APIModel
public interface O365TeamTabResponse extends O365TeamItemResponse{
  /**
   * Get the Team Tab display name.
   */
  Optional<String> displayName();

  /**
   * Get the Team Tab display name.
   */
  String contentUrl();

  /**
   * The Type of the Microsoft Teams Tab (Tab, Website).
   */
  String type();

}
