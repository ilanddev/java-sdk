/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.Objects;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * OrgBackupSummaryStatsResponse.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIDoc
public final class OrgBackupSummaryStatsResponse {

  @Expose
  @JsonRequired("The org UUID.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String orgUuid;

  @Expose
  @JsonRequired("The stats for the Org.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupSummaryStats stats;

  @Expose
  @JsonRequired("The stats for vDCs within the Org.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<VdcBackupSummaryStatsResponse> vdcStats;

  public OrgBackupSummaryStatsResponse(final String orgUuid,
      final BackupSummaryStats stats,
      final Set<VdcBackupSummaryStatsResponse> vdcStats) {
    this.orgUuid = orgUuid;
    this.stats = stats;
    this.vdcStats = vdcStats;
  }

  /**
   * Gets the org UUID.
   */
  public String getOrgUuid() {
    return orgUuid;
  }

  /**
   * Gets the org backup summary stats.
   */
  public BackupSummaryStats getStats() {
    return stats;
  }

  /**
   * Gets summary stats info for child vDCs.
   */
  public Set<VdcBackupSummaryStatsResponse> getVdcStats() {
    return vdcStats;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final OrgBackupSummaryStatsResponse that =
        (OrgBackupSummaryStatsResponse) o;
    return Objects.equals(orgUuid, that.orgUuid) && Objects
        .equals(stats, that.stats) && Objects.equals(vdcStats, that.vdcStats);
  }

  @Override
  public int hashCode() {
    return Objects.hash(orgUuid, stats, vdcStats);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("orgUuid", orgUuid)
        .add("stats", stats).add("vdcStats", vdcStats).toString();
  }
}
