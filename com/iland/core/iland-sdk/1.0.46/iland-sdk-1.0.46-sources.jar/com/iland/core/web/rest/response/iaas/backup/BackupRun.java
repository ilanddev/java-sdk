/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import com.google.common.base.MoreObjects;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.cohesity.iaas.backups.backupgroups.enums.StatusBackupRun;
import com.iland.cohesity.iaas.backups.common.enums.RunType;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonOptional;
import com.iland.core.web.rest.serialization.JsonRequired;

/**
 * BackupRun.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public final class BackupRun {

  @Expose
  @JsonOptional(
      "Specifies if an error occurred (if any) while running this task. This field "
          + "is populated when the status is equal to 'FAILURE'.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String errorMessage;

  @Expose
  @JsonOptional(
      "Specifies a message after finishing the task successfully. This field is "
          + "optionally populated when the status is equal to SUCCESS'.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String successMessage;

  @Expose
  @JsonRequired(
      "Specifies if the metadata and snapshots associated with this backup group "
          + "run have been deleted. This field is set to true when the snapshots, which "
          + "are marked for deletion, are removed by garbage collection. The associated "
          + "metadata is also deleted.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean metadataDeleted;

  @Expose
  @JsonRequired(
      "Specifies if app-consistent snapshot was captured. This field is set to "
          + "true, if an app-consistent snapshot was taken by quiescing applications and "
          + "the file system before taking a backup.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean quiesced;

  @Expose
  @JsonRequired("Specifies the type of backup.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final RunType runType;

  @Expose
  @JsonOptional(
      "Specifies if the SLA was violated for the backup group run. This field is "
          + "set to true, if time to complete the backup group run is longer than the "
          + "SLA specified. This field is populated when the status is set to 'SUCCESS' "
          + "or 'FAILURE'.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Boolean slaViolated;

  @Expose
  @JsonRequired(
      "Specifies if backup snapshots associated with this backup group run have "
          + "been marked for deletion because of the retention settings in the policy or "
          + "if they were manually deleted.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final boolean snapshotsDeleted;

  @Expose
  @JsonOptional("Specifies the time that snapshots were deleted.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Instant snapshotsDeletedTime;

  @Expose
  @JsonRequired("Array of Source Object Backup Status. "
      + "Specifies the status of backing up each source objects (such as VMs) "
      + "associated with the backup group run.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final Set<SourceBackupStatus> sourceBackupStatus;

  @Expose
  @JsonRequired(
      "Specifies statistics about a backup group run. This contains the backup "
          + "group run level statistics.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final BackupRunStats stats;

  @Expose
  @JsonRequired("Specifies the status of Backup task.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final StatusBackupRun status;

  @Expose
  @JsonRequired("Array of Warnings. "
      + "Specifies the warnings that occurred (if any) while running this task.")
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final List<String> warnings;

  public BackupRun(final String errorMessage, final String successMessage,
      final boolean metadataDeleted, final boolean quiesced,
      final RunType runType, final Boolean slaViolated,
      final boolean snapshotsDeleted, final Instant snapshotsDeletedTime,
      final Set<SourceBackupStatus> sourceBackupStatus,
      final BackupRunStats stats, final StatusBackupRun status,
      final List<String> warnings) {
    this.errorMessage = errorMessage;
    this.successMessage = successMessage;
    this.metadataDeleted = metadataDeleted;
    this.quiesced = quiesced;
    this.runType = runType;
    this.slaViolated = slaViolated;
    this.snapshotsDeleted = snapshotsDeleted;
    this.snapshotsDeletedTime = snapshotsDeletedTime;
    this.sourceBackupStatus = sourceBackupStatus;
    this.stats = stats;
    this.status = status;
    this.warnings = warnings;
  }

  /**
   * Specifies if an error occurred (if any) while running this task. This field
   * is populated when the status is equal to 'FAILURE'.
   */
  public Optional<String> getErrorMessage() {
    return Optional.ofNullable(errorMessage);
  }

  /**
   * Specifies a message after finishing the task successfully. This field is
   * optionally populated when the status is equal to SUCCESS'.
   */
  public Optional<String> getSuccessMessage() {
    return Optional.ofNullable(successMessage);
  }

  /**
   * Specifies if the metadata and snapshots associated with this backup group
   * run have been deleted. This field is set to true when the snapshots, which
   * are marked for deletion, are removed by garbage collection. The associated
   * metadata is also deleted.
   */
  public boolean isMetadataDeleted() {
    return metadataDeleted;
  }

  /**
   * Specifies if app-consistent snapshot was captured. This field is set to
   * true, if an app-consistent snapshot was taken by quiescing applications and
   * the file system before taking a backup.
   */
  public boolean isQuiesced() {
    return quiesced;
  }

  /**
   * Specifies the type of backup.
   */
  public RunType getRunType() {
    return runType;
  }

  /**
   * Specifies if the SLA was violated for the backup group run. This field is
   * set to true, if time to complete the backup group run is longer than the
   * SLA specified. This field is populated when the status is set to 'SUCCESS'
   * or 'FAILURE'.
   */
  public Optional<Boolean> getSlaViolated() {
    return Optional.ofNullable(slaViolated);
  }

  /**
   * Specifies if backup snapshots associated with this backup group run have
   * been marked for deletion because of the retention settings in the policy or
   * if they were manually deleted.
   */
  public boolean isSnapshotsDeleted() {
    return snapshotsDeleted;
  }

  /**
   * Specifies the time that snapshots were deleted.
   */
  public Optional<Instant> getSnapshotsDeletedTime() {
    return Optional.ofNullable(snapshotsDeletedTime);
  }

  /**
   * Array of Source Object Backup Status.
   * <p>
   * Specifies the status of backing up each source objects (such as VMs)
   * associated with the backup group run.
   */
  public Set<SourceBackupStatus> getSourceBackupStatus() {
    return sourceBackupStatus;
  }

  /**
   * Specifies statistics about a backup group run. This contains the backup
   * group run level statistics.
   */
  public BackupRunStats getStats() {
    return stats;
  }

  /**
   * Specifies the status of Backup task.
   */
  public StatusBackupRun getStatus() {
    return status;
  }

  /**
   * Array of Warnings.
   * <p>
   * Specifies the warnings that occurred (if any) while running this task.
   */
  public List<String> getWarnings() {
    return warnings;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    final BackupRun backupRun = (BackupRun) o;
    return metadataDeleted == backupRun.metadataDeleted
        && quiesced == backupRun.quiesced
        && snapshotsDeleted == backupRun.snapshotsDeleted && Objects
        .equals(errorMessage, backupRun.errorMessage) && Objects
        .equals(successMessage, backupRun.successMessage)
        && runType == backupRun.runType && Objects
        .equals(slaViolated, backupRun.slaViolated) && Objects
        .equals(snapshotsDeletedTime, backupRun.snapshotsDeletedTime) && Objects
        .equals(sourceBackupStatus, backupRun.sourceBackupStatus) && Objects
        .equals(stats, backupRun.stats) && status == backupRun.status && Objects
        .equals(warnings, backupRun.warnings);
  }

  @Override
  public int hashCode() {
    return Objects
        .hash(errorMessage, successMessage, metadataDeleted, quiesced, runType,
            slaViolated, snapshotsDeleted, snapshotsDeletedTime,
            sourceBackupStatus, stats, status, warnings);
  }

  @Override
  public String toString() {
    return MoreObjects.toStringHelper(this).add("errorMessage", errorMessage)
        .add("successMessage", successMessage)
        .add("metadataDeleted", metadataDeleted).add("quiesced", quiesced)
        .add("runType", runType).add("slaViolated", slaViolated)
        .add("snapshotsDeleted", snapshotsDeleted)
        .add("snapshotsDeletedTime", snapshotsDeletedTime)
        .add("sourceBackupStatus", sourceBackupStatus).add("stats", stats)
        .add("status", status).add("warnings", warnings).toString();
  }
}
