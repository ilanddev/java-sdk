/*
 * Copyright (c) 2013 - 2026, 11:11 Systems Inc.
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  11:11 Systems
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  https://1111systems.com/
 */

package com.iland.core.web.rest.api;

import java.io.InputStream;
import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.iland.cohesity.iaas.backups.backupgroups.BackupGroupV2PlatformVdcApi;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.BackupGroupV2;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.BlockBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.FileBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.MssqlFileBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.MssqlNativeBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.MssqlVolumeBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.backupgroups.api.modelx.OracleBasedBackupGroupWithCommonParams;
import com.iland.cohesity.iaas.backups.common.enums.RunType;
import com.iland.cohesity.iaas.backups.common.model.BackupRunUid;
import com.iland.cohesity.iaas.backups.common.model.ListResponse;
import com.iland.cohesity.iaas.backups.common.model.SourceUid;
import com.iland.cohesity.iaas.backups.common.model.VdcUuid;
import com.iland.core.api.iam.Permission;
import com.iland.core.web.rest.annotations.SecureEntityRef;
import com.iland.core.web.rest.annotations.SkipSecurityTest;
import com.iland.core.web.rest.request.common.UpdateMetadataRequest;
import com.iland.core.web.rest.request.iaas.backup.BackupGroupUpdateRequest;
import com.iland.core.web.rest.request.iaas.backup.BackupPolicyUpdateRequest;
import com.iland.core.web.rest.request.iaas.backup.GetBackupGroupSummaryStatsFilters;
import com.iland.core.web.rest.request.iaas.backup.GetBackupStorageSamplesFilters;
import com.iland.core.web.rest.request.iaas.backup.ListBackupGroupRunsQueryParams;
import com.iland.core.web.rest.request.iaas.backup.ListBackupRestoreTasksFilters;
import com.iland.core.web.rest.request.iaas.backup.RestoreVMBackupsInVdcParams;
import com.iland.core.web.rest.request.iaas.backup.SearchVdcRecoverableFilesAndFoldersFilters;
import com.iland.core.web.rest.request.iaas.backup.SearchVdcRecoverableVMsFilters;
import com.iland.core.web.rest.request.network.OrgVdcNetworkCreateRequest;
import com.iland.core.web.rest.request.nsx.DistributedFirewallLayer2RuleCreateRequest;
import com.iland.core.web.rest.request.nsx.DistributedFirewallLayer2RuleUpdateRequest;
import com.iland.core.web.rest.request.nsx.DistributedFirewallLayer2UpdateRequest;
import com.iland.core.web.rest.request.nsx.DistributedFirewallLayer3RuleCreateRequest;
import com.iland.core.web.rest.request.nsx.DistributedFirewallLayer3RuleUpdateRequest;
import com.iland.core.web.rest.request.nsx.DistributedFirewallLayer3UpdateRequest;
import com.iland.core.web.rest.request.nsx.DistributedFirewallRestorePointCreateRequest;
import com.iland.core.web.rest.request.nsx.IpSetCreateRequest;
import com.iland.core.web.rest.request.nsx.IpSetUpdateRequest;
import com.iland.core.web.rest.request.nsx.MacSetCreateRequest;
import com.iland.core.web.rest.request.nsx.MacSetUpdateRequest;
import com.iland.core.web.rest.request.nsx.RestoreDistributedFirewallRequest;
import com.iland.core.web.rest.request.nsx.SecurityGroupCreateRequest;
import com.iland.core.web.rest.request.nsx.SecurityGroupUpdateRequest;
import com.iland.core.web.rest.request.nsx.SecurityTagCreateRequest;
import com.iland.core.web.rest.request.nsx.SecurityTagUpdateRequest;
import com.iland.core.web.rest.request.reporting.ReportFormat;
import com.iland.core.web.rest.request.vapp.BuildVappRequest;
import com.iland.core.web.rest.request.vdc.VdcAddVappFromTemplateRequest;
import com.iland.core.web.rest.request.vm.VmAffinityRuleCreateRequest;
import com.iland.core.web.rest.request.vm.VmAffinityRuleUpdateRequest;
import com.iland.core.web.rest.response.billing.BillListResponse;
import com.iland.core.web.rest.response.billing.BillResponse;
import com.iland.core.web.rest.response.billing.BillingSampleSerieResponse;
import com.iland.core.web.rest.response.common.ObjectPagingParams;
import com.iland.core.web.rest.response.edge.EdgeListResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupListResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupGroupRunListResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupPolicyListResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupPolicyResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupRestoreTaskDetailResponse;
import com.iland.core.web.rest.response.iaas.backup.BackupRestoreTaskListResponse;
import com.iland.core.web.rest.response.iaas.backup.IaasBackupBillListResponse;
import com.iland.core.web.rest.response.iaas.backup.IaasBackupSubscriptionListResponse;
import com.iland.core.web.rest.response.iaas.backup.IaasBackupSummaryListResponse;
import com.iland.core.web.rest.response.iaas.backup.RecoverableFilesSearchResultListResponse;
import com.iland.core.web.rest.response.iaas.backup.VMBackupSnapshotListResponse;
import com.iland.core.web.rest.response.iaas.backup.VdcBackupClusterInfo;
import com.iland.core.web.rest.response.iaas.backup.VdcBackupStatusResponse;
import com.iland.core.web.rest.response.iaas.backup.VdcBackupStorageMetricListResponse;
import com.iland.core.web.rest.response.iaas.backup.VdcBackupStorageSampleSeriesResponse;
import com.iland.core.web.rest.response.iaas.backup.VdcBackupSummaryStatsResponse;
import com.iland.core.web.rest.response.iaas.intbackup.VdcIntegratedBackupStatusDetailResponse;
import com.iland.core.web.rest.response.media.MediaListResponse;
import com.iland.core.web.rest.response.metadata.MetadataListResponse;
import com.iland.core.web.rest.response.nsx.ApplicationGroupListResponse;
import com.iland.core.web.rest.response.nsx.ApplicationGroupResponse;
import com.iland.core.web.rest.response.nsx.ApplicationListResponse;
import com.iland.core.web.rest.response.nsx.ApplicationResponse;
import com.iland.core.web.rest.response.nsx.DistributedFirewallAppliedToObjectListResponse;
import com.iland.core.web.rest.response.nsx.DistributedFirewallAppliedToTypeListResponse;
import com.iland.core.web.rest.response.nsx.DistributedFirewallDestinationObjectListResponse;
import com.iland.core.web.rest.response.nsx.DistributedFirewallDestinationTypeListResponse;
import com.iland.core.web.rest.response.nsx.DistributedFirewallLayer2Response;
import com.iland.core.web.rest.response.nsx.DistributedFirewallLayer2RestorePointDetailsResponse;
import com.iland.core.web.rest.response.nsx.DistributedFirewallLayer2RuleResponse;
import com.iland.core.web.rest.response.nsx.DistributedFirewallLayer3Response;
import com.iland.core.web.rest.response.nsx.DistributedFirewallLayer3RestorePointDetailsResponse;
import com.iland.core.web.rest.response.nsx.DistributedFirewallLayer3RuleResponse;
import com.iland.core.web.rest.response.nsx.DistributedFirewallRestorePointListResponse;
import com.iland.core.web.rest.response.nsx.DistributedFirewallSourceObjectListResponse;
import com.iland.core.web.rest.response.nsx.DistributedFirewallSourceTypeListResponse;
import com.iland.core.web.rest.response.nsx.IpSetListResponse;
import com.iland.core.web.rest.response.nsx.IpSetResponse;
import com.iland.core.web.rest.response.nsx.MacSetListResponse;
import com.iland.core.web.rest.response.nsx.MacSetResponse;
import com.iland.core.web.rest.response.nsx.SecurityGroupMemberListResponse;
import com.iland.core.web.rest.response.nsx.SecurityGroupMemberTypeListResponse;
import com.iland.core.web.rest.response.nsx.SecurityGroupResponse;
import com.iland.core.web.rest.response.nsx.SecurityGroupsResponse;
import com.iland.core.web.rest.response.nsx.SecurityTagObjectListResponse;
import com.iland.core.web.rest.response.nsx.SecurityTagObjectTypeListResponse;
import com.iland.core.web.rest.response.nsx.SecurityTagWithAssignedVMsResponse;
import com.iland.core.web.rest.response.nsx.SecurityTagsResponse;
import com.iland.core.web.rest.response.org.OrgVdcNetworkListResponse;
import com.iland.core.web.rest.response.performance.PerfSampleSerieResponse;
import com.iland.core.web.rest.response.performance.PerformanceCounterListResponse;
import com.iland.core.web.rest.response.reporting.ReportHeaderListResponse;
import com.iland.core.web.rest.response.task.TaskResponse;
import com.iland.core.web.rest.response.vapp.VappListResponse;
import com.iland.core.web.rest.response.vapp.VappResourceSummaryMapResponse;
import com.iland.core.web.rest.response.vdc.StorageProfileListResponse;
import com.iland.core.web.rest.response.vdc.VdcResourceSummaryResponse;
import com.iland.core.web.rest.response.vdc.VdcResponse;
import com.iland.core.web.rest.response.vdc.VdcStorageProfileSummaryResponse;
import com.iland.core.web.rest.response.vdc.VmAffinityRuleListResponse;
import com.iland.core.web.rest.response.vm.VmListResponse;
import com.iland.core.web.rest.response.vm.VmResourceSummaryMapResponse;
import com.iland.core.web.rest.serialization.IlandVersionedMediaType;
import com.iland.core.web.rest.shared.iaas.backup.VdcBackupStorageMetric;
import com.iland.core.web.rest.swagger.annotation.processor.APIProperties;

/**
 * Vdc Resource Interface v1.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIProperties(name = "vDCs")
@Path("/vdcs")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(IlandVersionedMediaType.V1_APPLICATION_JSON)
@PlatformApi
public interface VdcResource extends BackupGroupV2PlatformVdcApi {

  /**
   * Get a VDC by its UUID.
   *
   * @param vdcUuid   vdc uuid
   * @param timestamp optional timestamp parameter to get the vDC details at a
   *                  certain point in time.
   * @return virtual data center
   */
  @GET
  @Path("/{vdcUuid}")
  VdcResponse getVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @QueryParam("timestamp") Long timestamp);

  /**
   * Get a list of vApps for a VDC.
   *
   * @param vdcUuid vdc uuid
   * @return list of vApps for the VDC
   */
  @GET
  @Path("/{vdcUuid}/vapps")
  VappListResponse getVappsForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get a list of VMs for a VDC.
   *
   * @param vdcUuid vdc uuid
   * @return list of VMs for the VDC
   */
  @SkipSecurityTest("Need a custom test provider.")
  @GET
  @Path("/{vdcUuid}/vms")
  VmListResponse getVmsForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Returns vDC billing for a given invoice period.
   * <p>
   * If month and year are not explicitly supplied the current invoice period is
   * used.
   *
   * @param vdcUuid vdc uuid
   * @param year    the invoice period year (defaults to current year)
   * @param month   the invoice period month (defaults to the current month) must
   *                be in range 1-12
   * @return billing for the vDC and given invoice period
   */
  @GET
  @Path("/{vdcUuid}/billing")
  BillResponse getBillingForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC_BILLING)
      @PathParam("vdcUuid") String vdcUuid, @QueryParam("year") Integer year,
      @QueryParam("month") Integer month);

  /**
   * Gets all vapp bills for a specified vDC. Returns the current month bills by
   * default, but query parameters can be used to select an earlier set of
   * bills.
   *
   * @param vdcUuid vdc uuid
   * @return vapp bills for the specified vDC
   */
  @GET
  @Path("/{vdcUuid}/vapp-bills")
  BillListResponse getVappBills(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC_BILLING)
      @PathParam("vdcUuid") String vdcUuid, @QueryParam("month") Integer month,
      @QueryParam("year") Integer year);

  /**
   * Gets all vm bills for a specified vDC. Returns the current month bills by
   * default, but query parameters can be used to select an earlier set of
   * bills.
   *
   * @param vdcUuid vdc uuid
   * @return vm bills for the specified vDC
   */
  @GET
  @Path("/{vdcUuid}/vm-bills")
  BillListResponse getVmBills(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC_BILLING)
      @PathParam("vdcUuid") String vdcUuid, @QueryParam("month") Integer month,
      @QueryParam("year") Integer year);

  /**
   * Retrieve metadata associated with a Vdc.
   *
   * @param vdcUuid vdc uuid
   * @return list of metadata for the given vdc
   */
  @GET
  @Path("/{vdcUuid}/metadata")
  MetadataListResponse getMetadataForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Add / update metadata associated with a Vdc.
   *
   * @param vdcUuid  vdc uuid
   * @param metadata of instances
   * @return asynchronous task details
   */
  @PUT
  @Path("/{vdcUuid}/metadata")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateMetadataForVdc(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      List<UpdateMetadataRequest> metadata);

  /**
   * Delete a specific piece of metadata associated with a Vdc by its key.
   *
   * @param vdcUuid vdc uuid
   * @param key     metadata key
   * @return asynchronous task details
   */
  @DELETE
  @Path("/{vdcUuid}/metadata/{key}")
  TaskResponse deleteMetadataForVdc(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid, @PathParam("key") String key);

  /**
   * Get medias available to a given Vdc.
   *
   * @param vdcUuid vdc uuid
   * @return list of medias for the vdc
   */
  @GET
  @Path("/{vdcUuid}/medias")
  MediaListResponse getMediasForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the storage profiles available to the vDC.
   *
   * @param vdcUuid         vdc uuid
   * @param includeDisabled whether to include disabled profiles (defaults to
   *                        false if not explicitly provided)
   * @return list of storage profiles available to the VDC
   */
  @GET
  @Path("/{vdcUuid}/storage-profiles")
  StorageProfileListResponse getStorageProfiles(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid,
      @QueryParam("includeDisabled") Boolean includeDisabled);

  /**
   * Add a vApp from a vApp template.
   *
   * Invocation of this endpoint implies that the user has reviewed and accepted
   * any and all EULAs associated with referenced templates.
   *
   * @param vdcUuid vdc uuid
   * @param request specification for new vApp paramters
   * @return asynchronous task details
   */
  @SkipSecurityTest("Need a custom test provider to submit appropriate vApp template UUIDs in the VdcAddVappFromTemplateRequest.")
  @POST
  @Path("/{vdcUuid}/actions/add-vapp-from-template")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse addVappFromTemplate(
      @SecureEntityRef(Permission.CREATE_ILAND_CLOUD_VDC_VAPPS)
      @PathParam("vdcUuid") String vdcUuid,
      VdcAddVappFromTemplateRequest request);

  /**
   * Create a vApp from scratch to the given VDC.
   *
   * Invocation of this endpoint implies that the user has reviewed and accepted
   * any and all EULAs associated with referenced templates.
   *
   * @param vdcUuid vdc uuid
   * @param spec    specification for the new vApp
   * @return asynchronous task details
   */
  @SkipSecurityTest("Need a custom test provider to submit appropriate vApp template UUIDs in the VappSpec.")
  @POST
  @Path("/{vdcUuid}/actions/build-vapp")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse buildVapp(
      @SecureEntityRef(Permission.CREATE_ILAND_CLOUD_VDC_VAPPS)
      @PathParam("vdcUuid") String vdcUuid, BuildVappRequest spec);

  /**
   * Get org vdc networks for a given VDC.
   *
   * @param vdcUuid vdc uuid
   * @return list of networks
   */
  @GET
  @Path("/{vdcUuid}/org-vdc-networks")
  OrgVdcNetworkListResponse getOrgVdcNetworksForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get VDC performance data for the given VDC, counter, and time range.
   *
   * @param vdcUuid  vDC UUID
   * @param group    the performance counter group
   * @param name     the performance counter name
   * @param type     the performance counter type
   * @param start    start date
   * @param end      end date
   * @param interval interval
   * @param limit    limit
   * @return performance samples serie for the given vdc, counter and date range
   */
  @GET
  @Path("/{vdcUuid}/performance/{group}::{name}::{type}")
  PerfSampleSerieResponse getPerformanceForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("group") String group,
      @PathParam("name") String name, @PathParam("type") String type,
      @QueryParam("start") Long start, @QueryParam("end") Long end,
      @QueryParam("interval") String interval,
      @QueryParam("limit") String limit);

  /**
   * Gets the Zerto Vpg performance samples at Vdc level for used & replicated storage
   * Currently hourly, daily abd monthly ranges are supported.
   *
   * @param vdcUuid The platform VDC UUID
   * @param name    the counter name e.g. RecoveryJournalUsedStorageInMB or UsedStorageInMB
   * @param start   the start datetime
   * @param end     the end datetime
   * @return zerto performance samples serie for the given vdc, counter and date range
   */
  @GET
  @Path("/{vdcUuid}/zerto-performance/vdc:{name}::latest")
  PerfSampleSerieResponse getZertoPerformanceForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
      String vdcUuid, @PathParam("name") String name,
      @QueryParam("start") Long start, @QueryParam("end") Long end);

  /**
   * Get the list of performance counters that can be used to query for vDC
   * performance data.
   *
   * @param vdcUuid vDC UUID
   * @return the list of performance counters
   */
  @GET
  @Path("/{vdcUuid}/performance-counters")
  PerformanceCounterListResponse getPerformanceCountersForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the resource summary for the given VDC.
   *
   * @param vdcUuid vdc uuid
   * @return vdc resource summary
   */
  @GET
  @Path("/{vdcUuid}/summary")
  VdcResourceSummaryResponse getSummaryForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the map of resource summaries for all vApps in the given vDC.
   *
   * @param vdcUuid vdc uuid
   * @return map of vApp uuid to vApp resource summary
   */
  @GET
  @Path("{vdcUuid}/vapp-summary-map")
  VappResourceSummaryMapResponse getVappResourceSummaries(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the map of resource summaries for all VMs in the given vDC.
   *
   * @param vdcUuid vdc uuid
   * @return map of VM uuid to vm resource summary
   */
  @GET
  @Path("{vdcUuid}/vm-summary-map")
  VmResourceSummaryMapResponse getVmResourceSummaries(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Create a new org-vdc network for this vDC.
   *
   * @param vdcUuid       vdc uuid
   * @param createRequest the new org vdc network
   * @return new network
   */
  @POST
  @Path("/{vdcUuid}/actions/create-org-vdc-network")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse createOrgVdcNetwork(
      @SecureEntityRef(Permission.CREATE_ILAND_CLOUD_VDC_INTERNAL_NETWORKS)
      @PathParam("vdcUuid") String vdcUuid,
      OrgVdcNetworkCreateRequest createRequest);

  /**
   * Get the edges for the vDC.
   *
   * @param vdcUuid vdc uuid
   * @return a list of vcd edges
   */
  @SkipSecurityTest("Custom logic in EJB")
  @GET
  @Path("/{vdcUuid}/edges")
  EdgeListResponse getEdgesForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Gets a summary of storage profile usage for a specified vDC and billing
   * period.
   *
   * @param vdcUuid the UUID of the vDC
   * @param year    the year
   * @param month   the month in range 1-12
   * @return a summary of storage profile usage
   */
  @GET
  @Path("/{vdcUuid}/storage-profile-summary")
  VdcStorageProfileSummaryResponse getStorageProfileSummary(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @QueryParam("year") Integer year,
      @QueryParam("month") Integer month);

  /**
   * Get a serie detailing the hourly cost over an invoice period for a given
   * vDC.
   *
   * @param vdcUuid          the UUID of the vDC
   * @param year             the year
   * @param month            the month in range 1-12
   * @param additionalFields any additional fields that should be included in
   *                         the series
   * @return a serie of samples detailing hourly vDC total cost by hour for the
   * invoice period
   */
  @GET
  @Path("/{vdcUuid}/cost-over-invoice-period")
  BillingSampleSerieResponse getCostOverInvoicePeriodSerie(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC_BILLING)
      @PathParam("vdcUuid") String vdcUuid, @QueryParam("year") Integer year,
      @QueryParam("month") Integer month,
      @QueryParam("additionalFields") List<String> additionalFields);

  /**
   * Generate a VM inventory report for the specified vDC.
   * <p>
   * Only available report type of 'csv'
   *
   * @param vdcUuid           vdc uuid
   * @param emailOnCompletion whether to email the report upon successful
   *                          generation, superseded by BillingReportSpec's email property
   * @param email             email address to send the report to if emailOnCompletion is
   *                          true, defaults to the user's profile email if not specified
   * @return asynchronous task details
   */
  @POST
  @Path("/{vdcUuid}/actions/generate-vm-inventory-report")
  TaskResponse generateVmInventoryReportForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid,
      @QueryParam("emailOnCompletion") boolean emailOnCompletion,
      @QueryParam("email") String email);

  /**
   * Get the VM inventory reports for vDC.
   * <p>
   * The endpoint also supports filtering by report format, using the query
   * param "format".
   *
   * @param vdcUuid virtual data center uuid
   * @return list of reports available for download
   */
  @GET
  @Path("/{vdcUuid}/vm-inventory-reports")
  ReportHeaderListResponse getVmInventoryReportsForVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @QueryParam("format") ReportFormat reportFormat);

  /**
   * Create a vm affinity rule.
   *
   * @param request vm affinity rule create request
   * @return core task
   */
  @POST
  @Path("/{vdcUuid}/actions/create-vm-affinity-rule")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse createVmAffinityRule(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      VmAffinityRuleCreateRequest request);

  /**
   * Update the given vm affinity rule.
   *
   * @param vdcUuid                     virtual data center uuid
   * @param vmAffinityRuleUpdateRequest vm affinity rule update request
   * @return a task response
   */
  @PUT
  @Path("/{vdcUuid}/actions/update-vm-affinity-rule")
  @Consumes(MediaType.APPLICATION_JSON)
  TaskResponse updateVmAffinityRule(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      VmAffinityRuleUpdateRequest vmAffinityRuleUpdateRequest);

  /**
   * Deletes a given vm affinity rule.
   *
   * @param vdcUuid  virtual data center uuid
   * @param ruleUuid vm affinity rule uuid
   * @return a task response
   */
  @DELETE
  @Path("/{vdcUuid}/actions/delete-vm-affinity-rule/{ruleUuid}")
  TaskResponse deleteVmAffinityRule(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("ruleUuid") String ruleUuid);

  /**
   * Get all the vm affinity rules for a given vDC.
   *
   * @param vdcUuid vdc uuid
   * @return a vm affinity rule list response
   */
  @GET
  @Path("/{vdcUuid}/vm-affinity-rules")
  VmAffinityRuleListResponse getVmAffinityRules(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Enable the distributed firewall on an Org vDC.
   *
   * @param vdcUuid vDC uuid
   */
  @POST
  @Path("/{vdcUuid}/actions/enable-distributed-firewall")
  void enableDistributedFirewall(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid);

  /**
   * Get the distributed firewall at layer 3 (general) for a given vDC.
   *
   * @param vdcUuid vDC uuid
   * @return distributed firewall layer 3 response
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer3")
  DistributedFirewallLayer3Response getDistributedFirewallLayer3(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the distributed firewall at layer 2 (ethernet) for a given vDC.
   *
   * @param vdcUuid vDC uuid
   * @return distributed firewall layer 2 response
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer2")
  DistributedFirewallLayer2Response getDistributedFirewallLayer2(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Update the distributed firewall at layer 3 (general) for a given vDC.
   *
   * @param vdcUuid       vDC uuid
   * @param eTag          the eTag value. specifying an eTag value allows a client to ensure that the distributed firewall has not been updated since it last read the configuration. If the specified eTag value does not match the current etag value, the request will fail. Use the response from getDistributedFirewallLayer3 to retrieve the current generationNumber needed to modify the configuration (e.g. 1583956143338)
   * @param updateRequest update request
   * @return distributed firewall layer 3 response
   */
  @PUT
  @Path("/{vdcUuid}/distributed-firewall-layer3")
  DistributedFirewallLayer3Response updateDistributedFirewallLayer3(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid, @QueryParam("eTag") Long eTag,
      DistributedFirewallLayer3UpdateRequest updateRequest);

  /**
   * Update the distributed firewall at layer 2 (ethernet) for a given vDC.
   *
   * @param vdcUuid       vDC uuid
   * @param eTag          the eTag value. specifying an eTag value allows a client to ensure that the distributed firewall has not been updated since it last read the configuration. If the specified eTag value does not match the current etag value, the request will fail. Use the response from getDistributedFirewallLayer3 to retrieve the current generationNumber needed to modify the configuration (e.g. 1583956143338)
   * @param updateRequest update request
   * @return distributed firewall layer 2 response
   */
  @PUT
  @Path("/{vdcUuid}/distributed-firewall-layer2")
  DistributedFirewallLayer2Response updateDistributedFirewallLayer2(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid, @QueryParam("eTag") Long eTag,
      DistributedFirewallLayer2UpdateRequest updateRequest);

  /**
   * Get a rule within the distributed firewall at layer 3 (general) for a given vDC.
   *
   * @param vdcUuid vDC uuid
   * @param ruleId  rule id
   * @return distributed firewall layer 3 rule response
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer3-rules/{ruleId}")
  DistributedFirewallLayer3RuleResponse getDistributedFirewallLayer3Rule(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("ruleId") long ruleId);

  /**
   * Get a rule within the distributed firewall at layer 2 (ethernet) for a given vDC.
   *
   * @param vdcUuid vDC uuid
   * @param ruleId  rule id
   * @return distributed firewall layer 2 rule response
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer2-rules/{ruleId}")
  DistributedFirewallLayer2RuleResponse getDistributedFirewallLayer2Rule(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("ruleId") long ruleId);

  /**
   * Create a rule within the distributed firewall at layer 3 (general) for a given vDC.
   *
   * @param vdcUuid       vDC uuid
   * @param eTag          the eTag value. specifying an eTag value allows a client to ensure that the distributed firewall has not been updated since it last read the configuration. If the specified eTag value does not match the current etag value, the request will fail. Use the response from getDistributedFirewallLayer3 to retrieve the current generationNumber needed to modify the configuration (e.g. 1583956143338)
   * @param createRequest create request
   * @return distributed firewall layer 3 rule response
   */
  @Consumes(MediaType.APPLICATION_JSON)
  @POST
  @Path("/{vdcUuid}/distributed-firewall-layer3-rules")
  DistributedFirewallLayer3RuleResponse createDistributedFirewallLayer3Rule(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid, @QueryParam("eTag") Long eTag,
      DistributedFirewallLayer3RuleCreateRequest createRequest);

  /**
   * Create a rule within the distributed firewall at layer 2 (ethernet) for a given vDC.
   *
   * @param vdcUuid       vDC uuid
   * @param eTag          the eTag value. specifying an eTag value allows a client to ensure that the distributed firewall has not been updated since it last read the configuration. If the specified eTag value does not match the current etag value, the request will fail. Use the response from getDistributedFirewallLayer3 to retrieve the current generationNumber needed to modify the configuration (e.g. 1583956143338)
   * @param createRequest create request
   * @return distributed firewall layer 2 rule response
   */
  @Consumes(MediaType.APPLICATION_JSON)
  @POST
  @Path("/{vdcUuid}/distributed-firewall-layer2-rules")
  DistributedFirewallLayer2RuleResponse createDistributedFirewallLayer2Rule(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid, @QueryParam("eTag") Long eTag,
      DistributedFirewallLayer2RuleCreateRequest createRequest);

  /**
   * Update a rule within the distributed firewall at layer 3 (general) for a given vDC.
   *
   * @param vdcUuid       vDC uuid
   * @param ruleId        rule id
   * @param eTag          the eTag value. specifying an eTag value allows a client to ensure that the distributed firewall has not been updated since it last read the configuration. If the specified eTag value does not match the current etag value, the request will fail. Use the response from getDistributedFirewallLayer3 to retrieve the current generationNumber needed to modify the configuration (e.g. 1583956143338)
   * @param updateRequest update request
   * @return distributed firewall layer 3 rule response
   */
  @Consumes(MediaType.APPLICATION_JSON)
  @PUT
  @Path("/{vdcUuid}/distributed-firewall-layer3-rules/{ruleId}")
  DistributedFirewallLayer3RuleResponse updateDistributedFirewallLayer3Rule(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid, @PathParam("ruleId") long ruleId,
      @QueryParam("eTag") Long eTag,
      DistributedFirewallLayer3RuleUpdateRequest updateRequest);

  /**
   * Update a rule within the distributed firewall at layer 2 (ethernet) for a given vDC.
   *
   * @param vdcUuid       vDC uuid
   * @param ruleId        rule id
   * @param eTag          the eTag value. specifying an eTag value allows a client to ensure that the distributed firewall has not been updated since it last read the configuration. If the specified eTag value does not match the current etag value, the request will fail. Use the response from getDistributedFirewallLayer3 to retrieve the current generationNumber needed to modify the configuration (e.g. 1583956143338)
   * @param updateRequest update request
   * @return distributed firewall layer 2 rule response
   */
  @Consumes(MediaType.APPLICATION_JSON)
  @PUT
  @Path("/{vdcUuid}/distributed-firewall-layer2-rules/{ruleId}")
  DistributedFirewallLayer2RuleResponse updateDistributedFirewallLayer2Rule(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid, @PathParam("ruleId") long ruleId,
      @QueryParam("eTag") Long eTag,
      DistributedFirewallLayer2RuleUpdateRequest updateRequest);

  /**
   * Delete a rule within the distributed firewall at layer 3 (general) for a given vDC.
   *
   * @param vdcUuid vDC uuid
   * @param ruleId  rule id
   * @param eTag    the eTag value. specifying an eTag value allows a client to ensure that the distributed firewall has not been updated since it last read the configuration. If the specified eTag value does not match the current etag value, the request will fail. Use the response from getDistributedFirewallLayer3 to retrieve the current generationNumber needed to modify the configuration (e.g. 1583956143338)
   */
  @DELETE
  @Path("/{vdcUuid}/distributed-firewall-layer3-rules/{ruleId}")
  void deleteDistributedFirewallLayer3Rule(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid, @PathParam("ruleId") long ruleId,
      @QueryParam("eTag") Long eTag);

  /**
   * Delete a rule within the distributed firewall at layer 2 (ethernet) for a given vDC.
   *
   * @param vdcUuid vDC uuid
   * @param ruleId  rule id
   * @param eTag    the eTag value. specifying an eTag value allows a client to ensure that the distributed firewall has not been updated since it last read the configuration. If the specified eTag value does not match the current etag value, the request will fail. Use the response from getDistributedFirewallLayer3 to retrieve the current generationNumber needed to modify the configuration (e.g. 1583956143338)
   */
  @DELETE
  @Path("/{vdcUuid}/distributed-firewall-layer2-rules/{ruleId}")
  void deleteDistributedFirewallLayer2Rule(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid, @PathParam("ruleId") long ruleId,
      @QueryParam("eTag") Long eTag);

  /**
   * Get the list of distributed firewall layer 3 (general) source object types.
   *
   * @param vdcUuid vDC uuid
   * @return the list of layer 3 source object types
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer3/sources")
  DistributedFirewallSourceTypeListResponse getDistributedFirewallLayer3SourceObjectTypes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the list of source objects for distributed firewall layer 3 (general).
   *
   * @param vdcUuid vDC uuid
   * @param type    source object type
   * @param filters source object filters
   * @return the list of source objects
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer3/sources/{type}")
  DistributedFirewallSourceObjectListResponse getDistributedFirewallLayer3SourceObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("type") String type,
      @BeanParam ObjectPagingParams filters);

  /**
   * Get the list of distributed firewall layer 3 (general) destination object types.
   *
   * @param vdcUuid vDC uuid
   * @return the list of layer 3 destination object types
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer3/destinations")
  DistributedFirewallDestinationTypeListResponse getDistributedFirewallLayer3DestinationObjectTypes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the list of destination objects for distributed firewall layer 3 (general).
   *
   * @param vdcUuid vDC uuid
   * @param type    destination object type
   * @param filters destination object filters
   * @return the list of destination objects
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer3/destinations/{type}")
  DistributedFirewallDestinationObjectListResponse getDistributedFirewallLayer3DestinationObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("type") String type,
      @BeanParam ObjectPagingParams filters);

  /**
   * Get the list of distributed firewall layer 3 (general) applied to object types.
   *
   * @param vdcUuid vDC uuid
   * @return the list of layer 3 applied to object types
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer3/applied-to-objects")
  DistributedFirewallAppliedToTypeListResponse getDistributedFirewallLayer3AppliedToObjectTypes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the list of applied to objects for distributed firewall layer 3 (general).
   *
   * @param vdcUuid vDC uuid
   * @param type    applied to object type
   * @param filters applied to object filters
   * @return the list of applied to objects
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer3/applied-to-objects/{type}")
  DistributedFirewallAppliedToObjectListResponse getDistributedFirewallLayer3AppliedToObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("type") String type,
      @BeanParam ObjectPagingParams filters);

  /**
   * Create a distributed firewall layer3 restore point for a vDC's distributed firewall.
   *
   * @param vdcUuid                   vdc uuid
   * @param restorePointCreateRequest distributed firewall layer3 restore point create request
   * @return distributed firewall restore point
   */
  @POST
  @Path("/{vdcUuid}/distributed-firewall-layer3/restore-points")
  DistributedFirewallLayer3RestorePointDetailsResponse createDistributedFirewallLayer3RestorePoint(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      DistributedFirewallRestorePointCreateRequest restorePointCreateRequest);

  /**
   * Get the distributed firewall layer3 restore points for a vDC.
   *
   * @param vdcUuid vDC uuid
   * @return distributed firewall restore points
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer3/restore-points")
  DistributedFirewallRestorePointListResponse getDistributedFirewallLayer3RestorePoints(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get a distributed firewall layer3 restore point for a vDC at a given time.
   * <p>
   * Restore point time is epoch time in milliseconds.
   *
   * @param vdcUuid          vDC uuid
   * @param restorePointTime restore point time
   * @return distributed firewall restore point
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer3/restore-points/{restorePointTime}")
  DistributedFirewallLayer3RestorePointDetailsResponse getDistributedFirewallLayer3RestorePoint(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("restorePointTime") long restorePointTime);

  /**
   * Delete a distributed firewall layer3 restore point.
   * <p>
   * Restore point time is epoch time in milliseconds.
   *
   * @param vdcUuid          vDC uuid
   * @param restorePointTime restore point time
   */
  @DELETE
  @Path("/{vdcUuid}/distributed-firewall-layer3/restore-points/{restorePointTime}")
  void deleteDistributedFirewallLayer3RestorePoint(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("restorePointTime") long restorePointTime);

  /**
   * Restore a vDC's distributed firewall layer3 configuration to a specified restore point.
   *
   * @param vdcUuid                           vDC uuid
   * @param restoreDistributedFirewallRequest the request body, which specifies the restore point time
   * @return distributed firewall
   */
  @POST
  @Path("/{vdcUuid}/distributed-firewall-layer3/actions/restore")
  DistributedFirewallLayer3Response restoreDistributedFirewallLayer3(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      RestoreDistributedFirewallRequest restoreDistributedFirewallRequest);

  /**
   * Create a distributed firewall layer2 restore point for a vDC's distributed firewall.
   *
   * @param vdcUuid                   vdc uuid
   * @param restorePointCreateRequest distributed firewall layer2 restore point create request
   * @return distributed firewall restore point
   */
  @POST
  @Path("/{vdcUuid}/distributed-firewall-layer2/restore-points")
  DistributedFirewallLayer2RestorePointDetailsResponse createDistributedFirewallLayer2RestorePoint(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      DistributedFirewallRestorePointCreateRequest restorePointCreateRequest);

  /**
   * Get the distributed firewall layer2 restore points for a vDC.
   *
   * @param vdcUuid vDC uuid
   * @return distributed firewall restore points
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer2/restore-points")
  DistributedFirewallRestorePointListResponse getDistributedFirewallLayer2RestorePoints(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get a distributed firewall layer2 restore point for a vDC at a given time.
   * <p>
   * Restore point time is epoch time in milliseconds.
   *
   * @param vdcUuid          vDC uuid
   * @param restorePointTime restore point time
   * @return distributed firewall restore point
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer2/restore-points/{restorePointTime}")
  DistributedFirewallLayer2RestorePointDetailsResponse getDistributedFirewallLayer2RestorePoint(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("restorePointTime") long restorePointTime);

  /**
   * Delete a distributed firewall layer2 restore point.
   * <p>
   * Restore point time is epoch time in milliseconds.
   *
   * @param vdcUuid          vDC uuid
   * @param restorePointTime restore point time
   */
  @DELETE
  @Path("/{vdcUuid}/distributed-firewall-layer2/restore-points/{restorePointTime}")
  void deleteDistributedFirewallLayer2RestorePoint(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("restorePointTime") long restorePointTime);

  /**
   * Restore a vDC's distributed firewall layer2 configuration to a specified restore point.
   *
   * @param vdcUuid                           vDC uuid
   * @param restoreDistributedFirewallRequest the request body, which specifies the restore point time
   * @return distributed firewall
   */
  @POST
  @Path("/{vdcUuid}/distributed-firewall-layer2/actions/restore")
  DistributedFirewallLayer2Response restoreDistributedFirewallLayer2(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      RestoreDistributedFirewallRequest restoreDistributedFirewallRequest);

  /**
   * Get the list of distributed firewall layer 2 (ethernet) source object types.
   *
   * @param vdcUuid vDC uuid
   * @return the list of layer 2 source object types
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer2/sources")
  DistributedFirewallSourceTypeListResponse getDistributedFirewallLayer2SourceObjectTypes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the list of source objects for distributed firewall layer 2 (ethernet).
   *
   * @param vdcUuid vDC uuid
   * @param type    source object type
   * @param filters source object filters
   * @return the list of source objects
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer2/sources/{type}")
  DistributedFirewallSourceObjectListResponse getDistributedFirewallLayer2SourceObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("type") String type,
      @BeanParam ObjectPagingParams filters);

  /**
   * Get the list of distributed firewall layer 2 (ethernet) destination object types.
   *
   * @param vdcUuid vDC uuid
   * @return the list of layer 2 destination object types
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer2/destinations")
  DistributedFirewallDestinationTypeListResponse getDistributedFirewallLayer2DestinationObjectTypes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the list of destination objects for distributed firewall layer 2 (ethernet).
   *
   * @param vdcUuid vDC uuid
   * @param type    destination object type
   * @param filters destination object filters
   * @return the list of destination objects
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer2/destinations/{type}")
  DistributedFirewallDestinationObjectListResponse getDistributedFirewallLayer2DestinationObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("type") String type,
      @BeanParam ObjectPagingParams filters);

  /**
   * Get the list of distributed firewall layer 2 (ethernet) applied to object types.
   *
   * @param vdcUuid vDC uuid
   * @return the list of layer 2 applied to object types
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer2/applied-to-objects")
  DistributedFirewallAppliedToTypeListResponse getDistributedFirewallLayer2AppliedToObjectTypes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the list of applied to objects for distributed firewall layer 2 (ethernet).
   *
   * @param vdcUuid vDC uuid
   * @param type    applied to object type
   * @param filters applied to object filters
   * @return the list of applied to objects
   */
  @GET
  @Path("/{vdcUuid}/distributed-firewall-layer2/applied-to-objects/{type}")
  DistributedFirewallAppliedToObjectListResponse getDistributedFirewallLayer2AppliedToObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("type") String type,
      @BeanParam ObjectPagingParams filters);

  /**
   * Create a IP set grouping object for a given vDC.
   *
   * @param vdcUuid            vDC uuid
   * @param ipSetCreateRequest ip set create request
   * @return created ip set
   */
  @POST
  @Path("/{vdcUuid}/ipsets")
  @Consumes(MediaType.APPLICATION_JSON)
  IpSetResponse createIpSet(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      IpSetCreateRequest ipSetCreateRequest);

  /**
   * Get all the IP sets for a given vDC.
   *
   * @param vdcUuid vDC uuid
   * @return ip set list response
   */
  @GET
  @Path("/{vdcUuid}/ipsets")
  IpSetListResponse getIpSets(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Create a MAC set grouping object for a given vDC.
   *
   * @param vdcUuid             vDC uuid
   * @param macSetCreateRequest mac set create request
   * @return created mac set
   */
  @POST
  @Path("/{vdcUuid}/macsets")
  @Consumes(MediaType.APPLICATION_JSON)
  MacSetResponse createMacSet(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      MacSetCreateRequest macSetCreateRequest);

  /**
   * Get all the MAC sets for a given vDC.
   *
   * @param vdcUuid vDC uuid
   * @return mac set list response
   */
  @GET
  @Path("/{vdcUuid}/macsets")
  MacSetListResponse getMacSets(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the specified IP set given it's UUID.
   *
   * @param vdcUuid vDC uuid
   * @param ipSetId ip set id (e.g. ipset-1)
   * @return ip set response
   */
  @GET
  @Path("/{vdcUuid}/ipsets/{ipsetId}")
  IpSetResponse getIpSet(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("ipsetId") String ipSetId);

  /**
   * Updates a IP set grouping object for a given vDC.
   *
   * @param vdcUuid            vDC uuid
   * @param ipSetId            ip set id (e.g. ipset-1)
   * @param ipSetUpdateRequest ip set update request
   * @return created ip set
   */
  @PUT
  @Path("/{vdcUuid}/ipsets/{ipsetId}")
  IpSetResponse updateIpSet(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("ipsetId") String ipSetId,
      IpSetUpdateRequest ipSetUpdateRequest);

  /**
   * Delete the specified IP set.
   *
   * @param vdcUuid vDC uuid
   * @param ipSetId ip set id (e.g. ipset-1)
   */
  @DELETE
  @Path("/{vdcUuid}/ipsets/{ipsetId}")
  void deleteIpSet(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("ipsetId") String ipSetId);

  /**
   * Get all the application grouping objects for a given vDC.
   *
   * @param vdcUuid vdc uuid
   * @return a application grouping object list response
   */
  @GET
  @Path("/{vdcUuid}/applications")
  ApplicationListResponse getApplications(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the specified application group for the given vDC.
   *
   * @param vdcUuid       vdc uuid
   * @param applicationId application grouping object id (e.g. application-1)
   * @return a application grouping object
   */
  @GET
  @Path("/{vdcUuid}/applications/{applicationId}")
  ApplicationResponse getApplication(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("applicationId") String applicationId);

  /**
   * Get a list application group grouping objects for a given vDC.
   *
   * @param vdcUuid vdc uuid
   * @return a application group grouping object list response
   */
  @GET
  @Path("/{vdcUuid}/application-groups")
  ApplicationGroupListResponse getApplicationGroups(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get a specified application group for a given vDC.
   *
   * @param vdcUuid            vdc uuid
   * @param applicationGroupId application group id (e.g. applicationgroup-1)
   * @return a application group grouping object response
   */
  @GET
  @Path("/{vdcUuid}/application-groups/{applicationGroupId}")
  ApplicationGroupResponse getApplicationGroup(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid,
      @PathParam("applicationGroupId") String applicationGroupId);

  /**
   * Get the specified MAC set given it's UUID.
   *
   * @param vdcUuid  vDC uuid
   * @param macSetId mac set id (e.g. macset-1)
   * @return mac set response
   */
  @GET
  @Path("/{vdcUuid}/macsets/{macsetId}")
  MacSetResponse getMacSet(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("macsetId") String macSetId);

  /**
   * Updates a MAC set grouping object for a given vDC.
   *
   * @param vdcUuid             vDC uuid
   * @param macSetId            mac set id (e.g. macset-1)
   * @param macSetUpdateRequest mac set update request
   * @return created mac set
   */
  @PUT
  @Path("/{vdcUuid}/macsets/{macsetId}")
  MacSetResponse updateMacSet(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("macsetId") String macSetId,
      MacSetUpdateRequest macSetUpdateRequest);

  /**
   * Delete the specified MAC set.
   *
   * @param vdcUuid  vDC uuid
   * @param macSetId mac set id (e.g. macset-1)
   */
  @DELETE
  @Path("/{vdcUuid}/macsets/{macsetId}")
  void deleteMacSet(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("macsetId") String macSetId);

  /**
   * Get a list of security tags for a given vDC.
   *
   * @param vdcUuid vDC uuid
   * @return list of security tags response
   */
  @GET
  @Path("/{vdcUuid}/security-tags")
  SecurityTagsResponse getSecurityTags(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the specified security tag for a given vDC.
   *
   * @param vdcUuid       vDC uuid
   * @param securitytagId security tag id (e.g. securitytag-1)
   * @return security tag response
   */
  @GET
  @Path("/{vdcUuid}/security-tags/{securitytagId}")
  SecurityTagWithAssignedVMsResponse getSecurityTag(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("securitytagId") String securitytagId);

  /**
   * Create a new security tag for a given vDC.
   *
   * @param vdcUuid       vDC uuid
   * @param createRequest create request
   * @return created security tag response
   */
  @POST
  @Path("/{vdcUuid}/security-tags")
  @Consumes(MediaType.APPLICATION_JSON)
  SecurityTagWithAssignedVMsResponse createSecurityTag(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      SecurityTagCreateRequest createRequest);

  /**
   * Update a specified security tag for a given vDC.
   *
   * @param vdcUuid       vDC uuid
   * @param securitytagId security tag id (e.g. securitytag-1)
   * @param updateRequest update request
   * @return updated security tag response
   */
  @PUT
  @Path("/{vdcUuid}/security-tags/{securitytagId}")
  SecurityTagWithAssignedVMsResponse updateSecurityTag(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("securitytagId") String securitytagId,
      SecurityTagUpdateRequest updateRequest);

  /**
   * Delete a specified security tag for a given vDC.
   *
   * @param vdcUuid       vDC uuid
   * @param securitytagId security tag id (e.g. securitytag-1)
   */
  @DELETE
  @Path("/{vdcUuid}/security-tags/{securitytagId}")
  void deleteSecurityTag(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("securitytagId") String securitytagId);

  /**
   * Get the list of security tag object types.
   *
   * @param vdcUuid vDC uuid
   * @return the list of security tag object types
   */
  @GET
  @Path("/{vdcUuid}/security-tag-objects")
  SecurityTagObjectTypeListResponse getSecurityTagObjectTypes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the list of security tag objects.
   *
   * @param vdcUuid vDC uuid
   * @param type    security tag object type
   * @param filter  security tag object filter
   * @return the list of security tag objects
   */
  @GET
  @Path("/{vdcUuid}/security-tag-objects/{type}")
  SecurityTagObjectListResponse getSecurityTagObjects(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("type") String type,
      @BeanParam ObjectPagingParams filter);

  /**
   * Get a list of security groups for a given vDC.
   *
   * @param vdcUuid vDC uuid
   * @return list of security groups response
   */
  @GET
  @Path("/{vdcUuid}/security-groups")
  SecurityGroupsResponse getSecurityGroups(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the specified security group for a given vDC.
   *
   * @param vdcUuid         vDC uuid
   * @param securitygroupId security group id (e.g. securitygroup-1)
   * @return security group response
   */
  @GET
  @Path("/{vdcUuid}/security-groups/{securitygroupId}")
  SecurityGroupResponse getSecurityGroup(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("securitygroupId") String securitygroupId);

  /**
   * Create a new security group for a given vDC.
   *
   * @param vdcUuid       vDC uuid
   * @param createRequest create request
   * @return created security group response
   */
  @POST
  @Path("/{vdcUuid}/security-groups")
  SecurityGroupResponse createSecurityGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      SecurityGroupCreateRequest createRequest);

  /**
   * Update a specified security group for a given vDC.
   *
   * @param vdcUuid         vDC uuid
   * @param securitygroupId security group id (e.g. securitygroup-1)
   * @param updateRequest   update request
   * @return updated security group response
   */
  @PUT
  @Path("/{vdcUuid}/security-groups/{securitygroupId}")
  SecurityGroupResponse updateSecurityGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("securitygroupId") String securitygroupId,
      SecurityGroupUpdateRequest updateRequest);

  /**
   * Delete a specified security group for a given vDC.
   *
   * @param vdcUuid         vDC uuid
   * @param securitygroupId security group id (e.g. securitygroup-1)
   */
  @DELETE
  @Path("/{vdcUuid}/security-groups/{securitygroupId}")
  void deleteSecurityGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("securitygroupId") String securitygroupId);

  /**
   * Get the list of security group member types.
   *
   * @param vdcUuid vDC uuid
   * @return the list of security group member types
   */
  @GET
  @Path("/{vdcUuid}/security-group-members")
  SecurityGroupMemberTypeListResponse getSecurityGroupMemberTypes(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Get the list of security group members.
   *
   * @param vdcUuid vDC uuid
   * @param type    security group member type
   * @param filter  security group member filter
   * @return the list of security group members
   */
  @GET
  @Path("/{vdcUuid}/security-group-members/{type}")
  SecurityGroupMemberListResponse getSecurityGroupMembers(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("type") String type,
      @BeanParam ObjectPagingParams filter);

  /**
   * Manually start an unscheduled backup group job run.
   *
   * @param vdcUuid        the UUID of the vDC
   * @param backupGroupUid the UID of the backup group
   * @param runType        the run type
   * @return the task response, used to track the asynchronous operation
   */
  @POST
  @Path("/{vdcUuid}/backup-groups/{backupGroupUid}/runs")
  TaskResponse startBackupGroupRun(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION) @PathParam("vdcUuid")
      String vdcUuid, @PathParam("backupGroupUid") String backupGroupUid,
      @QueryParam("runType") RunType runType);

  /**
   * List the existing backup groups that are configured in a specified virtual
   * datacenter.
   *
   * @param vdcUuid             the UUID of the vDC
   * @param includeDeleted      whether to include deleted backup groups
   * @param includeSummaryStats whether to include backup summary stats
   * @param includeLastRun      whether to include last run info in the response.
   * @param includeBackupPolicy whether to include backup policy details
   * @return {@link BackupGroupListResponse}
   */
  @GET
  @Path("/{vdcUuid}/backup-groups")
  BackupGroupListResponse listBackupGroups(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @QueryParam("includeDeleted") boolean includeDeleted,
      @QueryParam("includeSummaryStats") boolean includeSummaryStats,
      @QueryParam("includeLastRun") boolean includeLastRun,
      @QueryParam("includeBackupPolicy") boolean includeBackupPolicy);

  /**
   * List the existing backup groups that are configured in a specified virtual
   * datacenter.
   *
   * @param vdcUuid             the UUID of the vDC
   * @param includeDeleted      whether to include deleted backup groups
   * @param includeSummaryStats whether to include backup summary stats
   * @param includeLastRun      whether to include last run info in the response.
   * @param includeBackupPolicy whether to include backup policy details
   * @param includeLegacyVMware weather to include legacy VMware backup groups
   * @return {@link ListResponse list of backup groups}
   */
  @GET
  @Path("/{vdcUuid}/backup-groups-x")
  ListResponse<BackupGroupV2> listV2BackupGroups(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
      VdcUuid vdcUuid, @QueryParam("includeDeleted") boolean includeDeleted,
      @QueryParam("includeSummaryStats") boolean includeSummaryStats,
      @QueryParam("includeLastRun") boolean includeLastRun,
      @QueryParam("includeBackupPolicy") boolean includeBackupPolicy,
      @QueryParam("includeLegacyVMware") boolean includeLegacyVMware);

  /**
   * Gets backup group summary stats for the vDC.
   * <p>
   * Stat time-range defaults to the past 24 hours.
   *
   * @param vdcUuid the UUID of the vDC
   * @param filters optional filters that can be used to specify a custom
   *                timeframe.
   * @return {@link VdcBackupSummaryStatsResponse}
   */
  @GET
  @Path("/{vdcUuid}/backup-group-summary-stats")
  VdcBackupSummaryStatsResponse getBackupGroupSummaryStats(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @BeanParam GetBackupGroupSummaryStatsFilters filters);

  /**
   * Create a new backup group.
   *
   * @param vdcUuid         the UUID of the virtual datacenter
   * @param creationRequest the creation request body
   * @return {@link BackupGroupResponse}
   */
  @POST
  @Path("/{vdcUuid}/backup-groups")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupGroupResponse createBackupGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      BackupGroupUpdateRequest creationRequest);

  /**
   * Create a new file-based backup group.
   *
   * @param vdcUuid         the UUID of the virtual datacenter
   * @param creationRequest the creation request body
   * @return {@link BackupGroupResponse}
   */
  @POST
  @Path("/{vdcUuid}/backup-groups/file")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupGroupV2 createBackupGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") VdcUuid vdcUuid,
      FileBasedBackupGroupWithCommonParams creationRequest);

  /**
   * Create a new block-based backup group.
   *
   * @param vdcUuid         the UUID of the virtual datacenter
   * @param creationRequest the creation request body
   * @return {@link BackupGroupResponse}
   */
  @POST
  @Path("/{vdcUuid}/backup-groups/block")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupGroupV2 createBackupGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") VdcUuid vdcUuid,
      BlockBasedBackupGroupWithCommonParams creationRequest);

  /**
   * Create a new MSSQL file-based backup group.
   *
   * @param vdcUuid         the UUID of the virtual datacenter
   * @param creationRequest the creation request body
   * @return {@link BackupGroupResponse}
   */
  @POST
  @Path("/{vdcUuid}/backup-groups/mssql/file")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupGroupV2 createBackupGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") VdcUuid vdcUuid,
      MssqlFileBasedBackupGroupWithCommonParams creationRequest);

  /**
   * Create a new MSSQL volume-based backup group.
   *
   * @param vdcUuid         the UUID of the virtual datacenter
   * @param creationRequest the creation request body
   * @return {@link BackupGroupResponse}
   */
  @POST
  @Path("/{vdcUuid}/backup-groups/mssql/volume")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupGroupV2 createBackupGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") VdcUuid vdcUuid,
      MssqlVolumeBasedBackupGroupWithCommonParams creationRequest);

  /**
   * Create a new MSSQL native-based backup group.
   *
   * @param vdcUuid         the UUID of the virtual datacenter
   * @param creationRequest the creation request body
   * @return {@link BackupGroupResponse}
   */
  @POST
  @Path("/{vdcUuid}/backup-groups/mssql/native")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupGroupV2 createBackupGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") VdcUuid vdcUuid,
      MssqlNativeBasedBackupGroupWithCommonParams creationRequest);

  /**
   * Create a new oracle based backup group.
   *
   * @param vdcUuid         the UUID of the virtual datacenter
   * @param creationRequest the creation request body
   * @return {@link BackupGroupResponse}
   */
  @POST
  @Path("/{vdcUuid}/backup-groups/oracle")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupGroupV2 createBackupGroup(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") VdcUuid vdcUuid,
      OracleBasedBackupGroupWithCommonParams creationRequest);

  /**
   * List the existing backup policies that are configured in a
   * vDC.
   *
   * @param vdcUuid            the UUID of the vDC
   * @param includeOrgPolicies whether to include org-scoped policies from the parent org
   * @return {@link BackupPolicyListResponse}
   */
  @GET
  @Path("/{vdcUuid}/backup-policies")
  BackupPolicyListResponse listBackupPolicies(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid,
      @QueryParam("includeOrgPolicies") boolean includeOrgPolicies);

  /**
   * Get details of an individual vDC-scoped backup policy.
   *
   * @param backupPolicyUid the UID of the backup policy
   * @param vdcUuid         the UUID of the vdc
   * @return {@link BackupPolicyResponse}
   */
  @GET
  @Path("/{vdcUuid}/backup-policies/{backupPolicyUid}")
  BackupPolicyResponse getBackupPolicy(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("backupPolicyUid") String backupPolicyUid);

  /**
   * Create a new vdc-scoped backup policy.
   *
   * @param vdcUuid         the UUID of the vdc
   * @param creationRequest the creation request body
   * @return {@link BackupPolicyResponse}
   */
  @POST
  @Path("/{vdcUuid}/backup-policies")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupPolicyResponse createBackupPolicy(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      BackupPolicyUpdateRequest creationRequest);

  /**
   * Update a backup policy.
   *
   * @param vdcUuid         the UUID of the vdc
   * @param backupPolicyUid the UID of the backup policy
   * @param updateRequest   the update request body
   * @return {@link BackupPolicyResponse}
   */
  @PUT
  @Path("/{vdcUuid}/backup-policies/{backupPolicyUid}")
  @Consumes(MediaType.APPLICATION_JSON)
  BackupPolicyResponse updateBackupPolicy(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("backupPolicyUid") String backupPolicyUid,
      BackupPolicyUpdateRequest updateRequest);

  /**
   * Delete a backup policy.
   *
   * @param vdcUuid         the UUID of the vdc
   * @param backupPolicyUid the UID of the backup policy
   */
  @DELETE
  @Path("/{vdcUuid}/backup-policies/{backupPolicyUid}")
  @Consumes(MediaType.APPLICATION_JSON)
  void deleteBackupPolicy(
      @SecureEntityRef(Permission.MANAGE_ILAND_CLOUD_VDC_CONFIGURATION)
      @PathParam("vdcUuid") String vdcUuid,
      @PathParam("backupPolicyUid") String backupPolicyUid);

  /**
   * List backup runs for the specified vDC.
   * <p>
   * Limit defaults to 10 and query time range defaults to last 24 hours.
   *
   * @param vdcUuid the vDC UUID
   * @param params  query filter params
   * @return {@link BackupGroupRunListResponse}
   */
  @GET
  @Path("/{vdcUuid}/backup-runs")
  BackupGroupRunListResponse listBackupGroupRuns(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @BeanParam ListBackupGroupRunsQueryParams params);

  /**
   * Download the messages report of a single protected entity of a backup run as
   * a CSV.
   *
   * <p>The report is offered as an attachment whose file name is generated here,
   * so it never carries a name chosen by the backups service or its upstream
   * vendor.
   *
   * @param vdcUuid      the vDC UUID
   * @param backupRunUid the UID of the backup run
   * @param sourceUid    the UID of the protected entity to report on
   * @return the CSV report
   */
  @POST
  @Path("/{vdcUuid}/backup-runs/{backupRunUid}/sources/{sourceUid}/messages-report")
  @Produces("text/csv")
  InputStream getBackupGroupRunMessagesReport(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          VdcUuid vdcUuid, @PathParam("backupRunUid") BackupRunUid backupRunUid,
      @PathParam("sourceUid") SourceUid sourceUid);

  /**
   * Gets the vDC's backup status.
   *
   * @param vdcUuid the UUID of the vDC
   * @return vDC backup status details
   */
  @GET
  @Path("/{vdcUuid}/backup-status")
  VdcBackupStatusResponse getBackupStatus(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Gets the vDC's integrated backup status.
   *
   * @param vdcUuid the UUID of the vDC
   * @return vDC integrated backup status details
   */
  @GET
  @Path("/{vdcUuid}/integrated-backup-status")
  VdcIntegratedBackupStatusDetailResponse getIntegratedBackupStatus(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Searches for recoverable backup files and folders within the vDC.
   *
   * @param vdcUuid the UUID of the vDC
   * @param filters optional query filters
   * @return a list of recoverable files and folders
   */
  @GET
  @Path("/{vdcUuid}/recoverable-files-and-folders")
  RecoverableFilesSearchResultListResponse searchRecoverableFilesAndFolders(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid,
      @BeanParam SearchVdcRecoverableFilesAndFoldersFilters filters);

  /**
   * Gets the list of storage metrics that are available for the vDC.
   *
   * @param vdcUuid the UUID of the vDC
   * @return the list of storage metrics names
   */
  @GET
  @Path("/{vdcUuid}/backup-storage-metrics")
  VdcBackupStorageMetricListResponse getBackupStorageMetrics(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Gets a series of vDC backup storage samples for a specified storage metric.
   *
   * @param vdcUuid the UUID of the vDC
   * @param metric  the storage metric name
   * @param filters optional filters for the start and end of the series
   * @return the sample series
   */
  @GET
  @Path("/{vdcUuid}/backup-storage-metrics/{metric}/samples")
  VdcBackupStorageSampleSeriesResponse getBackupStorageSamples(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("metric") VdcBackupStorageMetric metric,
      @BeanParam GetBackupStorageSamplesFilters filters);

  /**
   * Lists bills for IaaS backup in the specified time range.
   * <p>
   * Both start and end time query params default to the current month.
   *
   * @param vdcUuid the UUID of the vDC
   * @param start   Specifies the start of the range as a year-month in the ISO-8601 calendar system, such as 2007-12.
   * @param end     Specifies the end of the range as a year-month in the ISO-8601 calendar system, such as 2007-12.
   * @return the list of bills
   */
  @GET
  @Path("/{vdcUuid}/iaas-backup-bills")
  IaasBackupBillListResponse listIaasBackupBills(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC_BILLING)
      @PathParam("vdcUuid") String vdcUuid, @QueryParam("start") String start,
      @QueryParam("end") String end);

  /**
   * Lists IaaS backup subscriptions that were active in the specified time range.
   *
   * @param vdcUuid         the UUID of the vDC
   * @param startTimeMillis the start time in epoch millis
   * @param endTimeMillis   the end time in epoch millis
   * @return list of subscriptions
   */
  @GET
  @Path("/{vdcUuid}/iaas-backup-subscriptions")
  IaasBackupSubscriptionListResponse listIaasBackupSubscriptions(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC_BILLING)
      @PathParam("vdcUuid") String vdcUuid,
      @QueryParam("startTimeMillis") Long startTimeMillis,
      @QueryParam("endTimeMillis") Long endTimeMillis);

  /**
   * Lists stats for IaaS backup groups.
   *
   * @param vdcUuid the UUID of the vDC
   * @param startMonth in the format of "yyyy-MM"; optional; defaults to 6 months ago; inclusive
   * @param endMonth in the format of "yyyy-MM"; optional; defaults to the current month; inclusive
   * @return {@link IaasBackupSummaryListResponse list response}
   */
  @GET
  @Path("/{vdcUuid}/stats")
  IaasBackupSummaryListResponse listIaasBackupGroupStats(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC_BILLING)
      @PathParam("vdcUuid") String vdcUuid,
      @QueryParam("startMonth") String startMonth,
      @QueryParam("endMonth") String endMonth);

  /**
   * Searches for recoverable VM snapshots within the vDC.
   *
   * @param vdcUuid the UUID of the vDC
   * @param filters optional query filters
   * @return a list of recoverable VM snapshots
   */
  @GET
  @Path("/{vdcUuid}/recoverable-vms")
  VMBackupSnapshotListResponse searchRecoverableVMs(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @BeanParam SearchVdcRecoverableVMsFilters filters);

  /**
   * Restores one or more VM backups within the vDC.
   *
   * @param vdcUuid the UUID of the vDC
   * @param params  restoration parameters
   * @return the restore task, used to track the asynchronous operation
   */
  @SkipSecurityTest("custom security logic in EJB")
  @POST
  @Path("/{vdcUuid}/actions/restore-vm-backups")
  TaskResponse restoreVMBackupsInVdc(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, RestoreVMBackupsInVdcParams params);

  /**
   * Gets info about the backup cluster and remote replicas that are available
   * to the vDC.
   *
   * @param vdcUuid the UUID of the vDC
   * @return information about the local backup cluster and available remote clusters
   */
  @GET
  @Path("/{vdcUuid}/backup-cluster-info")
  VdcBackupClusterInfo getVdcBackupClusterInfo(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid);

  /**
   * Lists detailed task information for advanced backup restore tasks in a
   * specified vDC.
   *
   * @param vdcUuid the UUID of the vDC
   * @param filters optional query filters
   * @return listing of advanced backup restore task details
   */
  @GET
  @Path("/{vdcUuid}/backup-restore-tasks")
  BackupRestoreTaskListResponse listBackupRestoreTasks(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @BeanParam ListBackupRestoreTasksFilters filters);

  /**
   * Gets detailed recovery task information for a specific advanced backup
   * restore task.
   *
   * @param vdcUuid        the UUID of the vDC
   * @param restoreTaskUid the UID of the restore task to retrieve
   * @return advanced backup restore task details
   */
  @GET
  @Path("/{vdcUuid}/backup-restore-tasks/{restoreTaskUid}")
  BackupRestoreTaskDetailResponse getBackupRestoreTask(
      @SecureEntityRef(Permission.VIEW_ILAND_CLOUD_VDC) @PathParam("vdcUuid")
          String vdcUuid, @PathParam("restoreTaskUid") String restoreTaskUid);

}
