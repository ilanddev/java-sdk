/*
 * Copyright (c) 2023, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within
 *  the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.shared.iaas.backup;

import com.iland.cohesity.sdk.api.model.WormRetentionType;
import com.iland.core.web.rest.annotation.APIModel;

/**
 * Datalock Config.
 *
 * @author <a href="mailto:tspilman@iland.com">Tag Spilman</a>
 */
@APIModel
public interface DatalockConfig {

	/**
	 * Specifies last N days to keep Snapshots under datalock in a protection group.
	 */
	Long daysToKeep();

	/**
	 * Returns the WORM retention type for the snapshots.
	 */
	WormRetentionType wormRetentionType();

}
