/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.intbackup;

/**
 * Enumeration of possible backup states associated with Integrated Backups.
 * {@link IntegratedBackupStatus#PARTIAL_BACKUPS_CONFIGURED} only applies to
 * composite entities (not VMs).
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
public enum IntegratedBackupStatus {

  FULL_BACKUPS_CONFIGURED,

  PARTIAL_BACKUPS_CONFIGURED,

  BACKUPS_NOT_CONFIGURED

}
