/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.response.billing.CurrencyCodeResponse;
import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.serialization.JsonRequired;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * O365 Bill Response.
 *
 * @author <a href="mailto:nkasprzak@iland.com">Nick Kasprzak</a>
 */
@APIDoc
public final class O365BillResponse implements Serializable {

  private static final long serialVersionUID = -8792072283721964952L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The year of the bill.")
  private int year;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The month of the bill.")
  private int month;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The total of the bill.")
  private double total;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The monthly contract cost of the bill.")
  private double fullMonthContractCost;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The currency code of the bill.")
  private CurrencyCodeResponse currencyCode;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Number of licenses.")
  private int numberOfLicenses;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The cost per license of the bill.")
  private double costPerLicense;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The used total including burst usage if any.")
  private double totalCostForUsedLicenses;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Number of licenses exceeded the reserved license count.")
  private int burstCountLicenses;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Licensed user count from licensed user api")
  private int licensedUserCount;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("The used total including burst usage if any for licensed user count.")
  private double totalCostForLicensedUserCount;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  @JsonRequired("Number of licensed users exceeded the reserved license count.")
  private int burstCountForLicensedUserCount;

  public O365BillResponse(final int year, final int month, final double total,
      final double fullMonthContractCost,
      final CurrencyCodeResponse currencyCode, final int numberOfLicenses,
      final double costPerLicense, final double totalCostForUsedLicenses,
      final int burstCountLicenses, final int licensedUserCount,
      final double totalCostForLicensedUserCount,
      final int burstCountForLicensedUserCount) {
    this.year = year;
    this.month = month;
    this.total = total;
    this.fullMonthContractCost = fullMonthContractCost;
    this.currencyCode = currencyCode;
    this.numberOfLicenses = numberOfLicenses;
    this.costPerLicense = costPerLicense;
    this.totalCostForUsedLicenses = totalCostForUsedLicenses;
    this.burstCountLicenses = burstCountLicenses;
    this.licensedUserCount = licensedUserCount;
    this.totalCostForLicensedUserCount = totalCostForLicensedUserCount;
    this.burstCountForLicensedUserCount = burstCountForLicensedUserCount;
  }

  /**
   * Gets year.
   *
   * @return the year
   */
  public int getYear() {
    return year;
  }

  /**
   * Gets month.
   *
   * @return the month
   */
  public int getMonth() {
    return month;
  }

  /**
   * Gets total.
   *
   * @return the total
   */
  public double getTotal() {
    return total;
  }

  /**
   * Gets full month contract cost.
   *
   * @return the full month contract cost
   */
  public double getFullMonthContractCost() {
    return fullMonthContractCost;
  }

  /**
   * Gets currency code.
   *
   * @return the currency code
   */
  public CurrencyCodeResponse getCurrencyCode() {
    return currencyCode;
  }

  /**
   * Gets number of licenses.
   *
   * @return the number of licenses
   */
  public int getNumberOfLicenses() {
    return numberOfLicenses;
  }

  /**
   * Gets cost per license.
   *
   * @return the cost per license
   */
  public double getCostPerLicense() {
    return costPerLicense;
  }

  /**
   * Gets total cost including burst if any.
   *
   * @return the usage total including burst
   */
  public double getTotalCostForUsedLicenses() { return totalCostForUsedLicenses; }

  /**
   * Gets total number of licenses consumed including burst.
   *
   * @return the number of burst licenses
   */
  public int getBurstCountLicenses() { return burstCountLicenses; }

  /**
   * Gets total number of licensed users.
   *
   * @return the the licensed user count
   */
  public int getLicensedUserCount() {
    return licensedUserCount;
  }

  /**
   * Gets total cost including burst if any.
   *
   * @return the usage total including burst
   */
  public double getTotalCostForLicensedUserCount() {
    return totalCostForLicensedUserCount;
  }

  /**
   * Gets total number of licensed users.
   *
   * @return the the licensed user count
   */
  public int getBurstCountForLicensedUserCount() {
    return burstCountForLicensedUserCount;
  }
}
