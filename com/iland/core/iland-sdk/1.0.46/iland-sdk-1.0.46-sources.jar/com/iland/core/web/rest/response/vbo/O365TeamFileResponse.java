/*
 * Copyright (c) 2013 - 2021, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vbo;

import java.time.Instant;
import java.util.Optional;

import com.iland.core.web.rest.annotation.APIModel;

/**
 * O365 Team file response.
 *
 * @author <a href="mailto:smittal@iland.com">Sachin Mittal</a>
 */
@APIModel
public interface O365TeamFileResponse extends O365TeamItemResponse {
  /**
   * The file name.
   */
  String name();

  /**
   * The file size.
   */
  long sizeBytes();

  /**
   * The Version of the file in the backup.
   */
  String version();

  /**
   * The name of the user who performed the latest modification of the file.
   */
  String modifiedBy();

  /**
   * The Date and time of the last modification of the file.
   */
  Instant modified();

  /**
   * The parent folder ID of the sub file/folder.
   */
  Optional<String> parentId();

  /**
   * The Type of the Microsoft Teams File (File, Folder).
   */
  String type();
}