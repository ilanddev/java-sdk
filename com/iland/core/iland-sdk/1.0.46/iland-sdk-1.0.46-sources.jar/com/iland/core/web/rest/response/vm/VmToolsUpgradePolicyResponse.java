/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vm;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * VMware Tools Upgrade Policy Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VmToolsUpgradePolicyResponse implements Serializable {

  private static final long serialVersionUID = -3055709806404760962L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String upgradePolicy;

  public VmToolsUpgradePolicyResponse(final String upgradePolicy) {
    this.upgradePolicy = upgradePolicy;
  }

  /**
   * Get the VMware tools upgrade policy.
   *
   * @return {@link String} upgrade policy: can be either 'manual' or
   * 'upgradeAtPowerCycle'
   */
  public String getUpgradePolicy() {
    return upgradePolicy;
  }

}
