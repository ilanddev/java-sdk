/*
 * Copyright (c) 2013 - 2018, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.vappnetwork;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.Since;

import com.iland.core.web.rest.serialization.ApiVersion;
import com.iland.core.web.rest.swagger.annotation.processor.APIDoc;

/**
 * Vapp Network Ip Translation Nat Rule Response.
 *
 * @author <a href="mailto:bsnyder@iland.com">Brett Snyder</a>
 */
@APIDoc
public class VappNetworkIpTranslationNATRuleResponse implements Serializable {

  private static final long serialVersionUID = 5187889824664369526L;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String mappingMode;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmInterface;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String externalIp;

  @Expose
  @Since(ApiVersion.ONE_DOT_ZERO)
  private final String vmLocalId;

  public VappNetworkIpTranslationNATRuleResponse(final String vmLocalId,
      final String mappingMode, final String vmInterface,
      final String externalIp) {
    this.vmLocalId = vmLocalId;
    this.mappingMode = mappingMode;
    this.vmInterface = vmInterface;
    this.externalIp = externalIp;
  }

  /**
   * Get the mapping mode.
   *
   * @return {@link String} mapping mode
   */
  public String getMappingMode() {
    return mappingMode;
  }

  /**
   * Get the VM interface.
   *
   * @return {@link String} vm interface
   */
  public String getVmInterface() {
    return vmInterface;
  }

  /**
   * Get the external IP address.
   *
   * @return {@link String} external ip
   */
  public String getExternalIp() {
    return externalIp;
  }

  /**
   * Get the associated Vm Uuid.
   *
   * @return {@link String} vm uuid
   */
  public String getVmLocalId() {
    return vmLocalId;
  }

}
