/*
 * Copyright (c) 2013 - 2020, iland Internet Solutions, Corp
 *
 *  This software is licensed under the Terms and Conditions contained within the
 *  "LICENSE.txt" file that accompanied this software. Any inquiries concerning
 *  the scope or enforceability of the license should be addressed to:
 *
 *  iland Internet Solutions, Corp
 *  1235 North Loop West, Suite 800
 *  Houston, TX 77008
 *  USA
 *
 *  http://www.iland.com
 */

package com.iland.core.web.rest.response.iaas.backup;

import java.util.List;

import com.iland.core.web.rest.annotation.APIModel;
import com.iland.core.web.rest.shared.iaas.backup.VdcBackupStorageMetric;

/**
 * BackupStorageSampleSeriesResponse.
 *
 * @author <a href="mailto:csnyder@iland.com">Cory Snyder</a>
 */
@APIModel
public interface VdcBackupStorageSampleSeriesResponse {

  /**
   * The vDC sample metric.
   */
  VdcBackupStorageMetric metric();

  /**
   * Associated location ID.
   */
  String locationId();

  /**
   * Associated company ID.
   */
  String companyId();

  /**
   * Associated org UUID.
   */
  String orgUuid();

  /**
   * Associated vDC UUID.
   */
  String vdcUuid();

  /**
   * Associated backup cluster UID.
   */
  String backupClusterUid();

  /**
   * List of samples.
   */
  List<Sample> samples();

}
